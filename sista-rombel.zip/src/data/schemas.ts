import { SheetSchemaDef } from '../types/schema';
import { MASTER_TABLES_60 } from './masterDatabase60';
import { SEED_MAPEL, SEED_TAHUN_AJARAN, SEED_SEMESTER, SEED_HARI_LIBUR, SEED_TARIF_BIAYA } from './seedMasterData';

export const OFFICIAL_56_SCHEMAS: SheetSchemaDef[] = MASTER_TABLES_60.map((table, index) => ({
  number: index + 1,
  name: table.name,
  category: table.category,
  description: table.description,
  headers: [...table.headers]
}));

export const INITIAL_SAMPLE_DATA: Record<string, any[]> = {
  SETTING: [
    { key: 'appName', value: 'E-Sekolah Terpadu 56' },
    { key: 'tahunAjaranAktif', value: '2026/2027' },
    { key: 'semesterAktif', value: 'Ganjil' },
    { key: 'instansiNama', value: 'Karang Taruna Kecamatan Tambora' }
  ],
  ROLE: [
    { id: 'RL-001', namaRole: 'SUPERADMIN', deskripsi: 'Super Administrator Sistem & Penuh Kontrol', level: '1', createdAt: '2026-01-01' },
    { id: 'RL-002', namaRole: 'ADMIN', deskripsi: 'Administrator Aplikasi & Manajemen Sistem', level: '2', createdAt: '2026-01-01' },
    { id: 'RL-003', namaRole: 'SYSTEM_ADMINISTRATOR', deskripsi: 'Pengelola Infrastruktur & Server Database', level: '2', createdAt: '2026-01-01' },
    { id: 'RL-004', namaRole: 'DEVELOPER', deskripsi: 'Pengembang Aplikasi & Kode Web Script', level: '2', createdAt: '2026-01-01' },
    { id: 'RL-005', namaRole: 'TECHNICAL_SUPPORT', deskripsi: 'Dukungan Teknis Perangkat & Aplikasi', level: '3', createdAt: '2026-01-01' },
    { id: 'RL-006', namaRole: 'KETUA_YAYASAN', deskripsi: 'Pimpinan Tertinggi Yayasan Pendidikan', level: '1', createdAt: '2026-01-01' },
    { id: 'RL-007', namaRole: 'PENGURUS_YAYASAN', deskripsi: 'Pengurus Harian & Manajemen Yayasan', level: '2', createdAt: '2026-01-01' },
    { id: 'RL-008', namaRole: 'PENGAWAS_YAYASAN', deskripsi: 'Tim Audit & Pengawas Internal Yayasan', level: '2', createdAt: '2026-01-01' },
    { id: 'RL-009', namaRole: 'KEPALA_SEKOLAH', deskripsi: 'Pimpinan Unit Sekolah & Penanggung Jawab', level: '2', createdAt: '2026-01-01' },
    { id: 'RL-010', namaRole: 'WAKASEK_KURIKULUM', deskripsi: 'Wakil Kepala Sekolah Bidang Kurikulum', level: '3', createdAt: '2026-01-01' },
    { id: 'RL-011', namaRole: 'WAKASEK_KESISWAAN', deskripsi: 'Wakil Kepala Sekolah Bidang Kesiswaan', level: '3', createdAt: '2026-01-01' },
    { id: 'RL-012', namaRole: 'WAKASEK_SARPRAS', deskripsi: 'Wakil Kepala Sekolah Sarana & Prasarana', level: '3', createdAt: '2026-01-01' },
    { id: 'RL-013', namaRole: 'WAKASEK_HUMAS', deskripsi: 'Wakil Kepala Sekolah Hubungan Masyarakat', level: '3', createdAt: '2026-01-01' },
    { id: 'RL-014', namaRole: 'KTU', deskripsi: 'Kepala Tata Usaha (Administrasi Utama)', level: '3', createdAt: '2026-01-01' },
    { id: 'RL-015', namaRole: 'OPERATOR', deskripsi: 'Operator DAPODIK & Entri Master Data', level: '4', createdAt: '2026-01-01' },
    { id: 'RL-016', namaRole: 'TU', deskripsi: 'Staf Tata Usaha & Surat Menyurat', level: '4', createdAt: '2026-01-01' },
    { id: 'RL-017', namaRole: 'BENDAHARA', deskripsi: 'Bendahara Sekolah & Pengelola Keuangan', level: '3', createdAt: '2026-01-01' },
    { id: 'RL-018', namaRole: 'KASIR', deskripsi: 'Petugas Loket Pembayaran & Tagihan Siswa', level: '4', createdAt: '2026-01-01' },
    { id: 'RL-019', namaRole: 'GURU', deskripsi: 'Tenaga Pendidik & Pengajar Matapelajaran', level: '4', createdAt: '2026-01-01' },
    { id: 'RL-020', namaRole: 'WALI_KELAS', deskripsi: 'Pembimbing & Penanggung Jawab Kelas', level: '4', createdAt: '2026-01-01' },
    { id: 'RL-021', namaRole: 'BK', deskripsi: 'Guru Bimbingan Konseling & Kedisiplinan', level: '4', createdAt: '2026-01-01' },
    { id: 'RL-022', namaRole: 'PUSTAKAWAN', deskripsi: 'Pengelola Perpustakaan & Literasi', level: '4', createdAt: '2026-01-01' },
    { id: 'RL-023', namaRole: 'PETUGAS_UKS', deskripsi: 'Pengelola Kesehatan Sekolah & UKS', level: '4', createdAt: '2026-01-01' },
    { id: 'RL-024', namaRole: 'INVENTARIS', deskripsi: 'Petugas Aset & Logistik Barang', level: '4', createdAt: '2026-01-01' },
    { id: 'RL-025', namaRole: 'ADMIN_CBT', deskripsi: 'Proktor & Administrator Ujian CBT', level: '4', createdAt: '2026-01-01' },
    { id: 'RL-026', namaRole: 'SISWA', deskripsi: 'Peserta Didik Aktif Sekolah', level: '5', createdAt: '2026-01-01' },
    { id: 'RL-027', namaRole: 'ORANG_TUA', deskripsi: 'Orang Tua / Wali Murid Siswa', level: '5', createdAt: '2026-01-01' },
    { id: 'RL-028', namaRole: 'CALON_SISWA', deskripsi: 'Pendaftar PPDB / SPMB Baru', level: '5', createdAt: '2026-01-01' },
    { id: 'RL-029', namaRole: 'ORTU_CALON_SISWA', deskripsi: 'Orang Tua / Wali Calon Pendaftar', level: '5', createdAt: '2026-01-01' },
    { id: 'RL-030', namaRole: 'ALUMNI', deskripsi: 'Lulusan & Peserta Alumni Sekolah', level: '5', createdAt: '2026-01-01' },
    { id: 'RL-031', namaRole: 'VENDOR', deskripsi: 'Mitra Penyedia & Rekanan Sekolah', level: '5', createdAt: '2026-01-01' },
    { id: 'RL-032', namaRole: 'GUEST', deskripsi: 'Pengunjung Umum / Akses Publik', level: '6', createdAt: '2026-01-01' }
  ],
  USERS: [
    { id: 'USR-001', username: 'superadmin', email: 'superadmin@rombel.sch.id', password: '123456', role: 'SUPERADMIN', name: 'Super Administrator Utama', status: 'AKTIF', nopdkt: '-', mustChangePass: '0', createdAt: '2026-01-01', updatedAt: '2026-01-01' },
    { id: 'USR-002', username: 'admin', email: 'admin@rombel.sch.id', password: '123456', role: 'ADMIN', name: 'Administrator Utama', status: 'AKTIF', nopdkt: '-', mustChangePass: '0', createdAt: '2026-01-01', updatedAt: '2026-01-01' }
  ],
  SISWA: [],
  GURU: [],
  KELAS: [],
  ABSENSI: [],
  BIAYA: [],
  TAGIHAN: [],
  BANK_SOAL: [],
  UJIAN: [],
  SPMB_PENDAFTAR: [],
  MENU: [
    { idMenu: 'MN-01', namaMenu: 'Dashboard Utama', icon: 'LayoutDashboard', route: '/dashboard', parentMenu: 'ROOT', urutan: 1, aktif: 'YA' },
    { idMenu: 'MN-02', namaMenu: 'Master Data', icon: 'Database', route: '/master-data', parentMenu: 'ROOT', urutan: 2, aktif: 'YA' },
    { idMenu: 'MN-03', namaMenu: 'SPMB / PPDB Online', icon: 'UserPlus', route: '/spmb', parentMenu: 'ROOT', urutan: 3, aktif: 'YA' },
    { idMenu: 'MN-04', namaMenu: 'Akademik & Presensi', icon: 'GraduationCap', route: '/akademik', parentMenu: 'ROOT', urutan: 4, aktif: 'YA' },
    { idMenu: 'MN-05', namaMenu: 'Ujian Online CBT', icon: 'Laptop', route: '/cbt', parentMenu: 'ROOT', urutan: 5, aktif: 'YA' },
    { idMenu: 'MN-06', namaMenu: 'Penugasan Siswa', icon: 'FileCheck', route: '/penugasan', parentMenu: 'ROOT', urutan: 6, aktif: 'YA' },
    { idMenu: 'MN-07', namaMenu: 'Keuangan & Tagihan', icon: 'CreditCard', route: '/keuangan', parentMenu: 'ROOT', urutan: 7, aktif: 'YA' },
    { idMenu: 'MN-08', namaMenu: 'Bimbingan Konseling', icon: 'HeartHandshake', route: '/bk', parentMenu: 'ROOT', urutan: 8, aktif: 'YA' },
    { idMenu: 'MN-09', namaMenu: 'Inventory & Aset', icon: 'Package', route: '/inventory', parentMenu: 'ROOT', urutan: 9, aktif: 'YA' },
    { idMenu: 'MN-10', namaMenu: 'Dokumen & Surat', icon: 'FolderKanban', route: '/dokumen', parentMenu: 'ROOT', urutan: 10, aktif: 'YA' },
    { idMenu: 'MN-11', namaMenu: 'Laporan & Analytics', icon: 'BarChart3', route: '/laporan', parentMenu: 'ROOT', urutan: 11, aktif: 'YA' },
    { idMenu: 'MN-12', namaMenu: 'Riwayat Audit Log', icon: 'History', route: '/riwayat', parentMenu: 'ROOT', urutan: 12, aktif: 'YA' },
    { idMenu: 'MN-13', namaMenu: 'Pengaturan System', icon: 'Settings', route: '/pengaturan', parentMenu: 'ROOT', urutan: 13, aktif: 'YA' }
  ],
  HAK_AKSES: [
    // 1. SUPERADMIN (All 13 Menus)
    { id: 'HA-001', role: 'SUPERADMIN', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'YA' },
    { id: 'HA-002', role: 'SUPERADMIN', menuId: 'MN-02', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'YA' },
    { id: 'HA-003', role: 'SUPERADMIN', menuId: 'MN-03', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'YA' },
    { id: 'HA-004', role: 'SUPERADMIN', menuId: 'MN-04', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'YA' },
    { id: 'HA-005', role: 'SUPERADMIN', menuId: 'MN-05', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'YA' },
    { id: 'HA-006', role: 'SUPERADMIN', menuId: 'MN-06', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'YA' },
    { id: 'HA-007', role: 'SUPERADMIN', menuId: 'MN-07', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'YA' },
    { id: 'HA-008', role: 'SUPERADMIN', menuId: 'MN-08', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'YA' },
    { id: 'HA-009', role: 'SUPERADMIN', menuId: 'MN-09', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'YA' },
    { id: 'HA-010', role: 'SUPERADMIN', menuId: 'MN-10', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'YA' },
    { id: 'HA-011', role: 'SUPERADMIN', menuId: 'MN-11', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'YA' },
    { id: 'HA-012', role: 'SUPERADMIN', menuId: 'MN-12', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'YA' },
    { id: 'HA-013', role: 'SUPERADMIN', menuId: 'MN-13', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'YA' },

    // 2. ADMIN
    { id: 'HA-014', role: 'ADMIN', menuId: 'MN-ALL', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'YA' },
    // 3. SYSTEM_ADMINISTRATOR
    { id: 'HA-015', role: 'SYSTEM_ADMINISTRATOR', menuId: 'MN-ALL', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'YA' },
    // 4. DEVELOPER
    { id: 'HA-016', role: 'DEVELOPER', menuId: 'MN-ALL', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'YA' },
    // 5. TECHNICAL_SUPPORT
    { id: 'HA-017', role: 'TECHNICAL_SUPPORT', menuId: 'MN-ALL', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'YA' },

    // 6. KETUA_YAYASAN
    { id: 'HA-018', role: 'KETUA_YAYASAN', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-019', role: 'KETUA_YAYASAN', menuId: 'MN-02', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-020', role: 'KETUA_YAYASAN', menuId: 'MN-03', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-021', role: 'KETUA_YAYASAN', menuId: 'MN-04', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-022', role: 'KETUA_YAYASAN', menuId: 'MN-07', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-023', role: 'KETUA_YAYASAN', menuId: 'MN-10', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-024', role: 'KETUA_YAYASAN', menuId: 'MN-11', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-025', role: 'KETUA_YAYASAN', menuId: 'MN-12', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },

    // 7. PENGURUS_YAYASAN
    { id: 'HA-026', role: 'PENGURUS_YAYASAN', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-027', role: 'PENGURUS_YAYASAN', menuId: 'MN-02', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-028', role: 'PENGURUS_YAYASAN', menuId: 'MN-07', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-029', role: 'PENGURUS_YAYASAN', menuId: 'MN-11', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },

    // 8. PENGAWAS_YAYASAN
    { id: 'HA-030', role: 'PENGAWAS_YAYASAN', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-031', role: 'PENGAWAS_YAYASAN', menuId: 'MN-07', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-032', role: 'PENGAWAS_YAYASAN', menuId: 'MN-11', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-033', role: 'PENGAWAS_YAYASAN', menuId: 'MN-12', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },

    // 9. KEPALA_SEKOLAH
    { id: 'HA-034', role: 'KEPALA_SEKOLAH', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-035', role: 'KEPALA_SEKOLAH', menuId: 'MN-02', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-036', role: 'KEPALA_SEKOLAH', menuId: 'MN-03', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-037', role: 'KEPALA_SEKOLAH', menuId: 'MN-04', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-038', role: 'KEPALA_SEKOLAH', menuId: 'MN-07', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-039', role: 'KEPALA_SEKOLAH', menuId: 'MN-10', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-040', role: 'KEPALA_SEKOLAH', menuId: 'MN-11', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-041', role: 'KEPALA_SEKOLAH', menuId: 'MN-12', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-042', role: 'KEPALA_SEKOLAH', menuId: 'MN-13', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },

    // 10. WAKASEK_KURIKULUM
    { id: 'HA-043', role: 'WAKASEK_KURIKULUM', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-044', role: 'WAKASEK_KURIKULUM', menuId: 'MN-02', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-045', role: 'WAKASEK_KURIKULUM', menuId: 'MN-04', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-046', role: 'WAKASEK_KURIKULUM', menuId: 'MN-05', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-047', role: 'WAKASEK_KURIKULUM', menuId: 'MN-06', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-048', role: 'WAKASEK_KURIKULUM', menuId: 'MN-11', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },

    // 11. WAKASEK_KESISWAAN
    { id: 'HA-049', role: 'WAKASEK_KESISWAAN', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-050', role: 'WAKASEK_KESISWAAN', menuId: 'MN-02', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-051', role: 'WAKASEK_KESISWAAN', menuId: 'MN-03', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-052', role: 'WAKASEK_KESISWAAN', menuId: 'MN-04', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-053', role: 'WAKASEK_KESISWAAN', menuId: 'MN-08', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-054', role: 'WAKASEK_KESISWAAN', menuId: 'MN-11', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },

    // 12. WAKASEK_SARPRAS
    { id: 'HA-055', role: 'WAKASEK_SARPRAS', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-056', role: 'WAKASEK_SARPRAS', menuId: 'MN-09', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-057', role: 'WAKASEK_SARPRAS', menuId: 'MN-10', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-058', role: 'WAKASEK_SARPRAS', menuId: 'MN-11', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },

    // 13. WAKASEK_HUMAS
    { id: 'HA-059', role: 'WAKASEK_HUMAS', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-060', role: 'WAKASEK_HUMAS', menuId: 'MN-03', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-061', role: 'WAKASEK_HUMAS', menuId: 'MN-10', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-062', role: 'WAKASEK_HUMAS', menuId: 'MN-11', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },

    // 14. KTU
    { id: 'HA-063', role: 'KTU', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-064', role: 'KTU', menuId: 'MN-02', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-065', role: 'KTU', menuId: 'MN-03', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-066', role: 'KTU', menuId: 'MN-07', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-067', role: 'KTU', menuId: 'MN-09', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-068', role: 'KTU', menuId: 'MN-10', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-069', role: 'KTU', menuId: 'MN-11', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },

    // 15. OPERATOR
    { id: 'HA-070', role: 'OPERATOR', menuId: 'MN-ALL', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'YA' },

    // 16. TU
    { id: 'HA-071', role: 'TU', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-072', role: 'TU', menuId: 'MN-02', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-073', role: 'TU', menuId: 'MN-03', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-074', role: 'TU', menuId: 'MN-09', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-075', role: 'TU', menuId: 'MN-10', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },

    // 17. BENDAHARA
    { id: 'HA-076', role: 'BENDAHARA', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-077', role: 'BENDAHARA', menuId: 'MN-02', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-078', role: 'BENDAHARA', menuId: 'MN-07', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'YA' },
    { id: 'HA-079', role: 'BENDAHARA', menuId: 'MN-11', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },

    // 18. KASIR
    { id: 'HA-080', role: 'KASIR', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-081', role: 'KASIR', menuId: 'MN-07', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-082', role: 'KASIR', menuId: 'MN-11', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },

    // 19. GURU
    { id: 'HA-083', role: 'GURU', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-084', role: 'GURU', menuId: 'MN-04', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-085', role: 'GURU', menuId: 'MN-05', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-086', role: 'GURU', menuId: 'MN-06', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-087', role: 'GURU', menuId: 'MN-08', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-088', role: 'GURU', menuId: 'MN-11', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },

    // 20. WALI_KELAS
    { id: 'HA-089', role: 'WALI_KELAS', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-090', role: 'WALI_KELAS', menuId: 'MN-04', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-091', role: 'WALI_KELAS', menuId: 'MN-05', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-092', role: 'WALI_KELAS', menuId: 'MN-06', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-093', role: 'WALI_KELAS', menuId: 'MN-08', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-094', role: 'WALI_KELAS', menuId: 'MN-11', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },

    // 21. BK
    { id: 'HA-095', role: 'BK', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-096', role: 'BK', menuId: 'MN-04', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-097', role: 'BK', menuId: 'MN-08', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'YA' },
    { id: 'HA-098', role: 'BK', menuId: 'MN-11', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },

    // 22. PUSTAKAWAN
    { id: 'HA-099', role: 'PUSTAKAWAN', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-100', role: 'PUSTAKAWAN', menuId: 'MN-09', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-101', role: 'PUSTAKAWAN', menuId: 'MN-10', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },

    // 23. PETUGAS_UKS
    { id: 'HA-102', role: 'PETUGAS_UKS', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-103', role: 'PETUGAS_UKS', menuId: 'MN-08', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-104', role: 'PETUGAS_UKS', menuId: 'MN-10', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },

    // 24. INVENTARIS
    { id: 'HA-105', role: 'INVENTARIS', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-106', role: 'INVENTARIS', menuId: 'MN-09', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'YA' },
    { id: 'HA-107', role: 'INVENTARIS', menuId: 'MN-10', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-108', role: 'INVENTARIS', menuId: 'MN-11', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },

    // 25. ADMIN_CBT
    { id: 'HA-109', role: 'ADMIN_CBT', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-110', role: 'ADMIN_CBT', menuId: 'MN-04', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-111', role: 'ADMIN_CBT', menuId: 'MN-05', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'YA' },
    { id: 'HA-112', role: 'ADMIN_CBT', menuId: 'MN-11', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },

    // 26. SISWA
    { id: 'HA-113', role: 'SISWA', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-114', role: 'SISWA', menuId: 'MN-04', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-115', role: 'SISWA', menuId: 'MN-05', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-116', role: 'SISWA', menuId: 'MN-06', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-117', role: 'SISWA', menuId: 'MN-07', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-118', role: 'SISWA', menuId: 'MN-08', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },

    // 27. ORANG_TUA
    { id: 'HA-119', role: 'ORANG_TUA', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-120', role: 'ORANG_TUA', menuId: 'MN-04', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-121', role: 'ORANG_TUA', menuId: 'MN-07', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-122', role: 'ORANG_TUA', menuId: 'MN-08', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },

    // 28. ALUMNI
    { id: 'HA-123', role: 'ALUMNI', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-124', role: 'ALUMNI', menuId: 'MN-10', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-125', role: 'ALUMNI', menuId: 'MN-12', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },

    // 29. VENDOR
    { id: 'HA-126', role: 'VENDOR', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-127', role: 'VENDOR', menuId: 'MN-09', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },
    { id: 'HA-128', role: 'VENDOR', menuId: 'MN-10', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },

    // 30. GUEST
    { id: 'HA-129', role: 'GUEST', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-130', role: 'GUEST', menuId: 'MN-03', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },

    // 31. CALON_SISWA
    { id: 'HA-131', role: 'CALON_SISWA', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-132', role: 'CALON_SISWA', menuId: 'MN-03', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' },

    // 32. ORTU_CALON_SISWA
    { id: 'HA-133', role: 'ORTU_CALON_SISWA', menuId: 'MN-01', dapatLihat: 'YA', dapatTambah: 'TIDAK', dapatEdit: 'TIDAK', dapatHapus: 'TIDAK' },
    { id: 'HA-134', role: 'ORTU_CALON_SISWA', menuId: 'MN-03', dapatLihat: 'YA', dapatTambah: 'YA', dapatEdit: 'YA', dapatHapus: 'TIDAK' }
  ],
  LOGS: [],
  AUDIT_LOG: [],
  NOTIFIKASI: [],
  WEB_DOWNLOADS: [],
  WEB_GALLERY: [],
  FORM_FIELDS: [
    { key: 'nama', label: 'Nama Lengkap Pendaftar', type: 'text', grid: '6', required: 'YA', show: 'YA' },
    { key: 'nisn', label: 'NISN (10 Digit)', type: 'text', grid: '6', required: 'YA', show: 'YA' },
    { key: 'nik', label: 'NIK KTP / KIA (16 Digit)', type: 'text', grid: '6', required: 'YA', show: 'YA' },
    { key: 'jk', label: 'Jenis Kelamin', type: 'select', grid: '6', required: 'YA', show: 'YA' },
    { key: 'noHp', label: 'Nomor WhatsApp Aktif', type: 'text', grid: '6', required: 'YA', show: 'YA' }
  ],
  WEB_CONFIG: [
    { appName: 'SISTA ROMBEL 56', judulSidebar: 'E-Sekolah Terpadu', logoUrl: '', heroImageUrl: '', teksHero: 'Selamat Datang di Portal Resmi Sekolah Terpadu', heroBaris1: 'Pendidikan Berkualitas', heroBaris2: 'Berkarakter & Berprestasi', heroSubteks: 'Mewujudkan Generasi Unggul Berteknologi', footerJudul: 'SISTA ROMBEL 56', footerAlamat: 'Jl. Tambora Raya No. 12, Jakarta Barat', footerTelepon: '021-5551234', footerEmail: 'info@rombel.sch.id', footerHakCipta: '© 2026 SISTA ROMBEL 56. All rights reserved.', linkFb: '#', linkIg: '#', linkYt: '#', pendaftaranStatus: 'BUKA', alur1_judul: 'Isi Formulir', alur1_desc: 'Lengkapi 36 kolom biodata pendaftar', alur2_judul: 'Unggah Berkas', alur2_desc: 'Upload KK, Akta, KTP, dan Ijazah', alur3_judul: 'Verifikasi', alur3_desc: 'Panitia mengecek keabsahan dokumen', alur4_judul: 'Pengumuman', alur4_desc: 'Cek status kelulusan secara online' }
  ],
  JENJANG: [],
  MAPEL: SEED_MAPEL,
  TAHUN_AJARAN: SEED_TAHUN_AJARAN,
  SEMESTER: SEED_SEMESTER,
  HARI_LIBUR: SEED_HARI_LIBUR,
  JADWAL: [],
  AGENDA: [],
  NILAI: [],
  RAPOR: [],
  KENAIKAN_KELAS: [],
  KELULUSAN: [],
  ABSENSI_GURU: [],
  QR_LOG: [],
  LOG_UJIAN: [],
  TOKEN: [],
  DRAFT_JAWABAN: [],
  HASIL_UJIAN: [],
  JENIS_UJIAN: [],
  TUGAS: [],
  HASIL_TUGAS: [],
  ANALISIS_SOAL: [],
  TABUNGAN: [],
  KAS: [],
  PENGELUARAN: [],
  INVOICE: [],
  BIMBINGAN: [],
  PELANGGARAN: [],
  BARANG: [],
  PEMELIHARAAN: [],
  PEMINJAMAN_BARANG: [],
  FILE: [],
  ARSIP: [],
  BACKUP: [],
  SUARA_KOMUNITAS: []
};
