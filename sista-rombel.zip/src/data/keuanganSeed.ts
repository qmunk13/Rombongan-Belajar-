import { db } from './db';

export interface KeuanganKelas {
  id: string;
  nama: string;
  wali: string;
  aktif: boolean;
  createdAt?: string;
}

export interface KeuanganBiaya {
  id: string; // BiayaID
  biayaId?: string;
  kodeBiaya?: string;
  nama: string; // NamaBiaya
  namaBiaya?: string;
  kategori?: string; // Iuran Pendidikan, Kegiatan, Seragam, Ujian, Gedung, Modul/Buku, Lainnya
  jenjang?: string; // Semua Jenjang, Paket A, Paket B, Paket C, dll
  targetKelas?: string; // Target_Kelas
  kelasId: string;
  kelasNama: string;
  siswaId?: string; // Target Siswa Khusus (opsional)
  namaSiswa?: string; // Nama Siswa Tertarget (opsional / 'Semua Siswa')
  nominal: number;
  periode?: string; // Bulanan, Semester, Tahunan, Sekali Bayar
  wajib?: 'Wajib' | 'Sukarela' | 'Pilihan' | string;
  aktif: boolean;
  status?: 'AKTIF' | 'NONAKTIF' | string;
  keterangan?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface KeuanganTagihan {
  id: string; // TagihanID
  tagihanId?: string;
  invoiceId?: string;
  siswaId: string;
  namaSiswa: string;
  nis?: string;
  kelasId: string;
  kelasNama: string;
  biayaId: string;
  namaBiaya: string;
  tahunAjaranId?: string;
  semesterId?: string;
  tanggalTagihan?: string;
  tanggalJatuhTempo?: string;
  jatuhTempo: string;
  nominal: number; // sisa tagihan
  nominalAsli: number; // harga dasar / tarif asli
  diskon?: number;
  denda?: number;
  totalTagihan?: number;
  totalBayar?: number;
  paidAmount: number;
  sisaTagihan?: number;
  periode: string;
  status: 'BELUM' | 'SEBAGIAN' | 'LUNAS';
  petugasId?: string;
  paidAt?: string;
  paidBy?: string;
  paymentType?: string;
  createdAt: string;
  updatedAt?: string;
}

export interface KeuanganInvoice {
  id: string; // PembayaranID
  pembayaranId?: string;
  tagihanId?: string;
  invoiceId: string;
  siswaId: string;
  namaSiswa: string;
  kelasId: string;
  namaKelas: string;
  tanggal?: string;
  tglBayar: string;
  nominal?: number;
  total: number;
  metodePembayaran?: string;
  metode: string; // CASH, TRANSFER, TABUNGAN, QRIS
  noReferensi?: string;
  bank?: string;
  petugasId?: string;
  createdBy: string;
  keterangan?: string;
  catatan?: string;
  status: 'PAID' | 'SUKSES' | 'PENDING' | 'BATAL' | string;
  tagihanIds: string[];
  items: {
    namaBiaya: string;
    periode: string;
    nominal: number;
  }[];
  createdAt: string;
  updatedAt?: string;
}

export interface KeuanganTabungan {
  id: string; // TabunganID
  tabunganId?: string;
  siswaId: string;
  namaSiswa: string;
  studentClass?: string;
  tanggal: string;
  jenisTransaksi?: 'SETOR' | 'TARIK' | string;
  jenis: 'SETOR' | 'TARIK';
  debit?: number;
  kredit?: number;
  nominal: number;
  saldo?: number;
  petugasId?: string;
  catatan: string;
  keterangan?: string;
  status?: 'SUKSES' | 'SELESAI' | string;
  createdBy?: string;
  createdAt: string;
  updatedAt?: string;
}

export const DEFAULT_BIAYA_MASTER: KeuanganBiaya[] = [];

// Inisialisasi master data default jika belum ada di database lokal
export function initKeuanganDefaultData(_studentsList?: any[]) {
  // Bersihkan data dummy secara permanen dan jangan membuat dummy baru
}
