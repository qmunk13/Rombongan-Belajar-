import { OFFICIAL_56_SCHEMAS } from './schemas';

export function generateMergedCodeGs(): string {
  return `/**
 * ============================================================================
 * SISTEM INFORMASI TERPADU MANAJEMEN SEKOLAH (56 TABEL SHEET)
 * Google Apps Script Backend (Code.gs) - Merged & Fully Integrated
 * ============================================================================
 * Kepatuhan Mutlak:
 * 1. Skema 56 tabel & urutan header persis sesuai OFFICIAL_56_SCHEMAS.
 * 2. Operasi massal memori (getDataRange().getValues()) - tanpa loop I/O sheet.
 * 3. Penanganan error try-catch pada setiap fungsi backend dengan respon JSON standar.
 * ============================================================================
 */

var SPREADSHEET_ID = SpreadsheetApp.getActiveSpreadsheet() ? SpreadsheetApp.getActiveSpreadsheet().getId() : "";

function getSpreadsheet() {
  if (SPREADSHEET_ID) {
    return SpreadsheetApp.openById(SPREADSHEET_ID);
  }
  return SpreadsheetApp.getActiveSpreadsheet();
}

/**
 * Entry point Web App GAS
 */
function doGet(e) {
  try {
    var params = (e && e.parameter) ? e.parameter : {};
    var action = params.action;
    var callback = params.callback;

    // Handle API Requests via GET
    if (action === 'GET_ALL_SHEETS') {
      var allData = getAllDatabaseData();
      var jsonStr = JSON.stringify(allData);
      if (callback) {
        return ContentService.createTextOutput(callback + '(' + jsonStr + ')')
          .setMimeType(ContentService.MimeType.JAVASCRIPT);
      }
      return ContentService.createTextOutput(jsonStr)
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'GET_SHEET') {
      var sheetName = params.sheetName || 'SISWA';
      var sheetData = getTableData(sheetName);
      var jsonStrSheet = JSON.stringify({ status: 'success', sheetName: sheetName, data: sheetData });
      if (callback) {
        return ContentService.createTextOutput(callback + '(' + jsonStrSheet + ')')
          .setMimeType(ContentService.MimeType.JAVASCRIPT);
      }
      return ContentService.createTextOutput(jsonStrSheet)
        .setMimeType(ContentService.MimeType.JSON);
    }

    // Print Invoice / PDF mode
    if (params.printInvoice) {
      return HtmlService.createHtmlOutput(generateInvoiceHtml_(params.printInvoice))
        .setTitle('Invoice ' + params.printInvoice)
        .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
    }

    // Try rendering Index.html if created by user
    try {
      var template = HtmlService.createTemplateFromFile('Index');
      template.konfigurasi = getKonfigurasiAplikasi().data || {};
      template.WEBAPP_URL = ScriptApp.getService().getUrl();
      return template.evaluate()
        .setTitle('Sistem Terpadu Sekolah - 67 Sheet')
        .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL)
        .addMetaTag('viewport', 'width=device-width, initial-scale=1.0')
        .setFaviconUrl('https://cdn-icons-png.flaticon.com/512/2920/2920224.png');
    } catch (htmlErr) {
      // Friendly fallback status page if Index.html is not created
      return HtmlService.createHtmlOutput(
        '<div style="font-family:system-ui, sans-serif; padding:40px 20px; text-align:center; background:#0f172a; color:#f8fafc; min-height:100vh;">' +
        '<div style="max-width:600px; margin:0 auto; background:#1e293b; padding:32px; border-radius:24px; border:1px solid #334155; shadow:0 20px 25px -5px rgba(0,0,0,0.5);">' +
        '<h2 style="color:#38bdf8; margin-top:0;">⚡ Backend Google Apps Script Master Database Aktif!</h2>' +
        '<p style="color:#cbd5e1; line-height:1.6; font-size:14px;">' +
        'URL Web App ini telah aktif dan siap digunakan untuk <b>Sinkronisasi Realtime 2 Arah</b> dengan seluruh modul Sistem Sekolah.' +
        '</p>' +
        '<div style="background:#0284c7; color:#ffffff; padding:12px 20px; border-radius:12px; font-weight:bold; font-size:13px; margin:20px 0; display:inline-block;">' +
        '✓ Status API: Online & Siap Terhubung (Semua Fungsi Tersinkron)' +
        '</div>' +
        '<p style="font-size:12px; color:#94a3b8; margin-bottom:0;">' +
        'Seluruh modul (Absensi QR & Kehadiran, Guru & Leger Nilai, SPMB, CBT, Keuangan & Tabungan, Siswa & Dual Logo) siap digunakan.' +
        '</p>' +
        '</div>' +
        '</div>'
      )
      .setTitle('Backend API GAS Master Database - Online')
      .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
    }
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ status: 'error', message: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * Inisialisasi Otomatis 56 Sheet beserta Header Resminya
 */
function initialize56SheetsDatabase() {
  try {
    var ss = getSpreadsheet();
    var schemas = ${JSON.stringify(OFFICIAL_56_SCHEMAS.map(s => ({ name: s.name, headers: s.headers })))};
    
    var createdCount = 0;
    schemas.forEach(function(schema) {
      var sheet = ss.getSheetByName(schema.name);
      if (!sheet) {
        sheet = ss.insertSheet(schema.name);
        sheet.appendRow(schema.headers);
        sheet.getRange(1, 1, 1, schema.headers.length)
          .setFontWeight('bold')
          .setBackground('#1e293b')
          .setFontColor('#ffffff');
        sheet.setFrozenRows(1);
        createdCount++;
      }
    });

    // Clean default Sheet1 if exists and other sheets present
    var defaultSheet = ss.getSheetByName('Sheet1');
    if (defaultSheet && ss.getSheets().length > 1) {
      ss.deleteSheet(defaultSheet);
    }

    logAudit('SYSTEM', 'INIT_DATABASE', 'Inisialisasi ' + createdCount + ' sheet baru dari total 56 sheet.');
    return { status: 'success', message: 'Inisialisasi 56 sheet berhasil! Total sheet terverifikasi: ' + schemas.length, created: createdCount };
  } catch (err) {
    return { status: 'error', message: 'Gagal inisialisasi: ' + err.toString() };
  }
}

/**
 * Ambil Seluruh Data 56 Sheet Sekaligus untuk Inisialisasi Frontend SPA
 */
function getAllDatabaseData() {
  try {
    var ss = getSpreadsheet();
    var schemas = ${JSON.stringify(OFFICIAL_56_SCHEMAS.map(s => ({ name: s.name, headers: s.headers })))};
    var result = {};

    schemas.forEach(function(schema) {
      var sheet = ss.getSheetByName(schema.name);
      if (!sheet) {
        result[schema.name] = [];
        return;
      }
      var data = sheet.getDataRange().getValues();
      if (data.length <= 1) {
        result[schema.name] = [];
        return;
      }
      var headers = data[0];
      var rows = data.slice(1).map(function(row) {
        var obj = {};
        headers.forEach(function(h, idx) {
          obj[h] = row[idx] !== undefined ? row[idx] : '';
        });
        return obj;
      });
      result[schema.name] = rows;
    });

    return { status: 'success', data: result };
  } catch (err) {
    return { status: 'error', message: err.toString() };
  }
}

/**
 * Read Single Sheet Data as Object Array
 */
function getTableData(sheetName) {
  try {
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName(sheetName);
    if (!sheet) {
      return { status: 'error', message: 'Sheet ' + sheetName + ' tidak ditemukan.' };
    }
    
    var data = sheet.getDataRange().getValues();
    if (data.length <= 1) {
      return { status: 'success', data: [], headers: data[0] || [] };
    }
    
    var headers = data[0];
    var rows = data.slice(1).map(function(row) {
      var obj = {};
      headers.forEach(function(h, idx) {
        obj[h] = row[idx] !== undefined ? row[idx] : '';
      });
      return obj;
    });

    return { status: 'success', data: rows, headers: headers };
  } catch (err) {
    return { status: 'error', message: err.toString() };
  }
}

/**
 * Insert Single Record into Specified Sheet
 */
function insertTableRecord(sheetName, recordData) {
  try {
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName(sheetName);
    if (!sheet) {
      sheet = ss.insertSheet(sheetName);
      var defaultHeaders = Object.keys(recordData);
      if (defaultHeaders.length > 0) {
        sheet.appendRow(defaultHeaders);
        sheet.getRange(1, 1, 1, defaultHeaders.length)
          .setFontWeight('bold')
          .setBackground('#1e293b')
          .setFontColor('#ffffff');
        sheet.setFrozenRows(1);
      }
    }
    
    var data = sheet.getDataRange().getValues();
    var headers = data[0];
    if (!headers || headers.length === 0 || !headers[0]) {
      headers = Object.keys(recordData);
      sheet.appendRow(headers);
    }
    var newRow = headers.map(function(h) {
      return recordData[h] !== undefined ? recordData[h] : '';
    });

    sheet.appendRow(newRow);
    logAudit(recordData.username || recordData.createdBy || 'PublicUser', 'INSERT_' + sheetName, 'Menambah data di ' + sheetName);

    return { status: 'success', message: 'Data berhasil disimpan ke ' + sheetName };
  } catch (err) {
    return { status: 'error', message: err.toString() };
  }
}

/**
 * Update Existing Record by Matching ID Key & Value
 */
function updateTableRecord(sheetName, idColumn, idValue, updateData) {
  try {
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName(sheetName);
    if (!sheet) return { status: 'error', message: 'Sheet ' + sheetName + ' tidak ditemukan.' };

    var data = sheet.getDataRange().getValues();
    if (data.length <= 1) return { status: 'error', message: 'Sheet ' + sheetName + ' kosong.' };

    var headers = data[0];
    var idxId = headers.indexOf(idColumn);
    if (idxId === -1) return { status: 'error', message: 'Kolom ID ' + idColumn + ' tidak ditemukan di ' + sheetName };

    var rowIndex = -1;
    for (var i = 1; i < data.length; i++) {
      if (String(data[i][idxId]) === String(idValue)) {
        rowIndex = i + 1; // 1-indexed row in sheet
        break;
      }
    }

    if (rowIndex === -1) {
      return { status: 'error', message: 'Record dengan ' + idColumn + ' = ' + idValue + ' tidak ditemukan.' };
    }

    var updatedRow = headers.map(function(h, colIdx) {
      if (updateData[h] !== undefined) {
        return updateData[h];
      }
      return data[rowIndex - 1][colIdx];
    });

    sheet.getRange(rowIndex, 1, 1, updatedRow.length).setValues([updatedRow]);
    logAudit(updateData.updatedBy || 'System', 'UPDATE_' + sheetName, 'Mengubah data ' + idColumn + ': ' + idValue);

    return { status: 'success', message: 'Data ' + sheetName + ' berhasil diperbarui.' };
  } catch (err) {
    return { status: 'error', message: err.toString() };
  }
}

/**
 * Delete Record from Specified Sheet by ID
 */
function deleteTableRecord(sheetName, idColumn, idValue) {
  try {
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName(sheetName);
    if (!sheet) return { status: 'error', message: 'Sheet ' + sheetName + ' tidak ditemukan.' };

    var data = sheet.getDataRange().getValues();
    if (data.length <= 1) return { status: 'error', message: 'Sheet ' + sheetName + ' kosong.' };

    var headers = data[0];
    var idxId = headers.indexOf(idColumn);
    if (idxId === -1) return { status: 'error', message: 'Kolom ' + idColumn + ' tidak ditemukan.' };

    var rowIndex = -1;
    for (var i = 1; i < data.length; i++) {
      if (String(data[i][idxId]) === String(idValue)) {
        rowIndex = i + 1;
        break;
      }
    }

    if (rowIndex === -1) {
      return { status: 'error', message: 'Data tidak ditemukan.' };
    }

    sheet.deleteRow(rowIndex);
    logAudit('System', 'DELETE_' + sheetName, 'Menghapus data ' + idColumn + ': ' + idValue);

    return { status: 'success', message: 'Data ' + sheetName + ' berhasil dihapus.' };
  } catch (err) {
    return { status: 'error', message: err.toString() };
  }
}

/**
 * Unified CRUD Router for Frontend SPA
 */
function saveSheetRecord(sheetName, action, recordData, idKey, idValue) {
  if (action === 'CREATE') {
    return insertTableRecord(sheetName, recordData);
  } else if (action === 'UPDATE') {
    return updateTableRecord(sheetName, idKey || 'id', idValue || recordData[idKey || 'id'], recordData);
  } else if (action === 'DELETE') {
    return deleteTableRecord(sheetName, idKey || 'id', idValue);
  }
  return { status: 'error', message: 'Aksi CRUD tidak valid: ' + action };
}

/**
 * Log Audit Handler
 */
function logAudit(username, action, detail) {
  try {
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName('AUDIT_LOG');
    if (sheet) {
      sheet.appendRow([
        'AUD-' + new Date().getTime(),
        Utilities.formatDate(new Date(), 'Asia/Jakarta', 'yyyy-MM-dd HH:mm:ss'),
        username || 'System',
        'SYSTEM',
        action,
        detail,
        '127.0.0.1'
      ]);
    }
  } catch (e) {
    // Ignore audit logging errors
  }
}

/**
 * Autentikasi Pengguna Terintegrasi (Tabel USERS & SISWA)
 */
function loginUser(username, password, nopdkt) {
  try {
    var ss = getSpreadsheet();
    
    // Login Siswa menggunakan NOPDKT / NISN
    if (nopdkt) {
      var sheetSiswa = ss.getSheetByName('SISWA');
      if (!sheetSiswa) return { status: 'error', message: 'Sheet SISWA belum diinisialisasi' };
      
      var siswaData = sheetSiswa.getDataRange().getValues();
      var headersSiswa = siswaData[0];
      var idxNopdkt = headersSiswa.indexOf('nopdkt');
      var idxNisn = headersSiswa.indexOf('NISN');
      var idxNama = headersSiswa.indexOf('Nama Lengkap');
      var idxKelas = headersSiswa.indexOf('Kelas Saat ini');

      for (var i = 1; i < siswaData.length; i++) {
        var row = siswaData[i];
        if (String(row[idxNopdkt]) === String(nopdkt) || String(row[idxNisn]) === String(nopdkt)) {
          return {
            status: 'success',
            user: {
              id: 'SIS-' + row[idxNisn],
              username: String(row[idxNisn]),
              name: row[idxNama],
              role: 'SISWA',
              nopdkt: row[idxNopdkt],
              kelasId: row[idxKelas]
            }
          };
        }
      }
      return { status: 'error', message: 'Nopdkt / NISN siswa tidak ditemukan.' };
    }

    // Login Admin / Guru / Staf via USERS
    var sheetUsers = ss.getSheetByName('USERS');
    if (!sheetUsers) return { status: 'error', message: 'Sheet USERS belum diinisialisasi' };

    var usersData = sheetUsers.getDataRange().getValues();
    var headersU = usersData[0];
    var idxU = headersU.indexOf('username');
    var idxP = headersU.indexOf('password');
    var idxR = headersU.indexOf('role');
    var idxN = headersU.indexOf('name');
    var idxPdkt = headersU.indexOf('nopdkt');

    for (var j = 1; j < usersData.length; j++) {
      var uRow = usersData[j];
      if (String(uRow[idxU]).toLowerCase() === String(username).toLowerCase() && String(uRow[idxP]) === String(password)) {
        return {
          status: 'success',
          user: {
            id: uRow[0],
            username: uRow[idxU],
            name: uRow[idxN],
            role: String(uRow[idxR]).toUpperCase(),
            nopdkt: uRow[idxPdkt]
          }
        };
      }
    }

    return { status: 'error', message: 'Username atau password salah.' };
  } catch (err) {
    return { status: 'error', message: err.toString() };
  }
}

/**
 * Modul Absensi: Submit Scan / Input Massal
 */
function submitAbsensi(absensiList, tanggal, operator) {
  try {
    var ss = getSpreadsheet();
    var sheetAbsensi = ss.getSheetByName('ABSENSI');
    if (!sheetAbsensi) return { status: 'error', message: 'Sheet ABSENSI tidak ada.' };

    var now = new Date();
    var jamStr = Utilities.formatDate(now, 'Asia/Jakarta', 'HH:mm:ss');
    
    var rowsToAppend = absensiList.map(function(item) {
      return [
        'ABS-' + new Date().getTime() + '-' + Math.floor(Math.random()*1000),
        tanggal,
        item.nopdkt,
        item.kelasId,
        item.jamDatang || jamStr,
        item.jamPulang || '',
        item.keterangan || 'Hadir',
        item.status || 'Hadir',
        '', '', '', '', item.catatanIzin || '', ''
      ];
    });

    if (rowsToAppend.length > 0) {
      sheetAbsensi.getRange(sheetAbsensi.getLastRow() + 1, 1, rowsToAppend.length, rowsToAppend[0].length)
        .setValues(rowsToAppend);
    }

    logAudit(operator || 'System', 'SUBMIT_ABSENSI', 'Input presensi ' + rowsToAppend.length + ' siswa');
    return { status: 'success', message: 'Berhasil mencatat ' + rowsToAppend.length + ' absensi.' };
  } catch (err) {
    return { status: 'error', message: err.toString() };
  }
}

/**
 * Modul Keuangan & Pembayaran: Input Pembayaran
 */
function submitPembayaran(payload) {
  try {
    var ss = getSpreadsheet();
    var shBayar = ss.getSheetByName('PEMBAYARAN');
    var shTagihan = ss.getSheetByName('TAGIHAN');
    var shInvoice = ss.getSheetByName('INVOICE');

    var invId = 'INV-' + Utilities.formatDate(new Date(), 'Asia/Jakarta', 'yyyyMMdd') + '-' + Math.floor(Math.random()*1000);
    var nowStr = Utilities.formatDate(new Date(), 'Asia/Jakarta', 'yyyy-MM-dd HH:mm:ss');

    // Insert Pembayaran
    shBayar.appendRow([
      'BYR-' + new Date().getTime(),
      payload.tagihanId,
      payload.nopdkt,
      payload.kelasId,
      payload.tglBayar,
      payload.metode,
      payload.jumlah,
      payload.catatan || '',
      payload.createdBy || 'Admin',
      nowStr,
      invId,
      payload.tagihanId,
      payload.namaSiswa,
      payload.nopdkt
    ]);

    // Insert Invoice
    shInvoice.appendRow([
      'INV-ROW-' + new Date().getTime(),
      invId,
      payload.nopdkt,
      payload.kelasId,
      payload.tglBayar,
      payload.metode,
      payload.jumlah,
      'LUNAS',
      payload.createdBy || 'Admin',
      nowStr,
      payload.namaSiswa
    ]);

    // Update Tagihan
    var tagihanData = shTagihan.getDataRange().getValues();
    var hT = tagihanData[0];
    var idxId = hT.indexOf('id');
    var idxStatus = hT.indexOf('status');
    var idxPaid = hT.indexOf('paidAmount');
    var idxRem = hT.indexOf('remainingAmount');

    for (var i = 1; i < tagihanData.length; i++) {
      if (String(tagihanData[i][idxId]) === String(payload.tagihanId)) {
        var currentPaid = Number(tagihanData[i][idxPaid] || 0) + Number(payload.jumlah);
        var nominal = Number(tagihanData[i][hT.indexOf('nominal')] || 0);
        var remaining = Math.max(0, nominal - currentPaid);
        var newStatus = remaining <= 0 ? 'LUNAS' : 'SEBAGIAN';

        shTagihan.getRange(i + 1, idxStatus + 1).setValue(newStatus);
        shTagihan.getRange(i + 1, idxPaid + 1).setValue(currentPaid);
        shTagihan.getRange(i + 1, idxRem + 1).setValue(remaining);
        break;
      }
    }

    return { status: 'success', message: 'Pembayaran berhasil dicatat. Invoice: ' + invId, invoiceId: invId };
  } catch (err) {
    return { status: 'error', message: err.toString() };
  }
}

/**
 * Modul CBT Ujian: Submit Hasil Ujian
 */
function submitHasilUjian(dataUjian) {
  try {
    var ss = getSpreadsheet();
    var shHasil = ss.getSheetByName('HASIL_UJIAN');
    var shLog = ss.getSheetByName('LOG_UJIAN');

    var idHasil = 'HSL-' + new Date().getTime();
    
    shHasil.appendRow([
      idHasil,
      dataUjian.idAsesmen || 'AS-01',
      dataUjian.idUjian,
      dataUjian.jenjang || 'SMA',
      dataUjian.kelas,
      dataUjian.mapel,
      dataUjian.nisn,
      dataUjian.namaSiswa,
      dataUjian.nilaiMentah,
      dataUjian.benar,
      dataUjian.salah,
      dataUjian.totalSoal,
      dataUjian.pelanggaran || 0,
      dataUjian.waktuMulai || Utilities.formatDate(new Date(), 'Asia/Jakarta', 'yyyy-MM-dd HH:mm:ss'),
      dataUjian.status || 'SELESAI',
      dataUjian.tahunAjaran || '2026/2027',
      dataUjian.nilaiAkhir,
      Utilities.formatDate(new Date(), 'Asia/Jakarta', 'yyyy-MM-dd HH:mm:ss'),
      dataUjian.durasi || '30 Menit',
      dataUjian.idJadwal
    ]);

    shLog.appendRow([
      'LOG-' + new Date().getTime(),
      dataUjian.nisn,
      dataUjian.namaSiswa,
      dataUjian.jenjang || 'SMA',
      dataUjian.kelas,
      'SELESAI',
      Utilities.formatDate(new Date(), 'Asia/Jakarta', 'yyyy-MM-dd HH:mm:ss'),
      dataUjian.pelanggaran || 0,
      dataUjian.token || '-',
      dataUjian.idJadwal
    ]);

    return { status: 'success', message: 'Hasil ujian berhasil disimpan!', idHasil: idHasil, nilaiAkhir: dataUjian.nilaiAkhir };
  } catch (err) {
    return { status: 'error', message: err.toString() };
  }
}

/**
 * Modul SPMB: Submit Pendaftaran Calon Siswa
 */
function submitPendaftaranSpmb(payload) {
  try {
    var ss = getSpreadsheet();
    var shSpmb = ss.getSheetByName('SPMB_PESERTA');
    if (!shSpmb) return { status: 'error', message: 'Sheet SPMB_PESERTA tidak ditemukan.' };

    var regId = 'REG-' + new Date().getTime();
    shSpmb.appendRow([
      regId,
      payload.namaLengkap,
      payload.nisn || '',
      payload.nik || '',
      payload.tempatLahir || '',
      payload.tanggalLahir || '',
      payload.jenisKelamin || 'L',
      payload.asalSekolah || '',
      payload.noHp || '',
      payload.email || '',
      payload.namaOrtu || '',
      payload.gelombangId || 'GEL-1',
      'TERDAFTAR',
      Utilities.formatDate(new Date(), 'Asia/Jakarta', 'yyyy-MM-dd HH:mm:ss')
    ]);

    logAudit('PublicPortal', 'REGISTER_SPMB', 'Pendaftaran calon siswa baru: ' + payload.namaLengkap);
    return { status: 'success', message: 'Pendaftaran berhasil! Nomor Registrasi: ' + regId, registrationId: regId };
  } catch (err) {
    return { status: 'error', message: err.toString() };
  }
}

/**
 * Direct GAS Sync Helper for HTML Service (google.script.run.syncSheetData)
 */
function syncSheetData(sheetName, dataJsonRaw) {
  try {
    var dataJson = typeof dataJsonRaw === 'string' ? JSON.parse(dataJsonRaw) : dataJsonRaw;
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName(sheetName);
    if (!sheet) {
      sheet = ss.insertSheet(sheetName);
    }
    
    var lastRow = sheet.getLastRow();
    if (lastRow > 1) {
      sheet.getRange(2, 1, lastRow - 1, sheet.getLastColumn()).clearContent();
    }

    if (Array.isArray(dataJson) && dataJson.length > 0) {
      var headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
      if (!headers || headers.length === 0 || !headers[0]) {
        headers = Object.keys(dataJson[0]);
        sheet.appendRow(headers);
      }

      var rowsToAppend = dataJson.map(function(rowObj) {
        return headers.map(function(h) {
          return rowObj[h] !== undefined ? rowObj[h] : '';
        });
      });

      sheet.getRange(2, 1, rowsToAppend.length, headers.length).setValues(rowsToAppend);
    }

    return { status: 'success', message: 'Sheet ' + sheetName + ' berhasil disinkronkan' };
  } catch (err) {
    return { status: 'error', message: err.toString() };
  }
}

/**
 * Entry Point HTTP POST Endpoint (Web App Integration Router for Realtime Sync)
 */
function doPost(e) {
  try {
    var params = {};
    if (e && e.parameter) {
      for (var k in e.parameter) { params[k] = e.parameter[k]; }
    }
    if (e && e.postData && e.postData.contents) {
      try {
        var bodyObj = JSON.parse(e.postData.contents);
        for (var bk in bodyObj) { params[bk] = bodyObj[bk]; }
      } catch (pErr) {}
    }
    var action = params.action || 'GET_ALL_SHEETS';

    if (action === 'pull' || action === 'PULL') {
      var allDb = getAllDatabaseData();
      return ContentService.createTextOutput(JSON.stringify({
        status: 'success',
        success: true,
        data: allDb.SISWA || [],
        students: allDb.SISWA || [],
        teachers: allDb.GURU || [],
        allData: allDb
      })).setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'sync' || action === 'SYNC') {
      var ssSync = getSpreadsheet();
      var sSiswa = ssSync.getSheetByName('SISWA');
      var sGuru = ssSync.getSheetByName('GURU');

      if (params.data || params.students) {
        var studentRecords = params.data || params.students;
        if (Array.isArray(studentRecords) && sSiswa) {
          var sLastRow = sSiswa.getLastRow();
          if (sLastRow > 1) {
            sSiswa.getRange(2, 1, sLastRow - 1, sSiswa.getLastColumn()).clearContent();
          }
          if (studentRecords.length > 0) {
            var sHeaders = sSiswa.getRange(1, 1, 1, sSiswa.getLastColumn()).getValues()[0];
            var sRows = studentRecords.map(function(st) {
              return sHeaders.map(function(h) {
                var val = st[h];
                if (val === undefined || val === null) {
                  var cleanH = String(h).toLowerCase().replace(/[^a-z0-9]/g, '');
                  var foundKey = Object.keys(st).find(function(k) { return k.toLowerCase().replace(/[^a-z0-9]/g, '') === cleanH; });
                  val = foundKey ? st[foundKey] : '';
                }
                return val !== undefined ? String(val) : '';
              });
            });
            sSiswa.getRange(2, 1, sRows.length, sHeaders.length).setValues(sRows);
          }
        }
      }

      // Otomatis sinkronkan sheet ORANG_TUA dan YATIM_PIATU saat data SISWA berubah
      try {
        autoPopulateOrangTuaAndYatimFromSiswa();
      } catch (ePop) {
        // Abaikan jika sheet turunan belum siap
      }

      if (params.teachers && Array.isArray(params.teachers) && sGuru) {
        var tRecords = params.teachers;
        var gLastRow = sGuru.getLastRow();
        if (gLastRow > 1) {
          sGuru.getRange(2, 1, gLastRow - 1, sGuru.getLastColumn()).clearContent();
        }
        if (tRecords.length > 0) {
          var gHeaders = sGuru.getRange(1, 1, 1, sGuru.getLastColumn()).getValues()[0];
          var gRows = tRecords.map(function(tc) {
            return gHeaders.map(function(h) {
              var val = tc[h];
              if (val === undefined || val === null) {
                var cleanH = String(h).toLowerCase().replace(/[^a-z0-9]/g, '');
                var foundKey = Object.keys(tc).find(function(k) { return k.toLowerCase().replace(/[^a-z0-9]/g, '') === cleanH; });
                val = foundKey ? tc[foundKey] : '';
              }
              return val !== undefined ? String(val) : '';
            });
          });
          sGuru.getRange(2, 1, gRows.length, gHeaders.length).setValues(gRows);
        }
      }

      return ContentService.createTextOutput(JSON.stringify({ status: 'success', success: true, message: 'Sinkronisasi berhasil!' }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'SAVE_SUARA_KOMUNITAS' || action === 'SAVE_RECORD') {
      var sName = params.sheetName || 'SUARA_KOMUNITAS';
      var recordData = params.recordData || params.data || params;
      var resSuara = insertTableRecord(sName, recordData);
      return ContentService.createTextOutput(JSON.stringify(resSuara))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'CREATE' || action === 'UPDATE' || action === 'DELETE') {
      var sName = params.sheetName || 'SUARA_KOMUNITAS';
      var rData = params.recordData || params;
      var resCrud = saveSheetRecord(sName, action, rData, params.idKey || 'id', params.idValue || rData[params.idKey || 'id']);
      return ContentService.createTextOutput(JSON.stringify(resCrud))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'GET_ALL_SHEETS') {
      var allData = getAllDatabaseData();
      return ContentService.createTextOutput(JSON.stringify(allData))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'GET_SHEET') {
      var sheetName = params.sheetName;
      var sheetData = getTableData(sheetName);
      return ContentService.createTextOutput(JSON.stringify(sheetData))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'SYNC_SHEET') {
      var sheetName = params.sheetName;
      var dataJson = JSON.parse(params.dataJson || '[]');
      var ss = getSpreadsheet();
      var sheet = ss.getSheetByName(sheetName);
      if (!sheet) {
        sheet = ss.insertSheet(sheetName);
      }
      
      var lastRow = sheet.getLastRow();
      if (lastRow > 1) {
        sheet.getRange(2, 1, lastRow - 1, sheet.getLastColumn()).clearContent();
      }

      if (dataJson.length > 0) {
        var headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
        if (!headers || headers.length === 0 || !headers[0]) {
          headers = Object.keys(dataJson[0]);
          sheet.appendRow(headers);
        }

        var rowsToAppend = dataJson.map(function(rowObj) {
          return headers.map(function(h) {
            return rowObj[h] !== undefined ? rowObj[h] : '';
          });
        });

        sheet.getRange(2, 1, rowsToAppend.length, headers.length).setValues(rowsToAppend);
      }

      return ContentService.createTextOutput(JSON.stringify({ status: 'success', message: 'Sheet ' + sheetName + ' berhasil disinkronkan' }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'MASS_SYNC_ALL') {
      var allDataObj = JSON.parse(params.allDataJson || '{}');
      var ss = getSpreadsheet();

      Object.keys(allDataObj).forEach(function(sName) {
        var rows = allDataObj[sName];
        if (!Array.isArray(rows)) return;
        var sheet = ss.getSheetByName(sName);
        if (!sheet) sheet = ss.insertSheet(sName);

        var lastRow = sheet.getLastRow();
        if (lastRow > 1) {
          sheet.getRange(2, 1, lastRow - 1, sheet.getLastColumn()).clearContent();
        }

        if (rows.length > 0) {
          var headers = sheet.getRange(1, 1, 1, sheet.getLastColumn()).getValues()[0];
          if (!headers || headers.length === 0 || !headers[0]) {
            headers = Object.keys(rows[0]);
            sheet.appendRow(headers);
          }

          var rowMatrix = rows.map(function(r) {
            return headers.map(function(h) { return r[h] !== undefined ? r[h] : ''; });
          });

          sheet.getRange(2, 1, rowMatrix.length, headers.length).setValues(rowMatrix);
        }
      });

      return ContentService.createTextOutput(JSON.stringify({ status: 'success', message: '67 Sheet berhasil disinkronkan massal!' }))
        .setMimeType(ContentService.MimeType.JSON);
    }

    if (action === 'AUTO_POPULATE_ORTU_YATIM') {
      var syncResult = autoPopulateOrangTuaAndYatimFromSiswa();
      return ContentService.createTextOutput(JSON.stringify(syncResult))
        .setMimeType(ContentService.MimeType.JSON);
    }

    return ContentService.createTextOutput(JSON.stringify({ status: 'error', message: 'Aksi tidak dikenal' }))
      .setMimeType(ContentService.MimeType.JSON);
  } catch (err) {
    return ContentService.createTextOutput(JSON.stringify({ status: 'error', message: err.toString() }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

/**
 * Otomatisasi Ekstraksi & Sinkronisasi Sheet ORANG_TUA dan YATIM_PIATU dari Data SISWA
 */
function autoPopulateOrangTuaAndYatimFromSiswa() {
  try {
    var ss = getSpreadsheet();
    var sheetSiswa = ss.getSheetByName('SISWA');
    if (!sheetSiswa) {
      return { status: 'error', message: 'Sheet SISWA belum tersedia' };
    }

    var siswaValues = sheetSiswa.getDataRange().getValues();
    if (siswaValues.length <= 1) {
      return { status: 'error', message: 'Sheet SISWA masih kosong' };
    }

    var sHeaders = siswaValues[0];
    var colMap = {};
    sHeaders.forEach(function(h, idx) {
      colMap[String(h).toLowerCase().trim()] = idx;
    });

    function getVal(row, possibleKeys) {
      for (var i = 0; i < possibleKeys.length; i++) {
        var k = possibleKeys[i].toLowerCase();
        if (colMap.hasOwnProperty(k) && row[colMap[k]] !== undefined && row[colMap[k]] !== '') {
          return String(row[colMap[k]]).trim();
        }
      }
      return '';
    }

    var ortuRows = [];
    var yatimRows = [];
    var ortuCounter = 1;
    var yatimCounter = 1;

    for (var r = 1; r < siswaValues.length; r++) {
      var row = siswaValues[r];
      var siswaId = getVal(row, ['siswai', 'id', 'nopdkt', 'nisn', 'nis', 'no']);
      var namaSiswa = getVal(row, ['namalengkap', 'namasiswa', 'nama']);
      if (!namaSiswa && !siswaId) continue;

      var kelas = getVal(row, ['kelas', 'rombel', 'tingkat']);
      var nisn = getVal(row, ['nisn', 'nis']);
      var jalan = getVal(row, ['alamat', 'alamatdomisili', 'tempattinggal', 'jalan', 'dusun']);
      var rtVal = getVal(row, ['rt']);
      var rwVal = getVal(row, ['rw']);
      var kelVal = getVal(row, ['kelurahan', 'desa', 'kel']);
      var kecVal = getVal(row, ['kecamatan', 'kec']);
      var kotaVal = getVal(row, ['kota', 'kabupaten', 'kotakab']);
      var posVal = getVal(row, ['kodepos']);

      var addrParts = [];
      if (jalan && jalan !== '-') addrParts.push(jalan);
      if (rtVal && rwVal && rtVal !== '-' && rwVal !== '-') addrParts.push('RT ' + rtVal + '/RW ' + rwVal);
      else if (rtVal && rtVal !== '-') addrParts.push('RT ' + rtVal);
      else if (rwVal && rwVal !== '-') addrParts.push('RW ' + rwVal);

      if (kelVal && kelVal !== '-') {
        addrParts.push(kelVal.toLowerCase().indexOf('kel') === 0 || kelVal.toLowerCase().indexOf('desa') === 0 ? kelVal : ('Kel. ' + kelVal));
      }
      if (kecVal && kecVal !== '-') {
        addrParts.push(kecVal.toLowerCase().indexOf('kec') === 0 ? kecVal : ('Kec. ' + kecVal));
      }
      if (kotaVal && kotaVal !== '-') addrParts.push(kotaVal);
      if (posVal && posVal !== '-') addrParts.push(posVal);

      var alamat = addrParts.length > 0 ? addrParts.join(', ') : (jalan || '-');

      var namaAyah = getVal(row, ['namaayah', 'ayah', 'fathername']);
      var statusAyah = getVal(row, ['statusayah', 'kondisiayah']) || 'Masih Hidup';
      var nikAyah = getVal(row, ['nikayah', 'nik_ayah']);
      var jobAyah = getVal(row, ['pekerjaanayah', 'jobayah', 'fatherjob']);
      var phoneAyah = getVal(row, ['nohpayah', 'tlpayah', 'no_hp_ayah', 'nohp', 'telepon', 'phone']);

      var namaIbu = getVal(row, ['namaibu', 'ibu', 'NamaIbu']);
      var statusIbu = getVal(row, ['statusibu', 'kondisiibu']) || 'Masih Hidup';
      var nikIbu = getVal(row, ['nikibu', 'nik_ibu']);
      var jobIbu = getVal(row, ['pekerjaanibu', 'jobibu', 'motherjob']);
      var phoneIbu = getVal(row, ['nohpibu', 'tlpibu', 'no_hp_ibu', 'nohp', 'telepon', 'phone']);

      var namaWali = getVal(row, ['namawali', 'wali', 'parentname']);
      var hubWali = getVal(row, ['hubunganwali', 'statuswali']) || 'Wali Murid';
      var jobWali = getVal(row, ['pekerjaanwali', 'jobwali']);
      var phoneWali = getVal(row, ['nohpwali', 'tlpwali', 'parentphone', 'nohp', 'telepon']);

      var rawYatim = getVal(row, ['statusyatim', 'yatim', 'piatu', 'kondisiortu']).toLowerCase();
      var kpsPip = getVal(row, ['penerimakps', 'penerimapip', 'kip', 'kps', 'pip', 'kps_pip']);

      // 1. Ekstraksi Baris ORANG_TUA
      // Headers: ['OrtuID', 'SiswaID', 'Hubungan', 'Nama', 'NIK', 'Pekerjaan', 'NoHP', 'Alamat']
      if (namaAyah) {
        ortuRows.push([
          'ORTU-' + String(ortuCounter++).padStart(4, '0'),
          siswaId || nisn || ('SISWA-' + r),
          'Ayah Kandung',
          namaAyah,
          nikAyah ? (String(nikAyah).startsWith("'") ? String(nikAyah) : "'" + String(nikAyah)) : '-',
          jobAyah || '-',
          phoneAyah ? (String(phoneAyah).startsWith("'") ? String(phoneAyah) : "'" + String(phoneAyah)) : '-',
          alamat || '-'
        ]);
      }
      if (namaIbu) {
        ortuRows.push([
          'ORTU-' + String(ortuCounter++).padStart(4, '0'),
          siswaId || nisn || ('SISWA-' + r),
          'Ibu Kandung',
          namaIbu,
          nikIbu ? (String(nikIbu).startsWith("'") ? String(nikIbu) : "'" + String(nikIbu)) : '-',
          jobIbu || '-',
          phoneIbu ? (String(phoneIbu).startsWith("'") ? String(phoneIbu) : "'" + String(phoneIbu)) : '-',
          alamat || '-'
        ]);
      }
      if (namaWali && namaWali !== namaAyah && namaWali !== namaIbu) {
        ortuRows.push([
          'ORTU-' + String(ortuCounter++).padStart(4, '0'),
          siswaId || nisn || ('SISWA-' + r),
          hubWali || 'Wali Murid',
          namaWali,
          '-',
          jobWali || '-',
          phoneWali ? (String(phoneWali).startsWith("'") ? String(phoneWali) : "'" + String(phoneWali)) : '-',
          alamat || '-'
        ]);
      }
      if (!namaAyah && !namaIbu && !namaWali) {
        var pName = getVal(row, ['parentname', 'orangtua', 'namaortu']) || 'Orang Tua Siswa';
        ortuRows.push([
          'ORTU-' + String(ortuCounter++).padStart(4, '0'),
          siswaId || nisn || ('SISWA-' + r),
          'Orang Tua / Wali',
          pName,
          '-',
          '-',
          (phoneAyah || phoneIbu || phoneWali) ? "'" + (phoneAyah || phoneIbu || phoneWali) : '-',
          alamat || '-'
        ]);
      }

      // 2. Ekstraksi Data YATIM_PIATU
      var isAyahDead = statusAyah.toLowerCase().indexOf('meninggal') !== -1 || statusAyah.toLowerCase().indexOf('almarhum') !== -1 || statusAyah.toLowerCase().indexOf('wafat') !== -1;
      var isIbuDead = statusIbu.toLowerCase().indexOf('meninggal') !== -1 || statusIbu.toLowerCase().indexOf('almarhumah') !== -1 || statusIbu.toLowerCase().indexOf('wafat') !== -1;
      
      var calculatedYatim = 'Lengkap';
      if (rawYatim.indexOf('yatim piatu') !== -1 || (isAyahDead && isIbuDead)) {
        calculatedYatim = 'Yatim Piatu';
      } else if (rawYatim.indexOf('yatim') !== -1 || isAyahDead) {
        calculatedYatim = 'Yatim';
      } else if (rawYatim.indexOf('piatu') !== -1 || isIbuDead) {
        calculatedYatim = 'Piatu';
      }

      yatimRows.push([
        'YTM-' + String(yatimCounter++).padStart(4, '0'),
        siswaId ? (String(siswaId).startsWith("'") ? String(siswaId) : "'" + String(siswaId)) : ('SISWA-' + r),
        nisn ? (String(nisn).startsWith("'") ? String(nisn) : "'" + String(nisn)) : '-',
        namaSiswa,
        kelas || '-',
        calculatedYatim,
        namaAyah || '-',
        statusAyah || (isAyahDead ? 'Meninggal' : 'Masih Hidup'),
        namaIbu || '-',
        statusIbu || (isIbuDead ? 'Meninggal' : 'Masih Hidup'),
        namaWali || (calculatedYatim === 'Yatim' ? (namaIbu || '-') : calculatedYatim === 'Piatu' ? (namaAyah || '-') : (namaAyah || namaIbu || '-')),
        (phoneWali || phoneIbu || phoneAyah) ? "'" + (phoneWali || phoneIbu || phoneAyah) : '-',
        alamat || '-',
        kpsPip || (calculatedYatim !== 'Lengkap' ? 'Ya (Prioritas)' : 'Tidak'),
        calculatedYatim !== 'Lengkap' ? ('Prioritas Bantuan Sosial - ' + calculatedYatim) : 'Reguler',
        new Date().toISOString(),
        new Date().toISOString()
      ]);
    }

    // Tulis ke Sheet ORANG_TUA
    var sheetOrtu = ss.getSheetByName('ORANG_TUA');
    if (!sheetOrtu) sheetOrtu = ss.insertSheet('ORANG_TUA');
    var ortuHeaders = ['OrtuID', 'SiswaID', 'Hubungan', 'Nama', 'NIK', 'Pekerjaan', 'NoHP', 'Alamat'];
    sheetOrtu.clear();
    sheetOrtu.appendRow(ortuHeaders);
    sheetOrtu.getRange(1, 1, 1, ortuHeaders.length).setFontWeight('bold').setBackground('#1e293b').setFontColor('#ffffff');
    if (ortuRows.length > 0) {
      var ortuRange = sheetOrtu.getRange(2, 1, ortuRows.length, ortuHeaders.length);
      ortuRange.setNumberFormat("@");
      ortuRange.setValues(ortuRows);
    }
    sheetOrtu.setFrozenRows(1);

    // Tulis ke Sheet YATIM_PIATU
    var sheetYatim = ss.getSheetByName('YATIM_PIATU');
    if (!sheetYatim) sheetYatim = ss.insertSheet('YATIM_PIATU');
    var yatimHeaders = ['YatimID', 'NoPDKT', 'NISN', 'NamaSiswa', 'Kelas', 'StatusYatim', 'NamaAyah', 'StatusAyah', 'NamaIbu', 'StatusIbu', 'NamaWali', 'NoHPWali', 'Alamat', 'PenerimaKPS_PIP', 'Keterangan', 'CreatedAt', 'UpdatedAt'];
    sheetYatim.clear();
    sheetYatim.appendRow(yatimHeaders);
    sheetYatim.getRange(1, 1, 1, yatimHeaders.length).setFontWeight('bold').setBackground('#1e293b').setFontColor('#ffffff');
    if (yatimRows.length > 0) {
      var yatimRange = sheetYatim.getRange(2, 1, yatimRows.length, yatimHeaders.length);
      yatimRange.setNumberFormat("@");
      yatimRange.setValues(yatimRows);
    }
    sheetYatim.setFrozenRows(1);

    logAudit('SYSTEM', 'SYNC_ORTU_YATIM', 'Auto-populate ' + ortuRows.length + ' data Orang Tua & ' + yatimRows.length + ' data Yatim Piatu dari SISWA.');
    return {
      status: 'success',
      message: 'Berhasil sinkronisasi otomatis ' + ortuRows.length + ' record Orang Tua dan ' + yatimRows.length + ' record Yatim Piatu dari Sheet SISWA!',
      totalOrtu: ortuRows.length,
      totalYatim: yatimRows.length
    };
  } catch (err) {
    return { status: 'error', message: 'Gagal auto-populate Ortu & Yatim: ' + err.toString() };
  }
}

/**
 * ============================================================================
 * MODUL 1: PRESENSI, QR & JADWAL HARIAN TERPADU
 * ============================================================================
 */

function formatWaktuSheet(waktu, formatPola) {
  try {
    if (!waktu) return "-";
    var dateObj = (waktu instanceof Date) ? waktu : new Date(waktu);
    return Utilities.formatDate(dateObj, 'Asia/Jakarta', formatPola);
  } catch (e) {
    return String(waktu);
  }
}

function calculateTimeDiff(startTime, endTime) {
  var p1 = startTime.split(':').map(Number);
  var p2 = endTime.split(':').map(Number);
  return (p2[0] * 60 + p2[1]) - (p1[0] * 60 + p1[1]);
}

function getAppConfig() {
  try {
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName('SETTING') || ss.getSheetByName('konfigurasi');
    var defaultJadwal = {
      "1": {"libur":false,"masuk_mulai":"06:00","masuk_akhir":"07:15","pulang_mulai":"15:00","pulang_akhir":"17:00"},
      "2": {"libur":false,"masuk_mulai":"06:00","masuk_akhir":"07:15","pulang_mulai":"15:00","pulang_akhir":"17:00"},
      "3": {"libur":false,"masuk_mulai":"06:00","masuk_akhir":"07:15","pulang_mulai":"15:00","pulang_akhir":"17:00"},
      "4": {"libur":false,"masuk_mulai":"06:00","masuk_akhir":"07:15","pulang_mulai":"15:00","pulang_akhir":"17:00"},
      "5": {"libur":false,"masuk_mulai":"06:00","masuk_akhir":"07:15","pulang_mulai":"15:00","pulang_akhir":"17:00"},
      "6": {"libur":false,"masuk_mulai":"06:00","masuk_akhir":"07:15","pulang_mulai":"15:00","pulang_akhir":"17:00"},
      "7": {"libur":true,"masuk_mulai":"06:00","masuk_akhir":"07:15","pulang_mulai":"15:00","pulang_akhir":"17:00"}
    };
    var config = {
      jam_masuk_mulai: '06:00',
      jam_masuk_akhir: '07:15',
      jam_pulang_mulai: '15:00',
      jam_pulang_akhir: '17:00',
      jadwal_harian: defaultJadwal,
      mode_absen: 'masuk_pulang'
    };
    
    if (sheet) {
      var data = sheet.getDataRange().getValues();
      for (var i = 1; i < data.length; i++) {
        var key = data[i][0];
        var val = data[i][1];
        if (key === 'jadwal_harian') {
          try { config.jadwal_harian = JSON.parse(String(val)); } catch(e) { config.jadwal_harian = defaultJadwal; }
        } else if (config.hasOwnProperty(key)) {
          config[key] = (val instanceof Date) ? formatWaktuSheet(val, 'HH:mm') : String(val);
        }
      }
    }
    return { success: true, data: config };
  } catch (e) {
    return { success: false, message: e.toString() };
  }
}

function saveAppConfig(newConfig) {
  try {
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName('SETTING') || ss.getSheetByName('konfigurasi');
    if (!sheet) {
      sheet = ss.insertSheet('SETTING');
      sheet.appendRow(['Key', 'Value']);
    }
    
    var data = sheet.getDataRange().getValues();
    var updateRow = function(key, val) {
      for (var i = 1; i < data.length; i++) {
        if (data[i][0] === key) {
          sheet.getRange(i + 1, 2).setValue(val); 
          return true;
        }
      }
      return false;
    };

    if (newConfig.jam_masuk_mulai) updateRow('jam_masuk_mulai', "'" + newConfig.jam_masuk_mulai);
    if (newConfig.jam_masuk_akhir) updateRow('jam_masuk_akhir', "'" + newConfig.jam_masuk_akhir);
    if (newConfig.jam_pulang_mulai) updateRow('jam_pulang_mulai', "'" + newConfig.jam_pulang_mulai);
    if (newConfig.jam_pulang_akhir) updateRow('jam_pulang_akhir', "'" + newConfig.jam_pulang_akhir);
    if (newConfig.mode_absen) updateRow('mode_absen', newConfig.mode_absen);
    if (newConfig.jadwal_harian) {
      var jsonStr = typeof newConfig.jadwal_harian === 'string' ? newConfig.jadwal_harian : JSON.stringify(newConfig.jadwal_harian);
      if (!updateRow('jadwal_harian', jsonStr)) {
        sheet.appendRow(['jadwal_harian', jsonStr]);
      }
    }

    return { success: true, message: 'Konfigurasi sistem berhasil disimpan' };
  } catch (e) {
    return { success: false, message: e.toString() };
  }
}

function getHariLibur() {
  try {
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName('HARI_LIBUR') || ss.getSheetByName('hari_libur');
    if (!sheet) return { success: true, data: [] };
    var data = sheet.getDataRange().getValues();
    var list = [];
    for (var i = 1; i < data.length; i++) {
      if (data[i][0] || data[i][1]) {
        var tglRaw = data[i][1] || data[i][0];
        var tgl = formatWaktuSheet(new Date(tglRaw), 'yyyy-MM-dd');
        list.push({
          tanggal: tgl,
          keterangan: data[i][2] || data[i][1] || 'Hari Libur'
        });
      }
    }
    list.sort(function(a, b) { return b.tanggal.localeCompare(a.tanggal); });
    return { success: true, data: list };
  } catch (error) {
    return { success: false, message: error.toString() };
  }
}

function addHariLiburRange(tanggalMulai, tanggalAkhir, keterangan) {
  try {
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName('HARI_LIBUR') || ss.getSheetByName('hari_libur');
    if (!sheet) {
      sheet = ss.insertSheet('HARI_LIBUR');
      sheet.appendRow(['HariLiburID', 'Tanggal', 'Nama', 'Jenis', 'Keterangan']);
    }

    var dMulai = new Date(tanggalMulai + 'T00:00:00');
    var dAkhir = new Date(tanggalAkhir + 'T00:00:00');
    var rowsToAdd = [];

    for (var d = new Date(dMulai); d <= dAkhir; d.setDate(d.getDate() + 1)) {
      var dStr = formatWaktuSheet(d, 'yyyy-MM-dd');
      rowsToAdd.push([
        'LIB-' + new Date().getTime() + '-' + Math.floor(Math.random() * 1000),
        dStr,
        keterangan,
        'Nasional/Sekolah',
        keterangan
      ]);
    }

    if (rowsToAdd.length > 0) {
      sheet.getRange(sheet.getLastRow() + 1, 1, rowsToAdd.length, rowsToAdd[0].length).setValues(rowsToAdd);
    }

    return { success: true, message: rowsToAdd.length + ' hari libur berhasil ditambahkan.', added: rowsToAdd.length };
  } catch (error) {
    return { success: false, message: error.toString() };
  }
}

/**
 * ============================================================================
 * MODUL 2: ADMINISTRASI GURU, JURNAL AGENDA, NILAI & LEGER
 * ============================================================================
 */

function simpanAbsensiServer(kelas, mapel, pert, tgl, guru, data) {
  try {
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName('ABSENSI') || ss.getSheetByName('absensi');
    if (!sheet) return { success: false, message: 'Sheet ABSENSI tidak ditemukan' };
    
    var time = new Date();
    var nowStr = formatWaktuSheet(time, 'HH:mm:ss');
    var rows = data.map(function(d) {
      return [
        'ABS-' + time.getTime() + '-' + Math.floor(Math.random()*1000),
        tgl,
        d.nama,
        kelas,
        nowStr,
        '',
        mapel + ' - Pertemuan ' + pert,
        d.status,
        '', '', '', '', '', nowStr
      ];
    });

    sheet.getRange(sheet.getLastRow() + 1, 1, rows.length, rows[0].length).setValues(rows);
    return { success: true, message: 'Absensi pertemuan ' + pert + ' berhasil disimpan!' };
  } catch (err) {
    return { success: false, message: err.toString() };
  }
}

function simpanNilaiServer(judul, mapel, kelas, guru, dataNilai) {
  try {
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName('NILAI') || ss.getSheetByName('nilai');
    if (!sheet) return { success: false, message: 'Sheet NILAI tidak ditemukan' };

    var nowStr = formatWaktuSheet(new Date(), 'yyyy-MM-dd HH:mm:ss');
    var rows = dataNilai.map(function(d) {
      return [
        'NIL-' + new Date().getTime() + '-' + Math.floor(Math.random()*1000),
        d.nama,
        mapel,
        guru,
        kelas,
        '1',
        '2026/2027',
        judul,
        d.nilai,
        75,
        Number(d.nilai) >= 75 ? 'A' : 'C',
        judul,
        nowStr,
        nowStr,
        nowStr
      ];
    });

    sheet.getRange(sheet.getLastRow() + 1, 1, rows.length, rows[0].length).setValues(rows);
    return { success: true, message: 'Nilai ' + judul + ' berhasil disimpan!' };
  } catch (err) {
    return { success: false, message: err.toString() };
  }
}

function getLegerDinamis(kelas, mapel) {
  try {
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName('NILAI') || ss.getSheetByName('nilai');
    if (!sheet) return { headers: [], data: [] };

    var data = sheet.getDataRange().getValues();
    var filtered = data.slice(1).filter(function(r) {
      return String(r[4]).toUpperCase() === String(kelas).toUpperCase() && String(r[2]).toUpperCase() === String(mapel).toUpperCase();
    });

    var headersSet = {};
    filtered.forEach(function(r) { if (r[7]) headersSet[String(r[7])] = true; });
    var headers = Object.keys(headersSet).sort();

    var siswaMap = {};
    filtered.forEach(function(r) {
      var sNama = String(r[1]);
      if (!siswaMap[sNama]) siswaMap[sNama] = { nama: sNama, total: 0, count: 0 };
      siswaMap[sNama][String(r[7])] = Number(r[8] || 0);
      siswaMap[sNama].total += Number(r[8] || 0);
      siswaMap[sNama].count++;
    });

    var rows = Object.keys(siswaMap).map(function(sNama, idx) {
      var item = siswaMap[sNama];
      item.no = idx + 1;
      item.rata = item.count > 0 ? (item.total / (headers.length || 1)).toFixed(1) : '0';
      return item;
    });

    return { success: true, headers: headers, data: rows };
  } catch (err) {
    return { success: false, message: err.toString() };
  }
}

function tambahAgenda(d) {
  try {
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName('AGENDA') || ss.getSheetByName('agenda');
    if (!sheet) return { success: false, message: 'Sheet AGENDA tidak ditemukan' };
    sheet.appendRow(d);
    return { success: true, message: 'Jurnal agenda mengajar berhasil disimpan' };
  } catch (err) {
    return { success: false, message: err.toString() };
  }
}

function getAgenda(g) {
  try {
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName('AGENDA') || ss.getSheetByName('agenda');
    if (!sheet) return [];
    var data = sheet.getDataRange().getValues();
    return data.slice(1).filter(function(r) { return !g || String(r[2]) === String(g) || String(r[10]) === String(g); });
  } catch (e) {
    return [];
  }
}

function simpanCatatanBimbingan(d) {
  try {
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName('BIMBINGAN') || ss.getSheetByName('bimbingan');
    if (!sheet) return { success: false, message: 'Sheet BIMBINGAN tidak ditemukan' };
    sheet.appendRow(d);
    return { success: true, message: 'Catatan bimbingan siswa berhasil disimpan' };
  } catch (err) {
    return { success: false, message: err.toString() };
  }
}

function getRiwayatBimbingan(g) {
  try {
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName('BIMBINGAN') || ss.getSheetByName('bimbingan');
    if (!sheet) return [];
    var data = sheet.getDataRange().getValues();
    return data.slice(1).filter(function(r) { return !g || String(r[3]) === String(g) || String(r[6]) === String(g); });
  } catch (e) {
    return [];
  }
}

/**
 * ============================================================================
 * MODUL 3: SPMB / PPDB ONLINE & FORM BUILDER
 * ============================================================================
 */

function getFormConfig() {
  try {
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName('FORM_FIELDS') || ss.getSheetByName('Config');
    if (!sheet) return [];
    var data = sheet.getDataRange().getValues();
    return data.slice(1).map(function(r) {
      return { label: r[1] || r[0], type: r[2] || 'text', options: r[6] || r[2] || '', width: r[3] || '12', required: Boolean(r[4]) };
    });
  } catch (e) {
    return [];
  }
}

function getKonfigurasiAplikasi() {
  var defaultConf = {
    appName: 'SPMB Online',
    judulSidebar: 'SPMB 2026',
    logoUrl: 'https://cdn-icons-png.flaticon.com/512/2920/2920224.png',
    heroImageUrl: 'https://images.unsplash.com/photo-1541339907198-e08756dedf3f?q=80&w=1920&auto=format&fit=crop',
    teksHero: 'Penerimaan Siswa Baru',
    heroBaris1: 'Pendidikan Terbaik untuk',
    heroBaris2: 'Masa Depan Cerah',
    heroSubteks: 'Bergabunglah bersama kami untuk meraih prestasi dan karakter unggul.',
    footerJudul: 'Rombel KTCT',
    footerAlamat: 'Kecamatan Tambora, Jakarta Barat',
    footerTelepon: '0812-3456-7890',
    footerEmail: 'info@rombelktct.sch.id',
    footerHakCipta: '© 2026 Rombongan Belajar Karang Taruna Kecamatan Tambora',
    linkFb: '#', linkIg: '#', linkYt: '#',
    pendaftaranStatus: 'dibuka',
    alur1_judul: 'Isi Formulir', alur1_desc: 'Lengkapi biodata diri secara online.',
    alur2_judul: 'Upload Berkas', alur2_desc: 'Unggah berkas KK, Akta & Foto.',
    alur3_judul: 'Verifikasi', alur3_desc: 'Panitia meninjau kelayakan berkas.',
    alur4_judul: 'Pengumuman', alur4_desc: 'Cek status kelulusan secara online.'
  };

  try {
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName('WEB_CONFIG') || ss.getSheetByName('Konfigurasi');
    if (!sheet) return { success: true, data: defaultConf };
    var data = sheet.getDataRange().getValues();
    if (data.length <= 1) return { success: true, data: defaultConf };
    
    var r = data[1];
    var conf = {
      appName: r[0] || defaultConf.appName,
      judulSidebar: r[1] || defaultConf.judulSidebar,
      logoUrl: r[2] || defaultConf.logoUrl,
      heroImageUrl: r[3] || defaultConf.heroImageUrl,
      teksHero: r[4] || defaultConf.teksHero,
      heroBaris1: r[5] || defaultConf.heroBaris1,
      heroBaris2: r[6] || defaultConf.heroBaris2,
      heroSubteks: r[7] || defaultConf.heroSubteks,
      footerJudul: r[8] || defaultConf.footerJudul,
      footerAlamat: r[9] || defaultConf.footerAlamat,
      footerTelepon: r[10] || defaultConf.footerTelepon,
      footerEmail: r[11] || defaultConf.footerEmail,
      footerHakCipta: r[12] || defaultConf.footerHakCipta,
      linkFb: r[13] || defaultConf.linkFb,
      linkIg: r[14] || defaultConf.linkIg,
      linkYt: r[15] || defaultConf.linkYt,
      pendaftaranStatus: r[16] || defaultConf.pendaftaranStatus,
      alur1_judul: r[17] || defaultConf.alur1_judul,
      alur1_desc: r[18] || defaultConf.alur1_desc,
      alur2_judul: r[19] || defaultConf.alur2_judul,
      alur2_desc: r[20] || defaultConf.alur2_desc,
      alur3_judul: r[21] || defaultConf.alur3_judul,
      alur3_desc: r[22] || defaultConf.alur3_desc,
      alur4_judul: r[23] || defaultConf.alur4_judul,
      alur4_desc: r[24] || defaultConf.alur4_desc
    };
    return { success: true, data: conf };
  } catch (e) {
    return { success: true, data: defaultConf };
  }
}

/**
 * ============================================================================
 * MODUL 4: CBT & ASESMEN UJIAN ONLINE
 * ============================================================================
 */

function registrasiAkunSiswaMandiri(nisnInput) {
  try {
    var ss = getSpreadsheet();
    var sheetSiswa = ss.getSheetByName('SISWA');
    var sheetUsers = ss.getSheetByName('USERS');
    if (!sheetSiswa || !sheetUsers) return { success: false, message: 'Sheet SISWA/USERS tidak ditemukan' };

    var cleanNisn = String(nisnInput || '').trim();
    var dataSiswa = sheetSiswa.getDataRange().getValues();
    var hS = dataSiswa[0];
    var idxNisn = hS.indexOf('NISN');
    var idxNama = hS.indexOf('NamaLengkap');
    var idxPdkt = hS.indexOf('nopdkt');

    var siswaFound = null;
    for (var i = 1; i < dataSiswa.length; i++) {
      if (String(dataSiswa[i][idxNisn]).trim() === cleanNisn) {
        siswaFound = dataSiswa[i];
        break;
      }
    }

    if (!siswaFound) return { success: false, message: 'NISN ' + cleanNisn + ' tidak terdaftar dalam database siswa.' };

    var nama = String(siswaFound[idxNama] || 'Siswa');
    var pdkt = String(siswaFound[idxPdkt] || '123');
    var password = nama.split(' ')[0].toLowerCase() + pdkt;

    sheetUsers.appendRow([
      'USR-' + new Date().getTime(),
      cleanNisn,
      password,
      'SISWA',
      nama,
      cleanNisn,
      '',
      '',
      'AKTIF',
      '',
      '',
      formatWaktuSheet(new Date(), 'yyyy-MM-dd HH:mm:ss'),
      formatWaktuSheet(new Date(), 'yyyy-MM-dd HH:mm:ss')
    ]);

    return { success: true, username: cleanNisn, password: password, nama: nama };
  } catch (e) {
    return { success: false, message: e.toString() };
  }
}

function verifyTokenAndFetchExam(idJadwal, tokenInput, nisn) {
  try {
    var ss = getSpreadsheet();
    var shJadwal = ss.getSheetByName('JADWAL');
    if (!shJadwal) return { success: false, message: 'Sheet JADWAL tidak ditemukan' };

    var data = shJadwal.getDataRange().getValues();
    for (var i = 1; i < data.length; i++) {
      if (String(data[i][1]).trim() === String(idJadwal).trim() || String(data[i][0]).trim() === String(idJadwal).trim()) {
        var tokenDb = String(data[i][10] || data[i][12] || '');
        if (tokenDb && tokenDb !== tokenInput) {
          return { success: false, message: 'Token ujian tidak valid!' };
        }
        return {
          success: true,
          mapel: data[i][3] || data[i][5] || 'Ujian',
          kelas: data[i][5] || data[i][4] || '-',
          durasi: Number(data[i][9] || data[i][8] || 60),
          message: 'Token valid'
        };
      }
    }
    return { success: false, message: 'Jadwal ujian tidak ditemukan.' };
  } catch (e) {
    return { success: false, message: e.toString() };
  }
}

function getSoalUjian(idJadwal) {
  try {
    var ss = getSpreadsheet();
    var sh = ss.getSheetByName('BANK_SOAL');
    if (!sh) return [];
    var data = sh.getDataRange().getValues();
    return data.slice(1).map(function(r, idx) {
      return {
        idSoal: r[0] || ('SOAL-' + (idx + 1)),
        mapel: r[1] || 'Ujian',
        jenjang: r[2] || 'SMA',
        kelas: r[3] || '-',
        soal: r[8] || r[5] || '-',
        a: r[9] || r[7] || '-',
        b: r[10] || r[8] || '-',
        c: r[11] || r[9] || '-',
        d: r[12] || r[10] || '-',
        bobot: Number(r[15] || r[12] || 1)
      };
    });
  } catch (e) {
    return [];
  }
}

function submitJawabanDanNilai(payload) {
  try {
    var ss = getSpreadsheet();
    var shHasil = ss.getSheetByName('HASIL_UJIAN') || ss.getSheetByName('HASIL');
    var shLog = ss.getSheetByName('LOG_UJIAN');

    var benar = 0;
    var totalSoal = payload.totalSoal || (payload.jawabanUser ? payload.jawabanUser.length : 10);
    if (payload.jawabanUser) {
      payload.jawabanUser.forEach(function(j) {
        if (j.jawaban) benar++;
      });
    }

    var nilaiMentah = totalSoal > 0 ? Math.round((benar / totalSoal) * 100) : 0;
    var pelanggaran = Number(payload.pelanggaran || 0);
    var nilaiAkhir = Math.max(0, nilaiMentah - (pelanggaran * 5));
    var status = nilaiAkhir >= 65 ? (pelanggaran === 0 ? '✅ LULUS' : '⚠️ SELESAI') : '❌ TIDAK TUNTAS';

    var idHasil = 'HSL-' + new Date().getTime();
    if (shHasil) {
      shHasil.appendRow([
        idHasil,
        payload.idUjian || 'AS-01',
        payload.jenjang || 'SMA',
        payload.kelas || '-',
        payload.mapel || 'Ujian',
        "'" + payload.nisn,
        payload.namaSiswa || 'Siswa',
        nilaiMentah,
        benar,
        totalSoal - benar,
        totalSoal,
        pelanggaran,
        formatWaktuSheet(new Date(), 'yyyy-MM-dd HH:mm:ss'),
        status,
        payload.tahunAjaran || '2026/2027',
        nilaiAkhir,
        formatWaktuSheet(new Date(), 'yyyy-MM-dd HH:mm:ss'),
        payload.durasi || '30 Menit',
        payload.idJadwal || '-'
      ]);
    }

    if (shLog) {
      shLog.appendRow([
        'LOG-' + new Date().getTime(),
        "'" + payload.nisn,
        payload.namaSiswa || 'Siswa',
        payload.jenjang || 'SMA',
        payload.kelas || '-',
        status,
        formatWaktuSheet(new Date(), 'yyyy-MM-dd HH:mm:ss'),
        pelanggaran,
        payload.token || '-',
        payload.idJadwal || '-'
      ]);
    }

    return {
      success: true,
      jmlBenar: benar,
      jmlSalah: totalSoal - benar,
      jmlPelanggaran: pelanggaran,
      nilaiMentah: nilaiMentah,
      nilaiAkhir: nilaiAkhir,
      status: status
    };
  } catch (e) {
    return { success: false, message: e.toString() };
  }
}

function catatPelanggaranSiswa(idUjian, nisn, nama, jenjang, kelas, jenisPelanggaran, token) {
  try {
    var ss = getSpreadsheet();
    var sheet = ss.getSheetByName('PELANGGARAN');
    if (sheet) {
      sheet.appendRow([
        'PLG-' + new Date().getTime(),
        idUjian || '-',
        "'" + nisn,
        nama,
        jenjang || '-',
        kelas || '-',
        jenisPelanggaran || 'Pindah Layar',
        formatWaktuSheet(new Date(), 'yyyy-MM-dd HH:mm:ss'),
        token || '-',
        'Deteksi Otomatis Sistem'
      ]);
    }
  } catch (e) {}
}

`;
}

export function generateMergedIndexHtml(): string {
  const schemasJson = JSON.stringify(OFFICIAL_56_SCHEMAS);

  return `<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Sistem Terpadu Sekolah - SISTA ROMBEL</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    body { font-family: 'Plus Jakarta Sans', sans-serif; }
    .scrollbar-thin::-webkit-scrollbar { width: 6px; height: 6px; }
    .scrollbar-thin::-webkit-scrollbar-track { background: #0f172a; }
    .scrollbar-thin::-webkit-scrollbar-thumb { background: #334155; border-radius: 4px; }
  </style>
</head>
<body class="bg-slate-950 text-slate-100 font-sans antialiased min-h-screen">
  <div id="app" class="flex flex-col min-h-screen">
    <!-- Header Utama -->
    <header class="bg-slate-900 border-b border-slate-800 px-6 py-4 flex flex-wrap items-center justify-between sticky top-0 z-50 shadow-lg">
      <div class="flex items-center gap-3">
        <div class="w-10 h-10 bg-gradient-to-tr from-amber-600 to-indigo-600 rounded-xl flex items-center justify-center font-black text-white text-xl shadow-lg shadow-indigo-500/20">
          <i class="fas fa-school-flag"></i>
        </div>
        <div>
          <h1 class="font-black text-base tracking-wide text-white flex items-center gap-2">
            SISTA ROMBEL <span class="bg-indigo-600/30 text-indigo-400 border border-indigo-500/30 text-[10px] font-bold px-2 py-0.5 rounded-full">GAS WEB APP</span>
          </h1>
          <p class="text-[10px] text-slate-400 font-medium">Sistem Informasi Terpadu Manajemen Sekolah • 56 Sheet Engine Native</p>
        </div>
      </div>

      <div class="flex items-center gap-3 mt-2 sm:mt-0">
        <button onclick="syncAllData()" class="px-3.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-lg text-xs font-semibold transition flex items-center gap-2">
          <i class="fas fa-sync-alt text-indigo-400" id="syncIcon"></i> Tarik / Sync Data
        </button>
        <button onclick="initDatabase()" class="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-bold transition shadow-md flex items-center gap-2">
          <i class="fas fa-database"></i> Inisialisasi 56 Sheet
        </button>
      </div>
    </header>

    <!-- Main Workspace -->
    <div class="flex-grow flex flex-col md:flex-row">
      <!-- Sidebar Navigation -->
      <aside class="w-full md:w-72 bg-slate-900/90 border-r border-slate-800 p-4 space-y-4 shrink-0">
        <!-- Quick Sheet Switcher Dropdown -->
        <div class="space-y-1.5">
          <label class="text-[11px] font-bold text-indigo-300 uppercase tracking-wider flex items-center gap-1.5">
            <i class="fas fa-table text-indigo-400"></i> Pilih Sheet (56 Skema):
          </label>
          <select id="sheetSelector" onchange="onSelectSheet(this.value)" class="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs font-bold text-white focus:outline-none focus:border-indigo-500">
            <!-- Populated dynamically via JS -->
          </select>
        </div>

        <div class="text-[11px] font-bold text-slate-500 uppercase tracking-wider px-1 pt-2 border-t border-slate-800">
          Kategori Modul Sekolah
        </div>
        
        <nav class="space-y-1 scrollbar-thin max-h-[60vh] overflow-y-auto pr-1" id="categoryMenu">
          <button onclick="filterCategory('ALL')" id="cat-ALL" class="cat-btn w-full px-3.5 py-2.5 rounded-xl text-xs font-bold text-left flex items-center justify-between bg-indigo-600 text-white shadow-md">
            <span class="flex items-center gap-2.5"><i class="fas fa-border-all w-4"></i> Semua 56 Sheet</span>
            <span class="text-[10px] bg-white/20 px-2 py-0.5 rounded-full font-mono">56</span>
          </button>
          <button onclick="filterCategory('MASTER')" id="cat-MASTER" class="cat-btn w-full px-3.5 py-2.5 rounded-xl text-xs font-bold text-left flex items-center justify-between text-slate-400 hover:bg-slate-800 hover:text-slate-200 transition">
            <span class="flex items-center gap-2.5"><i class="fas fa-users-gear w-4"></i> Master & Kesiswaan</span>
            <span class="text-[10px] bg-slate-800 px-2 py-0.5 rounded-full font-mono">11</span>
          </button>
          <button onclick="filterCategory('KEUANGAN')" id="cat-KEUANGAN" class="cat-btn w-full px-3.5 py-2.5 rounded-xl text-xs font-bold text-left flex items-center justify-between text-slate-400 hover:bg-slate-800 hover:text-slate-200 transition">
            <span class="flex items-center gap-2.5"><i class="fas fa-wallet w-4"></i> Keuangan & Tagihan</span>
            <span class="text-[10px] bg-slate-800 px-2 py-0.5 rounded-full font-mono">6</span>
          </button>
          <button onclick="filterCategory('AKADEMIK')" id="cat-AKADEMIK" class="cat-btn w-full px-3.5 py-2.5 rounded-xl text-xs font-bold text-left flex items-center justify-between text-slate-400 hover:bg-slate-800 hover:text-slate-200 transition">
            <span class="flex items-center gap-2.5"><i class="fas fa-graduation-cap w-4"></i> Akademik & CBT</span>
            <span class="text-[10px] bg-slate-800 px-2 py-0.5 rounded-full font-mono">8</span>
          </button>
          <button onclick="filterCategory('SPMB')" id="cat-SPMB" class="cat-btn w-full px-3.5 py-2.5 rounded-xl text-xs font-bold text-left flex items-center justify-between text-slate-400 hover:bg-slate-800 hover:text-slate-200 transition">
            <span class="flex items-center gap-2.5"><i class="fas fa-user-plus w-4"></i> SPMB Penerimaan</span>
            <span class="text-[10px] bg-slate-800 px-2 py-0.5 rounded-full font-mono">4</span>
          </button>
          <button onclick="filterCategory('INVENTARIS')" id="cat-INVENTARIS" class="cat-btn w-full px-3.5 py-2.5 rounded-xl text-xs font-bold text-left flex items-center justify-between text-slate-400 hover:bg-slate-800 hover:text-slate-200 transition">
            <span class="flex items-center gap-2.5"><i class="fas fa-boxes-packing w-4"></i> Inventaris & Aset</span>
            <span class="text-[10px] bg-slate-800 px-2 py-0.5 rounded-full font-mono">3</span>
          </button>
          <button onclick="filterCategory('BK')" id="cat-BK" class="cat-btn w-full px-3.5 py-2.5 rounded-xl text-xs font-bold text-left flex items-center justify-between text-slate-400 hover:bg-slate-800 hover:text-slate-200 transition">
            <span class="flex items-center gap-2.5"><i class="fas fa-user-shield w-4"></i> BK & Kedisiplinan</span>
            <span class="text-[10px] bg-slate-800 px-2 py-0.5 rounded-full font-mono">3</span>
          </button>
          <button onclick="filterCategory('SURAT')" id="cat-SURAT" class="cat-btn w-full px-3.5 py-2.5 rounded-xl text-xs font-bold text-left flex items-center justify-between text-slate-400 hover:bg-slate-800 hover:text-slate-200 transition">
            <span class="flex items-center gap-2.5"><i class="fas fa-file-contract w-4"></i> Surat & Dokumen</span>
            <span class="text-[10px] bg-slate-800 px-2 py-0.5 rounded-full font-mono">4</span>
          </button>
        </nav>
      </aside>

      <!-- Content Area -->
      <main class="flex-grow p-6 space-y-6 overflow-y-auto">
        <!-- Sheet Info & Action Bar -->
        <div class="bg-slate-900 border border-slate-800 rounded-2xl p-5 shadow-lg flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div class="space-y-1">
            <div class="flex items-center gap-2">
              <span id="sheetCategoryBadge" class="px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">Master</span>
              <h2 id="sheetTitle" class="text-xl font-black text-white">SISWA</h2>
            </div>
            <p id="sheetDesc" class="text-xs text-slate-400">Data Pokok Siswa & Biodata Lengkap</p>
          </div>

          <div class="flex flex-wrap items-center gap-2 w-full md:w-auto">
            <div class="relative flex-1 md:flex-initial min-w-[200px]">
              <i class="fas fa-search absolute left-3 top-3 text-slate-500 text-xs"></i>
              <input type="text" id="searchInput" oninput="onSearchChange(this.value)" placeholder="Cari data..." class="w-full bg-slate-950 border border-slate-700 rounded-xl pl-8 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500">
            </div>
            <button onclick="openAddModal()" class="px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center gap-1.5 shrink-0">
              <i class="fas fa-plus"></i> Tambah Data
            </button>
            <button onclick="saveCurrentSheetToGas()" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center gap-1.5 shrink-0">
              <i class="fas fa-floppy-disk"></i> Simpan Ke Sheet
            </button>
          </div>
        </div>

        <!-- Table Container -->
        <div class="bg-slate-900 border border-slate-800 rounded-2xl shadow-lg overflow-hidden">
          <div class="overflow-x-auto scrollbar-thin">
            <table class="w-full text-left text-xs text-slate-200">
              <thead id="tableHeader" class="bg-slate-950 border-b border-slate-800 text-slate-400 font-bold uppercase text-[11px] tracking-wider sticky top-0 z-10">
                <!-- Headers rendered dynamically -->
              </thead>
              <tbody id="tableBody" class="divide-y divide-slate-800/60 font-medium">
                <!-- Rows rendered dynamically -->
              </tbody>
            </table>
          </div>
          <div id="tableFooter" class="p-4 bg-slate-950/60 border-t border-slate-800/80 flex justify-between items-center text-xs text-slate-400">
            <span>Menampilkan <b id="rowCount" class="text-white">0</b> baris data</span>
            <span id="syncStatusTag" class="text-[11px] text-emerald-400 font-semibold">Ready</span>
          </div>
        </div>
      </main>
    </div>
  </div>

  <!-- Modal Form Add/Edit -->
  <div id="modalForm" class="fixed inset-0 bg-slate-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4 hidden">
    <div class="bg-slate-900 border border-slate-800 rounded-2xl max-w-2xl w-full max-h-[90vh] flex flex-col shadow-2xl overflow-hidden">
      <div class="p-5 border-b border-slate-800 flex justify-between items-center bg-slate-950">
        <h3 id="modalTitle" class="font-bold text-base text-white">Tambah Data Baru</h3>
        <button onclick="closeModal()" class="text-slate-400 hover:text-white transition">
          <i class="fas fa-times text-lg"></i>
        </button>
      </div>

      <form id="dataForm" onsubmit="handleFormSubmit(event)" class="p-6 space-y-4 overflow-y-auto scrollbar-thin flex-grow">
        <div id="modalInputsContainer" class="grid grid-cols-1 md:grid-cols-2 gap-4">
          <!-- Inputs generated dynamically -->
        </div>
        <div class="pt-4 border-t border-slate-800 flex justify-end gap-3">
          <button type="button" onclick="closeModal()" class="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs rounded-xl transition">Batal</button>
          <button type="submit" class="px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-xl shadow-lg transition">Simpan Data</button>
        </div>
      </form>
    </div>
  </div>

  <script>
    const SCHEMAS = ${schemasJson};

    let currentSchema = SCHEMAS[0];
    let sheetDataStore = {}; // { [sheetName]: array_of_row_objects }
    let searchQuery = '';
    let editingRowIndex = null;

    // Initialize UI on Load
    document.addEventListener('DOMContentLoaded', () => {
      populateSheetSelector(SCHEMAS);
      loadSheet(SCHEMAS[0].name);
    });

    function populateSheetSelector(schemaList) {
      const select = document.getElementById('sheetSelector');
      select.innerHTML = schemaList.map(s => \`<option value="\${s.name}">[\${s.category}] \${s.name} - \${s.description.slice(0, 30)}...</option>\`).join('');
    }

    function filterCategory(cat) {
      document.querySelectorAll('.cat-btn').forEach(el => {
        el.classList.remove('bg-indigo-600', 'text-white', 'shadow-md');
        el.classList.add('text-slate-400');
      });
      const activeBtn = document.getElementById('cat-' + cat);
      if (activeBtn) {
        activeBtn.classList.add('bg-indigo-600', 'text-white', 'shadow-md');
        activeBtn.classList.remove('text-slate-400');
      }

      const filtered = cat === 'ALL' ? SCHEMAS : SCHEMAS.filter(s => s.category.toUpperCase().includes(cat));
      populateSheetSelector(filtered);
      if (filtered.length > 0) {
        loadSheet(filtered[0].name);
        document.getElementById('sheetSelector').value = filtered[0].name;
      }
    }

    function onSelectSheet(sheetName) {
      loadSheet(sheetName);
    }

    function loadSheet(sheetName) {
      const schema = SCHEMAS.find(s => s.name === sheetName);
      if (!schema) return;
      
      currentSchema = schema;
      document.getElementById('sheetTitle').innerText = schema.name;
      document.getElementById('sheetDesc').innerText = schema.description || 'Skema Tabel SISTA ROMBEL';
      document.getElementById('sheetCategoryBadge').innerText = schema.category;

      if (!sheetDataStore[sheetName]) {
        sheetDataStore[sheetName] = generateSampleDataForSchema(schema);
        // Try fetching live data from GAS backend if available
        if (typeof google !== 'undefined' && google.script && google.script.run) {
          google.script.run
            .withSuccessHandler(res => {
              if (res && res.status === 'success' && Array.isArray(res.data) && res.data.length > 0) {
                sheetDataStore[sheetName] = res.data;
                renderTable();
              }
            })
            .getTableData(sheetName);
        }
      }

      renderTable();
    }

    function generateSampleDataForSchema(schema) {
      const rows = [];
      for (let i = 1; i <= 3; i++) {
        const row = {};
        schema.headers.forEach(h => {
          if (h.toLowerCase().includes('id')) row[h] = h.toUpperCase() + '-00' + i;
          else if (h.toLowerCase().includes('nama')) row[h] = 'Contoh Data ' + schema.name + ' #' + i;
          else if (h.toLowerCase().includes('tgl') || h.toLowerCase().includes('tanggal')) row[h] = '2026-07-26';
          else if (h.toLowerCase().includes('status')) row[h] = 'AKTIF';
          else if (h.toLowerCase().includes('nominal') || h.toLowerCase().includes('jumlah')) row[h] = 150000;
          else row[h] = 'Val-' + i;
        });
        rows.push(row);
      }
      return rows;
    }

    function renderTable() {
      const rows = sheetDataStore[currentSchema.name] || [];
      const filtered = rows.filter(r => {
        if (!searchQuery) return true;
        return Object.values(r).some(val => String(val).toLowerCase().includes(searchQuery.toLowerCase()));
      });

      // Render Header
      const thead = document.getElementById('tableHeader');
      thead.innerHTML = \`
        <tr>
          <th class="p-3.5 w-12 text-center">#</th>
          \${currentSchema.headers.map(h => \`<th class="p-3.5 shadow-sm whitespace-nowrap">\${h}</th>\`).join('')}
          <th class="p-3.5 w-24 text-center">Aksi</th>
        </tr>
      \`;

      // Render Body
      const tbody = document.getElementById('tableBody');
      if (filtered.length === 0) {
        tbody.innerHTML = \`
          <tr>
            <td colspan="\${currentSchema.headers.length + 2}" class="p-8 text-center text-slate-500 italic">
              Tidak ada data dalam sheet [\${currentSchema.name}]
            </td>
          </tr>
        \`;
      } else {
        tbody.innerHTML = filtered.map((row, idx) => \`
          <tr class="hover:bg-slate-800/50 transition border-b border-slate-800/40">
            <td class="p-3 text-center text-slate-500 font-mono">\${idx + 1}</td>
            \${currentSchema.headers.map(h => \`<td class="p-3 max-w-[200px] truncate">\${row[h] !== undefined ? row[h] : '-'}</td>\`).join('')}
            <td class="p-3 text-center space-x-1 whitespace-nowrap">
              <button onclick="openEditModal(\${idx})" class="p-1.5 bg-blue-600/20 text-blue-400 hover:bg-blue-600 hover:text-white rounded-lg transition" title="Edit">
                <i class="fas fa-edit"></i>
              </button>
              <button onclick="deleteRow(\${idx})" class="p-1.5 bg-rose-600/20 text-rose-400 hover:bg-rose-600 hover:text-white rounded-lg transition" title="Hapus">
                <i class="fas fa-trash"></i>
              </button>
            </td>
          </tr>
        \`).join('');
      }

      document.getElementById('rowCount').innerText = filtered.length;
    }

    function onSearchChange(val) {
      searchQuery = val;
      renderTable();
    }

    function openAddModal() {
      editingRowIndex = null;
      document.getElementById('modalTitle').innerText = 'Tambah Data - ' + currentSchema.name;
      buildModalInputs({});
      document.getElementById('modalForm').classList.remove('hidden');
    }

    function openEditModal(idx) {
      editingRowIndex = idx;
      const rows = sheetDataStore[currentSchema.name] || [];
      document.getElementById('modalTitle').innerText = 'Edit Data #' + (idx + 1) + ' - ' + currentSchema.name;
      buildModalInputs(rows[idx] || {});
      document.getElementById('modalForm').classList.remove('hidden');
    }

    function buildModalInputs(data) {
      const container = document.getElementById('modalInputsContainer');
      container.innerHTML = currentSchema.headers.map(h => \`
        <div class="space-y-1">
          <label class="text-[11px] font-bold text-slate-400 uppercase">\${h}</label>
          <input type="text" name="\${h}" value="\${data[h] !== undefined ? data[h] : ''}" class="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-indigo-500">
        </div>
      \`).join('');
    }

    function closeModal() {
      document.getElementById('modalForm').classList.add('hidden');
    }

    function handleFormSubmit(e) {
      e.preventDefault();
      const formData = new FormData(e.target);
      const newObj = {};
      currentSchema.headers.forEach(h => {
        newObj[h] = formData.get(h) || '';
      });

      if (!sheetDataStore[currentSchema.name]) sheetDataStore[currentSchema.name] = [];

      if (editingRowIndex !== null) {
        sheetDataStore[currentSchema.name][editingRowIndex] = newObj;
      } else {
        sheetDataStore[currentSchema.name].unshift(newObj);
      }

      closeModal();
      renderTable();
      saveCurrentSheetToGas(true);
    }

    function deleteRow(idx) {
      if (confirm('Apakah Anda yakin ingin menghapus baris data ini?')) {
        sheetDataStore[currentSchema.name].splice(idx, 1);
        renderTable();
        saveCurrentSheetToGas(true);
      }
    }

    function saveCurrentSheetToGas(silent = false) {
      const rows = sheetDataStore[currentSchema.name] || [];
      const statusTag = document.getElementById('syncStatusTag');
      if (statusTag) statusTag.innerText = '⚡ Menyimpan ke Google Sheet...';

      if (typeof google !== 'undefined' && google.script && google.script.run) {
        google.script.run
          .withSuccessHandler(res => {
            if (statusTag) statusTag.innerText = '✅ Tersimpan di Google Sheet!';
            if (!silent) Swal.fire('Berhasil!', 'Data sheet [' + currentSchema.name + '] tersimpan di Google Spreadsheet!', 'success');
            setTimeout(() => { if (statusTag) statusTag.innerText = 'Ready'; }, 4000);
          })
          .withFailureHandler(err => {
            if (statusTag) statusTag.innerText = '❌ Error Sync';
            if (!silent) Swal.fire('Gagal', err.toString(), 'error');
          })
          .syncSheetData(currentSchema.name, JSON.stringify(rows));
      } else {
        setTimeout(() => {
          if (statusTag) statusTag.innerText = 'Local Save OK';
          if (!silent) Swal.fire('Mode Lokal', 'Data [' + currentSchema.name + '] tersimpan di memori browser!', 'info');
          setTimeout(() => { if (statusTag) statusTag.innerText = 'Ready'; }, 3000);
        }, 500);
      }
    }

    function syncAllData() {
      const icon = document.getElementById('syncIcon');
      if (icon) icon.classList.add('fa-spin');

      if (typeof google !== 'undefined' && google.script && google.script.run) {
        google.script.run
          .withSuccessHandler(res => {
            if (icon) icon.classList.remove('fa-spin');
            if (res && res.status === 'success') {
              Swal.fire('Sync Berhasil', 'Seluruh 56 Sheet berhasil ditarik dari Google Sheets!', 'success');
              if (res.data) {
                sheetDataStore = res.data;
                renderTable();
              }
            }
          })
          .withFailureHandler(err => {
            if (icon) icon.classList.remove('fa-spin');
            Swal.fire('Error', err.toString(), 'error');
          })
          .getAllDatabaseData();
      } else {
        setTimeout(() => {
          if (icon) icon.classList.remove('fa-spin');
          Swal.fire('Mode Pratinjau', 'Fungsi sinkronisasi aktif saat aplikasi terpasang di Google Apps Script.', 'info');
        }, 800);
      }
    }

    function initDatabase() {
      Swal.fire({
        title: 'Menginisialisasi 56 Sheet...',
        text: 'Sedang membuat seluruh 56 Sheet Google Sheets beserta Header Resminya...',
        allowOutsideClick: false,
        didOpen: () => { Swal.showLoading(); }
      });

      if (typeof google !== 'undefined' && google.script && google.script.run) {
        google.script.run
          .withSuccessHandler(res => {
            Swal.fire(res.status === 'success' ? 'Berhasil' : 'Gagal', res.message, res.status === 'success' ? 'success' : 'error');
          })
          .withFailureHandler(err => {
            Swal.fire('Error', err.toString(), 'error');
          })
          .initialize56SheetsDatabase();
      } else {
        setTimeout(() => {
          Swal.fire('Mode Pratinjau', 'Inisialisasi 56 Sheet siap dijalankan di lingkungan Google Apps Script.', 'info');
        }, 1000);
      }
    }
  </script>
</body>
</html>`;
}

