// Data Master Seeding: Mapel, Tahun Ajaran, Semester, Hari Libur & Pos Biaya
// Clean / Empty initial state - Ready for user real data input or Google Sheets Sync

export interface MasterMapelItem {
  id: string;
  mapelId: string;
  kode: string;
  nama: string;
  namaMapel: string;
  kkm: number;
  guruId: string;
  kelompok: string;
  status: string;
  jenjang: string;
  kelas: string;
  guruPengampu: string;
  guru: string;
  jp: number;
  bebanJp: number;
  kategori?: string;
}

export interface MasterTahunAjaranItem {
  id: string;
  taId: string;
  tahun: string;
  nama: string;
  tahunAjaran: string;
  tanggalMulai: string;
  tanggalSelesai: string;
  status: string;
  aktif: string;
  deskripsi: string;
  kurikulum: string;
  semester?: string;
  rentang?: string;
  rentangWaktu?: string;
  periode?: string;
  [key: string]: any;
}

export interface MasterSemesterItem {
  id: string;
  semesterId: string;
  nama: string;
  semester: string;
  tahunAjaranId: string;
  tahunAjaran: string;
  aktif: string;
  status: string;
  tipe: 'ODD' | 'EVEN';
  tanggalMulai?: string;
  tanggalSelesai?: string;
}

export interface MasterHariLiburItem {
  id: string;
  hariLiburId: string;
  tanggal: string;
  nama: string;
  agenda: string;
  jenis: string;
  keterangan: string;
  hari?: string;
}

export interface MasterTarifBiayaItem {
  id: string;
  biayaId: string;
  kode: string;
  kodeBiaya: string;
  namaPos: string;
  namaBiaya: string;
  kategori: string;
  jenjang: string;
  target_Kelas: string;
  kelas: string;
  kelasId: string;
  nominal: number;
  periode: string;
  frekuensi: string;
  wajib: string;
  status: string;
  keterangan: string;
  jurusanId?: string;
}

export const SEED_MAPEL: MasterMapelItem[] = [];

export const SEED_TAHUN_AJARAN: MasterTahunAjaranItem[] = [];

export const SEED_SEMESTER: MasterSemesterItem[] = [];

export const SEED_HARI_LIBUR: MasterHariLiburItem[] = [];

export const SEED_TARIF_BIAYA: MasterTarifBiayaItem[] = [];
