// In-Memory Database Storage Engine (Zero localStorage persistence)
// All data is kept safely in-memory during session and directly synchronized with Google Sheets / GAS

const memoryStore = new Map<string, any>();

export const db = {
  get: <T = any>(key: string): T[] => {
    const val = memoryStore.get(key);
    if (Array.isArray(val)) return val;
    return [];
  },
  getSingle: <T = any>(key: string): T | null => {
    const val = memoryStore.get(key);
    return val !== undefined ? val : null;
  },
  set: (key: string, value: any): void => {
    memoryStore.set(key, value);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('erp-db-updated', { detail: { key } }));
    }
  },
  setSingle: (key: string, value: any): void => {
    memoryStore.set(key, value);
    if (typeof window !== 'undefined') {
      window.dispatchEvent(new CustomEvent('erp-db-updated', { detail: { key } }));
    }
  },
  insert: <T = any>(key: string, item: T): T[] => {
    const list = db.get<T>(key);
    const updated = [...list, item];
    db.set(key, updated);
    return updated;
  },
  clearAll: (): void => {
    memoryStore.clear();
    if (typeof window !== 'undefined') {
      try {
        if (window.localStorage) {
          window.localStorage.clear();
        }
      } catch {
        // ignore
      }
      window.dispatchEvent(new CustomEvent('erp-db-synced', { detail: { key: 'all' } }));
    }
  },
  purgeSimulationData: (): void => {
    db.clearAll();
  }
};

// Immediately purge any legacy browser localStorage on load so no stale cache remains
if (typeof window !== 'undefined') {
  try {
    if (window.localStorage) {
      window.localStorage.clear();
    }
  } catch {
    // ignore
  }
}
