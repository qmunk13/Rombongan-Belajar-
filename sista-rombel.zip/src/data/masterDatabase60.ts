export interface TableSchema {
  id: number;
  name: string;
  category: string;
  description: string;
  headers: string[];
  primaryKey: string;
}

export const MASTER_TABLES_60: TableSchema[] = [
  // ==========================================
  // SECTION 1: SISTEM, KONFIGURASI & KEAMANAN (1-10)
  // ==========================================
  {
    id: 1,
    name: "SETTING",
    category: "1. Sistem & Konfigurasi",
    description: "Pengaturan umum aplikasi, identitas sekolah, dan preferensi sistem",
    primaryKey: "Key",
    headers: ["Key", "Value", "Deskripsi", "UpdatedAt"]
  },
  {
    id: 2,
    name: "WEB_CONFIG",
    category: "1. Sistem & Konfigurasi",
    description: "Pengaturan konten web, landing page portal, branding, kontak & alur pendaftaran",
    primaryKey: "appName",
    headers: ["appName", "judulSidebar", "logoUrl", "heroImageUrl", "teksHero", "heroBaris1", "heroBaris2", "heroSubteks", "footerJudul", "footerAlamat", "footerTelepon", "footerEmail", "footerHakCipta", "linkFb", "linkIg", "linkYt", "pendaftaranStatus", "alur1_judul", "alur1_desc", "alur2_judul", "alur2_desc", "alur3_judul", "alur3_desc", "alur4_judul", "alur4_desc"]
  },
  {
    id: 3,
    name: "REFERENSI",
    category: "1. Sistem & Konfigurasi",
    description: "Data referensi master kode (agama, status, jenis dokumen, dll)",
    primaryKey: "Kode",
    headers: ["Kategori", "Kode", "Nama", "Aktif"]
  },
  {
    id: 4,
    name: "USERS",
    category: "1. Sistem & Konfigurasi",
    description: "Akun login pengguna (Admin, Kepala Sekolah, Guru, Staf, Siswa, Wali Murid)",
    primaryKey: "UserID",
    headers: ["UserID", "Username", "Password", "RoleID", "Nama", "NIP_NISN", "Email", "NoHP", "Status", "LastLogin", "Token", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 5,
    name: "ROLE",
    category: "1. Sistem & Konfigurasi",
    description: "Definisi tingkatan hak akses / peran dalam sistem (32 role)",
    primaryKey: "RoleID",
    headers: ["RoleID", "NamaRole", "Keterangan"]
  },
  {
    id: 6,
    name: "MENU",
    category: "1. Sistem & Konfigurasi",
    description: "Struktur navigasi modul dan susunan menu sistem",
    primaryKey: "MenuID",
    headers: ["MenuID", "ParentID", "NamaMenu", "Icon", "URL", "Urutan", "Status"]
  },
  {
    id: 7,
    name: "HAK_AKSES",
    category: "1. Sistem & Konfigurasi",
    description: "Matriks perizinan Create, Read, Update, Delete, Approve, Export, Import per Role",
    primaryKey: "HakAksesID",
    headers: ["HakAksesID", "RoleID", "MenuID", "Create", "Read", "Update", "Delete", "Approve", "Export", "Import"]
  },
  {
    id: 8,
    name: "SESSION",
    category: "1. Sistem & Konfigurasi",
    description: "Sesi login aktif pengguna dan informasi perangkat",
    primaryKey: "SessionID",
    headers: ["SessionID", "UserID", "Token", "IPAddress", "Device", "LoginAt", "ExpiredAt", "Status"]
  },
  {
    id: 9,
    name: "LOG",
    category: "1. Sistem & Konfigurasi",
    description: "Log aktivitas harian pengguna dalam sistem",
    primaryKey: "LogID",
    headers: ["LogID", "UserID", "Tanggal", "Aktivitas", "IP", "Device", "Browser"]
  },
  {
    id: 10,
    name: "AUDIT_LOG",
    category: "1. Sistem & Konfigurasi",
    description: "Riwayat perubahan nilai data record (sebelum & sesudah diedit)",
    primaryKey: "AuditID",
    headers: ["AuditID", "UserID", "Tabel", "RecordID", "Field", "ValueLama", "ValueBaru", "Tanggal"]
  },

  // ==========================================
  // SECTION 2: MASTER KESISWAAN & ALUMNI (11-17)
  // ==========================================
  {
    id: 11,
    name: "SISWA",
    category: "2. Master Kesiswaan",
    description: "Biodata Buku Induk lengkap kesiswaan (74 atribut standar Dapodik 2027 & berkas)",
    primaryKey: "nopdkt",
    headers: [
      "nopdkt", "TahunMasuk", "NISN", "NamaLengkap", "JenisKelamin", "Tempat Lahir", "TanggalLahir", 
      "NIK", "Anak ke", "Saudara", "Agama", "Golongan Darah", "TinggiBadan(cm)", "BeratBadan(kg)", 
      "Prestasi", "Hobi", "Catatan Penting", "Alamat", "RT", "RW", "Kelurahan", "Kecamatan", "Kota", 
      "Provinsi", "KodePos", "JenisTinggal", "AlatTransportasi", "NomorHP", "E-Mail", "AsalSekolah", 
      "SKHUN", "PenerimaKPS", "PasFoto", "NomorKartuKeluarga", "NamaAyah", "NIKAyah", "TempatLahirAyah", 
      "TanggalLahirAyah", "PendidikanAyah", "PekerjaanAyah", "PenghasilanAyah", "TlpAyah", "StatusAyah", "NamaIbu", 
      "NIKIbu", "TempatLahirIbu", "TanggalLahirIbu", "PendidikanIbu", "PekerjaanIbu", "PenghasilanIbu", 
      "TlpIbu", "StatusIbu", "StatusYatim", "NamaWali", "TempatLahirWali", "TglLahirWali", "PendidikanWali", "PekerjaanWali", 
      "PenghasilanWali", "Hubungan", "Tlp.Wali", "AktaKelahiran", "KartuKeluarga", "KIA", "KTPAyah", 
      "KTPIbu", "Ijazah", "KTPWali", "Rapor", "S.Pindah", "SuKet", "S.Domisili", "Status", "KelasSaatini"
    ]
  },
  {
    id: 12,
    name: "ORANG_TUA",
    category: "2. Master Kesiswaan",
    description: "Data detail orang tua / wali murid per siswa",
    primaryKey: "OrtuID",
    headers: ["OrtuID", "SiswaID", "Hubungan", "Nama", "NIK", "Pekerjaan", "NoHP", "Alamat"]
  },
  {
    id: 13,
    name: "YATIM_PIATU",
    category: "2. Master Kesiswaan",
    description: "Data khusus siswa Yatim, Piatu, Yatim Piatu, dan status bantuan sosial (KPS/PIP)",
    primaryKey: "YatimID",
    headers: ["YatimID", "NoPDKT", "NISN", "NamaSiswa", "Kelas", "StatusYatim", "NamaAyah", "StatusAyah", "NamaIbu", "StatusIbu", "NamaWali", "NoHPWali", "Alamat", "PenerimaKPS_PIP", "Keterangan", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 14,
    name: "PRESTASI_SISWA",
    category: "2. Master Kesiswaan",
    description: "Pencatatan prestasi lomba, kejuaraan akademik/non-akademik dan piagam siswa",
    primaryKey: "PrestasiID",
    headers: ["PrestasiID", "SiswaID", "NamaSiswa", "Kelas", "NamaPrestasi", "Tingkat", "Peringkat", "Tahun", "Penyelenggara", "SertifikatUrl", "Status", "CreatedAt"]
  },
  {
    id: 15,
    name: "KENAIKAN_KELAS",
    category: "2. Master Kesiswaan",
    description: "Riwayat proses kenaikan tingkat siswa tahunan",
    primaryKey: "KenaikanID",
    headers: ["KenaikanID", "SiswaID", "KelasAsalID", "KelasTujuanID", "SemesterID", "TahunAjaranID", "Status", "Keputusan", "Tanggal", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 16,
    name: "KELULUSAN",
    category: "2. Master Kesiswaan",
    description: "Data kelulusan akhir, SKL, nilai akhir dan ijazah",
    primaryKey: "KelulusanID",
    headers: ["KelulusanID", "SiswaID", "NomorSKL", "TanggalLulus", "NilaiAkhir", "Predikat", "Status", "Keterangan", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 17,
    name: "ALUMNI",
    category: "2. Master Kesiswaan",
    description: "Data penelusuran lulusan dan tracer study alumni siswa",
    primaryKey: "NISN",
    headers: ["Nama", "NISN", "Jenis Kelamin", "Kelas Terakhir", "Tahun Lulus", "StatusLanjut", "NamaKampus_Instansi", "Kontak", "Alamat", "CreatedAt"]
  },

  // ==========================================
  // SECTION 3: PENDIDIK & GTK (18-20)
  // ==========================================
  {
    id: 18,
    name: "GURU",
    category: "3. Pendidik & Tenaga Kependidikan",
    description: "Biodata PTK/GTK (Guru & Tenaga Kependidikan), NIP, NUPTK, dan staf",
    primaryKey: "GuruID",
    headers: [
      "GuruID", "NIK", "NIP", "NUPTK", "Nama", "Gelar", "JenisKelamin", "TempatLahir", "TanggalLahir", 
      "Agama", "Alamat", "NoHP", "Email", "Jabatan", "StatusKepegawaian", "Pendidikan", "Jurusan", "TMT", "Status", "Foto", "CreatedAt", "UpdatedAt"
    ]
  },
  {
    id: 19,
    name: "JABATAN_GTK",
    category: "3. Pendidik & Tenaga Kependidikan",
    description: "Daftar struktur penugasan dan jabatan GTK (Kepsek, Waka, Bendahara, Wali Kelas)",
    primaryKey: "JabatanID",
    headers: ["JabatanID", "NamaJabatan", "TugasUtama", "Eselon_Tingkat", "Keterangan"]
  },
  {
    id: 20,
    name: "RIWAYAT_MENGAJAR",
    category: "3. Pendidik & Tenaga Kependidikan",
    description: "Riwayat beban jam mengajar guru per tahun pelajaran dan semester",
    primaryKey: "RiwayatID",
    headers: ["RiwayatID", "GuruID", "TahunAjaranID", "SemesterID", "MapelID", "KelasID", "JumlahJam", "StatusSK"]
  },

  // ==========================================
  // SECTION 4: AKADEMIK & KURIKULUM (21-28)
  // ==========================================
  {
    id: 21,
    name: "TAHUN_AJARAN",
    category: "4. Akademik & Kurikulum",
    description: "Tahun pelajaran kalender akademik (misal: 2026/2027)",
    primaryKey: "TAID",
    headers: ["TAID", "Nama", "TanggalMulai", "TanggalSelesai", "Aktif"]
  },
  {
    id: 22,
    name: "SEMESTER",
    category: "4. Akademik & Kurikulum",
    description: "Semester berjalan (Ganjil / Genap)",
    primaryKey: "SemesterID",
    headers: ["SemesterID", "Nama", "TahunAjaranID", "TanggalMulai", "TanggalSelesai", "Aktif"]
  },
  {
    id: 23,
    name: "JENJANG",
    category: "4. Akademik & Kurikulum",
    description: "Jenjang pendidikan (SD, SMP, SMA, SMK, MI, MTs, MA)",
    primaryKey: "JenjangID",
    headers: ["JenjangID", "Kode", "NamaJenjang", "Keterangan"]
  },
  {
    id: 24,
    name: "KELAS",
    category: "4. Akademik & Kurikulum",
    description: "Rombongan belajar kelas, tingkat, ruangan, wali kelas, dan tutor",
    primaryKey: "KelasID",
    headers: ["KelasID", "NamaKelas", "JenjangID", "Tingkat", "WaliKelasID", "NamaTutor", "Ruangan", "Kapasitas", "Status"]
  },
  {
    id: 25,
    name: "MAPEL",
    category: "4. Akademik & Kurikulum",
    description: "Mata pelajaran, kelompok kurikulum, jenjang, kelas, guru pengampu, dan KKM",
    primaryKey: "MapelID",
    headers: ["MapelID", "Kode", "NamaMapel", "KKM", "GuruID", "Kelompok", "Status", "Jenjang", "Kelas", "GuruPengampu", "BebanJP"]
  },
  {
    id: 26,
    name: "HARI_LIBUR",
    category: "4. Akademik & Kurikulum",
    description: "Kalender hari libur nasional dan cuti bersama pendidikan",
    primaryKey: "HariLiburID",
    headers: ["HariLiburID", "Tanggal", "Nama", "Jenis", "Keterangan"]
  },
  {
    id: 27,
    name: "JADWAL",
    category: "4. Akademik & Kurikulum",
    description: "Jadwal pelajaran mingguan per kelas dan jam mengajar",
    primaryKey: "JadwalID",
    headers: ["JadwalID", "Hari", "JamMulai", "JamSelesai", "KelasID", "MapelID", "GuruID", "TAID", "SemesterID", "Status", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 28,
    name: "AGENDA",
    category: "4. Akademik & Kurikulum",
    description: "Jurnal agenda mengajar guru harian di kelas",
    primaryKey: "AgendaID",
    headers: ["AgendaID", "Tanggal", "GuruID", "MapelID", "KelasID", "Materi", "Pertemuan", "Metode", "Catatan", "Status", "CreatedAt", "UpdatedAt"]
  },

  // ==========================================
  // SECTION 5: PENUGASAN, EVALUASI & RAPOR (29-34)
  // ==========================================
  {
    id: 29,
    name: "TUGAS",
    category: "5. Pembelajaran & Penilaian",
    description: "Data penugasan online, PR, dan instruksi tugas siswa",
    primaryKey: "TugasID",
    headers: ["TugasID", "Judul", "Mapel", "Kelas", "Guru", "Tenggat", "Kategori", "Petunjuk", "Status", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 30,
    name: "PENGUMPULAN_TUGAS",
    category: "5. Pembelajaran & Penilaian",
    description: "Data pengumpulan berkas/jawaban tugas siswa beserta penilaian guru",
    primaryKey: "PengumpulanID",
    headers: ["PengumpulanID", "TugasID", "SiswaID", "NamaSiswa", "Kelas", "Status", "Nilai", "CatatanGuru", "FileUrl", "WaktuKumpul", "CreatedAt"]
  },
  {
    id: 31,
    name: "MATERI_DIGITAL",
    category: "5. Pembelajaran & Penilaian",
    description: "Buku digital, modul ajar, video edukasi, dan e-learning siswa",
    primaryKey: "MateriID",
    headers: ["MateriID", "Judul", "MapelID", "KelasID", "GuruID", "Deskripsi", "FileUrl", "Tipe", "CreatedAt"]
  },
  {
    id: 32,
    name: "CP_ATP",
    category: "5. Pembelajaran & Penilaian",
    description: "Capaian Pembelajaran (CP) dan Alur Tujuan Pembelajaran (ATP) Kurikulum Merdeka",
    primaryKey: "CpaID",
    headers: ["CpaID", "MapelID", "Fase", "Elemen", "CapaianPembelajaran", "TujuanPembelajaran", "AlurTujuan"]
  },
  {
    id: 33,
    name: "NILAI",
    category: "5. Pembelajaran & Penilaian",
    description: "Buku nilai formatif, sumatif, tugas, PTS, PAS, dan portofolio siswa",
    primaryKey: "NilaiID",
    headers: ["NilaiID", "SiswaID", "MapelID", "GuruID", "KelasID", "SemesterID", "TAID", "JenisNilai", "Nilai", "KKM", "Predikat", "Deskripsi", "TanggalInput", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 34,
    name: "RAPOR",
    category: "5. Pembelajaran & Penilaian",
    description: "Rekap nilai akhir rapor siswa, ranking, dan catatan wali kelas",
    primaryKey: "RaporID",
    headers: ["RaporID", "SiswaID", "SemesterID", "TahunAjaranID", "RataRata", "Ranking", "NaikKelas", "CatatanWaliKelas", "TanggalCetak", "CreatedAt", "UpdatedAt"]
  },

  // ==========================================
  // SECTION 6: PRESENSI & KEHADIRAN (35-40)
  // ==========================================
  {
    id: 35,
    name: "ABSENSI",
    category: "6. Presensi & Kehadiran",
    description: "Presensi harian siswa (masuk/pulang, GPS, QR code scan kartu pelajar)",
    primaryKey: "AbsenID",
    headers: ["AbsenID", "Tanggal", "SiswaID", "KelasID", "JamMasuk", "JamPulang", "Status", "Keterangan", "Lokasi", "Latitude", "Longitude", "QRCode", "PetugasID", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 36,
    name: "ABSENSI_GURU",
    category: "6. Presensi & Kehadiran",
    description: "Presensi kehadiran guru dan staf tenaga kependidikan",
    primaryKey: "AbsenGuruID",
    headers: ["AbsenGuruID", "Tanggal", "GuruID", "JamMasuk", "JamPulang", "Status", "Lokasi", "Latitude", "Longitude", "Keterangan", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 37,
    name: "IZIN_SAKIT_SISWA",
    category: "6. Presensi & Kehadiran",
    description: "Permohonan surat izin / sakit siswa beserta lampiran dokumen",
    primaryKey: "IzinID",
    headers: ["IzinID", "SiswaID", "TanggalMulai", "TanggalSelesai", "Jenis", "Alasan", "BuktiSuratUrl", "Status", "ApprovedBy", "CreatedAt"]
  },
  {
    id: 38,
    name: "IZIN_CUTI_GURU",
    category: "6. Presensi & Kehadiran",
    description: "Pengajuan izin cuti, dinas luar, dan ketidakhadiran guru/staf",
    primaryKey: "CutiID",
    headers: ["CutiID", "GuruID", "TanggalMulai", "TanggalSelesai", "JenisCuti", "Alasan", "LampiranUrl", "Status", "ApprovedBy", "CreatedAt"]
  },
  {
    id: 39,
    name: "REKAP_PRESENSI",
    category: "6. Presensi & Kehadiran",
    description: "Rekapitulasi persentase kehadiran bulanan siswa per kelas",
    primaryKey: "RekapID",
    headers: ["RekapID", "PeriodeBulan", "TahunAjaranID", "KelasID", "SiswaID", "Hadir", "Izin", "Sakit", "Alpa", "PersentaseHadir"]
  },
  {
    id: 40,
    name: "QR_LOG",
    category: "6. Presensi & Kehadiran",
    description: "Log pemindaian barcode / QR kartu pelajar siswa",
    primaryKey: "QRLogID",
    headers: ["QRLogID", "Tanggal", "UserID", "QRCode", "Latitude", "Longitude", "Device", "Browser", "Status", "Keterangan", "CreatedAt"]
  },

  // ==========================================
  // SECTION 7: ASESMEN & CBT ONLINE (41-48)
  // ==========================================
  {
    id: 41,
    name: "BANK_SOAL",
    category: "7. Asesmen & CBT Online",
    description: "Bank butir soal pilihan ganda, essay, bobot, dan kunci jawaban",
    primaryKey: "BankSoalID",
    headers: ["BankSoalID", "MapelID", "GuruID", "Bab", "SubBab", "Kompetensi", "Tingkat", "JenisSoal", "Soal", "PilihanA", "PilihanB", "PilihanC", "PilihanD", "PilihanE", "Jawaban", "Bobot", "Status", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 42,
    name: "UJIAN",
    category: "7. Asesmen & CBT Online",
    description: "Jadwal sesi ujian CBT, durasi, acak soal, dan token pengawas",
    primaryKey: "UjianID",
    headers: ["UjianID", "NamaUjian", "MapelID", "KelasID", "GuruID", "Tanggal", "JamMulai", "JamSelesai", "Durasi", "JumlahSoal", "AcakSoal", "AcakJawaban", "Token", "Status", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 43,
    name: "TOKEN",
    category: "7. Asesmen & CBT Online",
    description: "Daftar token ujian aktif & masa kedaluwarsa sesi",
    primaryKey: "TokenID",
    headers: ["TokenID", "UjianID", "Token", "Tanggal", "JamMulai", "JamSelesai", "Status", "CreatedAt"]
  },
  {
    id: 44,
    name: "SOAL",
    category: "7. Asesmen & CBT Online",
    description: "Distribusi butir soal yang diikutsertakan per paket ujian",
    primaryKey: "DetailSoalID",
    headers: ["DetailSoalID", "UjianID", "BankSoalID", "Nomor", "Bobot", "CreatedAt"]
  },
  {
    id: 45,
    name: "JAWABAN",
    category: "7. Asesmen & CBT Online",
    description: "Lembar jawaban pilihan dan essay siswa saat tes online",
    primaryKey: "JawabanID",
    headers: ["JawabanID", "UjianID", "SiswaID", "BankSoalID", "Jawaban", "Benar", "Nilai", "Tanggal", "CreatedAt"]
  },
  {
    id: 46,
    name: "DRAFT_JAWABAN",
    category: "7. Asesmen & CBT Online",
    description: "Backup sementara jawaban tes siswa secara realtime anti-hilang",
    primaryKey: "timestamp",
    headers: ["DraftID", "timestamp", "examId", "username", "jawaban", "sisaWaktu"]
  },
  {
    id: 47,
    name: "LOG_UJIAN",
    category: "7. Asesmen & CBT Online",
    description: "Catatan riwayat interaksi dan pengerjaan tes online per sesi siswa",
    primaryKey: "NO_LOG",
    headers: ["NO_LOG", "NISN", "NAMA_SISWA", "JENJANG", "KELAS", "STATUS", "Waktu", "Pelanggaran", "TOKEN", "ID_JADWAL"]
  },
  {
    id: 48,
    name: "HASIL_UJIAN",
    category: "7. Asesmen & CBT Online",
    description: "Rekapitulasi skor, jumlah benar/salah, dan peringkat nilai CBT",
    primaryKey: "HasilUjianID",
    headers: ["HasilUjianID", "UjianID", "SiswaID", "Benar", "Salah", "Kosong", "Nilai", "Peringkat", "Durasi", "Status", "CreatedAt"]
  },

  // ==========================================
  // SECTION 8: SPMB & PPDB ONLINE (49-55)
  // ==========================================
  {
    id: 49,
    name: "FORM_FIELDS",
    category: "8. SPMB & PPDB Online",
    description: "Konfigurasi formulir dinamis form builder pendaftaran online",
    primaryKey: "key",
    headers: ["key", "label", "type", "grid", "required", "show", "options"]
  },
  {
    id: 50,
    name: "SPMB_PENDAFTAR",
    category: "8. SPMB & PPDB Online",
    description: "Data registrasi pendaftar calon siswa baru (No Registrasi, Nama, NISN/JK, Jalur, Berkas)",
    primaryKey: "NoRegistrasi",
    headers: ["NoRegistrasi", "NamaCalonSiswa", "NISN", "JenisKelamin", "JalurMasuk", "StatusBerkas", "SkorSeleksi", "HasilKeputusan", "NoPDKT", "Kontak", "AsalSekolah", "Alamat", "TanggalDaftar"]
  },
  {
    id: 51,
    name: "SPMB_VERIFIKASI",
    category: "8. SPMB & PPDB Online",
    description: "Audit dan verifikasi keabsahan dokumen berkas fisik/digital pendaftar SPMB",
    primaryKey: "NoRegistrasi",
    headers: ["NoRegistrasi", "NamaCalonSiswa", "NISN", "StatusBerkas", "AktaKelahiran", "KartuKeluarga", "Ijazah", "KTPOrtu", "CatatanVerifikasi", "Verifikator", "TanggalVerifikasi"]
  },
  {
    id: 52,
    name: "SPMB_SELEKSI",
    category: "8. SPMB & PPDB Online",
    description: "Rekap penilaian, ujian seleksi, skor pembobotan, dan ranking calon siswa SPMB",
    primaryKey: "NoRegistrasi",
    headers: ["NoRegistrasi", "NamaCalonSiswa", "JalurMasuk", "NilaiAkademik", "NilaiWawancara", "NilaiPrestasi", "SkorSeleksi", "Ranking", "Rekomendasi", "StatusSeleksi"]
  },
  {
    id: 53,
    name: "SPMB_PENGUMUMAN",
    category: "8. SPMB & PPDB Online",
    description: "Hasil pengumuman kelulusan, penetapan SK resmi, dan status penerimaan calon siswa",
    primaryKey: "NoRegistrasi",
    headers: ["NoRegistrasi", "NamaCalonSiswa", "NISN", "JalurMasuk", "SkorSeleksi", "HasilKeputusan", "NomorSK", "TanggalPengumuman"]
  },
  {
    id: 54,
    name: "SPMB_DAFTAR_ULANG",
    category: "8. SPMB & PPDB Online",
    description: "Registrasi ulang calon siswa diterima, alokasi No PDKT, dan pembagian gugus/kelompok MPLS",
    primaryKey: "NoRegistrasi",
    headers: ["NoRegistrasi", "NamaCalonSiswa", "NISN", "NoPDKT", "KelompokMPLS", "StatusDaftarUlang", "TanggalDaftarUlang", "UkuranSeragam", "Catatan"]
  },
  {
    id: 55,
    name: "DAPODIK_VALIDASI",
    category: "8. SPMB & PPDB Online",
    description: "Data sinkronisasi dan audit validasi Dapodik 2027 (NISN, NIK, No KK, Ibu Kandung, Tanggal Lahir)",
    primaryKey: "ValidasiID",
    headers: ["ValidasiID", "SiswaID", "NISN", "NIK", "NoKK", "NamaSiswa", "NamaIbuKandung", "TanggalLahir", "StatusDapodik", "CatatanInvalid", "TglValidasi", "UpdatedAt"]
  },

  // ==========================================
  // SECTION 9: KEUANGAN & KAS (56-63)
  // ==========================================
  {
    id: 56,
    name: "BIAYA",
    category: "9. Keuangan & Tagihan",
    description: "Master tarif jenis biaya sekolah (Iuran, DSP, seragam, kegiatan)",
    primaryKey: "BiayaID",
    headers: ["BiayaID", "KodeBiaya", "NamaBiaya", "Kategori", "Jenjang", "Target_Kelas", "KelasID", "Nominal", "Periode", "Wajib", "Status", "Keterangan", "CreatedAt", "UpdatedAt", "JurusanID"]
  },
  {
    id: 57,
    name: "TAGIHAN",
    category: "9. Keuangan & Tagihan",
    description: "Daftar tagihan bulanan siswa dan tanggal jatuh tempo",
    primaryKey: "TagihanID",
    headers: ["TagihanID", "InvoiceID", "SiswaID", "BiayaID", "TahunAjaranID", "SemesterID", "TanggalTagihan", "TanggalJatuhTempo", "Nominal", "Diskon", "Denda", "TotalTagihan", "TotalBayar", "SisaTagihan", "Status", "PetugasID", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 58,
    name: "PEMBAYARAN",
    category: "9. Keuangan & Tagihan",
    description: "Kuitansi riwayat transaksi pembayaran kasir dari wali murid",
    primaryKey: "PembayaranID",
    headers: ["PembayaranID", "TagihanID", "InvoiceID", "SiswaID", "Tanggal", "Nominal", "MetodePembayaran", "NoReferensi", "Bank", "PetugasID", "Keterangan", "Status", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 59,
    name: "INVOICE",
    category: "9. Keuangan & Tagihan",
    description: "Faktur tagihan gabungan per siswa untuk periode tertentu",
    primaryKey: "InvoiceID",
    headers: ["InvoiceID", "NomorInvoice", "Tanggal", "SiswaID", "Total", "Diskon", "Denda", "GrandTotal", "Status", "TanggalBayar", "PetugasID", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 60,
    name: "TABUNGAN",
    category: "9. Keuangan & Tagihan",
    description: "Buku rekening tabungan siswa (setoran, penarikan & saldo)",
    primaryKey: "TabunganID",
    headers: ["TabunganID", "SiswaID", "Tanggal", "JenisTransaksi", "Debit", "Kredit", "Saldo", "PetugasID", "Keterangan", "Status", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 61,
    name: "KAS",
    category: "9. Keuangan & Tagihan",
    description: "Buku kas umum sekolah (pemasukan & arus kas operasional)",
    primaryKey: "KasID",
    headers: ["KasID", "Tanggal", "Jenis", "Kategori", "Nominal", "Keterangan", "Referensi", "PetugasID", "Status", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 62,
    name: "PENGELUARAN",
    category: "9. Keuangan & Tagihan",
    description: "Pengeluaran operasional sekolah dan bukti kuitansi belanja",
    primaryKey: "PengeluaranID",
    headers: ["PengeluaranID", "Tanggal", "Kategori", "NamaPengeluaran", "Nominal", "Penerima", "MetodePembayaran", "Bukti", "PetugasID", "Keterangan", "Status", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 63,
    name: "JURNAL_UMUM",
    category: "9. Keuangan & Tagihan",
    description: "Jurnal akuntansi debit-kredit kode akun keuangan sekolah",
    primaryKey: "JurnalID",
    headers: ["JurnalID", "Tanggal", "KodeAkun", "NamaAkun", "Keterangan", "Debit", "Kredit", "Referensi", "UserID", "CreatedAt", "UpdatedAt"]
  },

  // ==========================================
  // SECTION 10: BIMBINGAN KONSELING & TATIB (64-66)
  // ==========================================
  {
    id: 64,
    name: "BIMBINGAN",
    category: "10. Bimbingan Konseling (BK)",
    description: "Layanan konseling, solusi masalah, dan tindak lanjut siswa",
    primaryKey: "BimbinganID",
    headers: ["BimbinganID", "Tanggal", "SiswaID", "GuruBKID", "JenisBimbingan", "Permasalahan", "Solusi", "TindakLanjut", "Status", "Catatan", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 65,
    name: "PELANGGARAN",
    category: "10. Bimbingan Konseling (BK)",
    description: "Catatan pelanggaran tata tertib dan sistem poin siswa",
    primaryKey: "PelanggaranID",
    headers: ["PelanggaranID", "Tanggal", "SiswaID", "Kategori", "JenisPelanggaran", "Poin", "Sanksi", "GuruID", "Keterangan", "Status", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 66,
    name: "KARTU_POIN_SISWA",
    category: "10. Bimbingan Konseling (BK)",
    description: "Rekapitulasi akumulasi poin pelanggaran dan poin prestasi per siswa",
    primaryKey: "KartuID",
    headers: ["KartuID", "SiswaID", "TotalPoinPelanggaran", "TotalPoinPrestasi", "PoinBersih", "StatusPeringatan", "UpdatedAt"]
  },

  // ==========================================
  // SECTION 11: PERPUSTAKAAN (67-70)
  // ==========================================
  {
    id: 67,
    name: "BUKU",
    category: "11. Perpustakaan",
    description: "Katalog buku perpustakaan, ISBN, lokasi rak, dan stok",
    primaryKey: "BukuID",
    headers: ["BukuID", "ISBN", "KodeBuku", "Judul", "Penulis", "Penerbit", "TahunTerbit", "Kategori", "Rak", "Jumlah", "Stok", "Status", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 68,
    name: "PEMINJAMAN",
    category: "11. Perpustakaan",
    description: "Sirkulasi peminjaman dan pengembalian buku perpustakaan",
    primaryKey: "PeminjamanID",
    headers: ["PeminjamanID", "BukuID", "SiswaID", "GuruID", "TanggalPinjam", "TanggalKembali", "TanggalPengembalian", "Status", "Denda", "PetugasID", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 69,
    name: "DENDA",
    category: "11. Perpustakaan",
    description: "Catatan denda keterlambatan / penggantian buku rusak",
    primaryKey: "DendaID",
    headers: ["DendaID", "PeminjamanID", "Tanggal", "Nominal", "Status", "TanggalBayar", "PetugasID", "Keterangan", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 70,
    name: "PENGUNJUNG_PERPUS",
    category: "11. Perpustakaan",
    description: "Buku tamu dan pencatatan presensi pengunjung perpustakaan",
    primaryKey: "PengunjungID",
    headers: ["PengunjungID", "Tanggal", "UserID", "Nama", "Peran", "Keperluan", "WaktuMasuk", "WaktuKeluar"]
  },

  // ==========================================
  // SECTION 12: SARANA & PRASARANA (71-73)
  // ==========================================
  {
    id: 71,
    name: "BARANG",
    category: "12. Sarana & Prasarana",
    description: "Daftar aset sarana prasarana sekolah, lokasi, dan kondisi fisik",
    primaryKey: "BarangID",
    headers: ["BarangID", "KodeBarang", "NamaBarang", "Kategori", "Merk", "Tipe", "SerialNumber", "Jumlah", "Satuan", "Lokasi", "Kondisi", "Status", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 72,
    name: "PEMELIHARAAN",
    category: "12. Sarana & Prasarana",
    description: "Riwayat servis, perbaikan aset, dan biaya pemeliharaan barang",
    primaryKey: "PemeliharaanID",
    headers: ["PemeliharaanID", "BarangID", "Tanggal", "Jenis", "Biaya", "Pelaksana", "Hasil", "Keterangan", "Status", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 73,
    name: "PEMINJAMAN_BARANG",
    category: "12. Sarana & Prasarana",
    description: "Peminjaman sarana (proyektor, laptop, ruang, tenda, sound system)",
    primaryKey: "PeminjamanBarangID",
    headers: ["PeminjamanBarangID", "BarangID", "Peminjam", "Unit", "TanggalPinjam", "TanggalKembali", "TanggalPengembalian", "Jumlah", "Status", "PetugasID", "CreatedAt", "UpdatedAt"]
  },

  // ==========================================
  // SECTION 13: PERSURATAN, ARSIP & PORTAL (74-78)
  // ==========================================
  {
    id: 74,
    name: "SURAT_MASUK",
    category: "13. Persuratan & Dokumen",
    description: "Registrasi persuratan masuk dan disposisi kepala sekolah",
    primaryKey: "SuratMasukID",
    headers: ["SuratMasukID", "NoSurat", "Pengirim", "Perihal", "TanggalSurat", "TanggalDiterima", "FileUrl", "Status", "Disposisi", "CreatedAt"]
  },
  {
    id: 75,
    name: "SURAT_KELUAR",
    category: "13. Persuratan & Dokumen",
    description: "Registrasi nomor surat keluar dan dokumen arsip resmi sekolah",
    primaryKey: "SuratKeluarID",
    headers: ["SuratKeluarID", "NoSurat", "Tujuan", "Perihal", "TanggalSurat", "Penandatangan", "FileUrl", "Status", "Keterangan", "CreatedAt"]
  },
  {
    id: 76,
    name: "FILE",
    category: "13. Persuratan & Dokumen",
    description: "Master tautan file Google Drive, ukuran, dan modul pemilik",
    primaryKey: "FileID",
    headers: ["FileID", "Kategori", "Modul", "NamaFile", "NamaAsli", "URL", "Ukuran", "TipeFile", "UploadBy", "TanggalUpload", "Status", "Keterangan", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 77,
    name: "ARSIP",
    category: "13. Persuratan & Dokumen",
    description: "Registrasi arsip surat masuk/keluar dan dokumen penting sekolah",
    primaryKey: "ArsipID",
    headers: ["ArsipID", "Kategori", "NomorArsip", "Judul", "Tanggal", "Lokasi", "FileID", "Status", "Keterangan", "CreatedAt", "UpdatedAt"]
  },
  {
    id: 78,
    name: "SUARA_KOMUNITAS",
    category: "13. Persuratan & Dokumen",
    description: "Suara Komunitas Rombel, testimoni, masukan, dan harapan alumni/ortu/masyarakat",
    primaryKey: "id",
    headers: ["id", "nama", "peran", "teks", "status", "tanggal", "createdAt"]
  }
];

export const MASTER_TABLES_78 = MASTER_TABLES_60;
