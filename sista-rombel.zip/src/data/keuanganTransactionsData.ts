import { RAW_TAGIHAN_DATA } from './keuanganTagihanChunk1';
import { KeuanganPembayaranItem } from './keuanganTransactionsSeed';
import { KeuanganInvoice, KeuanganTagihan } from './keuanganSeed';

export const DEFAULT_TAGIHAN_LIST: KeuanganTagihan[] = [];

export const DEFAULT_PEMBAYARAN_LIST: KeuanganPembayaranItem[] = [];

export const DEFAULT_INVOICE_LIST: KeuanganInvoice[] = [];

