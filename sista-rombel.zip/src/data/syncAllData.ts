import { db } from './db';
import { DEFAULT_APP_CONFIG } from './config';

export interface SyncPayloadResult {
  totalTables: number;
  totalRecords: number;
  tables: { [tableName: string]: any[] };
}

/**
 * Mengumpulkan seluruh data yang tersimpan di aplikasi (Store & LocalStorage DB)
 * untuk dikirimkan secara serentak ke Google Spreadsheet.
 */
export function getAllAppDataForSync(storeStudents: any[] = [], storeTeachers: any[] = [], currentSettings: any = {}): { [tableName: string]: any[] } {
  const dataMap: { [tableName: string]: any[] } = {};

  // 1. SISTEM & AUTENTIKASI
  const profileSettings = {
    ...DEFAULT_APP_CONFIG,
    ...currentSettings,
    ...(db.getSingle('profil_sekolah') || {})
  };

  dataMap['SETTING'] = Object.keys(profileSettings).map(k => ({
    Key: k,
    Value: typeof profileSettings[k] === 'object' ? JSON.stringify(profileSettings[k]) : String(profileSettings[k] ?? '')
  }));

  dataMap['REFERENSI'] = db.get('referensi');
  dataMap['USERS'] = db.get('users');
  dataMap['ROLE'] = db.get('role');
  dataMap['MENU'] = db.get('menu');
  dataMap['HAK_AKSES'] = db.get('hak_akses');
  dataMap['SESSION'] = db.get('session');
  dataMap['LOG'] = db.get('logs');
  dataMap['AUDIT_LOG'] = db.get('audit_log');
  dataMap['NOTIFIKASI'] = db.get('notifikasi');

  // 2. KESISWAAN & GTK
  const students = storeStudents && storeStudents.length > 0 ? storeStudents : db.get('students');
  dataMap['SISWA'] = students;

  const teachers = storeTeachers && storeTeachers.length > 0 ? storeTeachers : db.get('teachers');
  dataMap['GURU'] = teachers;

  // Auto-generate Ortu & Yatim jika belum ada
  const savedOrtu = db.get('orang_tua');
  if (savedOrtu.length > 0) {
    dataMap['ORANG_TUA'] = savedOrtu;
  } else {
    dataMap['ORANG_TUA'] = students.map((s: any, idx: number) => ({
      OrtuID: `ORTU-${s.id || idx + 1}`,
      SiswaID: s.id || s.nis || s.nisn,
      Hubungan: s.hubunganWali || 'Orang Tua Kandung',
      Nama: s.parentName || s.namaAyah || s.namaIbu || s.namaWali || 'Orang Tua Siswa',
      NIK: s.nikAyah || s.nikIbu || '-',
      Pekerjaan: s.pekerjaanAyah || s.pekerjaanIbu || s.pekerjaanWali || '-',
      NoHP: s.tlpAyah || s.tlpIbu || s.tlpWali || s.noHp || '-',
      Alamat: s.address || '-'
    }));
  }

  // 3. AKADEMIK & KURIKULUM
  dataMap['KELAS'] = db.get('academic_classes');
  dataMap['JENJANG'] = db.get('academic_jenjang');
  dataMap['MAPEL'] = db.get('academic_subjects');
  dataMap['TAHUN_AJARAN'] = db.get('academic_years');
  dataMap['SEMESTER'] = db.get('academic_semesters');
  dataMap['HARI_LIBUR'] = db.get('academic_holidays');
  dataMap['JADWAL'] = db.get('academic_schedules');
  dataMap['AGENDA'] = db.get('academic_agendas');
  dataMap['NILAI'] = db.get('academic_grades');
  dataMap['RAPOR'] = db.get('academic_reports');
  dataMap['KENAIKAN_KELAS'] = db.get('academic_promotions');
  dataMap['KELULUSAN'] = db.get('academic_graduations');

  // 4. PRESENSI & QR CODE
  dataMap['ABSENSI'] = db.get('attendances');
  dataMap['ABSENSI_GURU'] = db.get('teacher_attendances');
  dataMap['QR_LOG'] = db.get('qr_logs');

  // 5. CBT & UJIAN ONLINE
  dataMap['BANK_SOAL'] = db.get('cbt_questions');
  dataMap['UJIAN'] = db.get('cbt_exams');
  dataMap['TOKEN'] = db.get('cbt_tokens');
  dataMap['SOAL'] = db.get('cbt_exam_questions');
  dataMap['JAWABAN'] = db.get('cbt_answers');
  dataMap['HASIL_UJIAN'] = db.get('cbt_results');
  dataMap['ANALISIS_SOAL'] = db.get('cbt_analysis');

  // 6. SPMB & PENDAFTARAN
  dataMap['PENDAFTAR'] = db.get('spmb_applicants');
  dataMap['BERKAS'] = db.get('spmb_files');
  dataMap['SELEKSI'] = db.get('spmb_selections');
  dataMap['DAFTAR_ULANG'] = db.get('spmb_re_registrations');
  dataMap['SPMB_PENDAFTAR'] = db.get('spmb_pendaftar');
  dataMap['SPMB_VERIFIKASI'] = db.get('spmb_verifikasi');
  dataMap['SPMB_SELEKSI'] = db.get('spmb_seleksi');
  dataMap['SPMB_PENGUMUMAN'] = db.get('spmb_pengumuman');
  dataMap['SPMB_DAFTAR_ULANG'] = db.get('spmb_daftar_ulang');

  // 7. KEUANGAN, TAGIHAN & KAS
  dataMap['BIAYA'] = db.get('keuangan_biaya');
  dataMap['TAGIHAN'] = db.get('keuangan_tagihan');
  dataMap['PEMBAYARAN'] = db.get('keuangan_pembayaran');
  dataMap['TABUNGAN'] = db.get('keuangan_tabungan');
  dataMap['KAS'] = db.get('keuangan_kas');
  dataMap['PENGELUARAN'] = db.get('keuangan_pengeluaran');
  dataMap['INVOICE'] = db.get('keuangan_invoices');
  dataMap['JURNAL_UMUM'] = db.get('keuangan_jurnal');

  // 8. BK (BIMBINGAN KONSELING)
  dataMap['BIMBINGAN'] = db.get('bk_counselings');
  dataMap['PELANGGARAN'] = db.get('bk_violations');

  // 9. PERPUSTAKAAN
  dataMap['BUKU'] = db.get('library_books');
  dataMap['PEMINJAMAN'] = db.get('library_borrowings');
  dataMap['DENDA'] = db.get('library_fines');

  // 10. SARPRAS & INVENTARIS
  dataMap['BARANG'] = db.get('sarpras_items');
  dataMap['PEMELIHARAAN'] = db.get('sarpras_maintenance');
  dataMap['PEMINJAMAN_BARANG'] = db.get('sarpras_borrowings');

  // 11. ARSIP & DOKUMEN
  dataMap['FILE'] = db.get('archived_files');
  dataMap['ARSIP'] = db.get('archived_documents');

  // 12. DASHBOARD, BACKUP & KOMUNITAS
  dataMap['DASHBOARD_CACHE'] = db.get('dashboard_cache');
  dataMap['BACKUP'] = db.get('backup_logs');
  dataMap['SUARA_KOMUNITAS'] = db.get('suara_komunitas');

  // 13. ALUMNI & LOG UJIAN
  dataMap['ALUMNI'] = db.get('alumni');
  dataMap['LOG_UJIAN'] = db.get('exam_logs');
  dataMap['DRAFT_JAWABAN'] = db.get('exam_drafts');

  // 14. FORM BUILDER, CMS & VALIDASI DAPODIK
  dataMap['FORM_FIELDS'] = db.get('form_fields');
  dataMap['WEB_CONFIG'] = [profileSettings];
  dataMap['SESSIONS'] = db.get('sessions');
  dataMap['DAPODIK_VALIDASI'] = db.get('dapodik_validations');

  // 15. TUGAS, PRESTASI, SURAT, YATIM
  dataMap['TUGAS'] = db.get('assignments');
  dataMap['PENGUMPULAN_TUGAS'] = db.get('assignment_submissions');
  dataMap['PRESTASI_SISWA'] = db.get('student_achievements');
  dataMap['SURAT_MASUK'] = db.get('letters_incoming');
  dataMap['SURAT_KELUAR'] = db.get('letters_outgoing');

  const savedYatim = db.get('yatim_piatu');
  if (savedYatim.length > 0) {
    dataMap['YATIM_PIATU'] = savedYatim;
  } else {
    dataMap['YATIM_PIATU'] = students
      .filter((s: any) => s.statusYatim && s.statusYatim !== 'Lengkap')
      .map((s: any, idx: number) => ({
        YatimID: `YTM-${s.id || idx + 1}`,
        NoPDKT: s.nis || s.id,
        NISN: s.nisn || '-',
        NamaSiswa: s.name || s.NamaLengkap || 'Siswa',
        Kelas: s.class || '1A',
        StatusYatim: s.statusYatim,
        NamaAyah: s.namaAyah || '-',
        StatusAyah: s.statusAyah || 'Masih Hidup',
        NamaIbu: s.namaIbu || '-',
        StatusIbu: s.statusIbu || 'Masih Hidup',
        NamaWali: s.namaWali || '-',
        NoHPWali: s.tlpWali || s.noHp || '-',
        Alamat: s.address || '-',
        PenerimaKPS_PIP: s.penerimaKps || 'Tidak',
        Keterangan: `Siswa terdaftar status ${s.statusYatim}`
      }));
  }

  return dataMap;
}
