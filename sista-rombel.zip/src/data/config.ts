// KONFIGURASI DEFAULT RESMI LEMBAGA - DIPATENKAN
// Nilai-nilai di bawah ini adalah default permanen aplikasi

export const DEFAULT_APP_CONFIG = {
  appName: "ROMBEL TAMBORA",
  schoolName: "ROMBEL TAMBORA",
  schoolLogoUrl: "https://lh3.googleusercontent.com/d/1Tg-mI0FDd8VDck4LVYt9NiDifdnoAyiJ",
  rawDriveLogoLink: "https://drive.google.com/file/d/1Tg-mI0FDd8VDck4LVYt9NiDifdnoAyiJ/view?usp=drive_link",
  scriptUrl: "https://script.google.com/macros/s/AKfycbz9ElB9x-jfZ7ZZSThMSi_QLm80VuJ7AWKAw1VX5XTi_le0ZNwD6NcI43L2yPtOj1k/exec",
  spreadsheetId: "1XTfNFkele0iVbb7W8qlJDujWKFbq-bqJO5VabY82bCk",
  folderId: "13W6zz_g_nN-zGJdbquP4H4NvXrZZLk0j",
  folderSiswaId: "1DfCtp8BbsRzFafEa8fk30Suq-aVQoS7V",
  tahunPelajaran: "2026/2027",
  adminUsername: "admin",
  adminPassword: "admin",
};
