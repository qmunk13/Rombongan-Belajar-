import { db } from './db';

export interface ArsipDigital {
  id: string;
  nomorDokumen: string;
  judulDokumen: string;
  kategori: 'SK & Regulasi' | 'Akreditasi' | 'Kurikulum' | 'Laporan Keuangan' | 'Administrasi GTK' | 'Sarpras & Aset' | 'Kesiswaan';
  tahunAjaran: string;
  tahunTerbit: string;
  formatFile: 'PDF' | 'DOCX' | 'XLSX' | 'SCAN / JPG';
  ukuranFile: string;
  fileUrl: string;
  pengunggah: string;
  tingkatAkses: 'Publik' | 'Internal Guru' | 'Pimpinan & TU' | 'Rahasia';
  deskripsi: string;
  tags: string[];
  createdAt: string;
}

export interface SuratMasuk {
  id: string;
  noAgenda: string;
  noSuratAsal: string;
  tanggalSurat: string;
  tanggalDiterima: string;
  pengirim: string;
  kategoriPengirim: 'Dinas Pendidikan' | 'Kemenag' | 'Sekolah Lain' | 'Yayasan' | 'Perguruan Tinggi' | 'Instansi Swasta' | 'Masyarakat';
  perihal: string;
  sifat: 'Sangat Segera' | 'Penting' | 'Biasa' | 'Rahasia';
  statusDisposisi: 'Menunggu Disposisi' | 'Didisposisikan' | 'Dalam Proses' | 'Selesai';
  instruksiDisposisi?: string;
  diteruskanKepada?: string;
  tenggatWaktu?: string;
  catatanKepsek?: string;
  lampiranNama?: string;
  lampiranUrl?: string;
  penerimaBerkas: string;
  createdAt: string;
}

export interface SuratKeluar {
  id: string;
  noSurat: string;
  kodeKlasifikasi: string;
  tanggalSurat: string;
  jenisSurat: 'Surat Keterangan Siswa Aktif' | 'Undangan Rapat Orang Tua' | 'Surat Tugas Guru' | 'Surat Rekomendasi' | 'Permohonan Izin / Kunjungan' | 'Panggilan Orang Tua' | 'Surat Pengantar Dinas';
  penerima: string;
  alamatPenerima?: string;
  perihal: string;
  isiSurat?: string;
  penandatangan: string;
  jabatanPenandatangan: string;
  status: 'Diterbitkan / Sah' | 'Draft' | 'Terkirim' | 'Dibatalkan';
  siswaId?: string;
  namaSiswa?: string;
  nisn?: string;
  kelas?: string;
  keperluan?: string;
  tembusan?: string;
  createdAt: string;
}

export interface MasterTemplateSurat {
  id: string;
  kodeTemplate: string;
  namaTemplate: string;
  kategori: 'Kesiswaan' | 'Kepegawaian' | 'Humas & Kerjasama' | 'Akademik' | 'Administrasi Umum';
  deskripsi: string;
  variabel: string[];
  penandatanganDefault: string;
  jabatanDefault: string;
  formatKop: string;
  strukturIsi: string;
  status: 'Aktif' | 'Nonaktif';
  updatedAt: string;
}

export const INITIAL_ARSIP_SEED: ArsipDigital[] = [];

export const INITIAL_SURAT_MASUK_SEED: SuratMasuk[] = [];

export const INITIAL_SURAT_KELUAR_SEED: SuratKeluar[] = [];

export const INITIAL_TEMPLATE_SEED: MasterTemplateSurat[] = [
  {
    id: 'TPL-001',
    kodeTemplate: 'TPL-KET-AKTIF',
    namaTemplate: 'Surat Keterangan Siswa Aktif Belajar',
    kategori: 'Kesiswaan',
    deskripsi: 'Format standar keterangan bahwa peserta didik masih aktif bersekolah untuk keperluan beasiswa, BPJS, atau tunjangan kerja.',
    variabel: ['{{NO_SURAT}}', '{{NAMA_SISWA}}', '{{NISN}}', '{{KELAS}}', '{{TEMPAT_TANGGAL_LAHIR}}', '{{NAMA_ORTU}}', '{{ALAMAT}}', '{{KEPERLUAN}}', '{{TANGGAL_SURAT}}', '{{NAMA_KEPSEK}}', '{{NIP_KEPSEK}}'],
    penandatanganDefault: '',
    jabatanDefault: 'Kepala Sekolah',
    formatKop: 'KOP RESMI SEKOLAH LENGKAP DENGAN LOGO & NPSN',
    strukturIsi: `Yang bertanda tangan di bawah ini Kepala Sekolah menerangkan dengan sebenarnya bahwa:
Nama: {{NAMA_SISWA}}
NISN / NIS: {{NISN}}
Kelas / Program: {{KELAS}}
Tempat, Tgl Lahir: {{TEMPAT_TANGGAL_LAHIR}}
Nama Orang Tua / Wali: {{NAMA_ORTU}}

Adalah benar peserta didik yang tercatat aktif mengikuti kegiatan pembelajaran pada Tahun Ajaran 2026/2027.
Surat keterangan ini diberikan untuk keperluan: {{KEPERLUAN}}.`,
    status: 'Aktif',
    updatedAt: '2026-01-15',
  },
  {
    id: 'TPL-002',
    kodeTemplate: 'TPL-TUGAS-GURU',
    namaTemplate: 'Surat Tugas Pendidik / Tenaga Kependidikan',
    kategori: 'Kepegawaian',
    deskripsi: 'Format penugasan resmi guru untuk mengikuti pelatihan, rapat dinas, diklat, atau pendampingan lomba.',
    variabel: ['{{NO_SURAT}}', '{{NAMA_GURU}}', '{{NIP_NUPTK}}', '{{JABATAN}}', '{{AGENDA_TUGAS}}', '{{LOKASI_TUGAS}}', '{{WAKTU_PELAKSANAAN}}', '{{TANGGAL_SURAT}}', '{{NAMA_KEPSEK}}'],
    penandatanganDefault: '',
    jabatanDefault: 'Kepala Sekolah',
    formatKop: 'KOP RESMI SEKOLAH LENGKAP',
    strukturIsi: `Kepala Sekolah dengan ini menugaskan kepada:
Nama: {{NAMA_GURU}}
NIP / NUPTK: {{NIP_NUPTK}}
Jabatan: {{JABATAN}}

Untuk melaksanakan tugas: {{AGENDA_TUGAS}}, yang akan diselenggarakan pada:
Hari / Tanggal: {{WAKTU_PELAKSANAAN}}
Tempat: {{LOKASI_TUGAS}}

Demikian surat tugas ini diberikan agar dapat dilaksanakan dengan penuh tanggung jawab.`,
    status: 'Aktif',
    updatedAt: '2026-01-20',
  },
  {
    id: 'TPL-003',
    kodeTemplate: 'TPL-UNDANGAN-ORTU',
    namaTemplate: 'Surat Undangan Rapat / Pertemuan Orang Tua Murid',
    kategori: 'Humas & Kerjasama',
    deskripsi: 'Format undangan resmi kepada orang tua/wali murid untuk rapat pleno, pembagian rapor, atau sosialisasi program.',
    variabel: ['{{NO_SURAT}}', '{{PERIHAL}}', '{{HARI_TANGGAL}}', '{{WAKTU}}', '{{TEMPAT}}', '{{AGENDA}}', '{{TANGGAL_SURAT}}', '{{NAMA_KEPSEK}}'],
    penandatanganDefault: '',
    jabatanDefault: 'Kepala Sekolah',
    formatKop: 'KOP RESMI SEKOLAH LENGKAP',
    strukturIsi: `Dengan hormat, sehubungan dengan program sekolah tahun ajaran 2026/2027, kami mengundang Bapak/Ibu Orang Tua/Wali Murid untuk hadir pada:
Hari / Tanggal: {{HARI_TANGGAL}}
Waktu: {{WAKTU}}
Tempat: {{TEMPAT}}
Acara: {{AGENDA}}

Mengingat pentingnya acara tersebut, kami sangat mengharapkan kehadiran Bapak/Ibu tepat pada waktunya.`,
    status: 'Aktif',
    updatedAt: '2026-02-01',
  },
  {
    id: 'TPL-004',
    kodeTemplate: 'TPL-REKOM-BEASISWA',
    namaTemplate: 'Surat Rekomendasi Beasiswa & Studi Lanjut',
    kategori: 'Kesiswaan',
    deskripsi: 'Format surat rekomendasi siswa berprestasi untuk seleksi beasiswa kuliah / pelatihan.',
    variabel: ['{{NO_SURAT}}', '{{NAMA_SISWA}}', '{{NISN}}', '{{KELAS}}', '{{PRESTASI_UTAMA}}', '{{INSTANSI_TUJUAN}}', '{{TANGGAL_SURAT}}', '{{NAMA_KEPSEK}}'],
    penandatanganDefault: '',
    jabatanDefault: 'Kepala Sekolah',
    formatKop: 'KOP RESMI SEKOLAH LENGKAP',
    strukturIsi: `Kepala Sekolah memberikan rekomendasi kepada siswa berprestasi berikut:
Nama: {{NAMA_SISWA}}
NISN: {{NISN}}
Kelas: {{KELAS}}

Berdasarkan rekam jejak akademik, kepribadian, serta capaian: {{PRESTASI_UTAMA}}, siswa tersebut dinilai sangat layak dan direkomendasikan untuk mengikuti program {{INSTANSI_TUJUAN}}.`,
    status: 'Aktif',
    updatedAt: '2026-02-10',
  }
];

export function ensureDokumenSeedData() {
  if ((db.get('template_surat') || []).length === 0) {
    db.set('template_surat', INITIAL_TEMPLATE_SEED);
  }
}
