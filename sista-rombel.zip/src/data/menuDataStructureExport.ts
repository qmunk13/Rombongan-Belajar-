import * as XLSX from 'xlsx';
import { MASTER_TABLES_60, TableSchema } from './masterDatabase60';

export interface MenuDataStructureRow {
  no: number;
  idMenu: string;
  sidebar: string;
  namaMenu: string;
  icon: string;
  sheet: string;
  headerSheet: string;
  namaListTampilan: string;
  statusTampil: 'ya' | 'Tidak';
  type?: string;
  grid?: string;
  keterangan?: string;
  contohIsian?: string;
}

// Icon dictionary for all 78 tables
const TABLE_ICONS: Record<string, string> = {
  SETTING: 'Settings',
  WEB_CONFIG: 'Globe',
  REFERENSI: 'Layers',
  USERS: 'Users',
  ROLE: 'Shield',
  MENU: 'Menu',
  HAK_AKSES: 'Key',
  SESSION: 'Laptop',
  LOG: 'Clock',
  AUDIT_LOG: 'FileText',
  SISWA: 'UserCheck',
  ORANG_TUA: 'Users',
  YATIM_PIATU: 'Heart',
  PRESTASI_SISWA: 'Award',
  KENAIKAN_KELAS: 'TrendingUp',
  KELULUSAN: 'GraduationCap',
  ALUMNI: 'Briefcase',
  GURU: 'User',
  JABATAN_GTK: 'Award',
  RIWAYAT_MENGAJAR: 'BookOpen',
  TAHUN_AJARAN: 'Calendar',
  SEMESTER: 'Clock',
  JENJANG: 'Layers',
  KELAS: 'LayoutGrid',
  MAPEL: 'Book',
  HARI_LIBUR: 'CalendarOff',
  JADWAL: 'Clock',
  AGENDA: 'FileText',
  TUGAS: 'Clipboard',
  PENGUMPULAN_TUGAS: 'CheckSquare',
  MATERI_DIGITAL: 'FileCode',
  CP_ATP: 'Target',
  NILAI: 'Star',
  RAPOR: 'FileSpreadsheet',
  ABSENSI: 'CheckCircle',
  ABSENSI_GURU: 'UserCheck',
  IZIN_SAKIT_SISWA: 'FileText',
  IZIN_CUTI_GURU: 'Calendar',
  REKAP_PRESENSI: 'BarChart',
  QR_LOG: 'QrCode',
  BANK_SOAL: 'HelpCircle',
  UJIAN: 'Clock',
  TOKEN: 'Key',
  SOAL: 'List',
  JAWABAN: 'Check',
  DRAFT_JAWABAN: 'Save',
  LOG_UJIAN: 'AlertTriangle',
  HASIL_UJIAN: 'Award',
  FORM_FIELDS: 'Sliders',
  SPMB_PENDAFTAR: 'UserPlus',
  SPMB_VERIFIKASI: 'CheckCircle',
  SPMB_SELEKSI: 'CheckSquare',
  SPMB_PENGUMUMAN: 'Bell',
  SPMB_DAFTAR_ULANG: 'FileCheck',
  DAPODIK_VALIDASI: 'ShieldCheck',
  BIAYA: 'Tag',
  TAGIHAN: 'CreditCard',
  PEMBAYARAN: 'Receipt',
  INVOICE: 'FileText',
  TABUNGAN: 'PiggyBank',
  KAS: 'DollarSign',
  PENGELUARAN: 'TrendingDown',
  JURNAL_UMUM: 'Book',
  BIMBINGAN: 'Smile',
  PELANGGARAN: 'AlertOctagon',
  KARTU_POIN_SISWA: 'ShieldAlert',
  BUKU: 'Book',
  PEMINJAMAN: 'Bookmark',
  DENDA: 'DollarSign',
  PENGUNJUNG_PERPUS: 'Users',
  BARANG: 'Package',
  PEMELIHARAAN: 'Tool',
  PEMINJAMAN_BARANG: 'Truck',
  SURAT_MASUK: 'Inbox',
  SURAT_KELUAR: 'Send',
  FILE: 'HardDrive',
  ARSIP: 'Archive',
  SUARA_KOMUNITAS: 'MessageSquare'
};

// Category / Sidebar mapping
function getSidebarName(category: string): string {
  if (category.includes('Sistem')) return 'Pengaturan & Sistem';
  if (category.includes('Kesiswaan')) return 'Master Kesiswaan';
  if (category.includes('Pendidik')) return 'Tenaga Pendidik (GTK)';
  if (category.includes('Akademik')) return 'Akademik & Kurikulum';
  if (category.includes('Penugasan')) return 'Penugasan & Rapor';
  if (category.includes('Presensi')) return 'Presensi & Kehadiran';
  if (category.includes('Asesmen') || category.includes('CBT')) return 'Asesmen & CBT Online';
  if (category.includes('SPMB') || category.includes('PPDB')) return 'SPMB & PPDB Online';
  if (category.includes('Keuangan')) return 'Keuangan, Tagihan & Kas';
  if (category.includes('Bimbingan')) return 'Bimbingan Konseling';
  if (category.includes('Perpustakaan')) return 'Perpustakaan Digital';
  if (category.includes('Sarana')) return 'Sarana & Prasarana';
  if (category.includes('Persuratan')) return 'Persuratan & Komunitas';
  return category;
}

// Friendly display name dictionary for common fields
const KNOWN_FIELD_LABELS: Record<string, string> = {
  nopdkt: 'Nomor Induk Siswa (No PDKT)',
  no_pdkt: 'Nomor Induk Siswa (No PDKT)',
  nisn: 'Nomor Induk Siswa Nasional (NISN)',
  nik: 'Nomor Induk Kependudukan (NIK)',
  nuptk: 'Nomor Unik Pendidik (NUPTK)',
  nip: 'Nomor Induk Pegawai (NIP)',
  namalengkap: 'Nama Lengkap Siswa',
  namasiswa: 'Nama Lengkap Siswa',
  jeniskelamin: 'Jenis Kelamin (L/P)',
  tempatlahir: 'Tempat Lahir',
  tanggallahir: 'Tanggal Lahir',
  agama: 'Agama',
  golongandarah: 'Golongan Darah',
  tinggibadan: 'Tinggi Badan (cm)',
  beratbadan: 'Berat Badan (kg)',
  alamat: 'Alamat Tempat Tinggal',
  rt: 'Rukun Tetangga (RT)',
  rw: 'Rukun Warga (RW)',
  kelurahan: 'Kelurahan / Desa',
  kecamatan: 'Kecamatan',
  kota: 'Kota / Kabupaten',
  provinsi: 'Provinsi',
  kodepos: 'Kode Pos',
  nomorhp: 'Nomor HP / WhatsApp',
  email: 'Alamat Email',
  status: 'Status Data',
  createdat: 'Waktu Dibuat',
  updatedat: 'Waktu Diperbarui',
  password: 'Kata Sandi / Password Hash',
  token: 'Token Autentikasi Sesi'
};

function formatHeaderToLabel(header: string, sheet: string): string {
  const cleanKey = header.toLowerCase().replace(/[^a-z0-9]/g, '');
  if (KNOWN_FIELD_LABELS[cleanKey]) {
    return KNOWN_FIELD_LABELS[cleanKey];
  }

  // Convert CamelCase or snake_case to Space Separated Words
  const spaced = header
    .replace(/([A-Z])/g, ' $1')
    .replace(/_/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();

  return spaced.charAt(0).toUpperCase() + spaced.slice(1);
}

/**
 * Intelligent metadata resolver for any column across 78 sheets
 */
function resolveHeaderMetadata(table: TableSchema, header: string): {
  type: string;
  grid: string;
  keterangan: string;
  contohIsian: string;
  statusTampil: 'ya' | 'Tidak';
} {
  const h = header.toLowerCase().replace(/[^a-z0-9]/g, '');
  const rawH = header.toLowerCase();
  const sheet = table.name.toUpperCase();

  let type = 'Text (String)';
  let grid = 'col-span-6 (1/2 Lebar)';
  let keterangan = `Input data ${formatHeaderToLabel(header, sheet)} pada tabel ${table.name}`;
  let contohIsian = 'Contoh Isian Data';
  let statusTampil: 'ya' | 'Tidak' = 'ya';

  // 1. Passwords & Tokens (Internal / Hidden)
  if (h.includes('password') || h === 'token' || h === 'refreshtoken' || h === 'apisecret') {
    type = 'Password / Hash (Teks Terenkripsi)';
    grid = 'col-span-6 (1/2 Lebar)';
    keterangan = 'Kredensial keamanan rahasia yang dienkripsi sistem';
    contohIsian = '$2a$12$eXamPLeHasHeDsTrInG12345';
    statusTampil = 'Tidak';
    return { type, grid, keterangan, contohIsian, statusTampil };
  }

  // 2. Primary Keys & Identifiers
  if (header === table.primaryKey || h.endsWith('id') || h === 'kode' || h === 'key' || h === 'nopdkt') {
    type = 'Text (Primary Key / Kode Unik)';
    grid = 'col-span-4 (1/3 Lebar)';
    keterangan = `Kode identifikasi unik (Primary Key) untuk record tabel ${table.name}`;
    if (h === 'nopdkt') {
      contohIsian = '2026-001';
    } else if (h.includes('user')) {
      contohIsian = 'USR_001';
    } else if (h.includes('guru')) {
      contohIsian = 'GR_001';
    } else if (h.includes('siswa')) {
      contohIsian = 'SIS_2026_001';
    } else if (h.includes('kelas')) {
      contohIsian = 'KLS_XRPL1';
    } else if (h.includes('mapel')) {
      contohIsian = 'MP_MAT01';
    } else if (h.includes('tagihan')) {
      contohIsian = 'TGH_202608_001';
    } else if (h.includes('bayar') || h.includes('pembayaran')) {
      contohIsian = 'BYR_20260822_001';
    } else if (h.includes('buku')) {
      contohIsian = 'BK_TIK_001';
    } else if (h.includes('barang')) {
      contohIsian = 'BRG_LAB_001';
    } else {
      contohIsian = `${table.name.slice(0, 3)}_001`;
    }
  }

  // 3. Official IDs (NISN, NIK, NUPTK, NIP, NPSN, KK)
  else if (h.includes('nisn')) {
    type = 'Number (10 Digit)';
    grid = 'col-span-4 (1/3 Lebar)';
    keterangan = 'Nomor Induk Siswa Nasional 10 digit resmi Dapodik Kemdikbud';
    contohIsian = '0081234567';
  } else if (h.includes('nik')) {
    type = 'Number (16 Digit)';
    grid = 'col-span-4 (1/3 Lebar)';
    keterangan = 'Nomor Induk Kependudukan 16 digit sesuai Kartu Keluarga / KTP';
    contohIsian = '3171012304080001';
  } else if (h.includes('nuptk')) {
    type = 'Number (16 Digit)';
    grid = 'col-span-4 (1/3 Lebar)';
    keterangan = 'Nomor Unik Pendidik & Tenaga Kependidikan (16 digit)';
    contohIsian = '9834752648291043';
  } else if (h.includes('nip')) {
    type = 'Text (18 Digit)';
    grid = 'col-span-4 (1/3 Lebar)';
    keterangan = 'Nomor Induk Pegawai PNS/P3K atau NIK Pegawai Yayasan';
    contohIsian = '198503152010011005';
  } else if (h === 'npsn') {
    type = 'Number (8 Digit)';
    grid = 'col-span-4 (1/3 Lebar)';
    keterangan = 'Nomor Pokok Sekolah Nasional resmi Kemdikbud (8 digit)';
    contohIsian = '20101234';
  } else if (h.includes('kartukeluarga') || h.includes('nokk')) {
    type = 'Number (16 Digit)';
    grid = 'col-span-4 (1/3 Lebar)';
    keterangan = 'Nomor Kartu Keluarga (16 digit) sesuai lembar KK asli';
    contohIsian = '3171010101200005';
  } else if (h.includes('isbn')) {
    type = 'Text (ISBN-13)';
    grid = 'col-span-4 (1/3 Lebar)';
    keterangan = 'Nomor Standar Buku Internasional (ISBN) 13 digit';
    contohIsian = '978-602-8519-93-8';
  }

  // 4. Dates & Timestamps
  else if (h.includes('tanggal') || h.includes('tgl') || h.includes('tenggat') || h.includes('tmt') || h.includes('date') || h === 'createdat' || h === 'updatedat' || h === 'lastlogin') {
    if (h === 'createdat' || h === 'updatedat' || h === 'lastlogin' || h.includes('waktu')) {
      type = 'DateTime (ISO Timestamp)';
      grid = 'col-span-4 (1/3 Lebar)';
      keterangan = 'Waktu pencatatan sistem otomatis format ISO (YYYY-MM-DD HH:mm:ss)';
      contohIsian = '2026-08-22 10:30:00';
    } else if (h.includes('lahir')) {
      type = 'Date (YYYY-MM-DD)';
      grid = 'col-span-4 (1/3 Lebar)';
      keterangan = 'Tanggal lahir valid format YYYY-MM-DD sesuai akta kelahiran';
      contohIsian = '2010-05-14';
    } else if (h.includes('tenggat') || h.includes('tempo')) {
      type = 'Date (YYYY-MM-DD)';
      grid = 'col-span-4 (1/3 Lebar)';
      keterangan = 'Batas akhir tenggat pembayaran / penyerahan tugas (YYYY-MM-DD)';
      contohIsian = '2026-10-10';
    } else {
      type = 'Date (YYYY-MM-DD)';
      grid = 'col-span-4 (1/3 Lebar)';
      keterangan = 'Tanggal transaksi / kegiatan format YYYY-MM-DD';
      contohIsian = '2026-08-22';
    }
  }

  // 5. Currency & Financial Numbers
  else if (h.includes('nominal') || h.includes('biaya') || h.includes('tagihan') || h.includes('bayar') || h.includes('tarif') || h.includes('debit') || h.includes('kredit') || h.includes('saldo') || h.includes('denda') || h.includes('gaji') || h.includes('harga') || h.includes('totalkas') || h.includes('penghasilan') || h.includes('uang')) {
    type = 'Currency (Rupiah)';
    grid = 'col-span-4 (1/3 Lebar)';
    keterangan = 'Besaran nominal nilai uang dalam satuan Rupiah (angka bulat tanpa titik/koma)';
    if (h.includes('penghasilan')) {
      contohIsian = '4500000';
    } else if (h.includes('denda')) {
      contohIsian = '5000';
    } else {
      contohIsian = '250000';
    }
  }

  // 6. Cloud Drive Files, Photos & URLs
  else if (h.includes('foto') || h.includes('url') || h.includes('file') || h.includes('sertifikat') || h.includes('bukti') || h.includes('ijazah') || h.includes('rapor') || h.includes('akta') || h.includes('kartu') || h.includes('kia') || h.includes('ktp') || h.includes('lampiran') || h.includes('dokumen') || h.includes('pdf') || h.includes('link') || h.includes('spindah') || h.includes('suket') || h.includes('sdomisili')) {
    type = 'File URL / Cloud Drive';
    grid = 'col-span-6 (1/2 Lebar)';
    keterangan = 'Tautan URL file dokumen resmi yang tersimpan di Google Drive / Cloud Storage';
    contohIsian = 'https://drive.google.com/file/d/1a2b3c4d5e6f/view';
  }

  // 7. Phone Numbers & WhatsApp
  else if (h.includes('hp') || h.includes('telepon') || h.includes('tlp') || h.includes('wa') || h.includes('whatsapp') || h.includes('phone') || h.includes('kontak')) {
    type = 'Phone / WhatsApp';
    grid = 'col-span-4 (1/3 Lebar)';
    keterangan = 'Nomor telepon / WhatsApp aktif diawali angka 08 (10-13 digit)';
    contohIsian = '081234567890';
  }

  // 8. Email Addresses
  else if (h.includes('email') || h.includes('mail')) {
    type = 'Email';
    grid = 'col-span-4 (1/3 Lebar)';
    keterangan = 'Alamat surel aktif format user@domain.com';
    contohIsian = 'user.sekolah@gmail.com';
  }

  // 9. Dropdown Selects / Enums / Flags
  else if (h === 'jeniskelamin' || h === 'jk') {
    type = 'Select (L / P)';
    grid = 'col-span-3 (1/4 Lebar)';
    keterangan = 'Pilihan jenis kelamin: L (Laki-laki) atau P (Perempuan)';
    contohIsian = 'L';
  } else if (h === 'agama') {
    type = 'Select (Dropdown)';
    grid = 'col-span-3 (1/4 Lebar)';
    keterangan = 'Pilihan agama: Islam, Kristen, Katolik, Hindu, Buddha, Khonghucu';
    contohIsian = 'Islam';
  } else if (h.includes('golongandarah') || h === 'goldarah') {
    type = 'Select (Dropdown)';
    grid = 'col-span-3 (1/4 Lebar)';
    keterangan = 'Golongan darah: A, B, AB, O, atau Tidak Tahu';
    contohIsian = 'O';
  } else if (h === 'statussiswa' || (sheet === 'SISWA' && h === 'status')) {
    type = 'Select (Status Siswa)';
    grid = 'col-span-4 (1/3 Lebar)';
    keterangan = 'Status siswa: AKTIF, TIDAK AKTIF, BELUM, PINDAH, KELUAR, LULUS, DROP_OUT, MENINGGAL';
    contohIsian = 'AKTIF';
  } else if (h === 'status' || h.endsWith('status')) {
    type = 'Select (Status)';
    grid = 'col-span-3 (1/4 Lebar)';
    keterangan = 'Status record: Aktif, Non-Aktif, Lunas, Pending, Selesai';
    contohIsian = 'Aktif';
  } else if (h === 'semester') {
    type = 'Select (Dropdown)';
    grid = 'col-span-3 (1/4 Lebar)';
    keterangan = 'Pilihan semester ajaran: Ganjil atau Genap';
    contohIsian = 'Ganjil';
  } else if (h === 'jenjang' || h === 'jenjangpendidikan' || (sheet === 'JENJANG' && (h === 'nama' || h === 'namajenjang'))) {
    type = 'Select (Jenjang Pendidikan)';
    grid = 'col-span-4 (1/3 Lebar)';
    keterangan = 'Pilihan jenjang pendidikan: Paket A, Paket B, Paket C';
    contohIsian = 'Paket A';
  } else if (h === 'hari' || h === 'harijadwal') {
    type = 'Select (Hari)';
    grid = 'col-span-3 (1/4 Lebar)';
    keterangan = 'Pilihan hari jadwal: Senin, Selasa, Rabu, Kamis, Jumat, Sabtu, Minggu';
    contohIsian = 'Senin';
  } else if (h === 'kategoribiaya' || (sheet === 'BIAYA' && (h === 'kategori' || h === 'kategoripos'))) {
    type = 'Select (Kategori Biaya)';
    grid = 'col-span-4 (1/3 Lebar)';
    keterangan = 'Kategori pos biaya: Iuran, Uang Pangkal, Uang Seragam, Uang Gedung, Kegiatan, Ujian, Lain-lain';
    contohIsian = 'Iuran';
  } else if (h === 'kelassaatini' || (sheet === 'SISWA' && (h === 'kelas' || h === 'idkelas' || h === 'kelasid'))) {
    type = 'Select (Master KELAS)';
    grid = 'col-span-4 (1/3 Lebar)';
    keterangan = 'Mengambil otomatis dari master KELAS (contoh: 4, 5, 6, 7, 8, 9, 10, 11, 12)';
    contohIsian = '4';
  } else if (h.includes('role')) {
    type = 'Select (32 Hak Akses)';
    grid = 'col-span-4 (1/3 Lebar)';
    keterangan = 'Peran hak akses pengguna (Admin, Kepala Sekolah, Guru, Bendahara, Siswa, dll)';
    contohIsian = 'Guru Mapel';
  } else if (h === 'statusyatim' || h.includes('yatim') || h.includes('piatu')) {
    type = 'Select (Status Yatim / Piatu)';
    grid = 'col-span-4 (1/3 Lebar)';
    keterangan = 'Pilihan status yatim / piatu: Lengkap, Yatim, Piatu, Yatim Piatu';
    contohIsian = 'Lengkap';
  } else if (h === 'penerimakps' || h.includes('afirmasi')) {
    type = 'Select (Ya / Tidak)';
    grid = 'col-span-3 (1/4 Lebar)';
    keterangan = 'Status afirmasi / penerima bansos KPS / KIP / PIP: Ya atau Tidak';
    contohIsian = 'Ya';
  } else if (h === 'create' || h === 'read' || h === 'update' || h === 'delete' || h === 'approve' || h === 'export' || h === 'import' || h === 'aktif') {
    type = 'Boolean / Switch (1 / 0)';
    grid = 'col-span-3 (1/4 Lebar)';
    keterangan = 'Status izin akses atau keaktifan fitur: 1 (Diizinkan / Aktif) atau 0 (Dilarang)';
    contohIsian = '1';
  }

  // 10. Long Textarea, Address, Descriptions
  else if (h.includes('alamat') || h.includes('catatan') || h.includes('deskripsi') || h.includes('konten') || h.includes('keterangan') || h.includes('pesan') || h.includes('solusi') || h.includes('tindaklanjut') || h.includes('uraian') || h.includes('materi') || h.includes('disposisi') || h.includes('jawaban') || h.includes('soal') || h.includes('teks')) {
    type = 'Textarea (Teks Panjang)';
    grid = 'col-span-12 (Full Width)';
    keterangan = 'Uraian teks lengkap dan terperinci tanpa batasan karakter';
    contohIsian = h.includes('alamat') 
      ? 'Jl. Raya Tambora No. 45 RT 03 RW 02, Jakarta Barat' 
      : (h.includes('soal') ? 'Jelaskan prinsip kerja dari protokol HTTP dan HTTPS!' : 'Catatan lengkap tindak lanjut kegiatan operasional sekolah.');
  }

  // 11. Numeric / Measurements / Scores
  else if (h === 'rt' || h === 'rw' || h === 'anakke' || h === 'saudara' || h === 'tingkat' || h === 'kkm' || h === 'bobot' || h === 'sks' || h === 'kodepos' || h === 'jumlah' || h === 'stok' || h === 'skor' || h === 'nilai' || h === 'poin') {
    type = 'Number (Angka Numerik)';
    grid = 'col-span-3 (1/4 Lebar)';
    keterangan = 'Nilai numerik pengukuran, skor, bobot atau urutan';
    if (h === 'kodepos') contohIsian = '11220';
    else if (h === 'kkm' || h === 'nilai' || h === 'skor') contohIsian = '85';
    else if (h === 'poin') contohIsian = '10';
    else if (h === 'jumlah' || h === 'stok') contohIsian = '30';
    else contohIsian = '1';
  } else if (h.includes('tinggibadan') || h.includes('beratbadan')) {
    type = 'Number (Satuan cm/kg)';
    grid = 'col-span-3 (1/4 Lebar)';
    keterangan = 'Pengukuran fisik siswa dalam satuan standar';
    contohIsian = h.includes('tinggi') ? '160' : '50';
  }

  // 12. Standard Text Inputs
  else {
    type = 'Text (String)';
    grid = 'col-span-6 (1/2 Lebar)';
    keterangan = `Input data ${formatHeaderToLabel(header, sheet)}`;
    if (h.includes('nama')) {
      contohIsian = 'Ahmad Fauzi Pratama';
    } else if (h.includes('judul')) {
      contohIsian = 'Peringatan Hari Guru Nasional';
    } else if (h.includes('kelas') || h.includes('rombel')) {
      contohIsian = 'X RPL 1';
    } else if (h.includes('mapel')) {
      contohIsian = 'Pemrograman Web & Perangkat Bergerak';
    } else if (h.includes('tahun') || h.includes('angkatan')) {
      contohIsian = '2026/2027';
    } else if (h.includes('kota') || h.includes('kabupaten')) {
      contohIsian = 'Jakarta Barat';
    } else if (h.includes('provinsi')) {
      contohIsian = 'DKI Jakarta';
    } else if (h.includes('tempatlahir')) {
      contohIsian = 'Jakarta';
    } else if (h.includes('pekerjaan')) {
      contohIsian = 'Wiraswasta / Karyawan Swasta';
    } else if (h.includes('pendidikan')) {
      contohIsian = 'S1 / Sarjana';
    } else {
      contohIsian = `${formatHeaderToLabel(header, sheet)} Sample`;
    }
  }

  return { type, grid, keterangan, contohIsian, statusTampil };
}

/**
 * Generate complete 888 detailed rows mapped from all 78 master database tables
 */
export function getAll888DetailedMappingRows(): MenuDataStructureRow[] {
  const rows: MenuDataStructureRow[] = [];
  let globalIndex = 1;

  MASTER_TABLES_60.forEach((table) => {
    const sidebar = getSidebarName(table.category);
    const namaMenu = table.description.split(',')[0].split('(')[0].trim() || table.name;
    const icon = TABLE_ICONS[table.name] || 'Database';

    table.headers.forEach((header, hIdx) => {
      const meta = resolveHeaderMetadata(table, header);
      const idMenu = `${table.id}.${hIdx + 1}`;
      const namaListTampilan = formatHeaderToLabel(header, table.name);

      rows.push({
        no: globalIndex,
        idMenu,
        sidebar,
        namaMenu,
        icon,
        sheet: table.name,
        headerSheet: header,
        namaListTampilan,
        statusTampil: meta.statusTampil,
        type: meta.type,
        grid: meta.grid,
        keterangan: meta.keterangan,
        contohIsian: meta.contohIsian
      });

      globalIndex++;
    });
  });

  return rows;
}

export const DETAILED_HEADERS_DATA: MenuDataStructureRow[] = getAll888DetailedMappingRows();

export function downloadMenuStructureExcel() {
  // 1. Sheet 1: DAFTAR LENGKAP 78 SHEET DATABASE
  const formatted78Sheets = MASTER_TABLES_60.map((table, idx) => ({
    'No': idx + 1,
    'Nama Sheet (Kode Database)': table.name,
    'Kategori Modul': table.category,
    'Primary Key': table.primaryKey || '-',
    'Jumlah Kolom': table.headers.length,
    'Deskripsi Fungsional': table.description,
    'Daftar Header Kolom Lengkap': table.headers.join(', ')
  }));

  const worksheet78 = XLSX.utils.json_to_sheet(formatted78Sheets);
  worksheet78['!cols'] = [
    { wch: 6 },   // No
    { wch: 28 },  // Nama Sheet
    { wch: 25 },  // Kategori Modul
    { wch: 18 },  // Primary Key
    { wch: 15 },  // Jumlah Kolom
    { wch: 55 },  // Deskripsi Fungsional
    { wch: 75 }   // Daftar Header Kolom
  ];

  // 2. Sheet 2: DETAIL STRUKTUR & MAPPING TAMPILAN LENGKAP 888 KOLOM DENGAN TYPE, GRID, KETERANGAN & CONTOH ISIAN
  const allRows = getAll888DetailedMappingRows();
  const formattedDetailedData = allRows.map((row) => ({
    'No': row.no,
    'idMenu': row.idMenu,
    'Sidebar': row.sidebar,
    'Nama Menu': row.namaMenu,
    'Icon': row.icon,
    'SHEET': row.sheet,
    'HEADER SHEET': row.headerSheet,
    'NAMA LIST YANG DITAMPILKAN + AKSI': row.namaListTampilan,
    'TYPE DATA / INPUT': row.type,
    'GRID (LAYOUT FORM)': row.grid,
    'KETERANGAN & PANDUAN': row.keterangan,
    'CONTOH ISIAN DATA': row.contohIsian,
    'LIST DITAMPILKAN / TIDAK DI TAMPILKAN': row.statusTampil
  }));

  const worksheetDetailed = XLSX.utils.json_to_sheet(formattedDetailedData);
  worksheetDetailed['!cols'] = [
    { wch: 6 },   // No
    { wch: 10 },  // idMenu
    { wch: 24 },  // Sidebar
    { wch: 32 },  // Nama Menu
    { wch: 18 },  // Icon
    { wch: 22 },  // SHEET
    { wch: 26 },  // HEADER SHEET
    { wch: 42 },  // NAMA LIST YANG DITAMPILKAN + AKSI
    { wch: 26 },  // TYPE DATA / INPUT
    { wch: 26 },  // GRID (LAYOUT FORM)
    { wch: 60 },  // KETERANGAN & PANDUAN
    { wch: 36 },  // CONTOH ISIAN DATA
    { wch: 36 }   // LIST DITAMPILKAN / TIDAK DI TAMPILKAN
  ];

  // 3. Sheet 3: PANDUAN INTEGRASI & SINKRONISASI
  const setupGuideData = [
    {
      'Langkah': 'Langkah 1',
      'Aksi': 'Buka Google Spreadsheet Baru',
      'Detail Instruksi': 'Buat spreadsheet baru di Google Drive Anda atau gunakan spreadsheet database yang sudah ada.'
    },
    {
      'Langkah': 'Langkah 2',
      'Aksi': 'Buka Script Editor (Apps Script)',
      'Detail Instruksi': 'Klik menu Extensions > Apps Script (Ekstensi > Apps Script) pada toolbar Google Spreadsheet.'
    },
    {
      'Langkah': 'Langkah 3',
      'Aksi': 'Salin Kode Google Apps Script',
      'Detail Instruksi': 'Buka menu Pengaturan > Tab Integrasi Google Apps Script di aplikasi ini, lalu klik tombol "Salin Kode GAS". Tempelkan kode ke file Code.gs.'
    },
    {
      'Langkah': 'Langkah 4',
      'Aksi': 'Jalankan Otorisasi Google Drive',
      'Detail Instruksi': 'Pilih fungsi otorisasiDrive di toolbar atas editor Apps Script, lalu klik Jalankan (Run). Berikan izin akses Review Permissions > Lanjutan (Advanced) > Buka project (tidak aman) > Izinkan (Allow).'
    },
    {
      'Langkah': 'Langkah 5',
      'Aksi': 'Deploy Sebagai Web App',
      'Detail Instruksi': 'Klik Deploy > New Deployment > Pilih jenis "Web app". Atur Execute as: Me (akun saya) dan Who has access: Anyone (Siapa saja).'
    },
    {
      'Langkah': 'Langkah 6',
      'Aksi': 'Salin URL Web App ke SIMS',
      'Detail Instruksi': 'Salin URL Web App yang dihasilkan (berakhiran /exec) dan simpan ke menu Pengaturan > URL Web App Google Apps Script.'
    },
    {
      'Langkah': 'Langkah 7',
      'Aksi': 'Buat Otomatis Seluruh 78 Sheet',
      'Detail Instruksi': 'Klik tombol "Buat 78 Sheet Otomatis Sekarang" di menu Pengaturan. Sistem akan otomatis membuat dan menata seluruh 78 sheet dengan header tebal dan freeze baris.'
    }
  ];

  const worksheetGuide = XLSX.utils.json_to_sheet(setupGuideData);
  worksheetGuide['!cols'] = [
    { wch: 14 },  // Langkah
    { wch: 35 },  // Aksi
    { wch: 90 }   // Detail Instruksi
  ];

  // Buat Workbook Excel dan masukkan ketiga sheet
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet78, "DAFTAR_78_SHEET_DATABASE");
  XLSX.utils.book_append_sheet(workbook, worksheetDetailed, "STRUKTUR_DETAIL_MAPPING");
  XLSX.utils.book_append_sheet(workbook, worksheetGuide, "PANDUAN_SETUP_SPREADSHEET");

  // Unduh file Excel
  XLSX.writeFile(workbook, "STRUKTUR_LENGKAP_78_SHEET_DATABASE_SIMS.xlsx");
}
