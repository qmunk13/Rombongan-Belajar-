import React, { useState, useMemo } from 'react';
import { useStore } from '../../store';
import { getActiveClasses, matchClass, matchStatusActive, formatClassLabel } from '../../lib/utils';
import { exportToExcel } from '../../lib/excel';
import { 
  Users, Search, Filter, Printer, UserCheck, School, 
  Phone, Mail, CheckCircle2, ChevronRight, Award, ShieldCheck,
  FileSpreadsheet
} from 'lucide-react';

export default function SiswaKelasTab() {
  const { students, teachers, settings } = useStore();
  const classesList = useMemo(() => {
    return getActiveClasses(students);
  }, [students]);

  const [selectedClass, setSelectedClass] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [genderFilter, setGenderFilter] = useState<'Semua' | 'L' | 'P'>('Semua');

  // Filtered active students
  const classStudents = useMemo(() => {
    return students
      .filter(s => {
        const isActive = matchStatusActive(s.status);
        const isClass = selectedClass ? matchClass(s.class, selectedClass) : true;
        const isGender = genderFilter === 'Semua' ? true : s.gender === genderFilter;
        const isSearch = searchTerm 
          ? s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            (s.nis && s.nis.includes(searchTerm)) ||
            (s.nisn && s.nisn.includes(searchTerm))
          : true;
        return isActive && isClass && isGender && isSearch;
      })
      .sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'id'));
  }, [students, selectedClass, genderFilter, searchTerm]);

  // Wali Kelas for selected class
  const waliKelas = useMemo(() => {
    return teachers.find(t => matchClass(t.class, selectedClass));
  }, [teachers, selectedClass]);

  const countL = useMemo(() => classStudents.filter(s => s.gender === 'L').length, [classStudents]);
  const countP = useMemo(() => classStudents.filter(s => s.gender === 'P').length, [classStudents]);

  const handleExportExcel = () => {
    if (classStudents.length === 0) {
      alert("Tidak ada data siswa pada rombel ini.");
      return;
    }
    const rows = classStudents.map((s, idx) => ({
      No: idx + 1,
      'Nama Siswa': s.name,
      'NISN': s.nisn || '-',
      'NIS': s.nis || '-',
      'Kelas': formatClassLabel(s.class, true),
      'Jenis Kelamin': s.gender === 'L' ? 'Laki-laki' : s.gender === 'P' ? 'Perempuan' : s.gender || '-',
      'Tempat Lahir': s.birthPlace || '-',
      'Tanggal Lahir': s.birthDate || '-',
      'Nama Ayah': s.fatherName || '-',
      'Nama Ibu': s.NamaIbu || '-',
      'No. HP Orang Tua / Siswa': s.phone || '-',
      'Alamat': s.address || '-',
      'Status': s.status
    }));
    exportToExcel(rows, `Roster_Siswa_${selectedClass ? formatClassLabel(selectedClass, true).replace(/\s+/g, '_') : 'Semua'}_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  return (
    <div className="space-y-6">
      {/* Header Info Banner */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-4 no-print">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-black text-lg border border-indigo-100/80">
              <Users size={22} />
            </div>
            <div>
              <h2 className="text-base font-black text-slate-900">Roster Data Siswa Per Rombel</h2>
              <p className="text-xs text-slate-500 font-medium">
                Daftar pembagian peserta didik aktif dalam rombongan belajar, rasio gender, dan penanggung jawab kelas.
              </p>
            </div>
          </div>
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-slate-100">
          <div>
            <label className="text-[11px] font-bold text-slate-500 block mb-1">Pilih Kelas:</label>
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black text-indigo-700 focus:outline-none"
            >
              <option value="">Semua Kelas ({students.filter(s => matchStatusActive(s.status)).length} Siswa)</option>
              {classesList.map(c => {
                const count = students.filter(s => matchStatusActive(s.status) && matchClass(s.class, c)).length;
                return (
                  <option key={c} value={c}>{formatClassLabel(c, true)} ({count} Siswa)</option>
                );
              })}
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-500 block mb-1">Filter Jenis Kelamin:</label>
            <select
              value={genderFilter}
              onChange={(e) => setGenderFilter(e.target.value as any)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
            >
              <option value="Semua">Semua</option>
              <option value="L">Hanya Laki-laki (L)</option>
              <option value="P">Hanya Perempuan (P)</option>
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-500 block mb-1">Cari Siswa di Kelas Ini:</label>
            <div className="relative">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Cari nama, NIS, NISN..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Class Statistics & Wali Kelas Card */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-slate-500 uppercase">Wali Kelas</span>
          <div className="text-sm font-black text-slate-900 truncate">
            {waliKelas ? waliKelas.name : 'Belum Ditentukan'}
          </div>
          <p className="text-[10px] text-slate-400 font-mono">
            {waliKelas ? `NIP: ${waliKelas.nip || '-'}` : 'Silakan atur di Data GTK'}
          </p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-slate-500 uppercase">Total Siswa Aktif</span>
          <div className="text-2xl font-black text-indigo-600">
            {classStudents.length} <span className="text-xs text-slate-500 font-normal">Anak</span>
          </div>
          <p className="text-[10px] text-slate-400">Rombel {selectedClass ? formatClassLabel(selectedClass, true) : 'Semua Rombel'}</p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-slate-500 uppercase">Laki-laki (L)</span>
          <div className="text-2xl font-black text-blue-600">
            {countL} <span className="text-xs text-slate-500 font-normal">Siswa</span>
          </div>
          <p className="text-[10px] text-slate-400">{classStudents.length > 0 ? Math.round((countL / classStudents.length) * 100) : 0}% dari total</p>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-slate-500 uppercase">Perempuan (P)</span>
          <div className="text-2xl font-black text-pink-600">
            {countP} <span className="text-xs text-slate-500 font-normal">Siswi</span>
          </div>
          <p className="text-[10px] text-slate-400">{classStudents.length > 0 ? Math.round((countP / classStudents.length) * 100) : 0}% dari total</p>
        </div>
      </div>

      {/* Roster Table */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden">
        {/* Printable Official Header */}
        <div className="p-5 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-wider text-slate-500">
              {settings.schoolName || 'ROMBEL CONTOH'}
            </div>
            <h3 className="text-base font-black text-slate-900 uppercase">
              ROSTER PESERTA DIDIK {selectedClass ? formatClassLabel(selectedClass, true) : 'SEMUA ROMBEL'} - T.A {settings.tahunPelajaran || '2026/2027'}
            </h3>
          </div>
          <div className="text-xs text-slate-500 text-right">
            <span>Total: <strong className="text-slate-900">{classStudents.length} Siswa</strong></span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-100/80 text-slate-600 uppercase font-black tracking-wider text-[10px] border-b border-slate-200">
                <th className="p-3 pl-4 text-center w-12">No</th>
                <th className="p-3 text-center">NIS / NISN</th>
                <th className="p-3">Nama Lengkap Peserta Didik</th>
                <th className="p-3 text-center">L/P</th>
                <th className="p-3">Tempat, Tanggal Lahir</th>
                <th className="p-3">Nama Orang Tua / Wali</th>
                <th className="p-3">Kontak / No HP</th>
                <th className="p-3 text-center pr-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {classStudents.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-12 text-center text-slate-400">
                    <Users size={32} className="mx-auto text-slate-300 mb-2" />
                    <p className="font-bold text-slate-600 text-sm">Tidak Ada Siswa di {selectedClass ? formatClassLabel(selectedClass, true) : 'Rombel Ini'}</p>
                    <p className="text-xs text-slate-400">Silakan pilih kelas lain atau tambahkan data siswa di menu Siswa.</p>
                  </td>
                </tr>
              ) : (
                classStudents.map((s, idx) => (
                  <tr key={s.id || idx} className="hover:bg-slate-50/80 transition">
                    <td className="p-3 pl-4 text-center font-mono font-bold text-slate-500">{idx + 1}</td>
                    <td className="p-3 text-center font-mono font-semibold text-slate-700">
                      <div>{s.nis || '-'}</div>
                      <div className="text-[10px] text-slate-400">{s.nisn || '-'}</div>
                    </td>
                    <td className="p-3 font-bold text-slate-900">
                      <div>{s.name}</div>
                      <div className="text-[10px] text-slate-400 font-normal">{s.alamat || '-'}</div>
                    </td>
                    <td className="p-3 text-center">
                      <span className={`px-2 py-0.5 rounded-md font-bold text-[10px] ${
                        s.gender === 'L' ? 'bg-blue-50 text-blue-700 border border-blue-200' : 'bg-pink-50 text-pink-700 border border-pink-200'
                      }`}>
                        {s.gender || 'L'}
                      </span>
                    </td>
                    <td className="p-3 text-slate-600">
                      {s.birthPlace || s.tempatLahir ? `${s.birthPlace || s.tempatLahir}, ` : ''}{s.birthDate || s.tanggalLahir || '-'}
                    </td>
                    <td className="p-3 text-slate-800">
                      <div>{s.parentName || s.namaAyah || s.namaIbu || '-'}</div>
                      <div className="text-[10px] text-slate-400">{s.pekerjaanOrtu || '-'}</div>
                    </td>
                    <td className="p-3 text-slate-600 font-mono text-[11px]">
                      {s.parentPhone || s.noHp || '-'}
                    </td>
                    <td className="p-3 text-center pr-4">
                      <span className="px-2 py-0.5 rounded-full font-bold text-[10px] bg-emerald-50 text-emerald-700 border border-emerald-200">
                        Aktif
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
