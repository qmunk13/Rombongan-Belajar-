import React, { useState, useMemo } from 'react';
import { useStore } from '../../store';
import { db } from '../../data/db';
import { getActiveClasses, matchClass, formatClassLabel } from '../../lib/utils';
import { 
  Calendar, Plus, Filter, Trash2, Edit2, Clock, MapPin, 
  User, BookOpen, Printer, X, Save, CheckCircle2, Search
} from 'lucide-react';

export interface JadwalItem {
  id: string;
  hari: 'Senin' | 'Selasa' | 'Rabu' | 'Kamis' | 'Jumat' | 'Sabtu' | 'Minggu';
  jamMulai: string;
  jamSelesai: string;
  kelas: string;
  mataPelajaran: string;
  guru: string;
  ruang: string;
  semester?: 'Ganjil' | 'Genap';
  tahunAjaran?: string;
}

const HARI_LIST = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'Minggu'] as const;

const DEFAULT_MAPEL = [
  'Pendidikan Agama dan Budi Pekerti',
  'Pendidikan Pancasila',
  'Bahasa Indonesia',
  'Matematika',
  'IPAS (Ilmu Pengetahuan Alam dan Sosial)',
  'Pendidikan Jasmani, Olahraga, dan Kesehatan (PJOK)',
  'Seni Rupa / Musik / Tari / Teater',
  'Bahasa Inggris',
  'Muatan Lokal / Bahasa Daerah',
  'Projek Penguatan Profil Pelajar Pancasila (P5)',
];

export default function JadwalRombelTab() {
  const { students, teachers, settings } = useStore();
  const classesList = useMemo(() => {
    return getActiveClasses(students);
  }, [students]);

  // Semester & Academic Year
  const [selectedSemester, setSelectedSemester] = useState<'Ganjil' | 'Genap'>('Ganjil');
  const [selectedClass, setSelectedClass] = useState<string>('');
  const [selectedHari, setSelectedHari] = useState<string>('Semua');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Persisted Jadwal List in DB
  const [jadwalList, setJadwalList] = useState<JadwalItem[]>(() => {
    const saved = db.get('jadwal_rombel');
    if (Array.isArray(saved)) return saved;
    return [];
  });

  // Modal State
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<JadwalItem>>({
    hari: 'Senin',
    jamMulai: '07:30',
    jamSelesai: '09:00',
    kelas: classesList[0] || '1',
    mataPelajaran: DEFAULT_MAPEL[0],
    guru: teachers[0]?.name || 'Guru Pengampu',
    ruang: 'Ruang Kelas',
    semester: 'Ganjil',
    tahunAjaran: settings.tahunPelajaran || '2026/2027'
  });

  const saveJadwalToDb = (newList: JadwalItem[]) => {
    setJadwalList(newList);
    db.set('jadwal_rombel', newList);
  };

  const handleOpenAdd = () => {
    setEditingId(null);
    setFormData({
      hari: 'Senin',
      jamMulai: '07:30',
      jamSelesai: '09:00',
      kelas: selectedClass || classesList[0] || '1',
      mataPelajaran: DEFAULT_MAPEL[0],
      guru: teachers[0]?.name || 'Guru Pengampu',
      ruang: 'Ruang Kelas',
      semester: selectedSemester,
      tahunAjaran: settings.tahunPelajaran || '2026/2027'
    });
    setModalOpen(true);
  };

  const handleOpenEdit = (item: JadwalItem) => {
    setEditingId(item.id);
    setFormData({ ...item });
    setModalOpen(true);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Hapus jadwal pelajaran ini?')) {
      const updated = jadwalList.filter(j => j.id !== id);
      saveJadwalToDb(updated);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.hari || !formData.mataPelajaran || !formData.kelas) {
      alert('Mohon lengkapi data jadwal.');
      return;
    }

    if (editingId) {
      const updated = jadwalList.map(j => (j.id === editingId ? { ...j, ...formData } as JadwalItem : j));
      saveJadwalToDb(updated);
    } else {
      const newItem: JadwalItem = {
        id: `jdw-${Date.now()}`,
        hari: formData.hari as any,
        jamMulai: formData.jamMulai || '07:30',
        jamSelesai: formData.jamSelesai || '09:00',
        kelas: formData.kelas || '1',
        mataPelajaran: formData.mataPelajaran || '',
        guru: formData.guru || 'Guru Pengampu',
        ruang: formData.ruang || 'Ruang Kelas',
        semester: selectedSemester,
        tahunAjaran: settings.tahunPelajaran || '2026/2027'
      };
      saveJadwalToDb([...jadwalList, newItem]);
    }
    setModalOpen(false);
  };

  // Filtered List
  const filteredJadwal = useMemo(() => {
    return jadwalList.filter(item => {
      const matchSem = !item.semester || item.semester === selectedSemester;
      const matchCls = selectedClass ? matchClass(item.kelas, selectedClass) : true;
      const matchDay = selectedHari === 'Semua' ? true : item.hari === selectedHari;
      const matchSrch = searchTerm 
        ? item.mataPelajaran.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.guru.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.ruang.toLowerCase().includes(searchTerm.toLowerCase())
        : true;
      return matchSem && matchCls && matchDay && matchSrch;
    });
  }, [jadwalList, selectedSemester, selectedClass, selectedHari, searchTerm]);

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-4 no-print">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
              <Calendar size={20} />
            </div>
            <div>
              <h2 className="text-base font-black text-slate-900">Jadwal Pembelajaran & Rombel</h2>
              <p className="text-xs text-slate-500 font-medium">
                Penyusunan alokasi jam tatap muka KBM per rombongan belajar sesuai Kurikulum Merdeka.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => window.print()}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3.5 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition"
            >
              <Printer size={15} />
              <span>Cetak Jadwal</span>
            </button>
            <button
              onClick={handleOpenAdd}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs shadow-md shadow-indigo-200 transition active:scale-95"
            >
              <Plus size={15} />
              <span>+ Tambah Jadwal</span>
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-3 border-t border-slate-100">
          {/* Semester Selector */}
          <div>
            <label className="text-[11px] font-bold text-slate-500 block mb-1">Semester Aktif:</label>
            <select
              value={selectedSemester}
              onChange={(e) => setSelectedSemester(e.target.value as any)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-indigo-700 focus:outline-none"
            >
              <option value="Ganjil">Semester 1 (Ganjil)</option>
              <option value="Genap">Semester 2 (Genap)</option>
            </select>
          </div>

          {/* Class Filter */}
          <div>
            <label className="text-[11px] font-bold text-slate-500 block mb-1">Filter Rombel / Kelas:</label>
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
            >
              <option value="">Semua Rombel</option>
              {classesList.map(c => (
                <option key={c} value={c}>{formatClassLabel(c, true)}</option>
              ))}
            </select>
          </div>

          {/* Hari Filter */}
          <div>
            <label className="text-[11px] font-bold text-slate-500 block mb-1">Filter Hari:</label>
            <select
              value={selectedHari}
              onChange={(e) => setSelectedHari(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
            >
              <option value="Semua">Semua Hari (Senin - Minggu)</option>
              {HARI_LIST.map(h => (
                <option key={h} value={h}>{h}</option>
              ))}
            </select>
          </div>

          {/* Search Mapel */}
          <div>
            <label className="text-[11px] font-bold text-slate-500 block mb-1">Cari Mata Pelajaran / Guru:</label>
            <div className="relative">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Cari..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Grid by Day */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {HARI_LIST.filter(h => selectedHari === 'Semua' || selectedHari === h).map(hari => {
          const itemsOnDay = filteredJadwal.filter(j => j.hari === hari);
          return (
            <div key={hari} className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden flex flex-col">
              {/* Day Header */}
              <div className="px-5 py-3.5 bg-gradient-to-r from-slate-900 to-indigo-950 text-white flex items-center justify-between">
                <div className="flex items-center gap-2 font-black text-sm">
                  <Clock size={16} className="text-indigo-400" />
                  <span>{hari}</span>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-white/20 text-[10px] font-bold">
                  {itemsOnDay.length} Sesi
                </span>
              </div>

              {/* Items List */}
              <div className="p-4 space-y-3 flex-1">
                {itemsOnDay.length === 0 ? (
                  <div className="py-8 text-center text-slate-400 text-xs">
                    Tidak ada jadwal pelajaran di hari {hari}.
                  </div>
                ) : (
                  itemsOnDay.map((item) => (
                    <div 
                      key={item.id} 
                      className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/70 hover:bg-indigo-50/40 hover:border-indigo-200 transition space-y-2 group"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <span className="px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-800 text-[10px] font-black tracking-wider uppercase inline-block mb-1">
                            {formatClassLabel(item.kelas, true)}
                          </span>
                          <h4 className="font-bold text-slate-900 text-xs leading-snug">{item.mataPelajaran}</h4>
                        </div>
                        <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 no-print">
                          <button
                            onClick={() => handleOpenEdit(item)}
                            className="p-1 rounded-lg hover:bg-amber-100 text-amber-700 transition"
                            title="Edit"
                          >
                            <Edit2 size={12} />
                          </button>
                          <button
                            onClick={() => handleDelete(item.id)}
                            className="p-1 rounded-lg hover:bg-rose-100 text-rose-700 transition"
                            title="Hapus"
                          >
                            <Trash2 size={12} />
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-1 text-[11px] text-slate-500 pt-1 border-t border-slate-200/50">
                        <div className="flex items-center gap-1 font-mono text-slate-700">
                          <Clock size={11} className="text-indigo-600 flex-shrink-0" />
                          <span>{item.jamMulai} - {item.jamSelesai}</span>
                        </div>
                        <div className="flex items-center gap-1 truncate text-slate-700">
                          <MapPin size={11} className="text-slate-400 flex-shrink-0" />
                          <span className="truncate">{item.ruang}</span>
                        </div>
                      </div>

                      <div className="flex items-center gap-1 text-[11px] text-slate-600 font-medium">
                        <User size={11} className="text-slate-400 flex-shrink-0" />
                        <span className="truncate">{item.guru}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Modal Add / Edit */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                  <Calendar size={16} />
                </div>
                <h3 className="font-black text-slate-900 text-sm">
                  {editingId ? 'Edit Jadwal Pelajaran' : 'Tambah Jadwal Pelajaran Baru'}
                </h3>
              </div>
              <button 
                onClick={() => setModalOpen(false)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center"
              >
                <X size={15} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-600 block mb-1">Hari</label>
                  <select
                    value={formData.hari}
                    onChange={(e) => setFormData({ ...formData, hari: e.target.value as any })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                  >
                    {HARI_LIST.map(h => <option key={h} value={h}>{h}</option>)}
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-600 block mb-1">Rombel / Kelas</label>
                  <select
                    value={formData.kelas}
                    onChange={(e) => setFormData({ ...formData, kelas: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                  >
                    {classesList.map(c => <option key={c} value={c}>{formatClassLabel(c, true)}</option>)}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-600 block mb-1">Jam Mulai</label>
                  <input
                    type="time"
                    value={formData.jamMulai}
                    onChange={(e) => setFormData({ ...formData, jamMulai: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                    required
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-600 block mb-1">Jam Selesai</label>
                  <input
                    type="time"
                    value={formData.jamSelesai}
                    onChange={(e) => setFormData({ ...formData, jamSelesai: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-600 block mb-1">Mata Pelajaran</label>
                <input
                  type="text"
                  list="mapel-options"
                  placeholder="Pilih atau ketik mata pelajaran..."
                  value={formData.mataPelajaran}
                  onChange={(e) => setFormData({ ...formData, mataPelajaran: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                  required
                />
                <datalist id="mapel-options">
                  {DEFAULT_MAPEL.map((m, idx) => <option key={idx} value={m} />)}
                </datalist>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-600 block mb-1">Guru Pengampu</label>
                  <input
                    type="text"
                    list="guru-options"
                    placeholder="Nama Guru..."
                    value={formData.guru}
                    onChange={(e) => setFormData({ ...formData, guru: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                  />
                  <datalist id="guru-options">
                    {teachers.map(t => <option key={t.id} value={t.name} />)}
                  </datalist>
                </div>
                <div>
                  <label className="font-bold text-slate-600 block mb-1">Ruangan</label>
                  <input
                    type="text"
                    placeholder="Contoh: Ruang Kelas 4"
                    value={formData.ruang}
                    onChange={(e) => setFormData({ ...formData, ruang: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                  />
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold flex items-center gap-1.5 shadow-md shadow-indigo-200"
                >
                  <Save size={14} />
                  <span>Simpan Jadwal</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
