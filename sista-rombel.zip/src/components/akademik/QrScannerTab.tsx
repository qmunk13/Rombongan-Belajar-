import React, { useState, useEffect, useRef } from 'react';
import { useStore } from '../../store';
import { db } from '../../data/db';
import { 
  QrCode, Camera, CheckCircle2, AlertCircle, Sparkles, 
  UserCheck, Users, Clock, ShieldCheck, Volume2, ArrowRight, RefreshCw, Zap
} from 'lucide-react';

export default function QrScannerTab() {
  const { students, teachers, settings } = useStore();

  const [isScanning, setIsScanning] = useState(false);
  const [manualCode, setManualCode] = useState('');
  const [lastScannedResult, setLastScannedResult] = useState<{
    success: boolean;
    type: 'SISWA' | 'GURU';
    name: string;
    idCode: string;
    subtext: string;
    time: string;
    actionType: 'Masuk' | 'Pulang';
    message: string;
  } | null>(null);

  const [recentScanHistory, setRecentScanHistory] = useState<any[]>(() => {
    return (db.get('recent_qr_scans') as any[]) || [];
  });

  // Audio Beep Effect Generator
  const playBeep = (isSuccess = true) => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.type = isSuccess ? 'sine' : 'sawtooth';
      osc.frequency.setValueAtTime(isSuccess ? 880 : 220, audioCtx.currentTime); // A5 or A3
      gain.gain.setValueAtTime(0.1, audioCtx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.3);
      osc.connect(gain);
      gain.connect(audioCtx.destination);
      osc.start();
      osc.stop(audioCtx.currentTime + 0.3);
    } catch (e) {
      // Audio context might be restricted
    }
  };

  // Logika Pintar Processor
  const processQrInput = (rawCode: string) => {
    if (!rawCode.trim()) return;
    const cleanCode = rawCode.trim();
    const now = new Date();
    const timeStr = now.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    const today = now.toISOString().slice(0, 10);
    const hour = now.getHours();

    // 1. Check if matches a Teacher (by NIP, NIK, ID, or Name)
    const matchedTeacher = teachers.find(t => 
      (t.nip && t.nip.trim() === cleanCode) ||
      (t.nik && t.nik.trim() === cleanCode) ||
      (t.id && t.id.trim() === cleanCode) ||
      t.name.toLowerCase().includes(cleanCode.toLowerCase())
    );

    if (matchedTeacher) {
      playBeep(true);
      const isMorning = hour < 12;
      const actionType = isMorning ? 'Masuk' : 'Pulang';
      const status = isMorning ? (hour < 7 ? 'Tepat Waktu' : 'Terlambat') : 'Tepat Waktu';

      // Save to absensi_guru
      const currentGuruAbsensi = (db.get('absensi_guru') as any[]) || [];
      const updatedGuruAbsensi = [
        {
          id: `absg-${Date.now()}`,
          tanggal: today,
          teacherId: matchedTeacher.id,
          nama: matchedTeacher.name,
          nip: matchedTeacher.nip || '-',
          jamMasuk: isMorning ? timeStr : '06:45:00',
          jamPulang: !isMorning ? timeStr : '-',
          status: status,
          metode: 'QR Scanner Portal',
          keterangan: `Presensi QR ${actionType} otomatis terverifikasi`
        },
        ...currentGuruAbsensi
      ];
      db.set('absensi_guru', updatedGuruAbsensi);

      const result = {
        success: true,
        type: 'GURU' as const,
        name: matchedTeacher.name,
        idCode: matchedTeacher.nip || matchedTeacher.id,
        subtext: `Tenaga Pendidik / Wali Kelas ${matchedTeacher.class || '-'}`,
        time: timeStr,
        actionType: actionType as any,
        message: `Selamat ${isMorning ? 'Pagi' : 'Sore'}, ${matchedTeacher.name}! Presensi ${actionType} Guru berhasil dicatat.`
      };

      setLastScannedResult(result);
      const newHistory = [result, ...recentScanHistory.slice(0, 9)];
      setRecentScanHistory(newHistory);
      db.set('recent_qr_scans', newHistory);
      setManualCode('');
      return;
    }

    // 2. Check if matches a Student (by NISN, NIS, ID, NIK, or Name)
    const matchedStudent = students.find(s => 
      (s.nisn && s.nisn.trim() === cleanCode) ||
      (s.nis && s.nis.trim() === cleanCode) ||
      (s.id && s.id.trim() === cleanCode) ||
      (s.nik && s.nik.trim() === cleanCode) ||
      s.name.toLowerCase().includes(cleanCode.toLowerCase())
    );

    if (matchedStudent) {
      playBeep(true);
      const isMorning = hour < 12;
      const actionType = isMorning ? 'Masuk' : 'Pulang';

      // Save to absensi siswa
      const currentAbsensi = (db.get('absensi') as any[]) || [];
      const updatedAbsensi = [
        {
          id: `abs-${Date.now()}`,
          studentId: matchedStudent.id,
          name: matchedStudent.name,
          class: matchedStudent.class,
          date: today,
          time: timeStr,
          status: 'H',
          type: actionType,
          method: 'QR Scanner Portal'
        },
        ...currentAbsensi
      ];
      db.set('absensi', updatedAbsensi);

      const result = {
        success: true,
        type: 'SISWA' as const,
        name: matchedStudent.name,
        idCode: `NISN: ${matchedStudent.nisn || matchedStudent.nis || '-'}`,
        subtext: `Peserta Didik - Kelas ${matchedStudent.class}`,
        time: timeStr,
        actionType: actionType as any,
        message: `Presensi Siswa Berhasil! Selamat Belajar, ${matchedStudent.name}.`
      };

      setLastScannedResult(result);
      const newHistory = [result, ...recentScanHistory.slice(0, 9)];
      setRecentScanHistory(newHistory);
      db.set('recent_qr_scans', newHistory);
      setManualCode('');
      return;
    }

    // Not found
    playBeep(false);
    setLastScannedResult({
      success: false,
      type: 'SISWA',
      name: 'Kode QR Tidak Dikenali',
      idCode: cleanCode,
      subtext: 'Data tidak terdaftar di database',
      time: timeStr,
      actionType: 'Masuk',
      message: `ID/Kode "${cleanCode}" tidak cocok dengan data Guru atau Siswa manapun.`
    });
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold border border-indigo-100">
            <QrCode size={24} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-black text-slate-900">Portal Pemindaian QR Code Pintar</h2>
              <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-extrabold flex items-center gap-1">
                <Zap size={10} className="fill-emerald-600" /> Logika Pintar Aktif
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium">
              Deteksi otomatis kartu ID Siswa & Guru, pencatatan real-time jam masuk/pulang, dan notifikasi visual instan.
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Interactive Scanner Area */}
        <div className="lg:col-span-7 space-y-5">
          
          {/* Main Scanner Box */}
          <div className="bg-slate-900 rounded-3xl p-6 text-white text-center space-y-5 relative overflow-hidden shadow-xl border border-slate-800">
            <div className="space-y-1">
              <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-400">
                Pusat Presensi Otomatis
              </span>
              <h3 className="text-lg font-black text-white">Arahkan Kartu QR / Masukkan ID</h3>
            </div>

            {/* Visual Viewfinder Frame */}
            <div className="w-56 h-56 mx-auto relative rounded-3xl border-2 border-dashed border-indigo-400/60 bg-slate-800/60 flex flex-col items-center justify-center p-4">
              {/* Corner brackets */}
              <div className="absolute top-2 left-2 w-5 h-5 border-t-2 border-l-2 border-indigo-400"></div>
              <div className="absolute top-2 right-2 w-5 h-5 border-t-2 border-r-2 border-indigo-400"></div>
              <div className="absolute bottom-2 left-2 w-5 h-5 border-b-2 border-l-2 border-indigo-400"></div>
              <div className="absolute bottom-2 right-2 w-5 h-5 border-b-2 border-r-2 border-indigo-400"></div>

              {/* Scanning laser line animation */}
              <div className="w-full h-0.5 bg-gradient-to-r from-transparent via-cyan-400 to-transparent absolute top-1/2 -translate-y-1/2 animate-pulse shadow-lg shadow-cyan-500"></div>

              <QrCode size={64} className="text-indigo-300 opacity-60 mb-2" />
              <span className="text-[11px] text-slate-300 font-medium">Area Fokus Scanner</span>
            </div>

            {/* Quick Simulate Buttons for Instant Testing */}
            <div className="pt-2 space-y-2">
              <span className="text-[11px] font-bold text-slate-400 block">Simulasi Pemindaian Cepat (Klik untuk coba):</span>
              <div className="flex flex-wrap items-center justify-center gap-2">
                {teachers.slice(0, 2).map((t, idx) => (
                  <button
                    key={t.id || idx}
                    onClick={() => processQrInput(t.nip || t.name)}
                    className="px-3 py-1.5 rounded-xl bg-purple-600/30 hover:bg-purple-600/50 border border-purple-500/40 text-purple-200 text-xs font-bold transition active:scale-95 flex items-center gap-1.5"
                  >
                    <UserCheck size={13} />
                    <span>Scan Guru: {t.name.split(' ')[0]}</span>
                  </button>
                ))}

                {students.slice(0, 2).map((s, idx) => (
                  <button
                    key={s.id || idx}
                    onClick={() => processQrInput(s.nisn || s.name)}
                    className="px-3 py-1.5 rounded-xl bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-500/40 text-indigo-200 text-xs font-bold transition active:scale-95 flex items-center gap-1.5"
                  >
                    <Users size={13} />
                    <span>Scan Siswa: {s.name.split(' ')[0]}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Manual Code Input Bar */}
            <form 
              onSubmit={(e) => {
                e.preventDefault();
                processQrInput(manualCode);
              }}
              className="flex items-center gap-2 pt-2 border-t border-slate-800"
            >
              <input
                type="text"
                placeholder="Atau ketik/scan NISN, NIP, atau Nama di sini..."
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                className="flex-1 px-4 py-2.5 bg-slate-800 border border-slate-700 rounded-xl text-xs text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono"
              />
              <button
                type="submit"
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl text-xs transition shadow-md"
              >
                Scan & Catat
              </button>
            </form>
          </div>

        </div>

        {/* Right Column: Scan Result & Realtime Feed */}
        <div className="lg:col-span-5 space-y-4">
          
          {/* Latest Result Card */}
          {lastScannedResult ? (
            <div className={`p-5 rounded-3xl border-2 transition-all space-y-3 animate-in zoom-in-95 ${
              lastScannedResult.success 
                ? 'bg-emerald-50/70 border-emerald-400 text-emerald-950 shadow-md shadow-emerald-100' 
                : 'bg-rose-50/70 border-rose-400 text-rose-950 shadow-md shadow-rose-100'
            }`}>
              <div className="flex items-center justify-between">
                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider ${
                  lastScannedResult.success ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white'
                }`}>
                  {lastScannedResult.success ? `✓ Terverifikasi (${lastScannedResult.type})` : '✕ Gagal Dikenali'}
                </span>
                <span className="font-mono text-xs font-bold text-slate-600">
                  ⏰ {lastScannedResult.time}
                </span>
              </div>

              <div className="flex items-start gap-3.5">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black text-xl flex-shrink-0 ${
                  lastScannedResult.success ? 'bg-emerald-200 text-emerald-800' : 'bg-rose-200 text-rose-800'
                }`}>
                  {lastScannedResult.name.charAt(0)}
                </div>
                <div className="space-y-0.5 min-w-0">
                  <h4 className="font-black text-sm text-slate-900 leading-tight">{lastScannedResult.name}</h4>
                  <div className="text-[11px] font-mono font-bold text-indigo-700">{lastScannedResult.idCode}</div>
                  <div className="text-[10px] text-slate-600">{lastScannedResult.subtext}</div>
                </div>
              </div>

              <p className="text-xs font-medium pt-2 border-t border-slate-200/60 leading-relaxed">
                {lastScannedResult.message}
              </p>
            </div>
          ) : (
            <div className="p-8 bg-white rounded-3xl border border-slate-200 text-center text-slate-400 space-y-2">
              <Clock size={32} className="mx-auto text-slate-300" />
              <h4 className="font-bold text-slate-700 text-sm">Menunggu Hasil Pemindaian</h4>
              <p className="text-xs text-slate-400">Scan QR Code siswa atau guru untuk melihat informasi kehadiran di sini.</p>
            </div>
          )}

          {/* Recent Scans History Feed */}
          <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-3">
            <h4 className="font-black text-slate-900 text-xs uppercase tracking-wider flex items-center justify-between">
              <span>Riwayat Pemindaian Terkini</span>
              <span className="text-[10px] font-bold text-slate-400">Hari Ini</span>
            </h4>

            <div className="space-y-2 max-h-64 overflow-y-auto pr-1">
              {recentScanHistory.length === 0 ? (
                <p className="text-xs text-slate-400 text-center py-4">Belum ada riwayat scan sesi ini.</p>
              ) : (
                recentScanHistory.map((item, idx) => (
                  <div 
                    key={idx}
                    className="p-2.5 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-between text-xs hover:bg-slate-100/70 transition"
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-[11px] ${
                        item.type === 'GURU' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'
                      }`}>
                        {item.type === 'GURU' ? 'G' : 'S'}
                      </div>
                      <div className="min-w-0">
                        <div className="font-bold text-slate-900 truncate">{item.name}</div>
                        <div className="text-[10px] text-slate-500">{item.subtext}</div>
                      </div>
                    </div>
                    <span className="font-mono text-[11px] font-semibold text-slate-600 pl-2">
                      {item.time}
                    </span>
                  </div>
                ))
              )}
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
