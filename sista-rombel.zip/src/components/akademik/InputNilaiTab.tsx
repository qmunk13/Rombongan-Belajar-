import React, { useState, useMemo, useEffect } from 'react';
import { useStore } from '../../store';
import { db } from '../../data/db';
import { getActiveClasses, matchClass, matchStatusActive, formatClassLabel } from '../../lib/utils';
import { getSemestersList, getActiveSemester, SemesterEntity } from '../../lib/semester';
import { exportToExcel } from '../../lib/excel';
import { 
  PenTool, Save, Filter, Search, Calculator, CheckCircle2, 
  AlertCircle, Sparkles, Download, RefreshCw, BookOpen, Layers, Award, Calendar,
  FileSpreadsheet
} from 'lucide-react';

export interface NilaiSiswaRecord {
  studentId: string;
  nisn: string;
  name: string;
  class: string;
  semester: string;
  mataPelajaran: string;
  tp1: number;
  tp2: number;
  tp3: number;
  tp4: number;
  sts: number; // Sumatif Tengah Semester
  sas: number; // Sumatif Akhir Semester
  nilaiAkhir: number;
  ketercapaian: 'Tuntas' | 'Perlu Bimbingan';
  deskripsiTinggi: string;
  deskripsiRendah: string;
}

const DEFAULT_MAPEL = [
  'Pendidikan Agama dan Budi Pekerti',
  'Pendidikan Pancasila',
  'Bahasa Indonesia',
  'Matematika',
  'IPAS (Ilmu Pengetahuan Alam dan Sosial)',
  'PJOK',
  'Seni Rupa / Seni Musik',
  'Bahasa Inggris',
  'Muatan Lokal / Bahasa Daerah'
];

export default function InputNilaiTab() {
  const { students, settings, setLoading } = useStore();
  const classesList = useMemo(() => {
    return getActiveClasses(students);
  }, [students]);

  const semestersList = useMemo(() => getSemestersList(), []);
  const initialActiveSemester = useMemo(() => getActiveSemester(), []);
  const [selectedSemesterId, setSelectedSemesterId] = useState<string>(initialActiveSemester.id);
  const currentSemesterObj = useMemo(() => {
    return semestersList.find(s => s.id === selectedSemesterId) || initialActiveSemester;
  }, [semestersList, selectedSemesterId, initialActiveSemester]);

  const selectedSemester = currentSemesterObj.semesterType;
  const [selectedClass, setSelectedClass] = useState<string>(classesList[0] || '1');
  const [selectedMapel, setSelectedMapel] = useState<string>(DEFAULT_MAPEL[0]);
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [isSavedNotice, setIsSavedNotice] = useState(false);

  // Active students in class
  const classStudents = useMemo(() => {
    return students
      .filter(s => matchStatusActive(s.status) && matchClass(s.class, selectedClass))
      .sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'id'));
  }, [students, selectedClass]);

  // Master Nilai Storage in DB
  const [gradesMap, setGradesMap] = useState<{ [key: string]: Partial<NilaiSiswaRecord> }>(() => {
    return (db.get('nilai_akademik_map') as any) || {};
  });

  // Calculate Logika Pintar for a student grade
  const calculateSmartScore = (tp1: number, tp2: number, tp3: number, tp4: number, sts: number, sas: number, mapel: string) => {
    const avgFormatif = (Number(tp1 || 0) + Number(tp2 || 0) + Number(tp3 || 0) + Number(tp4 || 0)) / 4;
    // Formula Kurikulum Merdeka: (Rata-rata Formatif + STS + 2 * SAS) / 4
    const finalScore = Math.round((avgFormatif + Number(sts || 0) + 2 * Number(sas || 0)) / 4);
    const ketercapaian = finalScore >= 75 ? 'Tuntas' : 'Perlu Bimbingan';

    // Auto-generate competency description based on highest & lowest TP
    const tpScores = [
      { tp: 'TP 1 (Pemahaman Konsep)', score: Number(tp1 || 0) },
      { tp: 'TP 2 (Penerapan Materi)', score: Number(tp2 || 0) },
      { tp: 'TP 3 (Analisis & Penalaran)', score: Number(tp3 || 0) },
      { tp: 'TP 4 (Keterampilan Praktis)', score: Number(tp4 || 0) },
    ];
    tpScores.sort((a, b) => b.score - a.score);

    const highest = tpScores[0];
    const lowest = tpScores[tpScores.length - 1];

    const deskripsiTinggi = `Menunjukkan penguasaan sangat baik dalam ${highest.tp} pada materi ${mapel}.`;
    const deskripsiRendah = lowest.score < 75 
      ? `Perlu pendampingan dan bimbingan lebih lanjut dalam ${lowest.tp}.`
      : `Mencapai kompetensi dasar dengan baik pada ${lowest.tp}.`;

    return {
      nilaiAkhir: isNaN(finalScore) ? 0 : finalScore,
      ketercapaian: ketercapaian as 'Tuntas' | 'Perlu Bimbingan',
      deskripsiTinggi,
      deskripsiRendah
    };
  };

  // Update grade cell
  const handleScoreChange = (studentId: string, field: 'tp1' | 'tp2' | 'tp3' | 'tp4' | 'sts' | 'sas', value: string) => {
    const numVal = value === '' ? 0 : Math.min(100, Math.max(0, Number(value) || 0));
    const gradeKey = `${studentId}_${selectedSemester}_${selectedMapel}`;
    const current = gradesMap[gradeKey] || {
      tp1: 0, tp2: 0, tp3: 0, tp4: 0, sts: 0, sas: 0
    };

    const updated = {
      ...current,
      [field]: numVal
    };

    const smart = calculateSmartScore(
      updated.tp1 ?? 0,
      updated.tp2 ?? 0,
      updated.tp3 ?? 0,
      updated.tp4 ?? 0,
      updated.sts ?? 0,
      updated.sas ?? 0,
      selectedMapel
    );

    setGradesMap(prev => ({
      ...prev,
      [gradeKey]: {
        ...updated,
        ...smart,
        studentId,
        semester: selectedSemester,
        mataPelajaran: selectedMapel
      }
    }));
  };

  // Batch Save to DB
  const handleSaveAll = () => {
    db.set('nilai_akademik_map', gradesMap);
    setIsSavedNotice(true);
    setTimeout(() => setIsSavedNotice(false), 3000);
  };

  const handleExportExcel = () => {
    if (classStudents.length === 0) {
      alert("Tidak ada siswa pada rombel ini.");
      return;
    }

    const rows = classStudents.map((s, idx) => {
      const gradeKey = `${s.id}_${selectedSemester}_${selectedMapel}`;
      const rowData = gradesMap[gradeKey];
      const hasData = rowData && (
        rowData.tp1 !== undefined || rowData.tp2 !== undefined || 
        rowData.tp3 !== undefined || rowData.tp4 !== undefined || 
        rowData.sts !== undefined || rowData.sas !== undefined
      );
      const smart = hasData ? calculateSmartScore(
        rowData.tp1 ?? 0,
        rowData.tp2 ?? 0,
        rowData.tp3 ?? 0,
        rowData.tp4 ?? 0,
        rowData.sts ?? 0,
        rowData.sas ?? 0,
        selectedMapel
      ) : null;

      return {
        No: idx + 1,
        'NISN / NIS': s.nisn || s.nis || '-',
        'Nama Lengkap': s.name,
        'Kelas': `Kelas ${selectedClass}`,
        'Mata Pelajaran': selectedMapel,
        'Semester': selectedSemester,
        'Formatif TP 1': rowData?.tp1 ?? '',
        'Formatif TP 2': rowData?.tp2 ?? '',
        'Formatif TP 3': rowData?.tp3 ?? '',
        'Formatif TP 4': rowData?.tp4 ?? '',
        'Sumatif Tengah Sem (STS)': rowData?.sts ?? '',
        'Sumatif Akhir Sem (SAS)': rowData?.sas ?? '',
        'Nilai Akhir (NA)': smart?.nilaiAkhir ?? '',
        'Ketercapaian (KKTP 75)': smart?.ketercapaian ?? '',
        'Deskripsi Nilai Tertinggi': smart?.deskripsiTinggi ?? '',
        'Deskripsi Nilai Terendah': smart?.deskripsiRendah ?? '',
      };
    });

    exportToExcel(rows, `Penilaian_${selectedMapel.replace(/[^a-zA-Z0-9]/g, '_')}_Kelas_${selectedClass}_${selectedSemester}_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-4 no-print">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold border border-indigo-100">
              <PenTool size={22} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black text-slate-900">Input Nilai & Asesmen Kurikulum Merdeka</h2>
                <span className="px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 text-[10px] font-extrabold flex items-center gap-1">
                  <Sparkles size={10} className="fill-indigo-600" /> Logika Pintar
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Kalkulasi otomatis Nilai Akhir (NA), status KKTP (75), dan auto-generate deskripsi capaian kompetensi TP tertinggi/terendah.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
            {isSavedNotice && (
              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-2 rounded-xl border border-emerald-200 flex items-center gap-1.5 animate-in fade-in">
                <CheckCircle2 size={14} /> Tersimpan ke Database!
              </span>
            )}
            <button
              onClick={handleExportExcel}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-xs transition active:scale-95 whitespace-nowrap"
              title="Ekspor Form Penilaian Mapel ke Excel"
            >
              <FileSpreadsheet size={15} />
              <span>Ekspor Excel</span>
            </button>
            <button
              onClick={handleSaveAll}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-black rounded-xl text-xs shadow-md shadow-indigo-200 transition active:scale-95 whitespace-nowrap"
            >
              <Save size={15} />
              <span>Simpan Seluruh Nilai</span>
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-3 border-t border-slate-100">
          <div>
            <label className="text-[11px] font-bold text-slate-500 block mb-1">Semester & Tahun Ajaran:</label>
            <select
              value={selectedSemesterId}
              onChange={(e) => setSelectedSemesterId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black text-indigo-700 focus:outline-none"
            >
              {semestersList.map(s => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.tahunPelajaran}){s.isActive ? ' ★ Aktif' : ''}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-500 block mb-1">Rombel / Kelas:</label>
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
            >
              {classesList.map(c => {
                const count = students.filter(s => matchStatusActive(s.status) && matchClass(s.class, c)).length;
                return (
                  <option key={c} value={c}>{formatClassLabel(c, true)} ({count} Siswa)</option>
                );
              })}
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-500 block mb-1">Mata Pelajaran:</label>
            <select
              value={selectedMapel}
              onChange={(e) => setSelectedMapel(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
            >
              {DEFAULT_MAPEL.map(m => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-500 block mb-1">Cari Nama Siswa:</label>
            <div className="relative">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Cari siswa..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Grade Ledger Table */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 text-xs">
          <div>
            <span className="font-bold text-slate-700">
              Formulir Penilaian: <strong className="text-indigo-700">{selectedMapel}</strong> (Kelas {selectedClass} - {selectedSemester})
            </span>
          </div>
          <div className="flex items-center gap-3 text-slate-500 text-[11px]">
            <span>KKTP: <strong className="text-slate-800">75</strong></span>
            <span>Rumus: <strong className="text-indigo-600">(Formatif + STS + 2×SAS) / 4</strong></span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-100/90 text-slate-600 uppercase font-black tracking-wider text-[10px] border-b border-slate-200">
                <th className="p-3 pl-4 text-center w-12" rowSpan={2}>No</th>
                <th className="p-3" rowSpan={2}>Nama Peserta Didik</th>
                <th className="p-2 text-center bg-indigo-50/60 border-l border-r border-slate-200" colSpan={4}>
                  Formatif (Tujuan Pembelajaran)
                </th>
                <th className="p-2 text-center bg-purple-50/60 border-r border-slate-200" colSpan={2}>
                  Sumatif
                </th>
                <th className="p-3 text-center bg-amber-50/80 w-20" rowSpan={2}>Nilai Akhir</th>
                <th className="p-3 text-center w-24" rowSpan={2}>Status</th>
                <th className="p-3 pr-4" rowSpan={2}>Deskripsi Capaian Kompetensi (Auto-Generated)</th>
              </tr>
              <tr className="bg-slate-50 text-slate-500 text-[10px] font-bold border-b border-slate-200">
                <th className="p-2 text-center w-14 bg-indigo-50/30 border-l border-slate-200">TP 1</th>
                <th className="p-2 text-center w-14 bg-indigo-50/30">TP 2</th>
                <th className="p-2 text-center w-14 bg-indigo-50/30">TP 3</th>
                <th className="p-2 text-center w-14 bg-indigo-50/30 border-r border-slate-200">TP 4</th>
                <th className="p-2 text-center w-14 bg-purple-50/30">STS</th>
                <th className="p-2 text-center w-14 bg-purple-50/30 border-r border-slate-200">SAS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {classStudents.length === 0 ? (
                <tr>
                  <td colSpan={11} className="p-10 text-center text-slate-400">
                    <p className="font-bold text-slate-600 text-sm">Tidak Ada Siswa di Kelas {selectedClass}</p>
                    <p className="text-xs text-slate-400">Silakan pilih kelas lain atau tambahkan siswa.</p>
                  </td>
                </tr>
              ) : (
                classStudents
                  .filter(s => searchTerm ? s.name.toLowerCase().includes(searchTerm.toLowerCase()) : true)
                  .map((s, idx) => {
                    const gradeKey = `${s.id}_${selectedSemester}_${selectedMapel}`;
                    const rowData = gradesMap[gradeKey];
                    const hasData = rowData !== undefined && (
                      rowData.tp1 !== undefined || rowData.tp2 !== undefined || 
                      rowData.tp3 !== undefined || rowData.tp4 !== undefined || 
                      rowData.sts !== undefined || rowData.sas !== undefined
                    );

                    const smart = hasData ? calculateSmartScore(
                      rowData.tp1 ?? 0,
                      rowData.tp2 ?? 0,
                      rowData.tp3 ?? 0,
                      rowData.tp4 ?? 0,
                      rowData.sts ?? 0,
                      rowData.sas ?? 0,
                      selectedMapel
                    ) : null;

                    return (
                      <tr key={s.id} className="hover:bg-slate-50 transition">
                        <td className="p-3 pl-4 text-center font-mono font-bold text-slate-400">{idx + 1}</td>
                        <td className="p-3 font-bold text-slate-900 min-w-[160px]">
                          <div>{s.name}</div>
                          <div className="text-[10px] font-mono text-slate-400 font-normal">NISN: {s.nisn || '-'}</div>
                        </td>

                        {/* Formatif Inputs */}
                        <td className="p-1.5 text-center bg-indigo-50/20 border-l border-slate-100">
                          <input
                            type="number"
                            min="0"
                            max="100"
                            placeholder="0"
                            value={rowData?.tp1 !== undefined ? rowData.tp1 : ''}
                            onChange={(e) => handleScoreChange(s.id, 'tp1', e.target.value)}
                            className="w-12 py-1 text-center font-mono font-bold text-slate-800 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                          />
                        </td>
                        <td className="p-1.5 text-center bg-indigo-50/20">
                          <input
                            type="number"
                            min="0"
                            max="100"
                            placeholder="0"
                            value={rowData?.tp2 !== undefined ? rowData.tp2 : ''}
                            onChange={(e) => handleScoreChange(s.id, 'tp2', e.target.value)}
                            className="w-12 py-1 text-center font-mono font-bold text-slate-800 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                          />
                        </td>
                        <td className="p-1.5 text-center bg-indigo-50/20">
                          <input
                            type="number"
                            min="0"
                            max="100"
                            placeholder="0"
                            value={rowData?.tp3 !== undefined ? rowData.tp3 : ''}
                            onChange={(e) => handleScoreChange(s.id, 'tp3', e.target.value)}
                            className="w-12 py-1 text-center font-mono font-bold text-slate-800 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                          />
                        </td>
                        <td className="p-1.5 text-center bg-indigo-50/20 border-r border-slate-100">
                          <input
                            type="number"
                            min="0"
                            max="100"
                            placeholder="0"
                            value={rowData?.tp4 !== undefined ? rowData.tp4 : ''}
                            onChange={(e) => handleScoreChange(s.id, 'tp4', e.target.value)}
                            className="w-12 py-1 text-center font-mono font-bold text-slate-800 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:outline-none"
                          />
                        </td>

                        {/* Sumatif Inputs */}
                        <td className="p-1.5 text-center bg-purple-50/20">
                          <input
                            type="number"
                            min="0"
                            max="100"
                            placeholder="0"
                            value={rowData?.sts !== undefined ? rowData.sts : ''}
                            onChange={(e) => handleScoreChange(s.id, 'sts', e.target.value)}
                            className="w-12 py-1 text-center font-mono font-bold text-slate-800 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
                          />
                        </td>
                        <td className="p-1.5 text-center bg-purple-50/20 border-r border-slate-100">
                          <input
                            type="number"
                            min="0"
                            max="100"
                            placeholder="0"
                            value={rowData?.sas !== undefined ? rowData.sas : ''}
                            onChange={(e) => handleScoreChange(s.id, 'sas', e.target.value)}
                            className="w-12 py-1 text-center font-mono font-bold text-slate-800 bg-white border border-slate-200 rounded-lg focus:ring-2 focus:ring-purple-500 focus:outline-none"
                          />
                        </td>

                        {/* Smart Output NA */}
                        <td className="p-2 text-center bg-amber-50/50">
                          {smart ? (
                            <span className={`font-mono font-black text-sm px-2 py-0.5 rounded-md ${
                              smart.nilaiAkhir >= 75 ? 'text-indigo-800 bg-indigo-100/80' : 'text-rose-700 bg-rose-100'
                            }`}>
                              {smart.nilaiAkhir}
                            </span>
                          ) : (
                            <span className="text-slate-400 font-mono font-bold text-xs">-</span>
                          )}
                        </td>

                        {/* Status */}
                        <td className="p-2 text-center">
                          {smart ? (
                            <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                              smart.ketercapaian === 'Tuntas' 
                                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' 
                                : 'bg-rose-50 text-rose-700 border border-rose-200'
                            }`}>
                              {smart.ketercapaian}
                            </span>
                          ) : (
                            <span className="px-2 py-0.5 rounded-full font-bold text-[10px] bg-slate-100 text-slate-500">
                              Belum Diisi
                            </span>
                          )}
                        </td>

                        {/* Smart Description */}
                        <td className="p-2.5 pr-4 text-[11px] text-slate-600 min-w-[280px] leading-snug">
                          {smart ? (
                            <>
                              <div className="text-slate-800 font-medium">✓ {smart.deskripsiTinggi}</div>
                              <div className="text-slate-500 text-[10px] mt-0.5">ℹ {smart.deskripsiRendah}</div>
                            </>
                          ) : (
                            <span className="text-slate-400 italic text-[11px]">Belum ada data nilai formatif/sumatif</span>
                          )}
                        </td>
                      </tr>
                    );
                  })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
