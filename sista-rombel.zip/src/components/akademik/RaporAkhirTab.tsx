import React, { useState, useMemo } from 'react';
import { useStore } from '../../store';
import { db } from '../../data/db';
import { getActiveClasses, matchClass, matchStatusActive, formatClassLabel } from '../../lib/utils';
import { getSemestersList, getActiveSemester, SemesterEntity } from '../../lib/semester';
import { exportToExcel } from '../../lib/excel';
import { 
  FileSpreadsheet, Printer, Search, Filter, Sparkles, 
  Award, CheckCircle2, UserCheck, BookOpen, Layers, Check, School, Calendar
} from 'lucide-react';

const DEFAULT_MAPEL = [
  'Pendidikan Agama dan Budi Pekerti',
  'Pendidikan Pancasila',
  'Bahasa Indonesia',
  'Matematika',
  'IPAS (Ilmu Pengetahuan Alam dan Sosial)',
  'PJOK',
  'Seni Rupa / Musik / Tari',
  'Bahasa Inggris',
  'Muatan Lokal / Bahasa Daerah'
];

export default function RaporAkhirTab() {
  const { students, teachers, settings } = useStore();
  const classesList = useMemo(() => {
    return getActiveClasses(students);
  }, [students]);

  const semestersList = useMemo(() => getSemestersList(), []);
  const initialActiveSemester = useMemo(() => getActiveSemester(), []);
  const [selectedSemesterId, setSelectedSemesterId] = useState<string>(initialActiveSemester.id);
  const currentSemesterObj = useMemo(() => {
    return semestersList.find(s => s.id === selectedSemesterId) || initialActiveSemester;
  }, [semestersList, selectedSemesterId, initialActiveSemester]);

  const selectedSemester = currentSemesterObj.semesterType;
  const [selectedClass, setSelectedClass] = useState<string>(classesList[0] || '1');
  const [selectedStudentId, setSelectedStudentId] = useState<string>('');
  const [isBatchPrinting, setIsBatchPrinting] = useState(false);

  // Active students in class
  const classStudents = useMemo(() => {
    return students
      .filter(s => matchStatusActive(s.status) && matchClass(s.class, selectedClass))
      .sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'id'));
  }, [students, selectedClass]);

  // Selected Student
  const currentStudent = useMemo(() => {
    return classStudents.find(s => s.id === selectedStudentId) || classStudents[0] || students[0];
  }, [classStudents, selectedStudentId, students]);

  // Wali Kelas & Kepsek
  const waliKelas = useMemo(() => {
    return teachers.find(t => matchClass(t.class, selectedClass)) || teachers[0];
  }, [teachers, selectedClass]);

  const kepsek = useMemo(() => {
    return teachers.find(t => t.class === 'Kepala Sekolah' || (t.class && t.class.toLowerCase().includes('kepala'))) || {
      name: settings.headmasterName || 'Kepala Sekolah',
      nip: settings.headmasterNip || '-'
    };
  }, [teachers, settings]);

  // Stored grades map and absensi
  const gradesMap = useMemo(() => {
    return (db.get('nilai_akademik_map') as any) || {};
  }, []);

  const absensiList = useMemo(() => {
    return (db.get('absensi') as any[]) || [];
  }, []);

  // Real attendance counts for current student
  const studentAbsence = useMemo(() => {
    if (!currentStudent) return { sakit: 0, izin: 0, alpa: 0 };
    const records = absensiList.filter((a: any) => a.studentId === currentStudent.id);
    const sakit = records.filter((a: any) => a.status === 'S' || a.status === 'Sakit').length;
    const izin = records.filter((a: any) => a.status === 'I' || a.status === 'Izin').length;
    const alpa = records.filter((a: any) => a.status === 'A' || a.status === 'Alpa' || a.status === 'Tanpa Keterangan').length;
    return { sakit, izin, alpa };
  }, [absensiList, currentStudent]);

  // Generate subjects score list for student
  const studentGrades = useMemo(() => {
    if (!currentStudent) return [];
    return DEFAULT_MAPEL.map((mapel) => {
      const gradeKey = `${currentStudent.id}_${selectedSemester}_${mapel}`;
      const saved = gradesMap[gradeKey];
      const hasGrade = saved && saved.nilaiAkhir !== undefined && saved.nilaiAkhir > 0;
      const na = hasGrade ? saved.nilaiAkhir : null;
      const deskripsiTinggi = saved?.deskripsiTinggi || '';
      const deskripsiRendah = saved?.deskripsiRendah || '';

      return {
        mapel,
        nilaiAkhir: na,
        capaianKompetensi: hasGrade 
          ? `${deskripsiTinggi} ${deskripsiRendah}`.trim()
          : 'Belum ada penilaian pada semester ini.'
      };
    });
  }, [currentStudent, selectedSemester, gradesMap]);

  const gradedOnly = useMemo(() => {
    return studentGrades.filter(g => g.nilaiAkhir !== null && typeof g.nilaiAkhir === 'number') as { mapel: string; nilaiAkhir: number; capaianKompetensi: string }[];
  }, [studentGrades]);

  const averageScore = useMemo(() => {
    if (gradedOnly.length === 0) return null;
    const sum = gradedOnly.reduce((acc, curr) => acc + curr.nilaiAkhir, 0);
    return Math.round(sum / gradedOnly.length);
  }, [gradedOnly]);

  const handleExportLegerExcel = () => {
    if (classStudents.length === 0) {
      alert("Tidak ada siswa pada rombel ini.");
      return;
    }

    const rows = classStudents.map((s, idx) => {
      const row: any = {
        No: idx + 1,
        'NIS / NISN': s.nisn || s.nis || '-',
        'Nama Lengkap': s.name,
        'Kelas': `Kelas ${selectedClass}`,
        'Semester': selectedSemester,
      };

      let totalScore = 0;
      let gradedCount = 0;

      DEFAULT_MAPEL.forEach(mapel => {
        const gradeKey = `${s.id}_${selectedSemester}_${mapel}`;
        const gradeRecord = gradesMap[gradeKey];
        const val = (gradeRecord && typeof gradeRecord.nilaiAkhir === 'number') ? gradeRecord.nilaiAkhir : '';
        row[mapel] = val;
        if (typeof val === 'number') {
          totalScore += val;
          gradedCount++;
        }
      });

      row['Jumlah Nilai'] = totalScore;
      row['Rata-Rata'] = gradedCount > 0 ? (totalScore / gradedCount).toFixed(1) : '-';

      // Absensi
      const studentAbs = absensiList.filter((a: any) => a.studentId === s.id);
      row['Sakit (S)'] = studentAbs.filter((a: any) => a.status === 'S' || a.status === 'Sakit').length;
      row['Izin (I)'] = studentAbs.filter((a: any) => a.status === 'I' || a.status === 'Izin').length;
      row['Alpa (A)'] = studentAbs.filter((a: any) => a.status === 'A' || a.status === 'Alpa' || a.status === 'Tanpa Keterangan').length;

      return row;
    });

    exportToExcel(rows, `Leger_Nilai_Kelas_${selectedClass}_${selectedSemester}_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  return (
    <div className="space-y-6 max-w-5xl mx-auto">
      {/* Control Banner */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-4 no-print">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="flex items-center gap-3.5">
            <div className="w-11 h-11 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold border border-indigo-100">
              <FileSpreadsheet size={22} />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-black text-slate-900">Generator & Cetak Rapor Kurikulum Merdeka</h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-extrabold flex items-center gap-1">
                  <Sparkles size={10} className="fill-emerald-600" /> Logika Pintar CP/TP
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Pencetakan lembar laporan hasil belajar resmi Kurikulum Merdeka (satuan per siswa atau sekaligus sekelas).
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handleExportLegerExcel}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3.5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs transition active:scale-95 whitespace-nowrap shadow-xs"
              title="Ekspor Leger Nilai 1 Rombel ke Excel"
            >
              <FileSpreadsheet size={15} />
              <span>Ekspor Leger Excel</span>
            </button>
            <button
              onClick={() => {
                setIsBatchPrinting(true);
                setTimeout(() => {
                  window.print();
                  setIsBatchPrinting(false);
                }, 300);
              }}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-4 py-2.5 bg-slate-800 hover:bg-slate-900 text-white font-bold rounded-xl text-xs transition whitespace-nowrap"
            >
              <Printer size={15} />
              <span>Cetak 1 Kelas ({classStudents.length})</span>
            </button>
            <button
              onClick={() => window.print()}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white font-black rounded-xl text-xs shadow-md shadow-indigo-200 transition active:scale-95 whitespace-nowrap"
            >
              <Printer size={15} />
              <span>Cetak Rapor Ini</span>
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-3 border-t border-slate-100">
          <div>
            <label className="text-[11px] font-bold text-slate-500 block mb-1">Semester & Tahun Ajaran:</label>
            <select
              value={selectedSemesterId}
              onChange={(e) => setSelectedSemesterId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black text-indigo-700 focus:outline-none"
            >
              {semestersList.map(s => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.tahunPelajaran}){s.isActive ? ' ★ Aktif' : ''}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-500 block mb-1">Pilih Kelas / Rombel:</label>
            <select
              value={selectedClass}
              onChange={(e) => {
                setSelectedClass(e.target.value);
                setSelectedStudentId('');
              }}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
            >
              {classesList.map(c => {
                const count = students.filter(s => matchStatusActive(s.status) && matchClass(s.class, c)).length;
                return (
                  <option key={c} value={c}>{formatClassLabel(c, true)} ({count} Siswa)</option>
                );
              })}
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-500 block mb-1">Pilih Peserta Didik:</label>
            <select
              value={currentStudent?.id || ''}
              onChange={(e) => setSelectedStudentId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
            >
              {classStudents.map(s => (
                <option key={s.id} value={s.id}>{s.name} (NISN: {s.nisn || '-'})</option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Official Printable Report Card View */}
      {currentStudent ? (
        <div className="bg-white p-8 sm:p-12 rounded-3xl border-2 border-slate-200 shadow-md space-y-6 text-slate-900 printable-card">
          
          {/* Header Kop Resmi */}
          <div className="text-center border-b-2 border-slate-900 pb-4 space-y-1">
            <h3 className="text-xs font-bold uppercase tracking-widest text-slate-600">
              PEMERINTAH KABUPATEN / KOTA DINAS PENDIDIKAN
            </h3>
            <h2 className="text-lg font-black tracking-tight text-slate-950 uppercase">
              {settings.schoolName || 'SD NEGERI CONTOH KELAS MERDEKA'}
            </h2>
            <p className="text-[11px] text-slate-600">
              {settings.schoolAddress || 'Jl. Pendidikan Nasional No. 45, Kompleks Edukasi'} | NPSN: {settings.schoolNpsn || '10293847'}
            </p>
            <div className="pt-2">
              <span className="px-4 py-1 rounded-full bg-slate-100 border border-slate-300 text-xs font-black uppercase tracking-wider">
                LAPORAN HASIL BELAJAR PESERTA DIDIK (RAPOR)
              </span>
            </div>
          </div>

          {/* Student Identitas Grid */}
          <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-xs border-b border-slate-200 pb-4 font-medium">
            <div className="flex">
              <span className="w-32 text-slate-500">Nama Peserta Didik</span>
              <span className="w-4 font-bold">:</span>
              <span className="font-black text-slate-900">{currentStudent.name}</span>
            </div>
            <div className="flex">
              <span className="w-32 text-slate-500">Kelas</span>
              <span className="w-4 font-bold">:</span>
              <span className="font-bold text-slate-900">{formatClassLabel(currentStudent.class, true)}</span>
            </div>
            <div className="flex">
              <span className="w-32 text-slate-500">NIS / NISN</span>
              <span className="w-4 font-bold">:</span>
              <span className="font-mono text-slate-800">{currentStudent.nis || '-'} / {currentStudent.nisn || '-'}</span>
            </div>
            <div className="flex">
              <span className="w-32 text-slate-500">Fase</span>
              <span className="w-4 font-bold">:</span>
              <span className="font-bold text-slate-800">
                {parseInt(currentStudent.class || '1') <= 2 ? 'Fase A' : parseInt(currentStudent.class || '1') <= 4 ? 'Fase B' : 'Fase C'}
              </span>
            </div>
            <div className="flex">
              <span className="w-32 text-slate-500">Nama Sekolah</span>
              <span className="w-4 font-bold">:</span>
              <span className="text-slate-800">{settings.schoolName || 'SD NEGERI CONTOH'}</span>
            </div>
            <div className="flex">
              <span className="w-32 text-slate-500">Semester / Tahun</span>
              <span className="w-4 font-bold">:</span>
              <span className="font-bold text-indigo-900">{currentSemesterObj.name} / {currentSemesterObj.tahunPelajaran}</span>
            </div>
          </div>

          {/* Nilai & Capaian Belajar Table */}
          <div className="space-y-2">
            <h4 className="font-black text-xs uppercase tracking-wider text-slate-800">
              A. Laporan Capaian Kompetensi Intrakurikuler
            </h4>
            
            <table className="w-full text-left text-xs border border-slate-300 border-collapse">
              <thead>
                <tr className="bg-slate-100 text-slate-800 font-bold border-b border-slate-300 text-[11px]">
                  <th className="p-2.5 text-center w-10 border-r border-slate-300">No</th>
                  <th className="p-2.5 w-48 border-r border-slate-300">Mata Pelajaran</th>
                  <th className="p-2.5 text-center w-20 border-r border-slate-300">Nilai Akhir</th>
                  <th className="p-2.5">Capaian Kompetensi Pembelajaran</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200">
                {studentGrades.map((g, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/50">
                    <td className="p-2.5 text-center font-mono font-bold text-slate-600 border-r border-slate-300">{idx + 1}</td>
                    <td className="p-2.5 font-bold text-slate-900 border-r border-slate-300">{g.mapel}</td>
                    <td className="p-2.5 text-center font-mono font-black text-sm text-indigo-900 border-r border-slate-300 bg-slate-50/60">
                      {g.nilaiAkhir !== null ? g.nilaiAkhir : '-'}
                    </td>
                    <td className="p-2.5 text-[11px] text-slate-700 leading-relaxed">
                      {g.capaianKompetensi}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-slate-100 font-bold text-slate-900 border-t border-slate-300">
                  <td colSpan={2} className="p-2.5 text-right border-r border-slate-300">Rata-Rata Nilai Akhir:</td>
                  <td className="p-2.5 text-center font-mono font-black text-sm text-indigo-900 border-r border-slate-300 bg-indigo-50">
                    {averageScore !== null ? averageScore : '-'}
                  </td>
                  <td className="p-2.5 text-[11px] text-slate-600">
                    {averageScore !== null 
                      ? (averageScore >= 85 ? 'Predikat Sangat Memuaskan (A)' : averageScore >= 75 ? 'Predikat Baik (B)' : 'Perlu Pendampingan Tambahan')
                      : 'Belum ada kalkulasi rata-rata nilai'
                    }
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Ekstrakurikuler & Presensi */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
            {/* Ekstrakurikuler */}
            <div className="space-y-2">
              <h4 className="font-black text-xs uppercase tracking-wider text-slate-800">
                B. Kegiatan Ekstrakurikuler
              </h4>
              <table className="w-full text-left text-xs border border-slate-300 border-collapse">
                <thead>
                  <tr className="bg-slate-100 text-slate-800 font-bold border-b border-slate-300 text-[10px]">
                    <th className="p-2 text-center w-8 border-r border-slate-300">No</th>
                    <th className="p-2 border-r border-slate-300">Kegiatan</th>
                    <th className="p-2 text-center w-20 border-r border-slate-300">Predikat</th>
                    <th className="p-2">Keterangan</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200 text-[11px]">
                  <tr>
                    <td className="p-2 text-center border-r border-slate-300">1</td>
                    <td className="p-2 font-bold border-r border-slate-300">Praja Muda Karana (Pramuka)</td>
                    <td className="p-2 text-center font-bold text-emerald-700 border-r border-slate-300">Baik</td>
                    <td className="p-2 text-slate-600">Aktif mengikuti latihan rutin</td>
                  </tr>
                </tbody>
              </table>
            </div>

            {/* Presensi */}
            <div className="space-y-2">
              <h4 className="font-black text-xs uppercase tracking-wider text-slate-800">
                C. Ketidakhadiran
              </h4>
              <table className="w-full text-left text-xs border border-slate-300 border-collapse">
                <tbody className="divide-y divide-slate-200 text-[11px]">
                  <tr>
                    <td className="p-2.5 font-medium border-r border-slate-300 w-40">Sakit (S)</td>
                    <td className="p-2.5 font-mono font-bold text-center w-20 border-r border-slate-300">{studentAbsence.sakit}</td>
                    <td className="p-2.5 text-slate-500">Hari</td>
                  </tr>
                  <tr>
                    <td className="p-2.5 font-medium border-r border-slate-300">Izin (I)</td>
                    <td className="p-2.5 font-mono font-bold text-center w-20 border-r border-slate-300">{studentAbsence.izin}</td>
                    <td className="p-2.5 text-slate-500">Hari</td>
                  </tr>
                  <tr>
                    <td className="p-2.5 font-medium border-r border-slate-300">Tanpa Keterangan (A)</td>
                    <td className="p-2.5 font-mono font-bold text-center w-20 border-r border-slate-300">{studentAbsence.alpa}</td>
                    <td className="p-2.5 text-slate-500">Hari</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

          {/* Catatan Wali Kelas */}
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-300 space-y-1 text-xs">
            <span className="font-bold text-slate-800 block">Catatan Wali Kelas:</span>
            <p className="text-slate-700 italic">
              "Ananda {currentStudent.name} menunjukkan semangat belajar yang sangat membanggakan, sikap sopan santun yang terpuji, serta kemandirian dalam menyelesaikan tugas. Pertahankan prestasi dan terus berkarya!"
            </p>
          </div>

          {/* Tanda Tangan */}
          <div className="grid grid-cols-3 gap-4 pt-6 text-center text-xs">
            <div className="space-y-12">
              <p className="font-medium text-slate-600">Mengetahui,<br />Orang Tua / Wali Peserta Didik</p>
              <div className="border-b border-slate-800 w-36 mx-auto"></div>
            </div>

            <div className="space-y-12">
              <p className="font-medium text-slate-600">
                Tempat, {new Date().toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}<br />
                Wali {formatClassLabel(currentStudent.class, true)}
              </p>
              <div>
                <p className="font-bold text-slate-900 underline">{waliKelas?.name || 'Wali Kelas'}</p>
                <p className="font-mono text-[10px] text-slate-500">NIP. {waliKelas?.nip || '-'}</p>
              </div>
            </div>

            <div className="space-y-12">
              <p className="font-medium text-slate-600">
                Mengetahui,<br />Kepala Sekolah
              </p>
              <div>
                <p className="font-bold text-slate-900 underline">{kepsek?.name || settings.headmasterName || 'Kepala Sekolah'}</p>
                <p className="font-mono text-[10px] text-slate-500">NIP. {kepsek?.nip || settings.headmasterNip || '-'}</p>
              </div>
            </div>
          </div>

        </div>
      ) : (
        <div className="p-12 bg-white rounded-3xl border border-slate-200 text-center text-slate-400">
          <p>Pilih peserta didik terlebih dahulu.</p>
        </div>
      )}
    </div>
  );
}
