import React, { useState, useMemo } from 'react';
import { useStore } from '../../store';
import { db } from '../../data/db';
import { getAllClasses, matchClass, formatClassLabel, STANDARD_CLASSES } from '../../lib/utils';
import { getSemestersList, getActiveSemester, SemesterEntity } from '../../lib/semester';
import { exportToExcel } from '../../lib/excel';
import { 
  BookMarked, Plus, Filter, Search, Calendar, User, 
  Trash2, Edit2, Printer, CheckCircle2, X, Save, Clock,
  FileSpreadsheet
} from 'lucide-react';

export interface AgendaItem {
  id: string;
  tanggal: string;
  kelas: string;
  jamKe: string;
  mataPelajaran: string;
  guru: string;
  materiPokok: string;
  capaianTp: string;
  catatanSiswa: string;
  jumlahHadir: number;
  jumlahTidakHadir: number;
  semester?: string;
  status: 'Terlaksana' | 'Tertunda' | 'Diganti';
}

const DEFAULT_MAPEL = [
  
];

export default function AgendaGuruTab() {
  const { students, teachers, settings } = useStore();
  const classesList = useMemo(() => {
    return Array.from(new Set([...getAllClasses(students), ...STANDARD_CLASSES])).sort((a, b) =>
      a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' })
    );
  }, [students]);

  const semestersList = useMemo(() => getSemestersList(), []);
  const initialActiveSemester = useMemo(() => getActiveSemester(), []);
  const [selectedSemesterId, setSelectedSemesterId] = useState<string>(initialActiveSemester.id);
  const currentSemesterObj = useMemo(() => {
    return semestersList.find(s => s.id === selectedSemesterId) || initialActiveSemester;
  }, [semestersList, selectedSemesterId, initialActiveSemester]);

  const selectedSemester = currentSemesterObj.semesterType;
  const [selectedClass, setSelectedClass] = useState<string>('');
  const [selectedMapel, setSelectedMapel] = useState<string>('Semua');
  const [searchTerm, setSearchTerm] = useState<string>('');

  // Persisted Agenda List
  const [agendaList, setAgendaList] = useState<AgendaItem[]>(() => {
    const saved = db.get('agenda_guru');
    if (Array.isArray(saved)) return saved;
    return [];
  });

  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState<Partial<AgendaItem>>({
    tanggal: new Date().toISOString().slice(0, 10),
    kelas: classesList[0] || '1',
    jamKe: '1 - 2 (07:30 - 09:00)',
    mataPelajaran: DEFAULT_MAPEL[0],
    guru: teachers[0]?.name || 'Guru Pengampu',
    materiPokok: '',
    capaianTp: '',
    catatanSiswa: '',
    jumlahHadir: 28,
    jumlahTidakHadir: 0,
    semester: 'Ganjil',
    status: 'Terlaksana'
  });

  const saveAgendaToDb = (newList: AgendaItem[]) => {
    setAgendaList(newList);
    db.set('agenda_guru', newList);
  };

  const handleOpenAdd = () => {
    setEditingId(null);
    setFormData({
      tanggal: new Date().toISOString().slice(0, 10),
      kelas: selectedClass || classesList[0] || '1',
      jamKe: '1 - 2 (07:30 - 09:00)',
      mataPelajaran: DEFAULT_MAPEL[0],
      guru: teachers[0]?.name || 'Guru Pengampu',
      materiPokok: '',
      capaianTp: '',
      catatanSiswa: '',
      jumlahHadir: 28,
      jumlahTidakHadir: 0,
      semester: selectedSemester,
      status: 'Terlaksana'
    });
    setModalOpen(true);
  };

  const handleOpenEdit = (item: AgendaItem) => {
    setEditingId(item.id);
    setFormData({ ...item });
    setModalOpen(true);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Hapus catatan Jurnal KBM ini?')) {
      const updated = agendaList.filter(a => a.id !== id);
      saveAgendaToDb(updated);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.materiPokok || !formData.mataPelajaran) {
      alert('Mohon isi mata pelajaran dan materi pokok.');
      return;
    }

    if (editingId) {
      const updated = agendaList.map(a => (a.id === editingId ? { ...a, ...formData } as AgendaItem : a));
      saveAgendaToDb(updated);
    } else {
      const newItem: AgendaItem = {
        id: `ag-${Date.now()}`,
        tanggal: formData.tanggal || new Date().toISOString().slice(0, 10),
        kelas: formData.kelas || '1',
        jamKe: formData.jamKe || '1 - 2',
        mataPelajaran: formData.mataPelajaran || '',
        guru: formData.guru || 'Guru Pengampu',
        materiPokok: formData.materiPokok || '',
        capaianTp: formData.capaianTp || '',
        catatanSiswa: formData.catatanSiswa || '',
        jumlahHadir: Number(formData.jumlahHadir) || 0,
        jumlahTidakHadir: Number(formData.jumlahTidakHadir) || 0,
        semester: selectedSemester,
        status: (formData.status as any) || 'Terlaksana'
      };
      saveAgendaToDb([newItem, ...agendaList]);
    }
    setModalOpen(false);
  };

  const filteredAgenda = useMemo(() => {
    return agendaList.filter(item => {
      const matchSem = !item.semester || item.semester === selectedSemester;
      const matchCls = selectedClass ? matchClass(item.kelas, selectedClass) : true;
      const matchMpl = selectedMapel === 'Semua' ? true : item.mataPelajaran === selectedMapel;
      const matchSrch = searchTerm
        ? item.materiPokok.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.guru.toLowerCase().includes(searchTerm.toLowerCase()) ||
          item.capaianTp.toLowerCase().includes(searchTerm.toLowerCase())
        : true;
      return matchSem && matchCls && matchMpl && matchSrch;
    });
  }, [agendaList, selectedSemester, selectedClass, selectedMapel, searchTerm]);

  const handleExportExcel = () => {
    if (filteredAgenda.length === 0) {
      alert("Tidak ada data agenda guru untuk diekspor.");
      return;
    }
    const rows = filteredAgenda.map((item, idx) => ({
      No: idx + 1,
      'Tanggal': item.tanggal,
      'Kelas': `Kelas ${item.kelas}`,
      'Jam Ke': item.jamKe,
      'Mata Pelajaran': item.mataPelajaran,
      'Guru Pengampu': item.guru,
      'Materi Pokok / TP': item.materiPokok,
      'Capaian Kompetensi / TP': item.capaianTp,
      'Jumlah Hadir': item.jumlahHadir,
      'Jumlah Tidak Hadir': item.jumlahTidakHadir,
      'Catatan Kasus / Siswa': item.catatanSiswa || '-',
      'Status KBM': item.status
    }));
    exportToExcel(rows, `Jurnal_Agenda_Guru_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-4 no-print">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
              <BookMarked size={20} />
            </div>
            <div>
              <h2 className="text-base font-black text-slate-900">Agenda & Jurnal Harian Guru (KBM)</h2>
              <p className="text-xs text-slate-500 font-medium">
                Pencatatan realisasi materi, ketercapaian TP, respon pembelajaran siswa, & presensi di kelas.
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
            <button
              onClick={handleOpenAdd}
              className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-4 py-2.5 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs shadow-md shadow-amber-200 transition active:scale-95 whitespace-nowrap"
            >
              <Plus size={15} />
              <span>+ Tambah Agenda KBM</span>
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 pt-3 border-t border-slate-100">
          <div>
            <label className="text-[11px] font-bold text-slate-500 block mb-1">Semester & Tahun Ajaran:</label>
            <select
              value={selectedSemesterId}
              onChange={(e) => setSelectedSemesterId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-amber-800 focus:outline-none"
            >
              {semestersList.map(s => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.tahunPelajaran}){s.isActive ? ' ★ Aktif' : ''}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-500 block mb-1">Filter Kelas:</label>
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
            >
              <option value="">Semua Kelas</option>
              {classesList.map(c => (
                <option key={c} value={c}>{formatClassLabel(c, true)}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-500 block mb-1">Filter Mata Pelajaran:</label>
            <select
              value={selectedMapel}
              onChange={(e) => setSelectedMapel(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
            >
              <option value="Semua">Semua Mata Pelajaran</option>
              {DEFAULT_MAPEL.map(m => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>

          <div>
            <label className="text-[11px] font-bold text-slate-500 block mb-1">Cari Jurnal / Materi:</label>
            <div className="relative">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Cari materi, TP, guru..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-8 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none"
              />
            </div>
          </div>
        </div>
      </div>

      {/* Agenda Entries List */}
      <div className="space-y-4">
        {filteredAgenda.length === 0 ? (
          <div className="p-12 bg-white rounded-3xl border border-slate-200/80 text-center text-slate-400">
            <BookMarked size={36} className="mx-auto text-slate-300 mb-2" />
            <p className="font-bold text-slate-700 text-sm">Belum Ada Catatan Agenda Guru</p>
            <p className="text-xs text-slate-400 mt-1">Klik "+ Tambah Agenda KBM" di atas untuk menambahkan jurnal harian baru.</p>
          </div>
        ) : (
          filteredAgenda.map(item => (
            <div 
              key={item.id}
              className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs hover:border-amber-300 transition space-y-3"
            >
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="px-2.5 py-1 rounded-xl bg-amber-50 text-amber-800 font-bold text-xs border border-amber-200">
                    {formatClassLabel(item.kelas, true)}
                  </span>
                  <span className="font-mono text-xs text-slate-500 font-semibold">
                    📅 {item.tanggal}
                  </span>
                  <span className="text-xs text-slate-400">•</span>
                  <span className="font-mono text-xs text-slate-500 font-semibold">
                    ⏰ {item.jamKe}
                  </span>
                  <span className="px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-bold border border-emerald-200">
                    {item.status}
                  </span>
                </div>

                <div className="flex items-center gap-1 no-print">
                  <button
                    onClick={() => handleOpenEdit(item)}
                    className="px-2.5 py-1 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg font-bold text-xs transition flex items-center gap-1"
                  >
                    <Edit2 size={12} />
                    <span>Edit</span>
                  </button>
                  <button
                    onClick={() => handleDelete(item.id)}
                    className="px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg font-bold text-xs transition flex items-center gap-1"
                  >
                    <Trash2 size={12} />
                    <span>Hapus</span>
                  </button>
                </div>
              </div>

              {/* Main Subject & Teacher */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                <div className="md:col-span-2 space-y-1">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Mata Pelajaran & Materi</span>
                  <h3 className="text-sm font-black text-slate-900">{item.mataPelajaran}</h3>
                  <p className="text-xs font-semibold text-indigo-700 bg-indigo-50/70 p-2 rounded-xl border border-indigo-100">
                    📖 Materi: {item.materiPokok}
                  </p>
                </div>

                <div className="space-y-1 bg-slate-50 p-3 rounded-2xl border border-slate-100">
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Guru Pengampu</span>
                  <p className="text-xs font-bold text-slate-800">{item.guru}</p>
                  <div className="text-[11px] text-slate-500 pt-1 flex items-center justify-between">
                    <span>Hadir: <strong className="text-emerald-700">{item.jumlahHadir}</strong></span>
                    <span>Absen: <strong className="text-rose-700">{item.jumlahTidakHadir}</strong></span>
                  </div>
                </div>
              </div>

              {/* TP & Respon Siswa */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs pt-2">
                <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100 space-y-1">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Tujuan Pembelajaran (TP) Terlaksana</span>
                  <p className="text-slate-700">{item.capaianTp || 'Mencakup penguasaan konsep dasar materi dan asesmen formatif.'}</p>
                </div>
                <div className="bg-slate-50 p-3 rounded-2xl border border-slate-100 space-y-1">
                  <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">Catatan Refleksi & Respon Pembelajaran</span>
                  <p className="text-slate-700">{item.catatanSiswa || 'Siswa aktif berpartisipasi dalam diskusi kelompok.'}</p>
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Modal Add / Edit */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-xl w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
                  <BookMarked size={16} />
                </div>
                <h3 className="font-black text-slate-900 text-sm">
                  {editingId ? 'Edit Jurnal Agenda Guru' : 'Tambah Jurnal Harian KBM Baru'}
                </h3>
              </div>
              <button 
                onClick={() => setModalOpen(false)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center"
              >
                <X size={15} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-3 text-xs max-h-[70vh] overflow-y-auto pr-1">
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="font-bold text-slate-600 block mb-1">Tanggal KBM</label>
                  <input
                    type="date"
                    value={formData.tanggal}
                    onChange={(e) => setFormData({ ...formData, tanggal: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                    required
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-600 block mb-1">Kelas</label>
                  <select
                    value={formData.kelas}
                    onChange={(e) => setFormData({ ...formData, kelas: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                  >
                    {classesList.map(c => <option key={c} value={c}>{formatClassLabel(c, true)}</option>)}
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-600 block mb-1">Jam Ke-</label>
                  <input
                    type="text"
                    placeholder="1 - 2 (07:30 - 09:00)"
                    value={formData.jamKe}
                    onChange={(e) => setFormData({ ...formData, jamKe: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-slate-600 block mb-1">Mata Pelajaran</label>
                  <select
                    value={formData.mataPelajaran}
                    onChange={(e) => setFormData({ ...formData, mataPelajaran: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                  >
                    {DEFAULT_MAPEL.map(m => <option key={m} value={m}>{m}</option>)}
                  </select>
                </div>
                <div>
                  <label className="font-bold text-slate-600 block mb-1">Guru Pengampu</label>
                  <input
                    type="text"
                    list="guru-options"
                    value={formData.guru}
                    onChange={(e) => setFormData({ ...formData, guru: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                  />
                  <datalist id="guru-options">
                    {teachers.map(t => <option key={t.id} value={t.name} />)}
                  </datalist>
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-600 block mb-1">Materi Pokok / Bab Pembelajaran</label>
                <input
                  type="text"
                  placeholder="Contoh: Operasi Penjumlahan Bilangan Cacah 1-20"
                  value={formData.materiPokok}
                  onChange={(e) => setFormData({ ...formData, materiPokok: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                  required
                />
              </div>

              <div>
                <label className="font-bold text-slate-600 block mb-1">Tujuan Pembelajaran (TP) / Capaian</label>
                <textarea
                  rows={2}
                  placeholder="Deskripsi TP yang dicapai siswa pada pertemuan ini..."
                  value={formData.capaianTp}
                  onChange={(e) => setFormData({ ...formData, capaianTp: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                />
              </div>

              <div>
                <label className="font-bold text-slate-600 block mb-1">Catatan Refleksi & Kejadian Khusus</label>
                <textarea
                  rows={2}
                  placeholder="Respon siswa, remedial spontan, atau kendala pembelajaran..."
                  value={formData.catatanSiswa}
                  onChange={(e) => setFormData({ ...formData, catatanSiswa: e.target.value })}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="font-bold text-slate-600 block mb-1">Jumlah Hadir</label>
                  <input
                    type="number"
                    value={formData.jumlahHadir}
                    onChange={(e) => setFormData({ ...formData, jumlahHadir: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-600 block mb-1">Jumlah Tidak Hadir</label>
                  <input
                    type="number"
                    value={formData.jumlahTidakHadir}
                    onChange={(e) => setFormData({ ...formData, jumlahTidakHadir: Number(e.target.value) })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-600 block mb-1">Status KBM</label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData({ ...formData, status: e.target.value as any })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl font-semibold"
                  >
                    <option value="Terlaksana">Terlaksana</option>
                    <option value="Tertunda">Tertunda</option>
                    <option value="Diganti">Diganti</option>
                  </select>
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold flex items-center gap-1.5 shadow-md shadow-amber-200"
                >
                  <Save size={14} />
                  <span>Simpan Jurnal KBM</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
