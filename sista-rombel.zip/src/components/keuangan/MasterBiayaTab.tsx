import React, { useState, useMemo } from 'react';
import { Plus, Edit3, Trash2, X, Save, Layers, Search, FileSpreadsheet, UserCheck, Users } from 'lucide-react';
import { db } from '../../data/db';
import { useStore } from '../../store';
import { KeuanganBiaya, KeuanganKelas, DEFAULT_BIAYA_MASTER } from '../../data/keuanganSeed';
import { exportToExcel } from '../../lib/excel';
import { getAllClasses, formatClassLabel, matchClass } from '../../lib/utils';

export default function MasterBiayaTab() {
  const { students } = useStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterKategori, setFilterKategori] = useState('');
  const [filterKelas, setFilterKelas] = useState('');

  const availableClasses = useMemo(() => getAllClasses(students), [students]);

  const [biayaList, setBiayaList] = useState<KeuanganBiaya[]>(() => {
    return db.get<KeuanganBiaya>('keuangan_biaya') || [];
  });

  const [kelasList] = useState<KeuanganKelas[]>(() => {
    return db.get<KeuanganKelas>('keuangan_kelas') || [];
  });

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<KeuanganBiaya | null>(null);

  // Form State matching sheet fields
  const [formData, setFormData] = useState({
    kodeBiaya: 'BYA-01',
    namaBiaya: '',
    kategori: 'Iuran',
    jenjang: 'Semua Jenjang',
    targetKelas: 'Semua Kelas',
    kelasId: '',
    siswaId: '',
    namaSiswa: 'Semua Siswa',
    nominal: 150000,
    periode: 'Bulanan',
    wajib: 'Wajib',
    status: 'AKTIF',
    keterangan: '',
  });

  const [siswaSearchInput, setSiswaSearchInput] = useState('');
  const [isStudentDropdownOpen, setIsStudentDropdownOpen] = useState(false);

  const saveBiayaToDb = (newList: KeuanganBiaya[]) => {
    setBiayaList(newList);
    db.set('keuangan_biaya', newList);
  };

  const handleOpenAdd = () => {
    setEditingItem(null);
    setFormData({
      kodeBiaya: `BYA-${String(biayaList.length + 1).padStart(3, '0')}`,
      namaBiaya: '',
      kategori: 'Iuran',
      jenjang: 'Semua Jenjang',
      targetKelas: 'Semua Kelas',
      kelasId: '',
      siswaId: '',
      namaSiswa: 'Semua Siswa',
      nominal: 150000,
      periode: 'Bulanan',
      wajib: 'Wajib',
      status: 'AKTIF',
      keterangan: '',
    });
    setSiswaSearchInput('');
    setIsModalOpen(true);
  };

  const handleOpenEdit = (item: KeuanganBiaya) => {
    setEditingItem(item);
    setFormData({
      kodeBiaya: item.kodeBiaya || item.id || '',
      namaBiaya: item.namaBiaya || item.nama || '',
      kategori: item.kategori || 'Iuran',
      jenjang: item.jenjang || 'Semua Jenjang',
      targetKelas: item.targetKelas || item.kelasNama || 'Semua Kelas',
      kelasId: item.kelasId || '',
      siswaId: item.siswaId || '',
      namaSiswa: item.namaSiswa || 'Semua Siswa',
      nominal: Number(item.nominal) || 0,
      periode: item.periode || 'Bulanan',
      wajib: item.wajib || 'Wajib',
      status: item.status || (item.aktif !== false ? 'AKTIF' : 'NONAKTIF'),
      keterangan: item.keterangan || '',
    });
    setSiswaSearchInput(item.namaSiswa && item.namaSiswa !== 'Semua Siswa' ? item.namaSiswa : '');
    setIsModalOpen(true);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('Hapus pos biaya ini?')) {
      const updated = biayaList.filter(b => b.id !== id);
      saveBiayaToDb(updated);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.namaBiaya.trim()) {
      alert('Nama pos biaya harus diisi');
      return;
    }

    const selectedKelasObj = kelasList.find(k => k.id === formData.kelasId);
    const targetKelas = formData.kelasId ? (selectedKelasObj?.nama || formData.kelasId) : 'Semua Kelas';

    if (editingItem) {
      const updated = biayaList.map(b => b.id === editingItem.id ? {
        ...b,
        kodeBiaya: formData.kodeBiaya,
        nama: formData.namaBiaya,
        namaBiaya: formData.namaBiaya,
        kategori: formData.kategori,
        jenjang: formData.jenjang,
        targetKelas,
        kelasId: formData.kelasId,
        kelasNama: targetKelas,
        siswaId: formData.siswaId,
        namaSiswa: formData.siswaId ? formData.namaSiswa : 'Semua Siswa',
        nominal: formData.nominal,
        periode: formData.periode,
        wajib: formData.wajib,
        status: formData.status,
        aktif: formData.status === 'AKTIF',
        keterangan: formData.keterangan,
        updatedAt: new Date().toISOString(),
      } : b);
      saveBiayaToDb(updated);
    } else {
      const newId = `BYA_${Date.now()}`;
      const newItem: KeuanganBiaya = {
        id: newId,
        biayaId: newId,
        kodeBiaya: formData.kodeBiaya,
        nama: formData.namaBiaya,
        namaBiaya: formData.namaBiaya,
        kategori: formData.kategori,
        jenjang: formData.jenjang,
        targetKelas,
        kelasId: formData.kelasId,
        kelasNama: targetKelas,
        siswaId: formData.siswaId,
        namaSiswa: formData.siswaId ? formData.namaSiswa : 'Semua Siswa',
        nominal: formData.nominal,
        periode: formData.periode,
        wajib: formData.wajib,
        status: formData.status,
        aktif: formData.status === 'AKTIF',
        keterangan: formData.keterangan,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      saveBiayaToDb([...biayaList, newItem]);
    }

    setIsModalOpen(false);
  };

  const filteredBiaya = useMemo(() => {
    return biayaList.filter(b => {
      const q = searchTerm.toLowerCase();
      const nama = String(b.namaBiaya || b.nama || '').toLowerCase();
      const kode = String(b.kodeBiaya || b.id || '').toLowerCase();
      const kat = String(b.kategori || '').toLowerCase();
      const siswa = String(b.namaSiswa || '').toLowerCase();
      const matchesQ = !searchTerm || nama.includes(q) || kode.includes(q) || kat.includes(q) || siswa.includes(q);
      const matchesKat = !filterKategori || b.kategori === filterKategori;
      const matchesKelas = !filterKelas || matchClass(b.kelasNama || b.targetKelas || '', filterKelas);
      return matchesQ && matchesKat && matchesKelas;
    });
  }, [biayaList, searchTerm, filterKategori, filterKelas]);

  // Filtered list of students for autocomplete
  const autocompleteStudents = useMemo(() => {
    if (!siswaSearchInput.trim()) return students.slice(0, 10);
    const q = siswaSearchInput.toLowerCase();
    return students.filter(s => 
      s.name.toLowerCase().includes(q) || 
      String(s.nis || s.nisn || '').toLowerCase().includes(q) ||
      String(s.class || '').toLowerCase().includes(q)
    );
  }, [students, siswaSearchInput]);

  const handleExportExcel = () => {
    if (biayaList.length === 0) {
      alert("Belum ada data pos biaya untuk diekspor.");
      return;
    }
    const rows = biayaList.map((b, idx) => ({
      No: idx + 1,
      BiayaID: b.biayaId || b.id,
      KodeBiaya: b.kodeBiaya || b.id,
      NamaBiaya: b.namaBiaya || b.nama,
      Kategori: b.kategori || 'Iuran',
      Jenjang: b.jenjang || 'Semua Jenjang',
      Target_Kelas: b.targetKelas || b.kelasNama || 'Semua Kelas',
      KelasID: b.kelasId || '-',
      SiswaID: b.siswaId || '-',
      NamaSiswa: b.namaSiswa || 'Semua Siswa',
      Nominal: b.nominal,
      Periode: b.periode || 'Bulanan',
      Wajib: b.wajib || 'Wajib',
      Status: b.status || (b.aktif !== false ? 'AKTIF' : 'NONAKTIF'),
      Keterangan: b.keterangan || '-',
      CreatedAt: b.createdAt || '-',
      UpdatedAt: b.updatedAt || '-'
    }));
    exportToExcel(rows, `Master_Tarif_Biaya_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  const fmtRp = (n: number) => 'Rp ' + Number(n || 0).toLocaleString('id-ID');

  return (
    <div className="space-y-5 animate-in fade-in">
      {/* Header & Filter Controls */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div>
          <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
            <Layers size={20} className="text-emerald-600" />
            Master Tarif
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Kelola master pos pembayaran, kategori, peruntukan rombel, dan target siswa khusus.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full lg:w-auto">
          <select
            value={filterKategori}
            onChange={(e) => setFilterKategori(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
          >
            <option value="">Semua Kategori</option>
            <option value="Iuran">Iuran</option>
            <option value="Kegiatan">Kegiatan</option>
            <option value="Seragam">Seragam</option>
            <option value="Ujian">Ujian</option>
            <option value="Gedung">Gedung</option>
            <option value="Raport">Raport</option>
            <option value="Modul/Buku">Modul / Buku</option>
            <option value="Lainnya">Lainnya</option>
          </select>

          <select
            value={filterKelas}
            onChange={(e) => setFilterKelas(e.target.value)}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
          >
            <option value="">Semua Rombel</option>
            {availableClasses.map(c => (
              <option key={c} value={c}>{formatClassLabel(c)}</option>
            ))}
          </select>

          <div className="relative flex-1 sm:w-56">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Cari biaya, kode, siswa..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-7 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
            />
            {searchTerm && (
              <button onClick={() => setSearchTerm('')} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                <X size={13} />
              </button>
            )}
          </div>

          <button
            onClick={handleExportExcel}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition active:scale-95 whitespace-nowrap"
            title="Ekspor ke Excel format Sheet BIAYA"
          >
            <FileSpreadsheet size={14} className="text-emerald-600" />
            <span>Ekspor Excel</span>
          </button>

          <button
            onClick={handleOpenAdd}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-xs transition flex items-center gap-1.5 active:scale-95 whitespace-nowrap"
          >
            <Plus size={15} />
            <span>+ Tambah Pos Biaya</span>
          </button>
        </div>
      </div>

      {/* Table Sesuai Skema Sheet BIAYA */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50/90 text-slate-600 uppercase font-black text-[10px] border-b border-slate-200 tracking-wider">
              <tr>
                <th className="p-3.5 pl-4">Kode & ID Biaya</th>
                <th className="p-3.5">Nama Biaya</th>
                <th className="p-3.5">Kategori</th>
                <th className="p-3.5">Target Rombel</th>
                <th className="p-3.5 text-right">Nominal Tarif</th>
                <th className="p-3.5 text-center">Periode</th>
                <th className="p-3.5 text-center">Kewajiban</th>
                <th className="p-3.5 text-center">Status</th>
                <th className="p-3.5 pr-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {filteredBiaya.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-10 text-center text-slate-400">
                    Belum ada pos biaya yang sesuai kriteria pencarian.
                  </td>
                </tr>
              ) : (
                filteredBiaya.map(b => {
                  const kode = b.kodeBiaya || b.id;
                  const nama = b.namaBiaya || b.nama;
                  const kategori = b.kategori || 'Iuran';
                  const rombel = b.targetKelas || b.kelasNama || 'Semua Kelas';
                  const periode = b.periode || 'Bulanan';
                  const wajib = b.wajib || 'Wajib';
                  const isAktif = b.status === 'AKTIF' || b.aktif !== false;

                  return (
                    <tr key={b.id} className="hover:bg-slate-50/80 transition">
                      <td className="p-3.5 pl-4 font-mono">
                        <div className="font-black text-slate-800">{kode}</div>
                        <div className="text-[10px] text-slate-400 font-mono">{b.biayaId || b.id}</div>
                      </td>
                      <td className="p-3.5">
                        <div className="font-black text-slate-900 text-sm">{nama}</div>
                        {b.keterangan && (
                          <div className="text-[11px] text-slate-500 line-clamp-1">{b.keterangan}</div>
                        )}
                      </td>
                      <td className="p-3.5">
                        <span className="px-2 py-0.5 rounded-lg font-bold text-[10px] bg-slate-100 text-slate-700 border border-slate-200">
                          {kategori}
                        </span>
                      </td>
                      <td className="p-3.5">
                        <div className="font-bold text-slate-800">{rombel}</div>
                      </td>
                      <td className="p-3.5 text-right font-mono font-black text-emerald-700 text-sm">
                        {fmtRp(b.nominal)}
                      </td>
                      <td className="p-3.5 text-center">
                        <span className="px-2 py-0.5 rounded-full font-bold text-[10px] bg-sky-50 text-sky-700 border border-sky-200">
                          {periode}
                        </span>
                      </td>
                      <td className="p-3.5 text-center">
                        <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                          wajib === 'Wajib' 
                            ? 'bg-amber-50 text-amber-800 border border-amber-200' 
                            : 'bg-indigo-50 text-indigo-700 border border-indigo-200'
                        }`}>
                          {wajib}
                        </span>
                      </td>
                      <td className="p-3.5 text-center">
                        <span className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                          isAktif ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-500'
                        }`}>
                          {isAktif ? 'AKTIF' : 'NONAKTIF'}
                        </span>
                      </td>
                      <td className="p-3.5 pr-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => handleOpenEdit(b)}
                            className="p-1.5 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-lg transition"
                            title="Edit Pos Biaya"
                          >
                            <Edit3 size={14} />
                          </button>
                          <button
                            onClick={() => handleDelete(b.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                            title="Hapus Pos Biaya"
                          >
                            <Trash2 size={14} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Input/Edit Biaya Sesuai Skema Sheet BIAYA */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-xl rounded-3xl border border-slate-200 shadow-2xl p-6 space-y-5 my-8 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
                  <Layers size={18} />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    {editingItem ? 'Edit Pos Tarif Biaya' : 'Tambah Pos Tarif Biaya Baru'}
                  </h3>
                  <p className="text-[11px] text-slate-400 font-medium">Skema Tabel Database Sheet: BIAYA</p>
                </div>
              </div>
              <button onClick={() => setIsModalOpen(false)} className="text-slate-400 hover:text-slate-700">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Kode Biaya (KodeBiaya)</label>
                  <input
                    type="text"
                    required
                    placeholder="misal: BYA-01, MODUL-01"
                    value={formData.kodeBiaya}
                    onChange={(e) => setFormData(prev => ({ ...prev, kodeBiaya: e.target.value }))}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Kategori Biaya (Kategori)</label>
                  <select
                    value={formData.kategori}
                    onChange={(e) => setFormData(prev => ({ ...prev, kategori: e.target.value }))}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
                  >
                    <option value="Iuran">Iuran</option>
                    <option value="Uang Pangkal">Uang Pangkal</option>
                    <option value="Uang Seragam">Uang Seragam</option>
                    <option value="Uang Gedung">Uang Gedung</option>
                    <option value="Kegiatan">Kegiatan</option>
                    <option value="Ujian">Ujian</option>
                    <option value="Lain-lain">Lain-lain</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Nama Pos Biaya (NamaBiaya)</label>
                <input
                  type="text"
                  required
                  placeholder="misal: Iuran Bulanan, Seragam Batik & Olahraga..."
                  value={formData.namaBiaya}
                  onChange={(e) => setFormData(prev => ({ ...prev, namaBiaya: e.target.value }))}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Jenjang (Jenjang)</label>
                  <select
                    value={formData.jenjang}
                    onChange={(e) => setFormData(prev => ({ ...prev, jenjang: e.target.value }))}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
                  >
                    <option value="Semua Jenjang">Semua Jenjang</option>
                    <option value="Paket A">Paket A (Setara SD)</option>
                    <option value="Paket B">Paket B (Setara SMP)</option>
                    <option value="Paket C">Paket C (Setara SMA)</option>
                    <option value="SD">SD</option>
                    <option value="SMP">SMP</option>
                    <option value="SMA">SMA</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Target Kelas / Rombel (Target_Kelas)</label>
                  <select
                    value={formData.kelasId}
                    onChange={(e) => setFormData(prev => ({ ...prev, kelasId: e.target.value }))}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
                  >
                    <option value="">Semua Kelas (Umum)</option>
                    {availableClasses.map(c => (
                      <option key={c} value={c}>{formatClassLabel(c)}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Target Siswa Khusus */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="block text-xs font-bold text-slate-700">Nama Siswa (Target Khusus / Individual)</label>
                  {formData.siswaId && (
                    <button
                      type="button"
                      onClick={() => {
                        setFormData(prev => ({ ...prev, siswaId: '', namaSiswa: 'Semua Siswa' }));
                        setSiswaSearchInput('');
                      }}
                      className="text-[10px] text-rose-600 font-bold hover:underline"
                    >
                      Reset ke Semua Siswa
                    </button>
                  )}
                </div>
                <div className="relative">
                  <input
                    type="text"
                    placeholder="Ketik nama siswa atau biarkan kosong untuk 'Semua Siswa'..."
                    value={siswaSearchInput || (formData.siswaId ? formData.namaSiswa : '')}
                    onChange={(e) => {
                      setSiswaSearchInput(e.target.value);
                      setIsStudentDropdownOpen(true);
                      if (!e.target.value) {
                        setFormData(prev => ({ ...prev, siswaId: '', namaSiswa: 'Semua Siswa' }));
                      }
                    }}
                    onFocus={() => setIsStudentDropdownOpen(true)}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
                  />
                  {isStudentDropdownOpen && (
                    <div className="absolute left-0 right-0 top-full mt-1 bg-white border border-slate-200 rounded-2xl shadow-xl z-20 max-h-48 overflow-y-auto divide-y divide-slate-100">
                      <button
                        type="button"
                        onClick={() => {
                          setFormData(prev => ({ ...prev, siswaId: '', namaSiswa: 'Semua Siswa' }));
                          setSiswaSearchInput('');
                          setIsStudentDropdownOpen(false);
                        }}
                        className="w-full text-left p-2.5 text-xs font-black text-slate-700 hover:bg-slate-50 flex items-center gap-2"
                      >
                        <Users size={14} className="text-slate-400" />
                        <span>Berlaku untuk Semua Siswa (Default)</span>
                      </button>
                      {autocompleteStudents.map(s => (
                        <button
                          key={s.id}
                          type="button"
                          onClick={() => {
                            setFormData(prev => ({
                              ...prev,
                              siswaId: s.id,
                              namaSiswa: s.name,
                              targetKelas: s.class || prev.targetKelas,
                            }));
                            setSiswaSearchInput(`${s.name} (${s.class})`);
                            setIsStudentDropdownOpen(false);
                          }}
                          className="w-full text-left p-2.5 text-xs text-slate-800 hover:bg-emerald-50 hover:text-emerald-800 transition flex items-center justify-between"
                        >
                          <span className="font-bold">{s.name}</span>
                          <span className="text-[10px] font-mono text-slate-400 bg-slate-100 px-2 py-0.5 rounded">
                            {s.class} | {s.nis || s.nisn || s.id}
                          </span>
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Nominal Tarif (Rp)</label>
                  <input
                    type="number"
                    required
                    min={0}
                    step={5000}
                    value={formData.nominal}
                    onChange={(e) => setFormData(prev => ({ ...prev, nominal: Number(e.target.value) || 0 }))}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-black text-emerald-700 font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Frekuensi / Periode</label>
                  <select
                    value={formData.periode}
                    onChange={(e) => setFormData(prev => ({ ...prev, periode: e.target.value }))}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
                  >
                    <option value="Bulanan">Bulanan</option>
                    <option value="Semester">Semester</option>
                    <option value="Tahunan">Tahunan</option>
                    <option value="Sekali Bayar">Sekali Bayar</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Status Kewajiban (Wajib)</label>
                  <select
                    value={formData.wajib}
                    onChange={(e) => setFormData(prev => ({ ...prev, wajib: e.target.value }))}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
                  >
                    <option value="Wajib">Wajib</option>
                    <option value="Sukarela">Sukarela</option>
                    <option value="Pilihan">Pilihan</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Status Keaktifan (Status)</label>
                  <select
                    value={formData.status}
                    onChange={(e) => setFormData(prev => ({ ...prev, status: e.target.value }))}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
                  >
                    <option value="AKTIF">AKTIF (Dapat Ditagihkan)</option>
                    <option value="NONAKTIF">NONAKTIF</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Keterangan Tambahan</label>
                  <input
                    type="text"
                    placeholder="misal: Termasuk buku modul semester 1 & 2"
                    value={formData.keterangan}
                    onChange={(e) => setFormData(prev => ({ ...prev, keterangan: e.target.value }))}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                  />
                </div>
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2.5 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-200 transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-xs flex items-center gap-1.5 transition active:scale-95"
                >
                  <Save size={14} />
                  <span>Simpan Pos Biaya</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
