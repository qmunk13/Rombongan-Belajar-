import React, { useState, useMemo } from 'react';
import { 
  Wallet, Search, Plus, Trash2, X, ArrowUpRight, ArrowDownRight,
  TrendingUp, TrendingDown, CheckCircle, UserCheck, FileSpreadsheet, User, Building2,
  Upload, FileText, ChevronLeft, ChevronRight, GraduationCap
} from 'lucide-react';
import { useStore } from '../../store';
import { db } from '../../data/db';
import { KeuanganTabungan } from '../../data/keuanganSeed';
import { parseRawTabunganTSV } from '../../data/tabunganImporter';
import { DEFAULT_TABUNGAN_LIST } from '../../data/tabunganSeedData';
import { exportToExcel } from '../../lib/excel';
import { getAllClasses, formatClassLabel, matchClass } from '../../lib/utils';
import { 
  getAcademicPeriodInfo, 
  matchAcademicFilter, 
  extractAvailableAcademicYears 
} from '../../lib/academicYear';

export default function TabunganSiswaTab() {
  const { students } = useStore();
  const [selectedSiswaId, setSelectedSiswaId] = useState('');
  const [filterKelas, setFilterKelas] = useState('');
  const [filterTahunAjaran, setFilterTahunAjaran] = useState('SEMUA');
  const [filterSemester, setFilterSemester] = useState('SEMUA');
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);

  const availableClasses = useMemo(() => getAllClasses(students), [students]);

  // Tabungan State
  const [tabunganList, setTabunganList] = useState<KeuanganTabungan[]>(() => {
    const rawData = db.get<KeuanganTabungan>('keuangan_tabungan');
    if (!rawData || rawData.length === 0) {
      return [];
    }
    // Deduplicate by ID
    const uniqueMap = new Map<string, KeuanganTabungan>();
    rawData.forEach((item, index) => {
      const uniqueKey = item.tabunganId || item.id || `TAB_${index}`;
      if (!uniqueMap.has(uniqueKey)) {
        uniqueMap.set(uniqueKey, { ...item, id: uniqueKey });
      }
    });
    return Array.from(uniqueMap.values());
  });

  // Modal Form State
  const [formData, setFormData] = useState({
    siswaId: '',
    namaSiswa: '',
    tanggal: new Date().toISOString().slice(0, 10),
    jenis: 'SETOR' as 'SETOR' | 'TARIK',
    nominal: 50000,
    petugasId: 'Bendahara Tabungan',
    keterangan: 'Setoran tabungan rutin',
  });

  const [siswaSearchInput, setSiswaSearchInput] = useState('');
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [importRawText, setImportRawText] = useState('');

  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  const saveTabunganToDb = (newList: KeuanganTabungan[]) => {
    setTabunganList(newList);
    db.set('keuangan_tabungan', newList);
  };

  const handleImportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!importRawText.trim()) {
      alert('Silakan tempel (paste) data spreadsheet terlebih dahulu.');
      return;
    }
    const parsed = parseRawTabunganTSV(importRawText);
    if (parsed.length === 0) {
      alert('Format data tidak dikenali. Pastikan menyertakan baris judul kolom dan dipisahkan tab/spasi.');
      return;
    }
    // Merge or replace safely without duplicate keys
    const mergeMap = new Map<string, KeuanganTabungan>();
    // Add existing first
    tabunganList.forEach((item, index) => {
      const k = item.tabunganId || item.id || `TAB_EXIST_${index}`;
      mergeMap.set(k, { ...item, id: k });
    });
    // Overlay new imported items
    parsed.forEach((item, index) => {
      const k = item.tabunganId || item.id || `TAB_NEW_${index}`;
      mergeMap.set(k, { ...item, id: k });
    });
    const combined = Array.from(mergeMap.values());
    saveTabunganToDb(combined);
    setIsImportModalOpen(false);
    setImportRawText('');
    alert(`Berhasil mengimpor ${parsed.length} transaksi tabungan!`);
  };

  const availableAcademicYears = useMemo(() => {
    const dates = tabunganList.map(t => t.tanggal);
    return extractAvailableAcademicYears(dates);
  }, [tabunganList]);

  // Distinct Siswa List with Savings
  const distinctSiswaList = useMemo(() => {
    const map = new Map<string, { id: string; name: string; class: string }>();
    students.forEach(s => {
      map.set(s.id, { id: s.id, name: s.name, class: s.class || '' });
    });
    tabunganList.forEach(t => {
      if (!map.has(t.siswaId)) {
        map.set(t.siswaId, { id: t.siswaId, name: t.namaSiswa, class: '-' });
      }
    });
    const all = Array.from(map.values());
    if (!filterKelas) return all;
    return all.filter(s => matchClass(s.class, filterKelas));
  }, [students, tabunganList, filterKelas]);

  // Filtered Tabungan Items & Running Balance calculation
  const filteredAndCalculatedItems = useMemo(() => {
    // Sort chronological first to compute running balance
    const sorted = [...tabunganList].sort((a, b) => 
      new Date(a.tanggal).getTime() - new Date(b.tanggal).getTime()
    );

    const balanceMap: { [siswaId: string]: number } = {};
    const withRunningBalance = sorted.map(t => {
      const nom = Number(t.nominal) || 0;
      const isSetor = t.jenis === 'SETOR' || t.jenisTransaksi === 'SETOR';
      if (!balanceMap[t.siswaId]) balanceMap[t.siswaId] = 0;
      if (isSetor) balanceMap[t.siswaId] += nom;
      else balanceMap[t.siswaId] -= nom;

      const studentObj = students.find(s => s.id === t.siswaId);
      const studentClass = studentObj?.class || '';

      const debit = isSetor ? nom : 0;
      const kredit = !isSetor ? nom : 0;

      return {
        ...t,
        tabunganId: t.tabunganId || t.id,
        jenisTransaksi: isSetor ? 'SETOR' : 'TARIK',
        debit,
        kredit,
        studentClass,
        saldo: balanceMap[t.siswaId],
      };
    });

    // Reverse to show latest first
    const reversed = [...withRunningBalance].reverse();

    return reversed.filter(t => {
      const q = searchTerm.toLowerCase();
      const nama = String(t.namaSiswa || '').toLowerCase();
      const sId = String(t.siswaId || '').toLowerCase();
      const tId = String(t.tabunganId || t.id || '').toLowerCase();
      const ket = String(t.keterangan || t.catatan || '').toLowerCase();
      const pet = String(t.petugasId || t.createdBy || '').toLowerCase();

      const matchesQ = !searchTerm || nama.includes(q) || sId.includes(q) || tId.includes(q) || ket.includes(q) || pet.includes(q);
      const matchesSiswa = !selectedSiswaId || t.siswaId === selectedSiswaId;
      const matchesKelas = !filterKelas || matchClass(t.studentClass, filterKelas);
      const matchesTA = matchAcademicFilter(t.tanggal, filterTahunAjaran, filterSemester);

      return matchesQ && matchesSiswa && matchesKelas && matchesTA;
    });
  }, [tabunganList, selectedSiswaId, filterKelas, filterTahunAjaran, filterSemester, searchTerm, students]);

  const totalPages = Math.ceil(filteredAndCalculatedItems.length / pageSize) || 1;
  const paginatedItems = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredAndCalculatedItems.slice(start, start + pageSize);
  }, [filteredAndCalculatedItems, currentPage, pageSize]);

  // Overall Total Savings
  const totalSaldoSemua = useMemo(() => {
    return tabunganList.reduce((acc, t) => {
      const nom = Number(t.nominal) || 0;
      const isSetor = t.jenis === 'SETOR' || t.jenisTransaksi === 'SETOR';
      return isSetor ? acc + nom : acc - nom;
    }, 0);
  }, [tabunganList]);

  // Filtered list of students for autocomplete
  const autocompleteStudents = useMemo(() => {
    if (!siswaSearchInput.trim()) return students.slice(0, 10);
    const q = siswaSearchInput.toLowerCase();
    return students.filter(s => 
      s.name.toLowerCase().includes(q) || 
      String(s.nis || s.nisn || '').toLowerCase().includes(q) ||
      String(s.class || '').toLowerCase().includes(q)
    );
  }, [students, siswaSearchInput]);

  const handleOpenAdd = () => {
    const firstStudent = students[0];
    setFormData({
      siswaId: firstStudent?.id || '',
      namaSiswa: firstStudent?.name || '',
      tanggal: new Date().toISOString().slice(0, 10),
      jenis: 'SETOR',
      nominal: 50000,
      petugasId: 'Bendahara Tabungan',
      keterangan: 'Setoran tabungan rutin',
    });
    setSiswaSearchInput(firstStudent ? `${firstStudent.name} (${firstStudent.class})` : '');
    setIsAddModalOpen(true);
  };

  const handleSelectStudentInModal = (st: any) => {
    setFormData(prev => ({
      ...prev,
      siswaId: st.id,
      namaSiswa: st.name,
    }));
    setSiswaSearchInput(`${st.name} (${st.class})`);
    setIsDropdownOpen(false);
  };

  const handleSubmitTabungan = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.siswaId) {
      alert('Pilih siswa terlebih dahulu');
      return;
    }

    const inputNominal = Number(formData.nominal) || 0;
    if (inputNominal <= 0) {
      alert('Nominal harus lebih besar dari Rp 0');
      return;
    }

    // Check withdrawal limit
    if (formData.jenis === 'TARIK') {
      const currentSaldo = tabunganList
        .filter(t => t.siswaId === formData.siswaId)
        .reduce((acc, t) => {
          const isSetor = t.jenis === 'SETOR' || t.jenisTransaksi === 'SETOR';
          return isSetor ? acc + Number(t.nominal) : acc - Number(t.nominal);
        }, 0);
      
      if (inputNominal > currentSaldo) {
        alert(`Saldo tidak cukup untuk penarikan. Saldo saat ini: Rp ${currentSaldo.toLocaleString('id-ID')}`);
        return;
      }
    }

    const nowStr = new Date().toISOString();
    const tabId = `TAB_${Date.now()}`;
    const newItem: KeuanganTabungan = {
      id: tabId,
      tabunganId: tabId,
      siswaId: formData.siswaId,
      namaSiswa: formData.namaSiswa,
      tanggal: formData.tanggal,
      jenisTransaksi: formData.jenis,
      jenis: formData.jenis,
      debit: formData.jenis === 'SETOR' ? inputNominal : 0,
      kredit: formData.jenis === 'TARIK' ? inputNominal : 0,
      nominal: inputNominal,
      petugasId: formData.petugasId,
      keterangan: formData.keterangan,
      catatan: formData.keterangan,
      status: 'SUKSES',
      createdBy: formData.petugasId,
      createdAt: nowStr,
      updatedAt: nowStr,
    };

    saveTabunganToDb([newItem, ...tabunganList]);
    setIsAddModalOpen(false);
    alert(`Transaksi tabungan ${formData.jenis} sebesar Rp ${inputNominal.toLocaleString('id-ID')} berhasil dicatat!`);
  };

  const handleDeleteTabungan = (id: string) => {
    if (window.confirm('Hapus transaksi tabungan ini?')) {
      const updated = tabunganList.filter(t => t.id !== id);
      saveTabunganToDb(updated);
    }
  };

  const fmtRp = (n: number) => 'Rp ' + Number(n || 0).toLocaleString('id-ID');

  const handleExportExcel = () => {
    if (filteredAndCalculatedItems.length === 0) {
      alert("Tidak ada transaksi tabungan untuk diekspor.");
      return;
    }
    const rows = filteredAndCalculatedItems.map((t, idx) => ({
      No: idx + 1,
      TabunganID: t.tabunganId || t.id,
      SiswaID: t.siswaId,
      NamaSiswa: t.namaSiswa,
      Kelas: t.studentClass || '-',
      Tanggal: t.tanggal,
      JenisTransaksi: t.jenisTransaksi || t.jenis,
      Debit: t.debit ?? (t.jenis === 'SETOR' ? t.nominal : 0),
      Kredit: t.kredit ?? (t.jenis === 'TARIK' ? t.nominal : 0),
      Saldo: t.saldo || 0,
      PetugasID: t.petugasId || t.createdBy || 'Bendahara Tabungan',
      Keterangan: t.keterangan || t.catatan || '-',
      Status: t.status || 'SUKSES',
      CreatedAt: t.createdAt || '-',
      UpdatedAt: t.updatedAt || '-'
    }));
    exportToExcel(rows, `Buku_Sheet_TABUNGAN_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  return (
    <div className="space-y-5 animate-in fade-in">
      {/* Header & Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">Total Transaksi Tabungan</span>
            <div className="text-3xl font-black text-slate-900 font-mono">{tabunganList.length}</div>
            <p className="text-[11px] text-slate-500">Mutasi Setor (Debit) & Tarik (Kredit)</p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
            <Wallet size={24} />
          </div>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div className="space-y-1">
            <span className="text-xs font-bold text-emerald-700 uppercase tracking-wider">Total Saldo Simpanan Siswa</span>
            <div className="text-3xl font-black text-emerald-700 font-mono">{fmtRp(totalSaldoSemua)}</div>
            <p className="text-[11px] text-emerald-600 font-semibold">Tersimpan Aman di Kas Sekolah</p>
          </div>
          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
            <TrendingUp size={24} />
          </div>
        </div>
      </div>

      {/* Toolbar & Filter */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2.5 flex-1">
          <select
            value={filterKelas}
            onChange={(e) => {
              setFilterKelas(e.target.value);
              setSelectedSiswaId('');
              setCurrentPage(1);
            }}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
          >
            <option value="">Semua Rombel</option>
            {availableClasses.map(c => (
              <option key={c} value={c}>{formatClassLabel(c)}</option>
            ))}
          </select>

          {/* Smart Filter Tahun Ajaran */}
          <select
            value={filterTahunAjaran}
            onChange={(e) => {
              setFilterTahunAjaran(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
          >
            <option value="SEMUA">Semua TA</option>
            {availableAcademicYears.map(ta => (
              <option key={ta} value={ta}>TA {ta}</option>
            ))}
          </select>

          {/* Smart Filter Semester */}
          <select
            value={filterSemester}
            onChange={(e) => {
              setFilterSemester(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
          >
            <option value="SEMUA">Semua Semester</option>
            <option value="1">Sem 1 (Ganjil: Jul-Des)</option>
            <option value="2">Sem 2 (Genap: Jan-Jun)</option>
          </select>

          <select
            value={selectedSiswaId}
            onChange={(e) => {
              setSelectedSiswaId(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none max-w-xs"
          >
            <option value="">-- Semua Siswa ({distinctSiswaList.length}) --</option>
            {distinctSiswaList.map(s => (
              <option key={s.id} value={s.id}>{s.name} ({formatClassLabel(s.class)})</option>
            ))}
          </select>

          <div className="relative flex-1 sm:w-56">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Cari transaksi, siswa, ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-7 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
            />
            {searchTerm && (
              <button onClick={() => setSearchTerm('')} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                <X size={13} />
              </button>
            )}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsImportModalOpen(true)}
            className="px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 active:scale-95 whitespace-nowrap border border-indigo-200"
            title="Tempel atau Impor data langsung dari Google Sheet / Excel"
          >
            <Upload size={14} />
            <span>Impor / Paste Sheet</span>
          </button>
          <button
            onClick={handleExportExcel}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 active:scale-95 whitespace-nowrap"
            title="Ekspor Rekap Tabungan ke Excel format Sheet TABUNGAN"
          >
            <FileSpreadsheet size={15} className="text-emerald-600" />
            <span>Ekspor Excel</span>
          </button>
          <button
            onClick={handleOpenAdd}
            className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-xs transition flex items-center justify-center gap-1.5 active:scale-95 whitespace-nowrap"
          >
            <Plus size={15} />
            <span>+ Transaksi Tabungan</span>
          </button>
        </div>
      </div>

      {/* Table Sesuai Skema Sheet TABUNGAN */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50/90 text-slate-600 uppercase font-black text-[10px] border-b border-slate-200 tracking-wider">
              <tr>
                <th className="p-3.5 pl-4">ID & Tanggal</th>
                <th className="p-3.5">Nama Siswa (SiswaID)</th>
                <th className="p-3.5">Kelas</th>
                <th className="p-3.5 text-center">Tahun Ajaran / Sem</th>
                <th className="p-3.5 text-center">Jenis Transaksi</th>
                <th className="p-3.5 text-right text-emerald-700">Debit / Setor (Rp)</th>
                <th className="p-3.5 text-right text-rose-700">Kredit / Tarik (Rp)</th>
                <th className="p-3.5 text-right">Saldo Berjalan</th>
                <th className="p-3.5">Petugas / Keterangan</th>
                <th className="p-3.5 text-center">Status</th>
                <th className="p-3.5 pr-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {filteredAndCalculatedItems.length === 0 ? (
                <tr>
                  <td colSpan={11} className="p-12 text-center text-slate-400 space-y-2">
                    <Wallet size={36} className="mx-auto text-slate-300" />
                    <p className="font-bold text-slate-600 text-sm">Belum Ada Transaksi Tabungan</p>
                    <p className="text-xs text-slate-400">Klik "+ Transaksi Tabungan" untuk mencatat setoran siswa.</p>
                  </td>
                </tr>
              ) : (
                paginatedItems.map((t, idx) => {
                  const isSetor = t.jenisTransaksi === 'SETOR' || t.jenis === 'SETOR';
                  const tabId = t.tabunganId || t.id;

                  return (
                    <tr key={`${t.id || tabId || 'tab'}_${idx}`} className="hover:bg-slate-50/80 transition">
                      <td className="p-3.5 pl-4 font-mono">
                        <div className="font-bold text-slate-900">{t.tanggal}</div>
                        <div className="text-[10px] text-slate-400 font-mono">{tabId}</div>
                      </td>
                      <td className="p-3.5 font-bold text-slate-900">
                        <div className="text-sm font-black text-slate-900">{t.namaSiswa}</div>
                        <div className="text-[10px] font-mono text-slate-400 font-normal">SiswaID: {t.siswaId}</div>
                      </td>
                      <td className="p-3.5 font-semibold text-slate-800">
                        {t.studentClass || '-'}
                      </td>
                      <td className="p-3.5 text-center font-mono text-[11px]">
                        {(() => {
                          const info = getAcademicPeriodInfo(t.tanggal);
                          return (
                            <div>
                              <span className="font-black text-slate-800 bg-slate-100 px-2 py-0.5 rounded-md text-[10px] inline-block">
                                TA {info.academicYear}
                              </span>
                              <div className={`text-[10px] font-bold mt-0.5 ${info.semester === 'Ganjil' ? 'text-indigo-600' : 'text-teal-600'}`}>
                                Sem {info.semesterNum} ({info.semester})
                              </div>
                            </div>
                          );
                        })()}
                      </td>
                      <td className="p-3.5 text-center">
                        <span className={`px-2.5 py-0.5 rounded-full font-black text-[10px] inline-flex items-center gap-1 ${
                          isSetor ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                        }`}>
                          {isSetor ? <ArrowDownRight size={12} /> : <ArrowUpRight size={12} />}
                          {isSetor ? 'SETOR (Debit)' : 'TARIK (Kredit)'}
                        </span>
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold text-emerald-700">
                        {isSetor ? fmtRp(t.nominal) : '-'}
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold text-rose-700">
                        {!isSetor ? fmtRp(t.nominal) : '-'}
                      </td>
                      <td className="p-3.5 text-right font-mono font-black text-slate-900 text-sm">
                        {fmtRp(t.saldo || 0)}
                      </td>
                      <td className="p-3.5 text-slate-700 text-xs">
                        <div className="font-semibold">{t.petugasId || t.createdBy || 'Bendahara'}</div>
                        <div className="text-[11px] text-slate-400 line-clamp-1">{t.keterangan || t.catatan || '-'}</div>
                      </td>
                      <td className="p-3.5 text-center">
                        <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px]">
                          {t.status || 'SUKSES'}
                        </span>
                      </td>
                      <td className="p-3.5 pr-4 text-center">
                        <button
                          onClick={() => handleDeleteTabungan(t.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                          title="Hapus Transaksi Tabungan"
                        >
                          <Trash2 size={13} />
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        {filteredAndCalculatedItems.length > 0 && (
          <div className="p-3.5 border-t border-slate-100 bg-slate-50/60 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600 font-medium">
            <div className="flex items-center gap-2">
              <span>Tampilkan:</span>
              <select
                value={pageSize}
                onChange={(e) => {
                  setPageSize(Number(e.target.value));
                  setCurrentPage(1);
                }}
                className="px-2 py-1 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-800 focus:outline-none"
              >
                <option value={10}>10 baris</option>
                <option value={25}>25 baris</option>
                <option value={50}>50 baris</option>
                <option value={100}>100 baris</option>
                <option value={500}>Semua ({filteredAndCalculatedItems.length})</option>
              </select>
              <span className="text-slate-400">|</span>
              <span>
                Menampilkan <b>{Math.min((currentPage - 1) * pageSize + 1, filteredAndCalculatedItems.length)}</b> - <b>{Math.min(currentPage * pageSize, filteredAndCalculatedItems.length)}</b> dari <b>{filteredAndCalculatedItems.length}</b> total transaksi
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                disabled={currentPage <= 1}
                onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                className="p-1.5 bg-white border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed transition"
                title="Halaman Sebelumnya"
              >
                <ChevronLeft size={16} />
              </button>

              <span className="px-3 py-1 bg-white border border-slate-200 rounded-lg text-xs font-black text-slate-800">
                Halaman {currentPage} / {totalPages}
              </span>

              <button
                disabled={currentPage >= totalPages}
                onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                className="p-1.5 bg-white border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed transition"
                title="Halaman Berikutnya"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Modal Tambah Transaksi Tabungan Sesuai Skema Sheet TABUNGAN */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-md rounded-3xl border border-slate-200 shadow-2xl p-6 space-y-5 my-8 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
                  <Wallet size={18} />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Transaksi Tabungan (Sheet: TABUNGAN)</h3>
                  <p className="text-[11px] text-slate-400 font-medium">Rekam mutasi simpanan setor debit atau tarik kredit</p>
                </div>
              </div>
              <button onClick={() => setIsAddModalOpen(false)} className="text-slate-400 hover:text-slate-700">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleSubmitTabungan} className="space-y-3.5">
              {/* Autocomplete Search Siswa */}
              <div className="relative">
                <label className="block text-xs font-bold text-slate-700 mb-1">Cari & Pilih Siswa (SiswaID)</label>
                <div className="relative">
                  <input
                    type="text"
                    required
                    placeholder="Ketik nama siswa..."
                    value={siswaSearchInput}
                    onFocus={() => setIsDropdownOpen(true)}
                    onChange={(e) => {
                      setSiswaSearchInput(e.target.value);
                      setIsDropdownOpen(true);
                    }}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900"
                  />
                  {formData.siswaId && (
                    <span className="absolute right-3 top-1/2 -translate-y-1/2 text-emerald-600 font-mono text-[10px] bg-emerald-50 px-2 py-0.5 rounded-md font-bold">
                      {formData.siswaId}
                    </span>
                  )}
                </div>

                {isDropdownOpen && (
                  <div className="absolute left-0 right-0 top-full mt-1 bg-white border border-slate-200 rounded-2xl shadow-xl z-20 max-h-48 overflow-y-auto divide-y divide-slate-100">
                    {autocompleteStudents.map(s => (
                      <button
                        key={s.id}
                        type="button"
                        onClick={() => handleSelectStudentInModal(s)}
                        className="w-full text-left p-2.5 text-xs hover:bg-emerald-50 hover:text-emerald-800 transition flex items-center justify-between"
                      >
                        <span className="font-bold text-slate-800">{s.name}</span>
                        <span className="text-[10px] font-mono text-slate-400 bg-slate-100 px-2 py-0.5 rounded">
                          {s.class} | {s.nis || s.nisn || s.id}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Tanggal</label>
                  <input
                    type="date"
                    required
                    value={formData.tanggal}
                    onChange={(e) => setFormData(prev => ({ ...prev, tanggal: e.target.value }))}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Jenis Transaksi</label>
                  <select
                    value={formData.jenis}
                    onChange={(e) => setFormData(prev => ({ ...prev, jenis: e.target.value as any }))}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
                  >
                    <option value="SETOR">SETOR (Debit / Tambah)</option>
                    <option value="TARIK">TARIK (Kredit / Kurang)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Nominal Transaksi (Rp)</label>
                <input
                  type="number"
                  required
                  min={1000}
                  step={5000}
                  value={formData.nominal}
                  onChange={(e) => setFormData(prev => ({ ...prev, nominal: Number(e.target.value) || 0 }))}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-black text-emerald-700 font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Petugas (PetugasID)</label>
                <input
                  type="text"
                  required
                  value={formData.petugasId}
                  onChange={(e) => setFormData(prev => ({ ...prev, petugasId: e.target.value }))}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Keterangan / Catatan Transaksi</label>
                <input
                  type="text"
                  placeholder="misal: Setoran kas mingguan..."
                  value={formData.keterangan}
                  onChange={(e) => setFormData(prev => ({ ...prev, keterangan: e.target.value }))}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2.5 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-200 transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-xs transition active:scale-95"
                >
                  Simpan Mutasi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Modal Import TSV/Excel */}
      {isImportModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-2xl rounded-3xl shadow-2xl border border-slate-100 overflow-hidden animate-in zoom-in-95">
            <div className="p-5 bg-gradient-to-r from-indigo-700 to-indigo-800 text-white flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
                  <Upload size={20} />
                </div>
                <div>
                  <h3 className="font-black text-base leading-tight">Impor Data Transaksi Tabungan</h3>
                  <p className="text-[11px] text-indigo-200">Tempel baris data dari Google Sheet / Excel langsung ke sini</p>
                </div>
              </div>
              <button
                onClick={() => setIsImportModalOpen(false)}
                className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center transition text-white"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleImportSubmit} className="p-6 space-y-4">
              <div className="bg-amber-50 border border-amber-200 p-3 rounded-2xl text-[11px] text-amber-800 space-y-1">
                <p className="font-bold flex items-center gap-1.5">
                  <FileText size={14} /> Format Kolom yang Diterima (Tab-Separated):
                </p>
                <p className="font-mono text-[10px] text-amber-900 bg-white/60 p-2 rounded-xl border border-amber-200/50 overflow-x-auto">
                  id &nbsp;|&nbsp; siswaId &nbsp;|&nbsp; tanggal &nbsp;|&nbsp; jenis &nbsp;|&nbsp; nominal &nbsp;|&nbsp; catatan &nbsp;|&nbsp; createdBy &nbsp;|&nbsp; createdAt &nbsp;|&nbsp; NAMA
                </p>
                <p className="text-slate-600">Cukup salin (Copy) tabel dari spreadsheet lalu tempelkan (Paste) ke kotak di bawah.</p>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">
                  Data Mentah Spreadsheet (Paste di sini)
                </label>
                <textarea
                  rows={8}
                  placeholder={`id\tsiswaId\ttanggal\tjenis\tnominal\tcatatan\tcreatedBy\tcreatedAt\tNAMA\nTAB_001\t001\t2024-07-30\tSETOR\t5,000\tNabung\tsuperadmin\t2024-07-30\tRIZKY KURNIAWAN`}
                  value={importRawText}
                  onChange={(e) => setImportRawText(e.target.value)}
                  className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsImportModalOpen(false)}
                  className="px-4 py-2.5 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-200 transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-black shadow-xs transition active:scale-95 flex items-center gap-2"
                >
                  <Upload size={14} />
                  <span>Proses & Masukkan Data</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
