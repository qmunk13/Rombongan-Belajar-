import React, { useState, useMemo } from 'react';
import { 
  Search, Plus, CheckSquare, Square, Filter, X, CreditCard, 
  Wallet, CheckCircle2, Clock, AlertCircle, Trash2, Edit3, ArrowRight, Printer,
  FileSpreadsheet, User, Calendar, Receipt, Upload, ClipboardCheck,
  ChevronLeft, ChevronRight, GraduationCap
} from 'lucide-react';
import { useStore } from '../../store';
import { db } from '../../data/db';
import { 
  KeuanganTagihan, KeuanganBiaya, KeuanganKelas, 
  KeuanganInvoice, KeuanganTabungan 
} from '../../data/keuanganSeed';
import { DEFAULT_TAGIHAN_LIST } from '../../data/keuanganTransactionsData';
import { parseRawTagihanTSV } from '../../data/keuanganTransactionsSeed';
import { exportToExcel } from '../../lib/excel';
import { getAllClasses, formatClassLabel, matchClass } from '../../lib/utils';
import { 
  getAcademicPeriodInfo, 
  matchAcademicFilter, 
  extractAvailableAcademicYears 
} from '../../lib/academicYear';

interface TagihanTunggakanTabProps {
  onPrintInvoice?: (invoiceId: string) => void;
  onRefreshAll?: () => void;
}

export default function TagihanTunggakanTab({ onPrintInvoice, onRefreshAll }: TagihanTunggakanTabProps) {
  const { students } = useStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterKelas, setFilterKelas] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterTahunAjaran, setFilterTahunAjaran] = useState('SEMUA');
  const [filterSemester, setFilterSemester] = useState('SEMUA');

  const availableClasses = useMemo(() => getAllClasses(students), [students]);

  // Live Database state
  const [tagihanList, setTagihanList] = useState<KeuanganTagihan[]>(() => {
    return db.get<KeuanganTagihan>('keuangan_tagihan') || [];
  });

  // Extract available Academic Years from data
  const availableAcademicYears = useMemo(() => {
    const dates = tagihanList.map(t => t.periode || t.tahunAjaranId || t.tanggalJatuhTempo || t.createdAt);
    return extractAvailableAcademicYears(dates);
  }, [tagihanList]);

  const [selectedTagihanIds, setSelectedTagihanIds] = useState<string[]>([]);
  const [isGenerateModalOpen, setIsGenerateModalOpen] = useState(false);
  const [isPayModalOpen, setIsPayModalOpen] = useState(false);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [rawImportText, setRawImportText] = useState('');

  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  // Pay Modal State
  const [activePayItem, setActivePayItem] = useState<{
    tagihanIds: string[];
    isMulti: boolean;
    siswaId: string;
    namaSiswa: string;
    kelasNama: string;
    namaBiaya: string;
    nominalAsli: number;
    sisaTagihan: number;
  } | null>(null);

  const [payFormData, setPayFormData] = useState({
    tglBayar: new Date().toISOString().slice(0, 10),
    metode: 'CASH',
    bank: '-',
    noReferensi: '-',
    petugasId: 'Kasir / Bendahara Sekolah',
    jumlahBayar: 0,
    catatan: '',
  });

  // Generate Multi-Month State
  const [genFormData, setGenFormData] = useState({
    fromPeriode: '2026-07',
    toPeriode: '2026-07',
    tahunAjaranId: '2026/2027',
    semesterId: 'Ganjil',
    tanggalTagihan: new Date().toISOString().slice(0, 10),
    jatuhTempo: new Date(Date.now() + 10 * 86400000).toISOString().slice(0, 10),
    diskon: 0,
    denda: 0,
    petugasId: 'Admin / Kasir Keuangan',
    biayaId: '',
    kelasId: '',
    siswaId: '',
  });

  // Master Data
  const biayaList = useMemo(() => db.get<KeuanganBiaya>('keuangan_biaya') || [], []);
  const kelasList = useMemo(() => db.get<KeuanganKelas>('keuangan_kelas') || [], []);

  // Filtered Siswa in Generate modal
  const filteredStudentsForGen = useMemo(() => {
    if (!genFormData.kelasId) return students;
    return students.filter(s => matchClass(s.class, genFormData.kelasId));
  }, [students, genFormData.kelasId]);

  // Tabungan Saldo checker for active student in Payment modal
  const activeStudentTabunganSaldo = useMemo(() => {
    if (!activePayItem || !activePayItem.siswaId) return 0;
    const allTabungan = db.get<KeuanganTabungan>('keuangan_tabungan') || [];
    return allTabungan
      .filter(t => t.siswaId === activePayItem.siswaId)
      .reduce((acc, t) => {
        const nom = Number(t.nominal) || 0;
        const isSetor = t.jenis === 'SETOR' || t.jenisTransaksi === 'SETOR';
        return isSetor ? acc + nom : acc - nom;
      }, 0);
  }, [activePayItem]);

  const saveTagihanToDb = (newList: KeuanganTagihan[]) => {
    setTagihanList(newList);
    db.set('keuangan_tagihan', newList);
    if (onRefreshAll) onRefreshAll();
  };

  // Filtered Tagihan
  const filteredTagihan = useMemo(() => {
    return tagihanList.filter(t => {
      const q = searchTerm.toLowerCase();
      const nama = String(t.namaSiswa || '').toLowerCase();
      const nis = String(t.nis || '').toLowerCase();
      const id = String(t.tagihanId || t.id || '').toLowerCase();
      const inv = String(t.invoiceId || '').toLowerCase();
      const biaya = String(t.namaBiaya || '').toLowerCase();
      const matchesQ = !searchTerm || nama.includes(q) || nis.includes(q) || id.includes(q) || inv.includes(q) || biaya.includes(q);
      const matchesKelas = !filterKelas || matchClass(t.kelasNama || t.kelasId, filterKelas);
      const matchesStatus = !filterStatus || t.status === filterStatus;
      
      // Smart TA & Semester Filter
      const periodDate = t.periode || t.tanggalTagihan || t.tanggalJatuhTempo || t.jatuhTempo || t.createdAt;
      const matchesTA = matchAcademicFilter(periodDate, filterTahunAjaran, filterSemester);

      return matchesQ && matchesKelas && matchesStatus && matchesTA;
    });
  }, [tagihanList, searchTerm, filterKelas, filterStatus, filterTahunAjaran, filterSemester]);

  // Pagination calculation
  const totalPages = Math.ceil(filteredTagihan.length / pageSize) || 1;
  const paginatedTagihan = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredTagihan.slice(start, start + pageSize);
  }, [filteredTagihan, currentPage, pageSize]);

  // Checkbox handlers
  const handleToggleSelectAll = () => {
    if (selectedTagihanIds.length === filteredTagihan.length && filteredTagihan.length > 0) {
      setSelectedTagihanIds([]);
    } else {
      setSelectedTagihanIds(filteredTagihan.map(t => t.id));
    }
  };

  const handleToggleSelectRow = (id: string) => {
    setSelectedTagihanIds(prev => 
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  };

  // Open Single Pay
  const handleOpenSinglePay = (t: KeuanganTagihan) => {
    const sisa = Number(t.sisaTagihan ?? (Number(t.nominal) || 0));
    setActivePayItem({
      tagihanIds: [t.id],
      isMulti: false,
      siswaId: t.siswaId,
      namaSiswa: t.namaSiswa,
      kelasNama: t.kelasNama,
      namaBiaya: t.namaBiaya,
      nominalAsli: Number(t.nominalAsli || t.nominal),
      sisaTagihan: sisa,
    });
    setPayFormData({
      tglBayar: new Date().toISOString().slice(0, 10),
      metode: 'CASH',
      bank: '-',
      noReferensi: `REF-${Date.now().toString().slice(-6)}`,
      petugasId: 'Kasir / Bendahara Sekolah',
      jumlahBayar: sisa,
      catatan: `Pembayaran ${t.namaBiaya} Periode ${t.periode}`,
    });
    setIsPayModalOpen(true);
  };

  // Open Multi Pay
  const handleOpenMultiPay = () => {
    if (selectedTagihanIds.length === 0) {
      alert('Pilih minimal 1 tagihan untuk dibayar.');
      return;
    }
    const selectedItems = tagihanList.filter(t => selectedTagihanIds.includes(t.id));
    const totalSisa = selectedItems.reduce((acc, t) => acc + (Number(t.sisaTagihan ?? t.nominal) || 0), 0);
    const first = selectedItems[0];

    setActivePayItem({
      tagihanIds: selectedTagihanIds,
      isMulti: true,
      siswaId: first.siswaId,
      namaSiswa: selectedItems.length === 1 ? first.namaSiswa : `${selectedItems.length} Tagihan Terpilih`,
      kelasNama: first.kelasNama,
      namaBiaya: selectedItems.map(t => t.namaBiaya).join(', '),
      nominalAsli: totalSisa,
      sisaTagihan: totalSisa,
    });
    setPayFormData({
      tglBayar: new Date().toISOString().slice(0, 10),
      metode: 'CASH',
      bank: '-',
      noReferensi: `REF-${Date.now().toString().slice(-6)}`,
      petugasId: 'Kasir / Bendahara Sekolah',
      jumlahBayar: totalSisa,
      catatan: `Pembayaran ${selectedItems.length} Tagihan Sekaligus`,
    });
    setIsPayModalOpen(true);
  };

  // Submit Payment
  const handleSubmitPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePayItem) return;

    const inputJumlah = Number(payFormData.jumlahBayar) || 0;
    if (inputJumlah <= 0) {
      alert('Jumlah pembayaran harus lebih besar dari Rp 0');
      return;
    }

    // Tabungan balance validation
    if (payFormData.metode === 'TABUNGAN') {
      if (activeStudentTabunganSaldo < inputJumlah) {
        alert(`Saldo tabungan tidak mencukupi. Saldo saat ini: Rp ${activeStudentTabunganSaldo.toLocaleString('id-ID')}`);
        return;
      }
    }

    const invoiceId = `INV-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;

    // 1. Update Tagihan in DB
    let sisaBudget = inputJumlah;
    const invoiceItems: { namaBiaya: string; periode: string; nominal: number }[] = [];

    const updatedTagihanList = tagihanList.map(t => {
      if (activePayItem.tagihanIds.includes(t.id) && sisaBudget > 0) {
        const curRemaining = Number(t.sisaTagihan ?? (Number(t.nominal) || 0));
        const payForThis = Math.min(sisaBudget, curRemaining);
        sisaBudget -= payForThis;

        const newRemaining = Math.max(0, curRemaining - payForThis);
        const newPaidAmount = Number(t.paidAmount ?? (Number(t.totalBayar) || 0)) + payForThis;
        const newStatus = newRemaining === 0 ? 'LUNAS' : 'SEBAGIAN';

        invoiceItems.push({
          namaBiaya: t.namaBiaya,
          periode: t.periode,
          nominal: payForThis,
        });

        return {
          ...t,
          invoiceId: t.invoiceId || invoiceId,
          nominal: newRemaining,
          sisaTagihan: newRemaining,
          totalBayar: newPaidAmount,
          paidAmount: newPaidAmount,
          status: newStatus as any,
          paidAt: payFormData.tglBayar,
          petugasId: payFormData.petugasId,
          paidBy: payFormData.petugasId,
          updatedAt: new Date().toISOString(),
        };
      }
      return t;
    });

    saveTagihanToDb(updatedTagihanList);

    // 2. Create Invoice
    const newInvoice: KeuanganInvoice = {
      id: `INV_${Date.now()}`,
      pembayaranId: `BYR_${Date.now()}`,
      tagihanId: activePayItem.tagihanIds[0] || '',
      invoiceId,
      siswaId: activePayItem.siswaId,
      namaSiswa: activePayItem.namaSiswa,
      kelasId: '',
      namaKelas: activePayItem.kelasNama,
      tanggal: payFormData.tglBayar,
      tglBayar: payFormData.tglBayar,
      metodePembayaran: payFormData.metode,
      metode: payFormData.metode,
      noReferensi: payFormData.noReferensi,
      bank: payFormData.bank,
      petugasId: payFormData.petugasId,
      nominal: inputJumlah,
      total: inputJumlah,
      status: 'PAID',
      catatan: payFormData.catatan,
      keterangan: payFormData.catatan,
      tagihanIds: activePayItem.tagihanIds,
      items: invoiceItems.length > 0 ? invoiceItems : [{
        namaBiaya: activePayItem.namaBiaya,
        periode: new Date().toISOString().slice(0, 7),
        nominal: inputJumlah,
      }],
      createdBy: payFormData.petugasId,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    const existingInvoices = db.get<KeuanganInvoice>('keuangan_invoices') || [];
    db.set('keuangan_invoices', [newInvoice, ...existingInvoices]);

    // 3. If Tabungan, Deduct from Tabungan
    if (payFormData.metode === 'TABUNGAN') {
      const newTabEntry: KeuanganTabungan = {
        id: `TAB_${Date.now()}`,
        tabunganId: `TAB_${Date.now()}`,
        siswaId: activePayItem.siswaId,
        namaSiswa: activePayItem.namaSiswa,
        tanggal: payFormData.tglBayar,
        jenisTransaksi: 'TARIK',
        jenis: 'TARIK',
        debit: 0,
        kredit: inputJumlah,
        nominal: inputJumlah,
        petugasId: payFormData.petugasId,
        catatan: `Debet otomatis bayar tagihan (${invoiceId})`,
        keterangan: `Debet otomatis bayar tagihan (${invoiceId})`,
        status: 'SUKSES',
        createdBy: payFormData.petugasId,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      const allTabungan = db.get<KeuanganTabungan>('keuangan_tabungan') || [];
      db.set('keuangan_tabungan', [newTabEntry, ...allTabungan]);
    }

    setIsPayModalOpen(false);
    setSelectedTagihanIds([]);
    alert(`Pembayaran berhasil diproses! Invoice No: ${invoiceId}`);
    if (onPrintInvoice) onPrintInvoice(invoiceId);
  };

  // Generate Multi-Bulan logic
  const handleGenerateTagihan = (e: React.FormEvent) => {
    e.preventDefault();
    const { fromPeriode, toPeriode, tahunAjaranId, semesterId, tanggalTagihan, jatuhTempo, diskon, denda, petugasId, biayaId, kelasId, siswaId } = genFormData;

    // Build period list (e.g. 2026-07 to 2026-12)
    const periods: string[] = [];
    let current = new Date(`${fromPeriode}-01`);
    const end = new Date(`${toPeriode}-01`);

    while (current <= end) {
      const y = current.getFullYear();
      const m = String(current.getMonth() + 1).padStart(2, '0');
      periods.push(`${y}-${m}`);
      current.setMonth(current.getMonth() + 1);
    }

    if (periods.length === 0) {
      alert('Rentang periode tidak valid');
      return;
    }

    // Determine target students
    let targetStudents = students;
    if (kelasId) {
      targetStudents = targetStudents.filter(s => matchClass(s.class, kelasId));
    }
    if (siswaId) {
      targetStudents = targetStudents.filter(s => s.id === siswaId);
    }

    if (targetStudents.length === 0) {
      alert('Tidak ada siswa yang cocok dengan filter kelas/siswa');
      return;
    }

    // Determine target biaya
    let targetBiaya = biayaList;
    if (biayaId) {
      targetBiaya = targetBiaya.filter(b => b.id === biayaId || b.biayaId === biayaId);
    }

    if (targetBiaya.length === 0) {
      alert('Tidak ada pos biaya yang dipilih');
      return;
    }

    const newTagihanRows: KeuanganTagihan[] = [];
    const nowStr = new Date().toISOString();

    periods.forEach(p => {
      targetStudents.forEach(st => {
        targetBiaya.forEach(b => {
          // If the fee is specific to a single student, check student ID
          if (b.siswaId && b.siswaId !== st.id) {
            return;
          }

          // Check duplicates
          const isExists = tagihanList.some(
            t => t.siswaId === st.id && (t.biayaId === b.id || t.biayaId === b.biayaId) && t.periode === p
          );
          if (!isExists) {
            const rawNominal = Number(b.nominal) || 0;
            const netDiskon = Number(diskon) || 0;
            const netDenda = Number(denda) || 0;
            const totalTagihan = Math.max(0, rawNominal - netDiskon + netDenda);
            const tagihanId = `TGH_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

            newTagihanRows.push({
              id: tagihanId,
              tagihanId,
              invoiceId: '-',
              siswaId: st.id,
              namaSiswa: st.name,
              nis: st.nis || st.nisn || '-',
              kelasId: st.class || 'Kelas 4',
              kelasNama: st.class || 'Kelas 4',
              biayaId: b.biayaId || b.id,
              namaBiaya: b.namaBiaya || b.nama,
              tahunAjaranId: tahunAjaranId || '2026/2027',
              semesterId: semesterId || 'Ganjil',
              tanggalTagihan: tanggalTagihan || nowStr.slice(0, 10),
              tanggalJatuhTempo: jatuhTempo || `${p}-10`,
              jatuhTempo: jatuhTempo || `${p}-10`,
              nominal: totalTagihan,
              nominalAsli: rawNominal,
              diskon: netDiskon,
              denda: netDenda,
              totalTagihan,
              totalBayar: 0,
              paidAmount: 0,
              sisaTagihan: totalTagihan,
              periode: p,
              status: 'BELUM',
              petugasId: petugasId || 'Admin / Kasir Keuangan',
              createdAt: nowStr,
              updatedAt: nowStr,
            });
          }
        });
      });
    });

    if (newTagihanRows.length === 0) {
      alert('Semua tagihan untuk kombinasi siswa, biaya, dan periode ini sudah pernah dibuat sebelumnya.');
      return;
    }

    saveTagihanToDb([...tagihanList, ...newTagihanRows]);
    setIsGenerateModalOpen(false);
    alert(`Berhasil membuat ${newTagihanRows.length} data tagihan baru untuk ${periods.length} periode!`);
  };

  const handleDeleteTagihan = (id: string) => {
    if (window.confirm('Hapus tagihan ini?')) {
      const updated = tagihanList.filter(t => t.id !== id);
      saveTagihanToDb(updated);
      setSelectedTagihanIds(prev => prev.filter(x => x !== id));
    }
  };

  const fmtRp = (n: number) => 'Rp ' + Number(n || 0).toLocaleString('id-ID');

  const handleExportExcel = () => {
    if (filteredTagihan.length === 0) {
      alert("Tidak ada data tagihan untuk diekspor.");
      return;
    }
    const rows = filteredTagihan.map((t, idx) => ({
      No: idx + 1,
      TagihanID: t.tagihanId || t.id,
      InvoiceID: t.invoiceId || '-',
      SiswaID: t.siswaId,
      NamaSiswa: t.namaSiswa,
      BiayaID: t.biayaId,
      NamaBiaya: t.namaBiaya,
      TahunAjaranID: t.tahunAjaranId || '2026/2027',
      SemesterID: t.semesterId || 'Ganjil',
      TanggalTagihan: t.tanggalTagihan || t.createdAt?.slice(0, 10) || '-',
      TanggalJatuhTempo: t.tanggalJatuhTempo || t.jatuhTempo || '-',
      Nominal: t.nominalAsli || t.nominal,
      Diskon: t.diskon || 0,
      Denda: t.denda || 0,
      TotalTagihan: t.totalTagihan || t.nominalAsli || t.nominal,
      TotalBayar: t.totalBayar || t.paidAmount || 0,
      SisaTagihan: t.sisaTagihan ?? Math.max(0, (t.totalTagihan || t.nominal) - (t.paidAmount || 0)),
      Status: t.status,
      PetugasID: t.petugasId || t.paidBy || 'Admin / Kasir Keuangan',
      CreatedAt: t.createdAt || '-',
      UpdatedAt: t.updatedAt || '-'
    }));
    exportToExcel(rows, `Data_Tagihan_Sheet_TAGIHAN_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  return (
    <div className="space-y-5 animate-in fade-in">
      {/* Top Header & Actions */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
            <CreditCard size={20} className="text-emerald-600" />
            Tagihan & Pembayaran Kasir (Sheet: TAGIHAN)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Daftar tagihan siswa terstruktur: TagihanID, InvoiceID, SiswaID, BiayaID, TA, Semester, Jatuh Tempo, & Kasir.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {selectedTagihanIds.length > 0 && (
            <button
              onClick={handleOpenMultiPay}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-sm transition flex items-center gap-1.5 active:scale-95"
            >
              <CreditCard size={15} />
              <span>Bayar {selectedTagihanIds.length} Tagihan Terpilih</span>
            </button>
          )}

          <button
            onClick={() => setIsImportModalOpen(true)}
            className="px-3.5 py-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-xl text-xs font-bold border border-emerald-200 shadow-xs transition flex items-center gap-1.5 active:scale-95"
          >
            <Upload size={14} className="text-emerald-700" />
            <span>Impor / Paste Sheet TAGIHAN</span>
          </button>

          <button
            onClick={() => setIsGenerateModalOpen(true)}
            className="px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-black shadow-sm transition flex items-center gap-1.5 active:scale-95"
          >
            <Plus size={15} />
            <span>Generate Tagihan Multi-Bulan</span>
          </button>
        </div>
      </div>

      {/* Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        <div className="flex flex-wrap items-center gap-2 flex-1">
          <div className="relative flex-1 min-w-[200px]">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Cari siswa, NIS, TagihanID, Invoice..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-7 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
            />
            {searchTerm && (
              <button onClick={() => setSearchTerm('')} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                <X size={13} />
              </button>
            )}
          </div>

          <select
            value={filterKelas}
            onChange={(e) => {
              setFilterKelas(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
          >
            <option value="">Semua Rombel</option>
            {availableClasses.map(c => (
              <option key={c} value={c}>{formatClassLabel(c)}</option>
            ))}
          </select>

          {/* Smart Filter Tahun Ajaran */}
          <select
            value={filterTahunAjaran}
            onChange={(e) => {
              setFilterTahunAjaran(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
          >
            <option value="SEMUA">Semua TA</option>
            {availableAcademicYears.map(ta => (
              <option key={ta} value={ta}>TA {ta}</option>
            ))}
          </select>

          {/* Smart Filter Semester */}
          <select
            value={filterSemester}
            onChange={(e) => {
              setFilterSemester(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
          >
            <option value="SEMUA">Semua Semester</option>
            <option value="1">Sem 1 (Ganjil: Jul-Des)</option>
            <option value="2">Sem 2 (Genap: Jan-Jun)</option>
          </select>

          <select
            value={filterStatus}
            onChange={(e) => {
              setFilterStatus(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
          >
            <option value="">Semua Status</option>
            <option value="BELUM">Belum Lunas</option>
            <option value="SEBAGIAN">Sebagian (Cicilan)</option>
            <option value="LUNAS">Lunas</option>
          </select>
        </div>

        <div className="flex items-center gap-2 self-center">
          <span className="text-[11px] font-bold text-slate-500">
            {filteredTagihan.length} Baris Tagihan
          </span>
          <button
            onClick={handleExportExcel}
            className="flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition active:scale-95 whitespace-nowrap"
            title="Ekspor Data Tagihan ke Excel format Sheet TAGIHAN"
          >
            <FileSpreadsheet size={14} className="text-emerald-600" />
            <span>Ekspor Excel</span>
          </button>
        </div>
      </div>

      {/* Table Sesuai Skema Sheet TAGIHAN */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50/90 text-slate-600 uppercase font-black text-[10px] border-b border-slate-200 tracking-wider">
              <tr>
                <th className="p-3.5 pl-4 w-10 text-center">
                  <button onClick={handleToggleSelectAll} className="text-slate-500 hover:text-emerald-600">
                    {selectedTagihanIds.length > 0 && selectedTagihanIds.length === filteredTagihan.length ? (
                      <CheckSquare size={16} className="text-emerald-600" />
                    ) : (
                      <Square size={16} />
                    )}
                  </button>
                </th>
                <th className="p-3.5">ID Tagihan / Invoice</th>
                <th className="p-3.5">Nama Siswa & NIS</th>
                <th className="p-3.5">Kelas</th>
                <th className="p-3.5">Pos Biaya (BiayaID)</th>
                <th className="p-3.5 text-center">TA / Semester</th>
                <th className="p-3.5 text-center">Periode / Tempo</th>
                <th className="p-3.5 text-right">Total Tagihan</th>
                <th className="p-3.5 text-right">Total Bayar</th>
                <th className="p-3.5 text-right">Sisa Tagihan</th>
                <th className="p-3.5 text-center">Status</th>
                <th className="p-3.5 pr-4 text-center">Aksi Kasir</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {filteredTagihan.length === 0 ? (
                <tr>
                  <td colSpan={12} className="p-12 text-center text-slate-400 space-y-2">
                    <CreditCard size={36} className="mx-auto text-slate-300" />
                    <p className="font-bold text-slate-600 text-sm">Belum Ada Data Tagihan</p>
                    <p className="text-xs text-slate-400">Klik "Generate Tagihan Multi-Bulan" untuk membuat tagihan otomatis.</p>
                  </td>
                </tr>
              ) : (
                paginatedTagihan.map((t, idx) => {
                  const isSelected = selectedTagihanIds.includes(t.id);
                  const isLunas = t.status === 'LUNAS';
                  const isSebagian = t.status === 'SEBAGIAN';
                  const sisa = t.sisaTagihan ?? Math.max(0, (t.totalTagihan || t.nominal) - (t.paidAmount || 0));
                  const totTagihan = t.totalTagihan || t.nominalAsli || t.nominal;
                  const totBayar = t.totalBayar || t.paidAmount || 0;

                  return (
                    <tr key={`${t.id || t.tagihanId || 'tag'}_${idx}`} className={`hover:bg-slate-50/80 transition ${isSelected ? 'bg-emerald-50/40' : ''}`}>
                      <td className="p-3.5 pl-4 text-center">
                        <button onClick={() => handleToggleSelectRow(t.id)} className="text-slate-400 hover:text-emerald-600">
                          {isSelected ? <CheckSquare size={16} className="text-emerald-600" /> : <Square size={16} />}
                        </button>
                      </td>
                      <td className="p-3.5 font-mono">
                        <div className="font-black text-slate-900">{t.tagihanId || t.id}</div>
                        {t.invoiceId && t.invoiceId !== '-' && (
                          <div className="text-[10px] text-emerald-700 font-bold flex items-center gap-1">
                            <Receipt size={10} />
                            <span>{t.invoiceId}</span>
                          </div>
                        )}
                      </td>
                      <td className="p-3.5">
                        <div className="font-black text-slate-900 text-sm">{t.namaSiswa}</div>
                        <div className="text-[10px] font-mono text-slate-400">ID: {t.siswaId} | NIS: {t.nis || '-'}</div>
                      </td>
                      <td className="p-3.5 font-bold text-slate-800">{t.kelasNama || '-'}</td>
                      <td className="p-3.5">
                        <div className="font-bold text-slate-900">{t.namaBiaya}</div>
                        <div className="text-[10px] font-mono text-slate-400">{t.biayaId}</div>
                      </td>
                      <td className="p-3.5 text-center font-mono text-[11px]">
                        {(() => {
                          const info = getAcademicPeriodInfo(t.periode || t.tanggalTagihan || t.tanggalJatuhTempo || t.jatuhTempo || t.createdAt);
                          return (
                            <div>
                              <span className="font-black text-slate-800 bg-slate-100 px-2 py-0.5 rounded-md text-[10px] inline-block">
                                TA {info.academicYear}
                              </span>
                              <div className={`text-[10px] font-bold mt-0.5 ${info.semester === 'Ganjil' ? 'text-indigo-600' : 'text-teal-600'}`}>
                                Sem {info.semesterNum} ({info.semester})
                              </div>
                            </div>
                          );
                        })()}
                      </td>
                      <td className="p-3.5 text-center font-mono">
                        <div className="font-bold text-slate-800">{t.periode || '-'}</div>
                        <div className="text-[10px] text-slate-400">Tempo: {t.tanggalJatuhTempo || t.jatuhTempo || '-'}</div>
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold text-slate-700">
                        {fmtRp(totTagihan)}
                      </td>
                      <td className="p-3.5 text-right font-mono font-bold text-emerald-700">
                        {fmtRp(totBayar)}
                      </td>
                      <td className="p-3.5 text-right font-mono font-black text-slate-900 text-sm">
                        {fmtRp(sisa)}
                      </td>
                      <td className="p-3.5 text-center">
                        <span className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] inline-flex items-center gap-1 ${
                          isLunas 
                            ? 'bg-emerald-100 text-emerald-800' 
                            : isSebagian 
                            ? 'bg-amber-100 text-amber-800' 
                            : 'bg-rose-100 text-rose-800'
                        }`}>
                          {isLunas ? 'LUNAS' : isSebagian ? 'SEBAGIAN' : 'BELUM'}
                        </span>
                      </td>
                      <td className="p-3.5 pr-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          {!isLunas && (
                            <button
                              onClick={() => handleOpenSinglePay(t)}
                              className="px-3 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-black text-[11px] transition flex items-center gap-1 active:scale-95 shadow-xs whitespace-nowrap"
                            >
                              <span>Bayar</span>
                            </button>
                          )}
                          <button
                            onClick={() => handleDeleteTagihan(t.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                            title="Hapus Tagihan"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        {filteredTagihan.length > 0 && (
          <div className="p-3.5 border-t border-slate-100 bg-slate-50/60 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600 font-medium">
            <div className="flex items-center gap-2">
              <span>Tampilkan:</span>
              <select
                value={pageSize}
                onChange={(e) => {
                  setPageSize(Number(e.target.value));
                  setCurrentPage(1);
                }}
                className="px-2 py-1 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-800 focus:outline-none"
              >
                <option value={10}>10 baris</option>
                <option value={25}>25 baris</option>
                <option value={50}>50 baris</option>
                <option value={100}>100 baris</option>
                <option value={500}>Semua ({filteredTagihan.length})</option>
              </select>
              <span className="text-slate-400">|</span>
              <span>
                Menampilkan <b>{Math.min((currentPage - 1) * pageSize + 1, filteredTagihan.length)}</b> - <b>{Math.min(currentPage * pageSize, filteredTagihan.length)}</b> dari <b>{filteredTagihan.length}</b> total tagihan
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                disabled={currentPage <= 1}
                onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                className="p-1.5 bg-white border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed transition"
                title="Halaman Sebelumnya"
              >
                <ChevronLeft size={16} />
              </button>

              <span className="px-3 py-1 bg-white border border-slate-200 rounded-lg text-xs font-black text-slate-800">
                Halaman {currentPage} / {totalPages}
              </span>

              <button
                disabled={currentPage >= totalPages}
                onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                className="p-1.5 bg-white border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed transition"
                title="Halaman Berikutnya"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Modal Generate Tagihan Multi-Bulan */}
      {isGenerateModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-lg rounded-3xl border border-slate-200 shadow-2xl p-6 sm:p-7 space-y-5 my-8 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
                  <CreditCard size={18} />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Generate Tagihan (Sheet: TAGIHAN)</h3>
                  <p className="text-[11px] text-slate-400 font-medium">Buat tagihan massal per rombel / siswa & periode kalender</p>
                </div>
              </div>
              <button onClick={() => setIsGenerateModalOpen(false)} className="text-slate-400 hover:text-slate-700">
                <X size={18} />
              </button>
            </div>

            <form onSubmit={handleGenerateTagihan} className="space-y-3.5">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Dari Periode</label>
                  <input
                    type="month"
                    required
                    value={genFormData.fromPeriode}
                    onChange={(e) => setGenFormData(prev => ({ ...prev, fromPeriode: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Sampai Periode</label>
                  <input
                    type="month"
                    required
                    value={genFormData.toPeriode}
                    onChange={(e) => setGenFormData(prev => ({ ...prev, toPeriode: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Tahun Ajaran (TahunAjaranID)</label>
                  <input
                    type="text"
                    required
                    value={genFormData.tahunAjaranId}
                    onChange={(e) => setGenFormData(prev => ({ ...prev, tahunAjaranId: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Semester (SemesterID)</label>
                  <select
                    value={genFormData.semesterId}
                    onChange={(e) => setGenFormData(prev => ({ ...prev, semesterId: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                  >
                    <option value="Ganjil">Ganjil</option>
                    <option value="Genap">Genap</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Tanggal Tagihan</label>
                  <input
                    type="date"
                    required
                    value={genFormData.tanggalTagihan}
                    onChange={(e) => setGenFormData(prev => ({ ...prev, tanggalTagihan: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Tanggal Jatuh Tempo</label>
                  <input
                    type="date"
                    required
                    value={genFormData.jatuhTempo}
                    onChange={(e) => setGenFormData(prev => ({ ...prev, jatuhTempo: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Pilih Jenis Tagihan (Pos Biaya)</label>
                <select
                  value={genFormData.biayaId}
                  onChange={(e) => setGenFormData(prev => ({ ...prev, biayaId: e.target.value }))}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                >
                  <option value="">Semua Pos Biaya Aktif</option>
                  {biayaList.filter(b => b.status === 'AKTIF' || b.aktif !== false).map(b => (
                    <option key={b.id} value={b.id}>
                      {b.namaBiaya || b.nama} - {fmtRp(b.nominal)} ({b.targetKelas || b.kelasNama || 'Semua Kelas'})
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Target Kelas / Rombel</label>
                  <select
                    value={genFormData.kelasId}
                    onChange={(e) => setGenFormData(prev => ({ ...prev, kelasId: e.target.value, siswaId: '' }))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
                  >
                    <option value="">Semua Siswa Terdaftar</option>
                    {availableClasses.map(c => (
                      <option key={c} value={c}>{formatClassLabel(c)}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Siswa Spesifik (Opsional)</label>
                  <select
                    value={genFormData.siswaId}
                    onChange={(e) => setGenFormData(prev => ({ ...prev, siswaId: e.target.value }))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
                  >
                    <option value="">Semua Siswa di Rombel</option>
                    {filteredStudentsForGen.map(s => (
                      <option key={s.id} value={s.id}>{s.name} ({s.class})</option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Diskon (Rp)</label>
                  <input
                    type="number"
                    min={0}
                    value={genFormData.diskon}
                    onChange={(e) => setGenFormData(prev => ({ ...prev, diskon: Number(e.target.value) || 0 }))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Denda (Rp)</label>
                  <input
                    type="number"
                    min={0}
                    value={genFormData.denda}
                    onChange={(e) => setGenFormData(prev => ({ ...prev, denda: Number(e.target.value) || 0 }))}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold font-mono"
                  />
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsGenerateModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-200 transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-xs transition active:scale-95"
                >
                  Proses & Buat Tagihan
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Pembayaran Kasir */}
      {isPayModalOpen && activePayItem && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-md rounded-3xl border border-slate-200 shadow-2xl p-6 space-y-5 my-8 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
                  <CreditCard size={18} />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Kasir Pembayaran Tagihan</h3>
                  <p className="text-[11px] text-slate-400 font-medium">Rekam penerimaan kas & cetak bukti kuitansi</p>
                </div>
              </div>
              <button onClick={() => setIsPayModalOpen(false)} className="text-slate-400 hover:text-slate-700">
                <X size={18} />
              </button>
            </div>

            <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200/80 space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-500 font-medium">Siswa:</span>
                <span className="font-black text-slate-900">{activePayItem.namaSiswa}</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-500 font-medium">Kelas:</span>
                <span className="font-bold text-slate-700">{activePayItem.kelasNama || '-'}</span>
              </div>
              <div className="flex justify-between items-center text-xs">
                <span className="text-slate-500 font-medium">Item Tagihan:</span>
                <span className="font-semibold text-slate-800 text-right line-clamp-1">{activePayItem.namaBiaya}</span>
              </div>
              <div className="flex justify-between items-center text-xs pt-1 border-t border-slate-200">
                <span className="text-slate-700 font-bold">Sisa Kewajiban:</span>
                <span className="font-mono font-black text-emerald-700 text-sm">
                  {fmtRp(activePayItem.sisaTagihan)}
                </span>
              </div>
            </div>

            <form onSubmit={handleSubmitPayment} className="space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Tanggal Transaksi</label>
                <input
                  type="date"
                  required
                  value={payFormData.tglBayar}
                  onChange={(e) => setPayFormData(prev => ({ ...prev, tglBayar: e.target.value }))}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Metode Pembayaran</label>
                  <select
                    value={payFormData.metode}
                    onChange={(e) => setPayFormData(prev => ({ ...prev, metode: e.target.value }))}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
                  >
                    <option value="CASH">Tunai / Loket Kasir</option>
                    <option value="TRANSFER">Transfer Bank</option>
                    <option value="TABUNGAN">Potong Tabungan Siswa</option>
                    <option value="QRIS">QRIS / E-Wallet</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Bank / Channel</label>
                  <input
                    type="text"
                    placeholder="BCA, BRI, Mandiri, Kasir"
                    value={payFormData.bank}
                    onChange={(e) => setPayFormData(prev => ({ ...prev, bank: e.target.value }))}
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                  />
                </div>
              </div>

              {payFormData.metode === 'TABUNGAN' && (
                <div className="bg-amber-50 p-3 rounded-xl border border-amber-200 text-xs">
                  <div className="flex justify-between items-center">
                    <span className="text-amber-800 font-bold">Saldo Tabungan Saat Ini:</span>
                    <span className="font-mono font-black text-amber-900">{fmtRp(activeStudentTabunganSaldo)}</span>
                  </div>
                  {activeStudentTabunganSaldo < activePayItem.sisaTagihan && (
                    <p className="text-[11px] text-rose-600 mt-1 font-semibold">
                      * Saldo tabungan kurang dari sisa tagihan. Pembayaran akan dicatat sebagai cicilan sebagian.
                    </p>
                  )}
                </div>
              )}

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Jumlah Yang Dibayarkan (Rp)</label>
                <input
                  type="number"
                  required
                  min={1000}
                  max={activePayItem.sisaTagihan}
                  value={payFormData.jumlahBayar}
                  onChange={(e) => setPayFormData(prev => ({ ...prev, jumlahBayar: Number(e.target.value) || 0 }))}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-base font-black text-emerald-700 font-mono"
                />
                <div className="flex justify-between items-center mt-1">
                  <span className="text-[11px] text-slate-400 font-medium">Bisa dicicil bertahap</span>
                  <button
                    type="button"
                    onClick={() => setPayFormData(prev => ({ ...prev, jumlahBayar: activePayItem.sisaTagihan }))}
                    className="text-[11px] text-emerald-600 font-bold hover:underline"
                  >
                    Bayar Lunas (100%)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">No. Referensi / Bukti Transfer</label>
                <input
                  type="text"
                  placeholder="Nomor referensi atau struk transaksi"
                  value={payFormData.noReferensi}
                  onChange={(e) => setPayFormData(prev => ({ ...prev, noReferensi: e.target.value }))}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Catatan Transaksi</label>
                <input
                  type="text"
                  placeholder="misal: Titipan wali murid..."
                  value={payFormData.catatan}
                  onChange={(e) => setPayFormData(prev => ({ ...prev, catatan: e.target.value }))}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsPayModalOpen(false)}
                  className="px-4 py-2.5 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-200 transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-xs transition active:scale-95"
                >
                  Konfirmasi Pembayaran
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal Impor / Paste TSV Sheet TAGIHAN */}
      {isImportModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-xl rounded-3xl border border-slate-200 shadow-2xl p-6 sm:p-7 space-y-4 my-8 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
                  <Upload size={18} />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Impor Data Sheet TAGIHAN</h3>
                  <p className="text-[11px] text-slate-400 font-medium">Salin baris dari Google Sheet / Excel kolom ID s/d Nama Siswa lalu tempel di sini</p>
                </div>
              </div>
              <button onClick={() => setIsImportModalOpen(false)} className="text-slate-400 hover:text-slate-700">
                <X size={18} />
              </button>
            </div>

            <div className="space-y-3">
              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200/80 text-[11px] text-slate-600 space-y-1">
                <p className="font-bold text-slate-800 flex items-center gap-1.5">
                  <ClipboardCheck size={14} className="text-emerald-600" />
                  <span>Petunjuk Impor Cepat:</span>
                </p>
                <p>1. Buka sheet <b>TAGIHAN</b> di Google Sheets / Excel Anda.</p>
                <p>2. Blok seluruh tabel termasuk baris judul header, lalu tekan <b>Ctrl + C</b>.</p>
                <p>3. Tempel (<b>Ctrl + V</b>) ke kotak di bawah ini, lalu klik tombol "Proses Impor Data".</p>
              </div>

              <div>
                <textarea
                  rows={8}
                  placeholder={`Contoh format:\nid\tsiswaId\tkelasId\tbiayaId\tnamaBiaya\tnominal\tperiode\tjatuhTempo\tstatus\tpaidAt\tpaidBy\tcreatedAt\tpaidAmount\tremainingAmount\tpaymentType\tNama Siswa\nTGH_001\t001\tA5\tA5_Modul24\tBuku Modul A5\t180,000\t2024-07\t2025-06-30\tLUNAS\t2025-06-30\t\t2025-06-30\t180,000\t0\tFULL\tRIZKY KURNIAWAN`}
                  value={rawImportText}
                  onChange={(e) => setRawImportText(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-2xl font-mono text-[11px] text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    setIsImportModalOpen(false);
                    setRawImportText('');
                  }}
                  className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-200 transition"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (!rawImportText.trim()) {
                      alert('Silakan tempel data tabel terlebih dahulu.');
                      return;
                    }
                    const parsed = parseRawTagihanTSV(rawImportText);
                    if (parsed.length === 0) {
                      alert('Gagal membaca data tagihan. Pastikan format tabel memiliki minimal kolom ID, Siswa, Kelas, Biaya, dan Nominal.');
                      return;
                    }
                    // Merge or replace
                    const existingMap = new Map(tagihanList.map(t => [t.id, t]));
                    parsed.forEach(p => existingMap.set(p.id, p));
                    const merged = Array.from(existingMap.values());
                    saveTagihanToDb(merged);
                    setIsImportModalOpen(false);
                    setRawImportText('');
                    alert(`Berhasil mengimpor/memperbarui ${parsed.length} baris data tagihan!`);
                  }}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-xs transition active:scale-95"
                >
                  Proses Impor Data
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
