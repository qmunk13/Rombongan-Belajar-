import React, { useState, useMemo } from 'react';
import { 
  Receipt, Search, Eye, Printer, Trash2, X, ArrowUpRight, 
  Calendar, CheckCircle, Clock, FileSpreadsheet, User, Building2, Hash, Upload, ClipboardCheck,
  ChevronLeft, ChevronRight, GraduationCap
} from 'lucide-react';
import { db } from '../../data/db';
import { useStore } from '../../store';
import { KeuanganInvoice } from '../../data/keuanganSeed';
import { DEFAULT_INVOICE_LIST } from '../../data/keuanganTransactionsData';
import { parseRawInvoiceTSV, parseRawPembayaranTSV } from '../../data/keuanganTransactionsSeed';
import { exportToExcel } from '../../lib/excel';
import { getAllClasses, formatClassLabel, matchClass } from '../../lib/utils';
import { 
  getAcademicPeriodInfo, 
  matchAcademicFilter, 
  extractAvailableAcademicYears 
} from '../../lib/academicYear';

interface PembayaranInvoiceTabProps {
  onPrintInvoice: (invoiceId: string) => void;
}

export default function PembayaranInvoiceTab({ onPrintInvoice }: PembayaranInvoiceTabProps) {
  const { students } = useStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterKelas, setFilterKelas] = useState('');
  const [filterMetode, setFilterMetode] = useState('');
  const [filterTahunAjaran, setFilterTahunAjaran] = useState('SEMUA');
  const [filterSemester, setFilterSemester] = useState('SEMUA');
  const [selectedInvoiceForDetail, setSelectedInvoiceForDetail] = useState<KeuanganInvoice | null>(null);
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [rawImportText, setRawImportText] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);

  const availableClasses = useMemo(() => getAllClasses(students), [students]);

  const [invoices, setInvoices] = useState<KeuanganInvoice[]>(() => {
    return db.get<KeuanganInvoice>('keuangan_invoices') || [];
  });

  const availableAcademicYears = useMemo(() => {
    const dates = invoices.map(i => i.tanggal || i.tglBayar || i.createdAt);
    return extractAvailableAcademicYears(dates);
  }, [invoices]);

  const filteredInvoices = useMemo(() => {
    return invoices.filter(inv => {
      const q = searchTerm.toLowerCase();
      const no = String(inv.invoiceId || '').toLowerCase();
      const pemId = String(inv.pembayaranId || inv.id || '').toLowerCase();
      const tagId = String(inv.tagihanId || '').toLowerCase();
      const nama = String(inv.namaSiswa || '').toLowerCase();
      const sId = String(inv.siswaId || '').toLowerCase();
      const metode = String(inv.metodePembayaran || inv.metode || '').toLowerCase();
      const bank = String(inv.bank || '').toLowerCase();
      const ref = String(inv.noReferensi || '').toLowerCase();
      const petugas = String(inv.petugasId || inv.createdBy || '').toLowerCase();

      const matchesQ = !searchTerm || 
        no.includes(q) || 
        pemId.includes(q) || 
        tagId.includes(q) || 
        nama.includes(q) || 
        sId.includes(q) || 
        metode.includes(q) || 
        bank.includes(q) || 
        ref.includes(q) || 
        petugas.includes(q);

      const matchesKelas = !filterKelas || matchClass(inv.namaKelas, filterKelas);
      const matchesMetode = !filterMetode || (inv.metodePembayaran || inv.metode) === filterMetode;
      
      const invDate = inv.tanggal || inv.tglBayar || inv.createdAt;
      const matchesTA = matchAcademicFilter(invDate, filterTahunAjaran, filterSemester);

      return matchesQ && matchesKelas && matchesMetode && matchesTA;
    });
  }, [invoices, searchTerm, filterKelas, filterMetode, filterTahunAjaran, filterSemester]);

  const totalPages = Math.ceil(filteredInvoices.length / pageSize) || 1;
  const paginatedInvoices = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredInvoices.slice(start, start + pageSize);
  }, [filteredInvoices, currentPage, pageSize]);

  const handleDeleteInvoice = (id: string) => {
    if (window.confirm('Hapus riwayat kwitansi & pembayaran ini?')) {
      const updated = invoices.filter(i => i.id !== id);
      setInvoices(updated);
      db.set('keuangan_invoices', updated);
    }
  };

  const handleExportExcel = () => {
    if (filteredInvoices.length === 0) {
      alert("Tidak ada data kwitansi/invoice untuk diekspor.");
      return;
    }
    const rows = filteredInvoices.map((inv, idx) => ({
      No: idx + 1,
      PembayaranID: inv.pembayaranId || inv.id,
      TagihanID: inv.tagihanId || (inv.tagihanIds && inv.tagihanIds[0]) || '-',
      InvoiceID: inv.invoiceId,
      SiswaID: inv.siswaId || '-',
      NamaSiswa: inv.namaSiswa,
      Kelas: inv.namaKelas || '-',
      Tanggal: inv.tanggal || inv.tglBayar,
      Nominal: inv.nominal || inv.total,
      MetodePembayaran: inv.metodePembayaran || inv.metode,
      NoReferensi: inv.noReferensi || '-',
      Bank: inv.bank || '-',
      PetugasID: inv.petugasId || inv.createdBy || 'Bendahara Sekolah',
      Keterangan: inv.keterangan || inv.catatan || '-',
      Status: inv.status || 'PAID',
      CreatedAt: inv.createdAt || '-',
      UpdatedAt: inv.updatedAt || '-'
    }));
    exportToExcel(rows, `Riwayat_Sheet_PEMBAYARAN_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  const fmtRp = (n: number) => 'Rp ' + Number(n || 0).toLocaleString('id-ID');

  return (
    <div className="space-y-5 animate-in fade-in">
      {/* Header */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div>
          <h2 className="text-lg font-black text-slate-900 flex items-center gap-2">
            <Receipt size={20} className="text-emerald-600" />
            Kwitansi & Riwayat Pembayaran (Sheet: PEMBAYARAN)
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Log mutasi penerimaan kas: PembayaranID, TagihanID, InvoiceID, SiswaID, Nominal, Metode, & Petugas.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full lg:w-auto">
          <select
            value={filterKelas}
            onChange={(e) => {
              setFilterKelas(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
          >
            <option value="">Semua Rombel</option>
            {availableClasses.map(c => (
              <option key={c} value={c}>{formatClassLabel(c)}</option>
            ))}
          </select>

          {/* Smart Filter Tahun Ajaran */}
          <select
            value={filterTahunAjaran}
            onChange={(e) => {
              setFilterTahunAjaran(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
          >
            <option value="SEMUA">Semua TA</option>
            {availableAcademicYears.map(ta => (
              <option key={ta} value={ta}>TA {ta}</option>
            ))}
          </select>

          {/* Smart Filter Semester */}
          <select
            value={filterSemester}
            onChange={(e) => {
              setFilterSemester(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
          >
            <option value="SEMUA">Semua Semester</option>
            <option value="1">Sem 1 (Ganjil: Jul-Des)</option>
            <option value="2">Sem 2 (Genap: Jan-Jun)</option>
          </select>

          <select
            value={filterMetode}
            onChange={(e) => {
              setFilterMetode(e.target.value);
              setCurrentPage(1);
            }}
            className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-none"
          >
            <option value="">Semua Metode</option>
            <option value="CASH">CASH (Tunai)</option>
            <option value="TRANSFER">TRANSFER (Bank)</option>
            <option value="TABUNGAN">TABUNGAN (Autodebet)</option>
            <option value="QRIS">QRIS</option>
          </select>

          <div className="relative flex-1 sm:w-56">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Cari invoice, siswa, ID..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-8 pr-7 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
            />
            {searchTerm && (
              <button onClick={() => setSearchTerm('')} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                <X size={13} />
              </button>
            )}
          </div>

          <button
            onClick={() => setIsImportModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-xl text-xs font-bold border border-emerald-200 transition active:scale-95 whitespace-nowrap"
            title="Impor / Paste Data dari Sheet PEMBAYARAN"
          >
            <Upload size={14} className="text-emerald-700" />
            <span>Impor Sheet PEMBAYARAN</span>
          </button>

          <button
            onClick={handleExportExcel}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition active:scale-95 whitespace-nowrap"
            title="Ekspor Riwayat Kwitansi ke Excel format Sheet PEMBAYARAN"
          >
            <FileSpreadsheet size={14} className="text-emerald-600" />
            <span>Ekspor Excel</span>
          </button>
        </div>
      </div>

      {/* Table Sesuai Skema Sheet PEMBAYARAN */}
      <div className="bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50/90 text-slate-600 uppercase font-black text-[10px] border-b border-slate-200 tracking-wider">
              <tr>
                <th className="p-3.5 pl-4">ID Pembayaran & Invoice</th>
                <th className="p-3.5">Nama Siswa (SiswaID)</th>
                <th className="p-3.5">Kelas</th>
                <th className="p-3.5 text-center">Tahun Ajaran / Sem</th>
                <th className="p-3.5 text-center">Tanggal Bayar</th>
                <th className="p-3.5 text-right">Nominal Bayar</th>
                <th className="p-3.5 text-center">Metode & Ref</th>
                <th className="p-3.5">Petugas Kasir</th>
                <th className="p-3.5 text-center">Status</th>
                <th className="p-3.5 pr-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {filteredInvoices.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-12 text-center text-slate-400 space-y-2">
                    <Receipt size={36} className="mx-auto text-slate-300" />
                    <p className="font-bold text-slate-600 text-sm">Belum Ada Riwayat Pembayaran</p>
                    <p className="text-xs text-slate-400">Pembayaran yang diproses di tab Tagihan akan otomatis terbit di sini.</p>
                  </td>
                </tr>
              ) : (
                paginatedInvoices.map((inv, idx) => {
                  const pemId = inv.pembayaranId || inv.id;
                  const invId = inv.invoiceId;
                  const tagId = inv.tagihanId || (inv.tagihanIds && inv.tagihanIds[0]) || '-';
                  const nominal = inv.nominal || inv.total;
                  const metode = inv.metodePembayaran || inv.metode || 'CASH';
                  const petugas = inv.petugasId || inv.createdBy || 'Bendahara';
                  const tgl = inv.tanggal || inv.tglBayar;

                  return (
                    <tr key={`${inv.id || pemId || 'inv'}_${idx}`} className="hover:bg-slate-50/80 transition">
                      <td className="p-3.5 pl-4 font-mono">
                        <div className="font-black text-emerald-800 text-xs flex items-center gap-1">
                          <Receipt size={12} />
                          <span>{invId}</span>
                        </div>
                        <div className="text-[10px] text-slate-400 font-mono">
                          ID: {pemId} | Tag: {tagId}
                        </div>
                      </td>
                      <td className="p-3.5 font-bold text-slate-900">
                        <div className="text-sm font-black text-slate-900">{inv.namaSiswa}</div>
                        <div className="text-[10px] font-mono text-slate-400 font-normal">SiswaID: {inv.siswaId || '-'}</div>
                      </td>
                      <td className="p-3.5 font-semibold text-slate-800">
                        {inv.namaKelas || '-'}
                      </td>
                      <td className="p-3.5 text-center font-mono text-[11px]">
                        {(() => {
                          const info = getAcademicPeriodInfo(tgl || inv.createdAt);
                          return (
                            <div>
                              <span className="font-black text-slate-800 bg-slate-100 px-2 py-0.5 rounded-md text-[10px] inline-block">
                                TA {info.academicYear}
                              </span>
                              <div className={`text-[10px] font-bold mt-0.5 ${info.semester === 'Ganjil' ? 'text-indigo-600' : 'text-teal-600'}`}>
                                Sem {info.semesterNum} ({info.semester})
                              </div>
                            </div>
                          );
                        })()}
                      </td>
                      <td className="p-3.5 text-center font-mono text-slate-700">
                        {tgl}
                      </td>
                      <td className="p-3.5 text-right font-mono font-black text-emerald-700 text-sm">
                        {fmtRp(nominal)}
                      </td>
                      <td className="p-3.5 text-center">
                        <div className="inline-flex flex-col items-center">
                          <span className="px-2 py-0.5 rounded-lg bg-slate-100 text-slate-700 font-mono font-bold text-[10px] border border-slate-200">
                            {metode}
                          </span>
                          {inv.bank && inv.bank !== '-' && (
                            <span className="text-[9px] text-slate-400 font-medium mt-0.5">{inv.bank}</span>
                          )}
                        </div>
                      </td>
                      <td className="p-3.5 text-slate-700 text-xs">
                        <div className="font-semibold">{petugas}</div>
                        {inv.catatan && (
                          <div className="text-[10px] text-slate-400 line-clamp-1">{inv.catatan}</div>
                        )}
                      </td>
                      <td className="p-3.5 text-center">
                        <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-black text-[10px]">
                          {inv.status || 'PAID'}
                        </span>
                      </td>
                      <td className="p-3.5 pr-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => setSelectedInvoiceForDetail(inv)}
                            className="px-2.5 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                            title="Lihat Detail Mutasi"
                          >
                            <Eye size={12} />
                            <span>Detail</span>
                          </button>
                          <button
                            onClick={() => onPrintInvoice(inv.invoiceId)}
                            className="px-2.5 py-1 bg-slate-900 hover:bg-slate-800 text-white rounded-lg font-bold text-[11px] transition flex items-center gap-1 shadow-2xs"
                            title="Cetak Kwitansi / Struk"
                          >
                            <Printer size={12} />
                            <span>Cetak</span>
                          </button>
                          <button
                            onClick={() => handleDeleteInvoice(inv.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition"
                            title="Hapus Data Kwitansi"
                          >
                            <Trash2 size={13} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        {filteredInvoices.length > 0 && (
          <div className="p-3.5 border-t border-slate-100 bg-slate-50/60 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-600 font-medium">
            <div className="flex items-center gap-2">
              <span>Tampilkan:</span>
              <select
                value={pageSize}
                onChange={(e) => {
                  setPageSize(Number(e.target.value));
                  setCurrentPage(1);
                }}
                className="px-2 py-1 bg-white border border-slate-200 rounded-lg text-xs font-bold text-slate-800 focus:outline-none"
              >
                <option value={10}>10 baris</option>
                <option value={25}>25 baris</option>
                <option value={50}>50 baris</option>
                <option value={100}>100 baris</option>
                <option value={500}>Semua ({filteredInvoices.length})</option>
              </select>
              <span className="text-slate-400">|</span>
              <span>
                Menampilkan <b>{Math.min((currentPage - 1) * pageSize + 1, filteredInvoices.length)}</b> - <b>{Math.min(currentPage * pageSize, filteredInvoices.length)}</b> dari <b>{filteredInvoices.length}</b> total pembayaran
              </span>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                disabled={currentPage <= 1}
                onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
                className="p-1.5 bg-white border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed transition"
                title="Halaman Sebelumnya"
              >
                <ChevronLeft size={16} />
              </button>

              <span className="px-3 py-1 bg-white border border-slate-200 rounded-lg text-xs font-black text-slate-800">
                Halaman {currentPage} / {totalPages}
              </span>

              <button
                disabled={currentPage >= totalPages}
                onClick={() => setCurrentPage(prev => Math.min(totalPages, prev + 1))}
                className="p-1.5 bg-white border border-slate-200 rounded-lg text-slate-600 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed transition"
                title="Halaman Berikutnya"
              >
                <ChevronRight size={16} />
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Modal Detail Invoice Sesuai Skema Sheet PEMBAYARAN */}
      {selectedInvoiceForDetail && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-lg rounded-3xl border border-slate-200 shadow-2xl p-6 sm:p-7 space-y-5 my-8 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                  <Receipt size={18} />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Kwitansi: {selectedInvoiceForDetail.invoiceId}</h3>
                  <p className="text-xs text-slate-500">{selectedInvoiceForDetail.namaSiswa} ({selectedInvoiceForDetail.namaKelas})</p>
                </div>
              </div>
              <button onClick={() => setSelectedInvoiceForDetail(null)} className="text-slate-400 hover:text-slate-700">
                <X size={18} />
              </button>
            </div>

            {/* Field Skema Database Sheet PEMBAYARAN */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-200 text-xs">
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">PembayaranID</span>
                <span className="font-mono font-bold text-slate-800">{selectedInvoiceForDetail.pembayaranId || selectedInvoiceForDetail.id}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">SiswaID</span>
                <span className="font-mono font-bold text-slate-800">{selectedInvoiceForDetail.siswaId || '-'}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">TagihanID</span>
                <span className="font-mono font-bold text-slate-800">{selectedInvoiceForDetail.tagihanId || (selectedInvoiceForDetail.tagihanIds && selectedInvoiceForDetail.tagihanIds[0]) || '-'}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Tanggal Bayar</span>
                <span className="font-mono font-bold text-slate-800">{selectedInvoiceForDetail.tanggal || selectedInvoiceForDetail.tglBayar}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Metode</span>
                <span className="font-mono font-bold text-emerald-700">{selectedInvoiceForDetail.metodePembayaran || selectedInvoiceForDetail.metode}</span>
              </div>
              <div>
                <span className="text-[10px] uppercase font-bold text-slate-400 block">Bank / Ref</span>
                <span className="font-mono font-bold text-slate-700">{selectedInvoiceForDetail.bank || selectedInvoiceForDetail.noReferensi || '-'}</span>
              </div>
            </div>

            {/* Items Table */}
            <div className="space-y-2">
              <div className="text-xs font-black text-slate-700 uppercase tracking-wider">
                Rincian Tagihan yang Dibayar
              </div>
              <div className="rounded-2xl border border-slate-200 overflow-hidden">
                <table className="w-full text-xs">
                  <thead className="bg-slate-50 text-slate-600 uppercase font-black text-[10px] border-b border-slate-200">
                    <tr>
                      <th className="p-3 text-left">Pos Biaya</th>
                      <th className="p-3 text-center">Periode</th>
                      <th className="p-3 text-right">Nominal</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-medium">
                    {selectedInvoiceForDetail.items && selectedInvoiceForDetail.items.length > 0 ? (
                      selectedInvoiceForDetail.items.map((item, idx) => (
                        <tr key={idx}>
                          <td className="p-3 font-bold text-slate-800">{item.namaBiaya}</td>
                          <td className="p-3 text-center font-mono text-slate-600">{item.periode}</td>
                          <td className="p-3 text-right font-mono font-bold text-emerald-700">{fmtRp(item.nominal)}</td>
                        </tr>
                      ))
                    ) : (
                      <tr>
                        <td className="p-3 font-bold text-slate-800">Pembayaran Tagihan</td>
                        <td className="p-3 text-center font-mono text-slate-600">-</td>
                        <td className="p-3 text-right font-mono font-bold text-emerald-700">{fmtRp(selectedInvoiceForDetail.nominal || selectedInvoiceForDetail.total)}</td>
                      </tr>
                    )}
                  </tbody>
                  <tfoot className="bg-slate-50 font-bold border-t border-slate-200">
                    <tr>
                      <td colSpan={2} className="p-3 text-right text-slate-700 font-black">TOTAL DITERIMA KASIR:</td>
                      <td className="p-3 text-right font-mono font-black text-emerald-700 text-sm">
                        {fmtRp(selectedInvoiceForDetail.nominal || selectedInvoiceForDetail.total)}
                      </td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>

            {selectedInvoiceForDetail.catatan && (
              <div className="p-3 rounded-xl bg-slate-50 border border-slate-200 text-xs">
                <span className="font-bold text-slate-600 block mb-0.5">Catatan Kasir:</span>
                <p className="text-slate-700 font-medium">{selectedInvoiceForDetail.catatan}</p>
              </div>
            )}

            <div className="pt-2 flex justify-between items-center border-t border-slate-100">
              <span className="text-[11px] font-bold text-slate-400">
                Petugas Kasir: {selectedInvoiceForDetail.petugasId || selectedInvoiceForDetail.createdBy || 'Bendahara'}
              </span>
              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={() => setSelectedInvoiceForDetail(null)}
                  className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-200"
                >
                  Tutup
                </button>
                <button
                  type="button"
                  onClick={() => {
                    onPrintInvoice(selectedInvoiceForDetail.invoiceId);
                    setSelectedInvoiceForDetail(null);
                  }}
                  className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 shadow-xs"
                >
                  <Printer size={13} />
                  <span>Cetak Kwitansi</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal Impor / Paste TSV Sheet PEMBAYARAN */}
      {isImportModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
          <div className="bg-white w-full max-w-xl rounded-3xl border border-slate-200 shadow-2xl p-6 sm:p-7 space-y-4 my-8 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
                  <Upload size={18} />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">Impor Data Sheet PEMBAYARAN / INVOICE</h3>
                  <p className="text-[11px] text-slate-400 font-medium">Salin baris dari Google Sheet / Excel lalu tempel di sini</p>
                </div>
              </div>
              <button onClick={() => setIsImportModalOpen(false)} className="text-slate-400 hover:text-slate-700">
                <X size={18} />
              </button>
            </div>

            <div className="space-y-3">
              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200/80 text-[11px] text-slate-600 space-y-1">
                <p className="font-bold text-slate-800 flex items-center gap-1.5">
                  <ClipboardCheck size={14} className="text-emerald-600" />
                  <span>Petunjuk Impor Cepat:</span>
                </p>
                <p>1. Buka sheet <b>PEMBAYARAN</b> atau <b>INVOICE</b> di Google Sheets / Excel Anda.</p>
                <p>2. Blok seluruh tabel termasuk baris judul header, lalu tekan <b>Ctrl + C</b>.</p>
                <p>3. Tempel (<b>Ctrl + V</b>) ke kotak di bawah ini, lalu klik tombol "Proses Impor Data".</p>
              </div>

              <div>
                <textarea
                  rows={8}
                  placeholder={`Contoh format:\nid\ttagihanId\tsiswaId\tkelasId\ttglBayar\tmetode\tjumlah\tcatatan\tcreatedBy\tcreatedAt\tinvoiceId\ttagihanIds\tNAMA SISWA\nBYR_001\tTGH_001\t001\tA5\t2025-06-30\tTABUNGAN\t180,000\tBayar Buku Modul A5\tsuperadmin\t2025-06-30\tINV-E578D\t["TGH_001"]\tRIZKY KURNIAWAN`}
                  value={rawImportText}
                  onChange={(e) => setRawImportText(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-2xl font-mono text-[11px] text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    setIsImportModalOpen(false);
                    setRawImportText('');
                  }}
                  className="px-4 py-2 bg-slate-100 text-slate-700 rounded-xl text-xs font-bold hover:bg-slate-200 transition"
                >
                  Batal
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (!rawImportText.trim()) {
                      alert('Silakan tempel data tabel terlebih dahulu.');
                      return;
                    }
                    // Check if it's invoice format or pembayaran format
                    let parsedInvoices: KeuanganInvoice[] = [];
                    if (rawImportText.includes('invoiceId') && rawImportText.includes('total')) {
                      parsedInvoices = parseRawInvoiceTSV(rawImportText);
                    } else {
                      const parsedPayments = parseRawPembayaranTSV(rawImportText);
                      parsedInvoices = parsedPayments.map(p => ({
                        id: `INV_${p.id}`,
                        pembayaranId: p.id,
                        tagihanId: p.tagihanId || (p.tagihanIds && p.tagihanIds[0]) || '',
                        invoiceId: p.invoiceId || `INV-${p.id.slice(-6)}`,
                        siswaId: p.siswaId,
                        namaSiswa: p.namaSiswa,
                        kelasId: p.kelasId,
                        namaKelas: p.kelasId,
                        tanggal: p.tglBayar,
                        tglBayar: p.tglBayar,
                        metodePembayaran: p.metode,
                        metode: p.metode,
                        nominal: p.jumlah,
                        total: p.jumlah,
                        status: 'PAID',
                        catatan: p.catatan,
                        keterangan: p.catatan,
                        tagihanIds: p.tagihanIds,
                        items: [{
                          namaBiaya: p.catatan || 'Pembayaran Sekolah',
                          periode: p.tglBayar.slice(0, 7),
                          nominal: p.jumlah
                        }],
                        createdBy: p.createdBy,
                        createdAt: p.createdAt,
                        updatedAt: p.createdAt
                      }));
                    }

                    if (parsedInvoices.length === 0) {
                      alert('Gagal membaca data pembayaran. Pastikan format tabel memiliki kolom ID/Invoice, Siswa, Tanggal, dan Nominal.');
                      return;
                    }

                    const existingMap = new Map(invoices.map(inv => [inv.invoiceId || inv.id, inv]));
                    parsedInvoices.forEach(inv => existingMap.set(inv.invoiceId || inv.id, inv));
                    const merged = Array.from(existingMap.values());

                    setInvoices(merged);
                    db.set('keuangan_invoices', merged);
                    setIsImportModalOpen(false);
                    setRawImportText('');
                    alert(`Berhasil mengimpor/memperbarui ${parsedInvoices.length} baris riwayat kwitansi!`);
                  }}
                  className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black shadow-xs transition active:scale-95"
                >
                  Proses Impor Data
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
