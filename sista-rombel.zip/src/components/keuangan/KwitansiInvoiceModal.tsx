import React, { useRef } from 'react';
import { Printer, X, CheckCircle, ShieldCheck } from 'lucide-react';
import { useStore } from '../../store';
import { db } from '../../data/db';
import { KeuanganInvoice } from '../../data/keuanganSeed';

interface KwitansiInvoiceModalProps {
  invoiceId: string;
  onClose: () => void;
}

export default function KwitansiInvoiceModal({ invoiceId, onClose }: KwitansiInvoiceModalProps) {
  const { settings } = useStore();
  const printRef = useRef<HTMLDivElement>(null);

  const allInvoices = db.get<KeuanganInvoice>('keuangan_invoices') || [];
  const invoice = allInvoices.find(i => i.invoiceId === invoiceId || i.id === invoiceId);

  const handlePrint = () => {
    window.print();
  };

  const fmtRp = (n: number) => 'Rp ' + Number(n || 0).toLocaleString('id-ID');

  if (!invoice) {
    return (
      <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
        <div className="bg-white rounded-3xl p-6 text-center max-w-sm w-full space-y-4">
          <p className="text-sm font-bold text-slate-800">Invoice tidak ditemukan</p>
          <button onClick={onClose} className="px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold">
            Tutup
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-slate-900/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto print:p-0 print:bg-white">
      <div className="bg-white w-full max-w-2xl rounded-3xl border border-slate-200 shadow-2xl overflow-hidden my-8 print:shadow-none print:border-none print:m-0 print:w-full print:max-w-none animate-in fade-in zoom-in-95">
        
        {/* Modal Controls - Hidden when Printing */}
        <div className="bg-slate-900 text-white px-6 py-4 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <ShieldCheck size={18} className="text-emerald-400" />
            <span className="text-xs font-black uppercase tracking-wider">Kwitansi Pembayaran Sah (Invoice)</span>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-black transition flex items-center gap-1.5 shadow-xs"
            >
              <Printer size={13} />
              <span>Cetak Sekarang</span>
            </button>
            <button
              onClick={onClose}
              className="p-1.5 text-slate-400 hover:text-white rounded-lg transition"
            >
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Printable Receipt Body */}
        <div ref={printRef} className="p-8 sm:p-10 space-y-6 text-slate-900 font-sans">
          
          {/* Header & Kop Sekolah */}
          <div className="border-b-2 border-slate-900 pb-5 flex items-start justify-between gap-4">
            <div className="space-y-1">
              <h1 className="text-xl font-black uppercase tracking-tight text-slate-950">
                {settings?.schoolName || 'PKBM / SEKOLAH CERDAS BANGSA'}
              </h1>
              <p className="text-xs text-slate-600 font-medium max-w-md">
                {settings?.address || 'Jl. Pendidikan Karakter No. 10, Jakarta Pusat'} • Telp: {settings?.phone || '021-5556789'}
              </p>
              <p className="text-[11px] text-slate-500 font-mono">NPSN: {settings?.npsn || '69988221'} • Website: www.cerdasbangsa.sch.id</p>
            </div>
            <div className="text-right space-y-0.5">
              <span className="px-3 py-1 bg-emerald-100 text-emerald-900 font-black text-xs rounded-lg uppercase tracking-wider inline-block">
                KWITANSI LUNAS
              </span>
              <div className="text-xs font-mono font-bold text-slate-500 mt-1">No: {invoice.invoiceId}</div>
            </div>
          </div>

          {/* Info Transaksi & Siswa */}
          <div className="grid grid-cols-2 gap-4 text-xs">
            <div className="space-y-1 bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Data Peserta Didik</span>
              <div className="font-black text-sm text-slate-900">{invoice.namaSiswa}</div>
              <div className="text-slate-600 font-semibold">Kelas: {invoice.namaKelas || '-'}</div>
            </div>

            <div className="space-y-1 bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">Detail Transaksi</span>
              <div className="font-mono font-bold text-slate-800">Tanggal: {invoice.tglBayar}</div>
              <div className="font-semibold text-emerald-700">Metode: {invoice.metode}</div>
            </div>
          </div>

          {/* Breakdown Items Table */}
          <div className="space-y-2">
            <table className="w-full text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-300 text-slate-600 uppercase font-black text-[10px]">
                  <th className="py-2.5 text-left w-12">No</th>
                  <th className="py-2.5 text-left">Keterangan / Pos Tagihan</th>
                  <th className="py-2.5 text-center">Periode</th>
                  <th className="py-2.5 text-right">Jumlah Bayar</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium">
                {invoice.items && invoice.items.length > 0 ? (
                  invoice.items.map((it, idx) => (
                    <tr key={idx}>
                      <td className="py-2.5 text-slate-500 font-mono">{idx + 1}</td>
                      <td className="py-2.5 font-bold text-slate-900">{it.namaBiaya}</td>
                      <td className="py-2.5 text-center font-mono text-slate-600">{it.periode}</td>
                      <td className="py-2.5 text-right font-mono font-black text-slate-900">{fmtRp(it.nominal)}</td>
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td className="py-2.5 text-slate-500 font-mono">1</td>
                    <td className="py-2.5 font-bold text-slate-900">Pembayaran Tagihan Sekolah</td>
                    <td className="py-2.5 text-center font-mono text-slate-600">-</td>
                    <td className="py-2.5 text-right font-mono font-black text-slate-900">{fmtRp(invoice.total)}</td>
                  </tr>
                )}
              </tbody>
              <tfoot>
                <tr className="border-t-2 border-slate-900 font-black">
                  <td colSpan={3} className="py-3 text-right uppercase text-slate-700">TOTAL PEMBAYARAN:</td>
                  <td className="py-3 text-right font-mono text-emerald-800 text-base">{fmtRp(invoice.total)}</td>
                </tr>
              </tfoot>
            </table>
          </div>

          {invoice.catatan && (
            <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-xs text-slate-600">
              <span className="font-bold text-slate-700 block mb-0.5">Catatan:</span>
              {invoice.catatan}
            </div>
          )}

          {/* Signature & Stamp Section */}
          <div className="pt-8 grid grid-cols-2 gap-8 text-xs text-center border-t border-slate-200">
            <div className="space-y-12">
              <p className="text-slate-500">Penyetor / Wali Murid,</p>
              <div className="font-bold text-slate-900 underline underline-offset-4">
                ( {invoice.namaSiswa.split(' ')[0]} / Wali )
              </div>
            </div>

            <div className="space-y-12">
              <p className="text-slate-500">Kasir / Bendahara,</p>
              <div className="font-bold text-slate-900 underline underline-offset-4">
                ( {invoice.createdBy || 'Bendahara'} )
              </div>
            </div>
          </div>

          <div className="text-[10px] text-slate-400 text-center pt-4 font-mono">
            Bukti pembayaran ini sah dan dicetak secara otomatis oleh Sistem Informasi Keuangan.
          </div>
        </div>
      </div>
    </div>
  );
}
