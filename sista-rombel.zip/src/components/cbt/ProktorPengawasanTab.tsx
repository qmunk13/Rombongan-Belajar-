import React, { useState, useMemo } from 'react';
import { 
  Eye, Search, X, Users, CheckCircle2, Clock, 
  AlertTriangle, ShieldAlert, Wifi, PlusCircle, 
  RotateCcw, Send, Check, MessageSquare, Volume2
} from 'lucide-react';
import { db } from '../../data/db';
import { useStore } from '../../store';
import { getAllClasses, formatClassLabel, matchClass, matchStatusActive, STANDARD_CLASSES } from '../../lib/utils';

interface StudentSessionStatus {
  id: string;
  nisn: string;
  name: string;
  class: string;
  ip: string;
  device: string;
  loginTime: string;
  totalSoal: number;
  terjawab: number;
  sisaMenit: number;
  status: 'Mengerjakan' | 'Selesai' | 'Peringatan' | 'Belum Login';
  pelanggaranCount: number;
}

export default function ProktorPengawasanTab() {
  const { students } = useStore();
  const rawUjian = db.get('ujian_cbt');
  const ujianList = Array.isArray(rawUjian) ? rawUjian : [];

  const availableClasses = useMemo(() => {
    return Array.from(new Set([...getAllClasses(students), ...STANDARD_CLASSES])).sort((a, b) =>
      a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' })
    );
  }, [students]);

  const [selectedSession, setSelectedSession] = useState<string>(() => {
    if (ujianList.length > 0) {
      return `${ujianList[0].id} - ${ujianList[0].mapel} (${ujianList[0].kelas})`;
    }
    return '';
  });
  const [filterStatus, setFilterStatus] = useState('');
  const [filterKelas, setFilterKelas] = useState('');
  const [searchTerm, setSearchTerm] = useState('');

  // Broadcast Message State
  const [broadcastText, setBroadcastText] = useState('');
  const [broadcastSent, setBroadcastSent] = useState(false);

  // Quick Action Notification
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  // Generate live list of students from active students matching selected session
  const [studentList, setStudentList] = useState<StudentSessionStatus[]>(() => {
    return students.map((s, idx) => {
      return {
        id: s.id,
        nisn: s.nisn || '-',
        name: s.name,
        class: s.class || 'Kelas 4',
        ip: '192.168.1.100',
        device: 'Chromebook Siswa',
        loginTime: '-',
        totalSoal: 30,
        terjawab: 0,
        sisaMenit: 90,
        status: 'Belum Login' as const,
        pelanggaranCount: 0
      };
    });
  });

  const filteredStudents = useMemo(() => {
    return studentList.filter(s => {
      const q = searchTerm.toLowerCase();
      const matchesQ = !searchTerm || s.name.toLowerCase().includes(q) || s.nisn.includes(q) || s.ip.includes(q);
      const matchesStatus = !filterStatus || s.status === filterStatus;
      const matchesKelas = !filterKelas || matchClass(s.class, filterKelas);
      return matchesQ && matchesStatus && matchesKelas;
    });
  }, [studentList, searchTerm, filterStatus, filterKelas]);

  // Statistics
  const totalPeserta = studentList.length;
  const sedangMengerjakan = studentList.filter(s => s.status === 'Mengerjakan').length;
  const sudahSelesai = studentList.filter(s => s.status === 'Selesai').length;
  const belumLogin = studentList.filter(s => s.status === 'Belum Login').length;
  const pelanggaran = studentList.filter(s => s.status === 'Peringatan' || s.pelanggaranCount > 0).length;

  // Actions
  const handleAddExtraTime = (studentId: string, name: string) => {
    setStudentList(prev => prev.map(s => s.id === studentId ? { ...s, sisaMenit: s.sisaMenit + 10 } : s));
    showToast(`+10 Menit waktu pengerjaan ditambahkan untuk ${name}`);
  };

  const handleForceFinish = (studentId: string, name: string) => {
    setStudentList(prev => prev.map(s => s.id === studentId ? { ...s, status: 'Selesai', sisaMenit: 0 } : s));
    showToast(`Sesi ujian ${name} diselesaikan paksa oleh proktor.`);
  };

  const handleResetLogin = (studentId: string, name: string) => {
    setStudentList(prev => prev.map(s => s.id === studentId ? { ...s, status: 'Mengerjakan', pelanggaranCount: 0 } : s));
    showToast(`Login siswa ${name} berhasil di-reset.`);
  };

  const handleSendBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastText.trim()) return;
    setBroadcastSent(true);
    showToast(`Pesan broadcast dikirim ke seluruh ${totalPeserta} peserta CBT.`);
    setTimeout(() => {
      setBroadcastSent(false);
      setBroadcastText('');
    }, 2500);
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-5 py-3 rounded-2xl shadow-xl border border-slate-700 text-xs font-bold flex items-center gap-2 animate-in slide-in-from-bottom-5">
          <CheckCircle2 size={16} className="text-emerald-400" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Header & Session Selector */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-cyan-50 text-cyan-600 flex items-center justify-center font-bold">
              <Eye size={18} />
            </div>
            <h2 className="text-lg font-black text-slate-900">Ruang Pengawasan Proktor (Live Monitoring)</h2>
          </div>
          <p className="text-xs text-slate-500">
            Pantau progres pengerjaan, status koneksi perangkat, dan cegah kecurangan secara real-time.
          </p>
        </div>

        <div className="flex items-center gap-2 w-full lg:w-auto">
          <select
            value={selectedSession}
            onChange={(e) => setSelectedSession(e.target.value)}
            className="px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
          >
            {ujianList.length === 0 ? (
              <option value="">Belum Ada Sesi Ujian Aktif</option>
            ) : (
              ujianList.map((u: any) => (
                <option key={u.id} value={`${u.id} - ${u.mapel} (${u.kelas})`}>
                  {u.id} - {u.mapel} ({u.kelas})
                </option>
              ))
            )}
          </select>
        </div>
      </div>

      {/* 5 Real-Time KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
        <div className="bg-white p-4 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-slate-500">Total Peserta</span>
          <div className="text-2xl font-black text-slate-900">{totalPeserta}</div>
          <span className="text-[10px] text-slate-400">Siswa Terdaftar</span>
        </div>

        <div className="bg-white p-4 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-emerald-600 flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            Mengerjakan
          </span>
          <div className="text-2xl font-black text-emerald-600">{sedangMengerjakan}</div>
          <span className="text-[10px] text-slate-400">Online Live</span>
        </div>

        <div className="bg-white p-4 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-indigo-600">Selesai Submit</span>
          <div className="text-2xl font-black text-indigo-600">{sudahSelesai}</div>
          <span className="text-[10px] text-slate-400">Telah Mengirim</span>
        </div>

        <div className="bg-white p-4 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
          <span className="text-[11px] font-bold text-slate-500">Belum Login</span>
          <div className="text-2xl font-black text-slate-600">{belumLogin}</div>
          <span className="text-[10px] text-slate-400">Offline / Belum Masuk</span>
        </div>

        <div className="bg-white p-4 rounded-3xl border border-slate-200/80 shadow-xs space-y-1 col-span-2 sm:col-span-1">
          <span className="text-[11px] font-bold text-rose-600 flex items-center gap-1">
            <ShieldAlert size={13} /> Peringatan
          </span>
          <div className="text-2xl font-black text-rose-600">{pelanggaran}</div>
          <span className="text-[10px] text-slate-400">Pindah Tab / Blur</span>
        </div>
      </div>

      {/* Broadcast to Students Bar */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white p-5 rounded-3xl shadow-sm border border-slate-700 space-y-3">
        <div className="flex items-center gap-2">
          <Volume2 size={16} className="text-cyan-400" />
          <h3 className="text-xs font-black uppercase tracking-wider text-cyan-300">
            Kirim Pesan Siaran (Broadcast) Proktor ke Layar Peserta
          </h3>
        </div>

        <form onSubmit={handleSendBroadcast} className="flex flex-col sm:flex-row items-center gap-2.5">
          <input
            type="text"
            value={broadcastText}
            onChange={(e) => setBroadcastText(e.target.value)}
            placeholder="Ketik instruksi, misalnya: 'Waktu tersisa 15 menit lagi, silakan periksa kembali jawaban Anda'..."
            className="flex-1 w-full px-4 py-2.5 bg-slate-800/90 border border-slate-600 rounded-2xl text-xs text-white placeholder-slate-400 focus:outline-none focus:border-cyan-400"
          />
          <button
            type="submit"
            disabled={broadcastSent || !broadcastText.trim()}
            className="w-full sm:w-auto px-5 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 rounded-2xl font-black text-xs transition flex items-center justify-center gap-2 active:scale-95 disabled:opacity-50"
          >
            {broadcastSent ? <Check size={15} /> : <Send size={15} />}
            <span>{broadcastSent ? 'Terkirim!' : 'Kirim Siaran'}</span>
          </button>
        </form>
      </div>

      {/* Live Student Grid & Control Table */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
        {/* Filters */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div className="relative flex-1 sm:w-80">
            <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Cari nama peserta, NISN, IP address..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-8 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
            />
            {searchTerm && (
              <button onClick={() => setSearchTerm('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                <X size={14} />
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={filterKelas}
              onChange={(e) => setFilterKelas(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
            >
              <option value="">Semua Kelas</option>
              {availableClasses.map(c => (
                <option key={c} value={c}>{formatClassLabel(c, true)}</option>
              ))}
            </select>

            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
            >
              <option value="">Semua Status Siswa</option>
              <option value="Mengerjakan">Sedang Mengerjakan</option>
              <option value="Selesai">Selesai Submit</option>
              <option value="Peringatan">Ada Peringatan (Tab Blur)</option>
              <option value="Belum Login">Belum Login</option>
            </select>

            <span className="text-xs font-bold text-slate-500 bg-slate-100 px-3 py-2 rounded-xl">
              {filteredStudents.length} Peserta
            </span>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto rounded-2xl border border-slate-200/80">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50/90 text-slate-600 uppercase font-bold text-[11px] border-b border-slate-200">
              <tr>
                <th className="p-3.5 pl-4">NISN & Nama Peserta</th>
                <th className="p-3.5">Rombel</th>
                <th className="p-3.5">IP & Perangkat</th>
                <th className="p-3.5">Waktu Masuk</th>
                <th className="p-3.5">Progres Pengerjaan</th>
                <th className="p-3.5 text-center">Sisa Waktu</th>
                <th className="p-3.5 text-center">Status</th>
                <th className="p-3.5 pr-4 text-center">Kontrol Proktor</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-10 text-center text-slate-400">
                    <Users size={32} className="mx-auto text-slate-300 mb-2" />
                    <p className="font-bold text-slate-600 text-sm">Tidak Ada Peserta Sesuai Filter</p>
                  </td>
                </tr>
              ) : (
                filteredStudents.map((s) => {
                  const percent = Math.round((s.terjawab / s.totalSoal) * 100);
                  return (
                    <tr key={s.id} className="hover:bg-slate-50/80 transition">
                      <td className="p-3.5 pl-4">
                        <div className="font-bold text-slate-900 text-sm">{s.name}</div>
                        <div className="text-[10px] text-slate-400 font-mono">NISN: {s.nisn}</div>
                      </td>
                      <td className="p-3.5 font-bold text-slate-800">{formatClassLabel(s.class, true)}</td>
                      <td className="p-3.5 font-mono text-slate-600">
                        <div className="text-slate-800 font-semibold">{s.ip}</div>
                        <div className="text-[10px] text-slate-400">{s.device}</div>
                      </td>
                      <td className="p-3.5 font-mono text-slate-600">{s.loginTime}</td>
                      <td className="p-3.5 w-48">
                        <div className="flex items-center justify-between text-[11px] font-bold mb-1">
                          <span className="text-slate-700">{s.terjawab}/{s.totalSoal} Soal</span>
                          <span className="text-cyan-700">{percent}%</span>
                        </div>
                        <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                          <div 
                            className={`h-full rounded-full transition-all duration-300 ${
                              percent === 100 ? 'bg-emerald-500' : 'bg-cyan-500'
                            }`}
                            style={{ width: `${percent}%` }}
                          />
                        </div>
                      </td>
                      <td className="p-3.5 text-center font-mono font-bold text-slate-800">
                        {s.status === 'Selesai' ? '-' : `${s.sisaMenit}m`}
                      </td>
                      <td className="p-3.5 text-center">
                        <span className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                          s.status === 'Mengerjakan' ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' :
                          s.status === 'Selesai' ? 'bg-indigo-100 text-indigo-800' :
                          s.status === 'Peringatan' ? 'bg-rose-100 text-rose-800 border border-rose-200 animate-pulse' :
                          'bg-slate-100 text-slate-600'
                        }`}>
                          {s.status === 'Peringatan' ? `⚠️ Pindah Tab (${s.pelanggaranCount}x)` : s.status}
                        </span>
                      </td>
                      <td className="p-3.5 pr-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => handleAddExtraTime(s.id, s.name)}
                            className="p-1.5 bg-cyan-50 hover:bg-cyan-100 text-cyan-700 rounded-lg font-bold text-xs transition"
                            title="Tambah Waktu +10 Menit"
                          >
                            <PlusCircle size={13} />
                          </button>
                          <button
                            onClick={() => handleResetLogin(s.id, s.name)}
                            className="p-1.5 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg font-bold text-xs transition"
                            title="Reset Login Siswa"
                          >
                            <RotateCcw size={13} />
                          </button>
                          <button
                            onClick={() => handleForceFinish(s.id, s.name)}
                            className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg font-bold text-xs transition"
                            title="Selesaikan Paksa (Force Submit)"
                          >
                            <CheckCircle2 size={13} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
