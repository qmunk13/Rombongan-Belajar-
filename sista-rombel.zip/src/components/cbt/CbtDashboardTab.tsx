import React, { useState } from 'react';
import { 
  Laptop, Calendar, FileQuestion, Key, Eye, 
  CheckCircle2, Award, ArrowRight, ShieldCheck, 
  Clock, Users, BarChart3, Activity, AlertCircle, Play
} from 'lucide-react';
import { useStore } from '../../store';
import { formatClassLabel } from '../../lib/utils';

interface CbtDashboardTabProps {
  onNavigateTab: (tabId: string) => void;
  ujianList: any[];
  bankSoalList: any[];
  tokenActive: string;
}

export default function CbtDashboardTab({ 
  onNavigateTab, 
  ujianList, 
  bankSoalList, 
  tokenActive 
}: CbtDashboardTabProps) {
  const { students, teachers } = useStore();

  const totalSesi = ujianList.length;
  const sesiBerlangsung = ujianList.filter(u => u.status === 'Berlangsung').length;
  const sesiSelesai = ujianList.filter(u => u.status === 'Selesai').length;
  const totalSoal = bankSoalList.reduce((acc, curr) => acc + (Number(curr.jumlahSoal) || 0), 0);

  const avgScore = ujianList.length > 0
    ? (ujianList.reduce((acc, curr) => acc + (Number(curr.avg) || 0), 0) / ujianList.length).toFixed(1)
    : '0';

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Top 4 KPI Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div 
          onClick={() => onNavigateTab('jadwal-ujian')}
          className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-2 cursor-pointer hover:border-cyan-400 hover:shadow-md transition group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">Sesi Ujian CBT</span>
            <div className="w-8 h-8 rounded-xl bg-cyan-50 text-cyan-600 flex items-center justify-center group-hover:scale-110 transition">
              <Calendar size={16} />
            </div>
          </div>
          <div className="text-3xl font-black text-cyan-600">
            {totalSesi} <span className="text-sm font-semibold text-slate-400">Sesi</span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-100">
            <span>{sesiBerlangsung} Aktif • {sesiSelesai} Selesai</span>
            <span className="text-cyan-600 font-bold flex items-center gap-0.5">Kelola <ArrowRight size={12} /></span>
          </div>
        </div>

        <div 
          onClick={() => onNavigateTab('bank-soal')}
          className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-2 cursor-pointer hover:border-indigo-400 hover:shadow-md transition group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">Bank Soal Tersedia</span>
            <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center group-hover:scale-110 transition">
              <FileQuestion size={16} />
            </div>
          </div>
          <div className="text-3xl font-black text-indigo-600">
            {bankSoalList.length} <span className="text-sm font-semibold text-slate-400">Paket</span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-100">
            <span>{totalSoal} Total Butir Soal</span>
            <span className="text-indigo-600 font-bold flex items-center gap-0.5">Bank Soal <ArrowRight size={12} /></span>
          </div>
        </div>

        <div 
          onClick={() => onNavigateTab('token-ujian')}
          className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-2 cursor-pointer hover:border-amber-400 hover:shadow-md transition group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">Token Aktif</span>
            <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center group-hover:scale-110 transition">
              <Key size={16} />
            </div>
          </div>
          <div className="text-2xl font-mono font-black text-amber-600 tracking-wider">
            {tokenActive && tokenActive !== '-' && tokenActive !== 'BELUM AKTIF' ? tokenActive : '-'}
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-100">
            {tokenActive && tokenActive !== '-' && tokenActive !== 'BELUM AKTIF' ? (
              <span className="flex items-center gap-1 text-emerald-600 font-bold">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" /> Valid & Aktif
              </span>
            ) : (
              <span className="text-slate-400 font-medium">Belum Ada Token Aktif</span>
            )}
            <span className="text-amber-600 font-bold flex items-center gap-0.5">Token <ArrowRight size={12} /></span>
          </div>
        </div>

        <div 
          onClick={() => onNavigateTab('hasil-ujian')}
          className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-2 cursor-pointer hover:border-emerald-400 hover:shadow-md transition group"
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-500">Rata-rata Skor Nilai</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center group-hover:scale-110 transition">
              <Award size={16} />
            </div>
          </div>
          <div className="text-3xl font-black text-emerald-600">
            {avgScore} <span className="text-sm font-semibold text-slate-400">Poin</span>
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-100">
            <span>{students.length} Siswa Terdata</span>
            <span className="text-emerald-600 font-bold flex items-center gap-0.5">Hasil <ArrowRight size={12} /></span>
          </div>
        </div>
      </div>

      {/* Live Server CBT & Proktor Quick Bar */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white p-6 rounded-3xl shadow-md border border-slate-700/60 relative overflow-hidden">
        <div className="relative z-10 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2 max-w-xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              Engine CBT Online Aktif & Siap Digunakan
            </div>
            <h2 className="text-xl font-black text-white">
              Sistem Computer-Based Testing (CBT) Terintegrasi
            </h2>
            <p className="text-xs text-slate-300 leading-relaxed">
              Mendukung pelaksanaan Asesmen Sumatif Harian, STS, SAS, hingga Tryout ANBK secara fleksibel, acak soal otomatis, token dinamis, dan pengawasan proktor live.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3 w-full lg:w-auto">
            <button
              onClick={() => onNavigateTab('jadwal-ujian')}
              className="flex-1 sm:flex-initial px-4 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-black text-xs rounded-2xl shadow-lg transition flex items-center justify-center gap-2 active:scale-95"
            >
              <Calendar size={15} />
              <span>Buat Sesi Ujian</span>
            </button>
            <button
              onClick={() => onNavigateTab('proktor')}
              className="flex-1 sm:flex-initial px-4 py-2.5 bg-white/10 hover:bg-white/20 text-white font-bold text-xs rounded-2xl border border-white/20 transition flex items-center justify-center gap-2 active:scale-95"
            >
              <Eye size={15} />
              <span>Live Monitor Proktor</span>
            </button>
          </div>
        </div>

        {/* Server metrics bottom strip */}
        <div className="mt-6 pt-4 border-t border-slate-700/80 grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs">
          <div>
            <span className="text-slate-400 text-[11px] block">Status Engine CBT</span>
            <span className="font-bold text-emerald-400 flex items-center gap-1.5 mt-0.5">
              <Activity size={13} /> Online (Latency 14ms)
            </span>
          </div>
          <div>
            <span className="text-slate-400 text-[11px] block">Mode Keamanan</span>
            <span className="font-bold text-cyan-300 flex items-center gap-1.5 mt-0.5">
              <ShieldCheck size={13} /> Token Lock & Anti-Cheat
            </span>
          </div>
          <div>
            <span className="text-slate-400 text-[11px] block">Total Peserta Terdaftar</span>
            <span className="font-bold text-white flex items-center gap-1.5 mt-0.5">
              <Users size={13} /> {students.length} Siswa Aktif
            </span>
          </div>
          <div>
            <span className="text-slate-400 text-[11px] block">Guru / Proktor</span>
            <span className="font-bold text-amber-300 flex items-center gap-1.5 mt-0.5">
              <Laptop size={13} /> {teachers.length} Akun GTK
            </span>
          </div>
        </div>
      </div>

      {/* Sesi Ujian Terkini & Quick Launcher */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Sesi Ujian Terkini */}
        <div className="lg:col-span-2 bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-black text-slate-900">Sesi Ujian Terjadwal & Aktif</h3>
              <p className="text-xs text-slate-500">Daftar pelaksanaan asesmen CBT terbaru</p>
            </div>
            <button
              onClick={() => onNavigateTab('jadwal-ujian')}
              className="text-xs font-bold text-cyan-600 hover:text-cyan-700 flex items-center gap-1"
            >
              Lihat Semua ({ujianList.length}) <ArrowRight size={13} />
            </button>
          </div>

          <div className="space-y-3">
            {ujianList.length === 0 ? (
              <div className="p-8 text-center bg-slate-50 rounded-2xl border border-slate-100 text-slate-400">
                <Calendar size={28} className="mx-auto text-slate-300 mb-2" />
                <p className="text-xs font-bold text-slate-600">Belum ada sesi ujian terjadwal</p>
                <p className="text-[11px] text-slate-400 mt-0.5">Klik tab "Jadwal & Sesi Ujian" untuk membuat sesi baru.</p>
              </div>
            ) : (
              ujianList.slice(0, 4).map((u: any) => (
                <div 
                  key={u.id}
                  className="p-4 rounded-2xl bg-slate-50/80 hover:bg-slate-50 border border-slate-200/70 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition"
                >
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="px-2 py-0.5 bg-cyan-100 text-cyan-800 font-bold rounded-md text-[10px]">
                        {u.jenis}
                      </span>
                      <span className="text-xs font-mono font-bold text-slate-400">{u.id}</span>
                    </div>
                    <h4 className="text-sm font-extrabold text-slate-900">{u.mapel}</h4>
                    <p className="text-xs text-slate-500">
                      Kelas: <strong className="text-slate-700">{formatClassLabel(u.kelas, true)}</strong> • {u.tgl} ({u.durasi})
                    </p>
                  </div>

                  <div className="flex items-center gap-3 self-end sm:self-center">
                    <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                      u.status === 'Berlangsung' 
                        ? 'bg-amber-100 text-amber-800 border border-amber-200' 
                        : u.status === 'Selesai'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-slate-200/70 text-slate-700'
                    }`}>
                      {u.status}
                    </span>
                    <button
                      onClick={() => onNavigateTab('proktor')}
                      className="p-2 bg-white hover:bg-cyan-50 text-cyan-700 rounded-xl border border-slate-200 font-bold text-xs transition flex items-center gap-1 shadow-2xs"
                      title="Buka Pengawasan Proktor"
                    >
                      <Eye size={14} />
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Shortcut Navigasi Cepat & Modul CBT */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <div>
              <h3 className="text-sm font-black text-slate-900">Pusat Navigasi CBT</h3>
              <p className="text-xs text-slate-500">Pintasan cepat modul asesmen & evaluasi</p>
            </div>

            <div className="space-y-2">
              <button
                onClick={() => onNavigateTab('bank-soal')}
                className="w-full p-3 rounded-2xl bg-indigo-50/60 hover:bg-indigo-50 border border-indigo-100 text-left flex items-center justify-between transition group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-indigo-600 text-white flex items-center justify-center shadow-xs">
                    <FileQuestion size={16} />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">Kelola Bank Soal</div>
                    <div className="text-[11px] text-slate-500">{bankSoalList.length} Paket Soal Aktif</div>
                  </div>
                </div>
                <ArrowRight size={14} className="text-indigo-600 group-hover:translate-x-0.5 transition" />
              </button>

              <button
                onClick={() => onNavigateTab('token-ujian')}
                className="w-full p-3 rounded-2xl bg-amber-50/60 hover:bg-amber-50 border border-amber-100 text-left flex items-center justify-between transition group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-amber-600 text-white flex items-center justify-center shadow-xs">
                    <Key size={16} />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">Distribusi Token Sesi</div>
                    <div className="text-[11px] text-slate-500">Token Aktif: {tokenActive}</div>
                  </div>
                </div>
                <ArrowRight size={14} className="text-amber-600 group-hover:translate-x-0.5 transition" />
              </button>

              <button
                onClick={() => onNavigateTab('proktor')}
                className="w-full p-3 rounded-2xl bg-cyan-50/60 hover:bg-cyan-50 border border-cyan-100 text-left flex items-center justify-between transition group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-cyan-600 text-white flex items-center justify-center shadow-xs">
                    <Eye size={16} />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">Pengawasan Proktor Live</div>
                    <div className="text-[11px] text-slate-500">Pantau aktivitas & status siswa</div>
                  </div>
                </div>
                <ArrowRight size={14} className="text-cyan-600 group-hover:translate-x-0.5 transition" />
              </button>

              <button
                onClick={() => onNavigateTab('rapor-pendidikan')}
                className="w-full p-3 rounded-2xl bg-purple-50/60 hover:bg-purple-50 border border-purple-100 text-left flex items-center justify-between transition group"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-purple-600 text-white flex items-center justify-center shadow-xs">
                    <Award size={16} />
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">Rapor Pendidikan (ANBK)</div>
                    <div className="text-[11px] text-slate-500">Analisis Mutu Literasi & Numerasi</div>
                  </div>
                </div>
                <ArrowRight size={14} className="text-purple-600 group-hover:translate-x-0.5 transition" />
              </button>
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 text-[11px] text-slate-500 flex items-center gap-2">
            <AlertCircle size={15} className="text-cyan-600 shrink-0" />
            <span>Semua hasil ujian dan pengawasan terenkripsi otomatis di server lokal sekolah.</span>
          </div>
        </div>
      </div>
    </div>
  );
}
