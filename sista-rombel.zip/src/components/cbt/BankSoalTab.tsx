import React, { useState, useMemo } from 'react';
import { 
  FileQuestion, Plus, Search, X, Eye, Edit, Trash2, 
  Save, AlertTriangle, CheckCircle2, HelpCircle, 
  Layers, Sparkles, BookOpen, ListOrdered, Check
} from 'lucide-react';
import { db } from '../../data/db';
import { useStore } from '../../store';
import { getAllClasses, matchClass, formatClassLabel, STANDARD_CLASSES } from '../../lib/utils';

interface BankSoalItem {
  id: string;
  mapel: string;
  kelas: string;
  kurikulum: string;
  jumlahSoal: number;
  tipeSoal: string; // "30 PG, 5 Esai"
  guru: string;
  kesulitan: string; // "Mudah (30%), Sedang (50%), Sukar (20%)"
  status: 'Siap Digunakan' | 'Draf' | 'Sedang Ditelaah';
  updatedAt: string;
  soalList?: Array<{
    id: number;
    pertanyaan: string;
    tipe: 'Pilihan Ganda' | 'Esai' | 'PG Kompleks';
    opsi: { a: string; b: string; c: string; d: string };
    kunci: string;
    bobot: number;
  }>;
}

export default function BankSoalTab() {
  const { teachers, students } = useStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterKelas, setFilterKelas] = useState('');
  const [filterStatus, setFilterStatus] = useState('');

  // Persisted Bank Soal List from DB (no dummy data)
  const [bankSoalList, setBankSoalList] = useState<BankSoalItem[]>(() => {
    const saved = db.get('cbt_bank_soal');
    return Array.isArray(saved) ? saved : [];
  });

  const saveToDb = (list: BankSoalItem[]) => {
    setBankSoalList(list);
    db.set('cbt_bank_soal', list);
  };

  // Modals
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [editModal, setEditModal] = useState<BankSoalItem | null>(null);
  const [previewModal, setPreviewModal] = useState<BankSoalItem | null>(null);
  const [deleteModal, setDeleteModal] = useState<{ id: string; name: string } | null>(null);

  // New Question in Preview Modal
  const [newQuestionText, setNewQuestionText] = useState('');
  const [newQuestionKey, setNewQuestionKey] = useState<'a' | 'b' | 'c' | 'd'>('a');
  const [newOpsiA, setNewOpsiA] = useState('');
  const [newOpsiB, setNewOpsiB] = useState('');
  const [newOpsiC, setNewOpsiC] = useState('');
  const [newOpsiD, setNewOpsiD] = useState('');

  const availableClasses = useMemo(() => {
    return Array.from(new Set([...getAllClasses(students), ...STANDARD_CLASSES])).sort((a, b) =>
      a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' })
    );
  }, [students]);

  // Form State for creating new bank
  const [formState, setFormState] = useState<Partial<BankSoalItem>>({
    id: `BNK-${Math.floor(1000 + Math.random() * 9000)}`,
    mapel: '',
    kelas: '1A',
    kurikulum: 'Kurikulum Merdeka',
    jumlahSoal: 30,
    tipeSoal: '25 PG, 5 Isian',
    guru: '',
    kesulitan: 'Sedang',
    status: 'Draf'
  });

  const filteredList = useMemo(() => {
    return bankSoalList.filter((b) => {
      const q = searchTerm.toLowerCase();
      const mapel = String(b.mapel || '').toLowerCase();
      const kelas = String(b.kelas || '').toLowerCase();
      const id = String(b.id || '').toLowerCase();

      const matchesQ = !searchTerm || mapel.includes(q) || kelas.includes(q) || id.includes(q);
      const matchesKelas = !filterKelas || matchClass(b.kelas, filterKelas);
      const matchesStatus = !filterStatus || b.status === filterStatus;

      return matchesQ && matchesKelas && matchesStatus;
    });
  }, [bankSoalList, searchTerm, filterKelas, filterStatus]);

  const handleCreateBank = (e: React.FormEvent) => {
    e.preventDefault();
    const newItem: BankSoalItem = {
      id: formState.id || `BNK-${Math.floor(1000 + Math.random() * 9000)}`,
      mapel: formState.mapel || 'Mata Pelajaran',
      kelas: formState.kelas || 'Kelas ',
      kurikulum: formState.kurikulum || 'Kurikulum Merdeka',
      jumlahSoal: Number(formState.jumlahSoal) || 30,
      tipeSoal: formState.tipeSoal || '25 PG, 5 Esai',
      guru: formState.guru || teachers[0]?.name || '',
      kesulitan: formState.kesulitan || 'Sedang',
      status: (formState.status as any) || 'Siap Digunakan',
      updatedAt: new Date().toISOString().slice(0, 10),
      soalList: []
    };

    const updated = [newItem, ...bankSoalList];
    saveToDb(updated);
    setCreateModalOpen(false);
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editModal) return;
    const updated = bankSoalList.map(b => b.id === editModal.id ? { 
      ...b, 
      ...editModal,
      jumlahSoal: Number(editModal.jumlahSoal) || b.jumlahSoal,
      updatedAt: new Date().toISOString().slice(0, 10)
    } : b);
    saveToDb(updated);
    setEditModal(null);
  };

  const handleConfirmDelete = () => {
    if (!deleteModal) return;
    const updated = bankSoalList.filter(b => b.id !== deleteModal.id);
    saveToDb(updated);
    setDeleteModal(null);
  };

  // Add Question to open bank modal
  const handleAddQuestionToBank = (e: React.FormEvent) => {
    e.preventDefault();
    if (!previewModal || !newQuestionText.trim()) return;

    const currentQuestions = previewModal.soalList || [];
    const newQ = {
      id: currentQuestions.length + 1,
      pertanyaan: newQuestionText,
      tipe: 'Pilihan Ganda' as const,
      opsi: {
        a: newOpsiA || 'Pilihan A',
        b: newOpsiB || 'Pilihan B',
        c: newOpsiC || 'Pilihan C',
        d: newOpsiD || 'Pilihan D'
      },
      kunci: newQuestionKey,
      bobot: 2
    };

    const updatedBank = {
      ...previewModal,
      jumlahSoal: currentQuestions.length + 1,
      soalList: [...currentQuestions, newQ]
    };

    const updatedList = bankSoalList.map(b => b.id === previewModal.id ? updatedBank : b);
    saveToDb(updatedList);
    setPreviewModal(updatedBank);

    // Reset inputs
    setNewQuestionText('');
    setNewOpsiA('');
    setNewOpsiB('');
    setNewOpsiC('');
    setNewOpsiD('');
    setNewQuestionKey('a');
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Header & Quick Action */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
              <FileQuestion size={18} />
            </div>
            <h2 className="text-lg font-black text-slate-900">Manajemen Bank Soal & Kisi-Kisi</h2>
          </div>
          <p className="text-xs text-slate-500">
            Kumpulan paket soal pilihan ganda, isian, dan uraian terstandar Kurikulum Merdeka untuk asesmen harian & semester.
          </p>
        </div>

        <button
          onClick={() => setCreateModalOpen(true)}
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl text-xs font-bold shadow-sm transition flex items-center gap-2 active:scale-95 whitespace-nowrap"
        >
          <Plus size={16} />
          <span>Buat Paket Bank Soal</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
          <div className="relative flex-1">
            <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Cari mata pelajaran, kode bank soal, guru pembuat..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-8 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            />
            {searchTerm && (
              <button onClick={() => setSearchTerm('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                <X size={14} />
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={filterKelas}
              onChange={(e) => setFilterKelas(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            >
              <option value="">Semua Kelas</option>
              {availableClasses.map(cls => (
                <option key={cls} value={cls}>{formatClassLabel(cls, true)}</option>
              ))}
            </select>

            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
            >
              <option value="">Semua Status</option>
              <option value="Siap Digunakan">Siap Digunakan</option>
              <option value="Sedang Ditelaah">Sedang Ditelaah</option>
              <option value="Draf">Draf</option>
            </select>

            <span className="text-[11px] font-bold text-slate-500 bg-slate-100 px-3 py-2 rounded-xl">
              {filteredList.length} Paket Soal
            </span>
          </div>
        </div>

        {/* Bank Soal Table */}
        <div className="overflow-x-auto rounded-2xl border border-slate-200/80">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50/90 text-slate-600 uppercase font-bold text-[11px] border-b border-slate-200">
              <tr>
                <th className="p-3.5 pl-4">Kode Bank</th>
                <th className="p-3.5">Mata Pelajaran</th>
                <th className="p-3.5">Kelas / Fase</th>
                <th className="p-3.5">Kurikulum</th>
                <th className="p-3.5 text-center">Komposisi Butir Soal</th>
                <th className="p-3.5">Guru Pembuat</th>
                <th className="p-3.5 text-center">Status</th>
                <th className="p-3.5 pr-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {filteredList.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-10 text-center text-slate-400">
                    <FileQuestion size={32} className="mx-auto text-slate-300 mb-2" />
                    <p className="font-bold text-slate-600 text-sm">Tidak Ada Paket Soal</p>
                    <p className="text-xs text-slate-400 mt-0.5">Buat paket bank soal baru dengan menekan tombol di atas.</p>
                  </td>
                </tr>
              ) : (
                filteredList.map((b) => (
                  <tr key={b.id} className="hover:bg-slate-50/80 transition">
                    <td className="p-3.5 pl-4 font-mono font-bold text-indigo-700">{b.id}</td>
                    <td className="p-3.5">
                      <div className="font-bold text-slate-900 text-sm">{b.mapel}</div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        Diperbarui: {b.updatedAt}
                      </div>
                    </td>
                    <td className="p-3.5 font-bold text-slate-800">
                      <span className="px-2 py-0.5 bg-slate-100 rounded-md">{formatClassLabel(b.kelas, true)}</span>
                    </td>
                    <td className="p-3.5 text-slate-600 font-semibold">{b.kurikulum}</td>
                    <td className="p-3.5 text-center">
                      <span className="font-mono font-bold text-indigo-900 bg-indigo-50 px-2 py-0.5 rounded-md text-xs">
                        {b.jumlahSoal} Soal
                      </span>
                      <div className="text-[10px] text-slate-500 mt-0.5">{b.tipeSoal}</div>
                    </td>
                    <td className="p-3.5 text-slate-800">{b.guru}</td>
                    <td className="p-3.5 text-center">
                      <span className={`px-2.5 py-1 rounded-full font-bold text-[10px] ${
                        b.status === 'Siap Digunakan'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          : b.status === 'Sedang Ditelaah'
                          ? 'bg-amber-100 text-amber-800 border border-amber-200'
                          : 'bg-slate-100 text-slate-700'
                      }`}>
                        {b.status}
                      </span>
                    </td>
                    <td className="p-3.5 pr-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => setPreviewModal(b)}
                          className="px-2.5 py-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl font-bold text-xs transition flex items-center gap-1 shadow-2xs"
                          title="Lihat & Kelola Butir Soal"
                        >
                          <BookOpen size={13} />
                          <span>Butir Soal</span>
                        </button>
                        <button
                          onClick={() => setEditModal({ ...b })}
                          className="p-1.5 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg font-bold text-xs transition"
                          title="Edit Metadata"
                        >
                          <Edit size={13} />
                        </button>
                        <button
                          onClick={() => setDeleteModal({ id: b.id, name: `${b.mapel} (${b.kelas})` })}
                          className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg font-bold text-xs transition"
                          title="Hapus Bank Soal"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* MODAL LIHAT & KELOLA BUTIR SOAL */}
      {previewModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 shadow-2xl border border-slate-200 space-y-5 animate-in zoom-in-95 max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 shrink-0">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                  <BookOpen size={18} />
                </div>
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    Butir Soal: {previewModal.mapel} ({previewModal.kelas})
                  </h3>
                  <p className="text-[11px] text-slate-500 font-mono">Kode Bank: {previewModal.id}</p>
                </div>
              </div>
              <button 
                onClick={() => setPreviewModal(null)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition"
              >
                <X size={16} />
              </button>
            </div>

            {/* List of Questions */}
            <div className="flex-1 overflow-y-auto space-y-4 pr-1 text-xs">
              <div className="flex items-center justify-between bg-slate-50 p-3 rounded-2xl border border-slate-100">
                <span className="font-bold text-slate-700">Daftar Pertanyaan & Kunci Jawaban</span>
                <span className="px-2 py-0.5 bg-indigo-100 text-indigo-800 font-bold rounded-md">
                  {(previewModal.soalList || []).length} Soal Terdaftar
                </span>
              </div>

              {(previewModal.soalList || []).length === 0 ? (
                <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200 text-slate-400">
                  <HelpCircle size={28} className="mx-auto text-slate-300 mb-1.5" />
                  <p className="font-bold text-slate-600">Belum Ada Butir Soal Terinput</p>
                  <p className="text-[11px] text-slate-400">Gunakan formulir di bawah untuk menambahkan pertanyaan baru.</p>
                </div>
              ) : (
                previewModal.soalList?.map((q, idx) => (
                  <div key={q.id || idx} className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2">
                        <span className="w-6 h-6 rounded-lg bg-indigo-600 text-white font-black text-xs flex items-center justify-center">
                          {idx + 1}
                        </span>
                        <span className="px-2 py-0.5 bg-slate-100 text-slate-700 font-bold rounded text-[10px]">
                          {q.tipe}
                        </span>
                      </div>
                      <span className="text-[11px] font-mono text-slate-400">Bobot: {q.bobot} Poin</span>
                    </div>

                    <p className="font-bold text-slate-900 text-sm leading-relaxed">
                      {q.pertanyaan}
                    </p>

                    {q.opsi && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
                        {Object.entries(q.opsi).map(([key, optText]) => {
                          const isCorrect = q.kunci.toLowerCase() === key.toLowerCase();
                          return (
                            <div 
                              key={key} 
                              className={`p-2.5 rounded-xl border flex items-center gap-2 text-xs ${
                                isCorrect 
                                  ? 'bg-emerald-50 border-emerald-300 text-emerald-900 font-bold' 
                                  : 'bg-slate-50/70 border-slate-200 text-slate-700'
                              }`}
                            >
                              <span className={`w-5 h-5 rounded-md flex items-center justify-center text-[10px] font-black uppercase ${
                                isCorrect ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-600'
                              }`}>
                                {key}
                              </span>
                              <span className="flex-1">{optText}</span>
                              {isCorrect && <Check size={14} className="text-emerald-600 font-bold" />}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                ))
              )}

              {/* Form Tambah Soal Cepat */}
              <div className="p-4 rounded-2xl bg-indigo-50/40 border border-indigo-100 space-y-3 mt-4">
                <div className="flex items-center gap-2">
                  <Sparkles size={15} className="text-indigo-600" />
                  <h4 className="font-black text-slate-900 text-xs">Tambah Butir Soal Baru</h4>
                </div>

                <form onSubmit={handleAddQuestionToBank} className="space-y-3">
                  <div>
                    <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block mb-1">
                      Teks Pertanyaan / Stimulus
                    </label>
                    <textarea
                      required
                      rows={2}
                      value={newQuestionText}
                      onChange={(e) => setNewQuestionText(e.target.value)}
                      placeholder="Tuliskan teks pertanyaan soal..."
                      className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Opsi A</span>
                      <input
                        type="text"
                        placeholder="Teks pilihan A"
                        value={newOpsiA}
                        onChange={(e) => setNewOpsiA(e.target.value)}
                        className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Opsi B</span>
                      <input
                        type="text"
                        placeholder="Teks pilihan B"
                        value={newOpsiB}
                        onChange={(e) => setNewOpsiB(e.target.value)}
                        className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Opsi C</span>
                      <input
                        type="text"
                        placeholder="Teks pilihan C"
                        value={newOpsiC}
                        onChange={(e) => setNewOpsiC(e.target.value)}
                        className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800"
                      />
                    </div>
                    <div>
                      <span className="text-[10px] font-bold text-slate-500 uppercase block mb-1">Opsi D</span>
                      <input
                        type="text"
                        placeholder="Teks pilihan D"
                        value={newOpsiD}
                        onChange={(e) => setNewOpsiD(e.target.value)}
                        className="w-full px-3 py-1.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-800"
                      />
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-1">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-bold text-slate-700">Kunci Jawaban Benar:</span>
                      <select
                        value={newQuestionKey}
                        onChange={(e) => setNewQuestionKey(e.target.value as any)}
                        className="px-3 py-1 bg-white border border-slate-300 rounded-lg text-xs font-black text-indigo-700"
                      >
                        <option value="a">A</option>
                        <option value="b">B</option>
                        <option value="c">C</option>
                        <option value="d">D</option>
                      </select>
                    </div>

                    <button
                      type="submit"
                      className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center gap-1.5"
                    >
                      <Plus size={14} />
                      <span>Simpan Butir Soal</span>
                    </button>
                  </div>
                </form>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-100 flex justify-end shrink-0">
              <button
                onClick={() => setPreviewModal(null)}
                className="px-5 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800 transition"
              >
                Tutup Tampilan Soal
              </button>
            </div>
          </div>
        </div>
      )}

      {/* CREATE MODAL */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-5 animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                  <FileQuestion size={18} />
                </div>
                <h3 className="text-base font-black text-slate-900">Buat Paket Bank Soal Baru</h3>
              </div>
              <button 
                onClick={() => setCreateModalOpen(false)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleCreateBank} className="space-y-4 max-h-[65vh] overflow-y-auto pr-1">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Mata Pelajaran</label>
                <input
                  type="text"
                  required
                  value={formState.mapel}
                  onChange={(e) => setFormState({ ...formState, mapel: e.target.value })}
                  placeholder="Misal: Pendidikan Pancasila, Bahasa Indonesia, IPAS"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Kelas / Tingkat</label>
                  <select
                    value={formState.kelas}
                    onChange={(e) => setFormState({ ...formState, kelas: e.target.value })}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  >
                    {availableClasses.map(cls => (
                      <option key={cls} value={cls}>{formatClassLabel(cls, true)}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Kurikulum</label>
                  <select
                    value={formState.kurikulum}
                    onChange={(e) => setFormState({ ...formState, kurikulum: e.target.value })}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  >
                    <option value="Kurikulum Merdeka">Kurikulum Merdeka</option>
                    <option value="Kurikulum 2013">Kurikulum 2013</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Target Jumlah Soal</label>
                  <input
                    type="number"
                    value={formState.jumlahSoal}
                    onChange={(e) => setFormState({ ...formState, jumlahSoal: Number(e.target.value) })}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Komposisi Bentuk Soal</label>
                  <input
                    type="text"
                    value={formState.tipeSoal}
                    onChange={(e) => setFormState({ ...formState, tipeSoal: e.target.value })}
                    placeholder="25 PG, 5 Esai"
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Guru Penyusun / Penelaah</label>
                <select
                  value={formState.guru}
                  onChange={(e) => setFormState({ ...formState, guru: e.target.value })}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                >
                  {teachers.map(t => (
                    <option key={t.id} value={t.name}>{t.name} ({t.nip || 'Guru'})</option>
                  ))}
                  <option value="Tim MGMP / KKG">Tim MGMP / KKG Sekolah</option>
                </select>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setCreateModalOpen(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center gap-1.5"
                >
                  <Save size={14} />
                  <span>Simpan Paket Bank Soal</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* EDIT MODAL */}
      {editModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-5 animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
                  <Edit size={18} />
                </div>
                <h3 className="text-base font-black text-slate-900">Edit Bank Soal: {editModal.mapel}</h3>
              </div>
              <button 
                onClick={() => setEditModal(null)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Mata Pelajaran</label>
                <input
                  type="text"
                  value={editModal.mapel}
                  onChange={(e) => setEditModal({ ...editModal, mapel: e.target.value })}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Kelas</label>
                  <select
                    value={editModal.kelas || ''}
                    onChange={(e) => setEditModal({ ...editModal, kelas: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  >
                    {availableClasses.map(cls => (
                      <option key={cls} value={cls}>{formatClassLabel(cls, true)}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Status</label>
                  <select
                    value={editModal.status}
                    onChange={(e) => setEditModal({ ...editModal, status: e.target.value as any })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  >
                    <option value="Siap Digunakan">Siap Digunakan</option>
                    <option value="Sedang Ditelaah">Sedang Ditelaah</option>
                    <option value="Draf">Draf</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Jumlah Soal</label>
                  <input
                    type="number"
                    value={editModal.jumlahSoal}
                    onChange={(e) => setEditModal({ ...editModal, jumlahSoal: Number(e.target.value) })}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Guru Penyusun</label>
                  <input
                    type="text"
                    value={editModal.guru}
                    onChange={(e) => setEditModal({ ...editModal, guru: e.target.value })}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditModal(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center gap-1.5"
                >
                  <Save size={14} />
                  <span>Simpan Perubahan</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {deleteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4 animate-in zoom-in-95">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto border border-rose-100">
              <AlertTriangle size={24} />
            </div>
            
            <div className="text-center space-y-1">
              <h3 className="text-base font-black text-slate-900">Hapus Paket Bank Soal</h3>
              <p className="text-xs text-slate-500">
                Apakah Anda yakin ingin menghapus paket bank soal <strong className="text-slate-800">"{deleteModal.name}"</strong>?
              </p>
            </div>

            <div className="pt-2 flex items-center justify-center gap-2.5">
              <button
                type="button"
                onClick={() => setDeleteModal(null)}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex-1"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center justify-center gap-1.5 flex-1"
              >
                <Trash2 size={14} />
                <span>Ya, Hapus</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
