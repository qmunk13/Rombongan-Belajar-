import React, { useState, useEffect } from 'react';
import { 
  Key, RefreshCw, Copy, Check, ShieldCheck, 
  Clock, AlertCircle, Users, Unlock, Eye, Sparkles
} from 'lucide-react';
import { db } from '../../data/db';
import { useStore } from '../../store';
import { formatClassLabel } from '../../lib/utils';

interface TokenItem {
  id: string;
  sesiId: string;
  mapel: string;
  kelas: string;
  token: string;
  waktuDibuat: string;
  kedaluwarsa: string;
  status: 'Aktif' | 'Kedaluwarsa' | 'Dinonaktifkan';
  proktor: string;
}

export default function TokenUjianTab() {
  const { students, teachers } = useStore();
  const [copied, setCopied] = useState(false);
  // Persisted Token History in DB (no dummy data)
  const [tokenList, setTokenList] = useState<TokenItem[]>(() => {
    const saved = db.get('cbt_token_history');
    return Array.isArray(saved) ? saved : [];
  });

  const [currentToken, setCurrentToken] = useState(() => {
    const saved = db.get('cbt_token_history');
    const active = Array.isArray(saved) ? saved.find((t: any) => t.status === 'Aktif') : null;
    return active?.token || 'BELUM AKTIF';
  });
  const [tokenDuration, setTokenDuration] = useState('30'); // Menit
  const [secondsRemaining, setSecondsRemaining] = useState(1800); // 30 mins

  // Reset Login Siswa Search / List
  const [studentSearch, setStudentSearch] = useState('');
  const [resetSuccessId, setResetSuccessId] = useState<string | null>(null);

  const saveTokensToDb = (list: TokenItem[]) => {
    setTokenList(list);
    db.set('cbt_token_history', list);
  };

  // Timer countdown
  useEffect(() => {
    const interval = setInterval(() => {
      setSecondsRemaining(prev => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const formatTimer = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const remainderSecs = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${remainderSecs.toString().padStart(2, '0')}`;
  };

  const handleGenerateNewToken = () => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setCurrentToken(result);
    setSecondsRemaining(Number(tokenDuration) * 60);

    const now = new Date();
    const timeStr = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')} WIB`;
    const expDate = new Date(now.getTime() + Number(tokenDuration) * 60000);
    const expStr = `${expDate.getHours().toString().padStart(2, '0')}:${expDate.getMinutes().toString().padStart(2, '0')} WIB`;

    const newTokenItem: TokenItem = {
      id: `tok-${Date.now()}`,
      sesiId: 'SES-LIVE',
      mapel: 'Sesi Ujian Aktif',
      kelas: 'Semua Kelas',
      token: result,
      waktuDibuat: timeStr,
      kedaluwarsa: expStr,
      status: 'Aktif',
      proktor: 'Admin Proktor CBT'
    };

    saveTokensToDb([newTokenItem, ...tokenList]);
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(currentToken);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleToggleStatus = (id: string) => {
    const updated = tokenList.map(t => {
      if (t.id === id) {
        const next = t.status === 'Aktif' ? 'Dinonaktifkan' : 'Aktif';
        return { ...t, status: next as any };
      }
      return t;
    });
    saveTokensToDb(updated);
  };

  const handleResetStudentLogin = (studentId: string) => {
    setResetSuccessId(studentId);
    setTimeout(() => setResetSuccessId(null), 3000);
  };

  const filteredStudents = students.filter(s => {
    if (!studentSearch) return true;
    const q = studentSearch.toLowerCase();
    return s.name.toLowerCase().includes(q) || s.nisn?.includes(q) || s.class?.toLowerCase().includes(q);
  });

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Top Banner with Big Live Token */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Token Card */}
        <div className="lg:col-span-2 bg-gradient-to-br from-amber-500 via-amber-600 to-orange-600 rounded-3xl p-6 sm:p-8 text-white shadow-lg relative overflow-hidden flex flex-col justify-between space-y-6">
          <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/20 backdrop-blur-xs rounded-full text-[11px] font-extrabold uppercase tracking-wider">
                <ShieldCheck size={14} /> Token Resmi CBT
              </div>
              <h2 className="text-xl font-black">Distribusi Token Sesi Ujian</h2>
              <p className="text-xs text-amber-100">
                Berikan token ini kepada peserta untuk memulai pengerjaan butir soal.
              </p>
            </div>

            <div className="bg-black/20 backdrop-blur-xs px-4 py-2 rounded-2xl border border-white/20 text-right self-start sm:self-auto">
              <span className="text-[10px] text-amber-200 uppercase font-bold block">Kedaluwarsa Dalam</span>
              <span className="font-mono text-xl font-black tracking-wider flex items-center gap-1.5 text-white">
                <Clock size={16} className="text-amber-200 animate-pulse" /> {formatTimer(secondsRemaining)}
              </span>
            </div>
          </div>

          {/* Token Big Box */}
          <div className="relative z-10 bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="text-center sm:text-left">
              <span className="text-xs font-bold text-amber-200 uppercase tracking-widest block">
                Kode Token Aktif
              </span>
              <div className="text-4xl sm:text-5xl font-mono font-black tracking-widest text-white drop-shadow-sm mt-1">
                {currentToken}
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <button
                onClick={handleCopy}
                className="flex-1 sm:flex-initial px-4 py-3 bg-white text-slate-900 rounded-xl font-black text-xs shadow-md hover:bg-amber-50 active:scale-95 transition flex items-center justify-center gap-2"
              >
                {copied ? <Check size={16} className="text-emerald-600" /> : <Copy size={16} />}
                <span>{copied ? 'Tersalin!' : 'Salin Token'}</span>
              </button>

              <button
                onClick={handleGenerateNewToken}
                className="flex-1 sm:flex-initial px-4 py-3 bg-slate-950/40 hover:bg-slate-950/60 text-white rounded-xl font-black text-xs border border-white/20 active:scale-95 transition flex items-center justify-center gap-2"
                title="Rilis Token Baru"
              >
                <RefreshCw size={16} />
                <span>Rilis Baru</span>
              </button>
            </div>
          </div>

          {/* Settings Duration */}
          <div className="relative z-10 flex flex-wrap items-center justify-between text-xs text-amber-100 gap-3 pt-2 border-t border-white/10">
            <div className="flex items-center gap-2">
              <span>Masa Berlaku Token:</span>
              <select
                value={tokenDuration}
                onChange={(e) => {
                  setTokenDuration(e.target.value);
                  setSecondsRemaining(Number(e.target.value) * 60);
                }}
                className="bg-white/20 border border-white/30 rounded-lg px-2.5 py-1 text-xs font-bold text-white focus:outline-none"
              >
                <option value="15" className="text-slate-900">15 Menit</option>
                <option value="30" className="text-slate-900">30 Menit</option>
                <option value="60" className="text-slate-900">60 Menit</option>
                <option value="120" className="text-slate-900">120 Menit (2 Jam)</option>
              </select>
            </div>
            <span className="text-[11px] text-amber-200">
              *Token akan otomatis me-refresh setelah waktu kedaluwarsa habis.
            </span>
          </div>
        </div>

        {/* Security / Token Policy Widget */}
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
                <Sparkles size={18} />
              </div>
              <h3 className="text-sm font-black text-slate-900">Protokol Keamanan Token</h3>
            </div>

            <ul className="space-y-2.5 text-xs text-slate-600 leading-relaxed">
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" />
                <span>Token wajib diinput peserta saat halaman asesmen terbuka.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" />
                <span>Siswa yang sudah login tidak perlu memasukkan token ulang kecuali terputus.</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-500 mt-1.5 shrink-0" />
                <span>Proktor dapat mematikan token seketika jika sesi ujian telah selesai.</span>
              </li>
            </ul>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200/80 text-[11px] text-slate-500 flex items-center gap-2">
            <AlertCircle size={16} className="text-amber-600 shrink-0" />
            <span>Pastikan proktor berada di ruang kelas sebelum mengumumkan token ke siswa.</span>
          </div>
        </div>
      </div>

      {/* Riwayat & Alokasi Token Table */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-black text-slate-900">Riwayat Distribusi Token</h3>
            <p className="text-xs text-slate-500">Catatan pembuatan & status token per sesi asesmen</p>
          </div>
          <span className="text-xs font-bold text-slate-500 bg-slate-100 px-3 py-1.5 rounded-xl">
            {tokenList.length} Catatan Token
          </span>
        </div>

        <div className="overflow-x-auto rounded-2xl border border-slate-200/80">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50/90 text-slate-600 uppercase font-bold text-[11px] border-b border-slate-200">
              <tr>
                <th className="p-3.5 pl-4">Sesi & Mapel</th>
                <th className="p-3.5">Rombel / Kelas</th>
                <th className="p-3.5 font-mono text-center">Kode Token</th>
                <th className="p-3.5">Waktu Dibuat</th>
                <th className="p-3.5">Kedaluwarsa</th>
                <th className="p-3.5">Proktor Pembuat</th>
                <th className="p-3.5 text-center">Status</th>
                <th className="p-3.5 pr-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {tokenList.length === 0 ? (
                <tr>
                  <td colSpan={8} className="p-8 text-center text-slate-400">
                    <Key size={28} className="mx-auto text-slate-300 mb-2" />
                    <p className="font-bold text-slate-600 text-sm">Belum Ada Token Sesi Aktif</p>
                    <p className="text-xs text-slate-400 mt-0.5">Klik tombol "Rilis Baru" di atas untuk men-generate token ujian baru.</p>
                  </td>
                </tr>
              ) : (
                tokenList.map((t) => (
                  <tr key={t.id} className="hover:bg-slate-50/80 transition">
                    <td className="p-3.5 pl-4">
                      <div className="font-bold text-slate-900 text-sm">{t.mapel}</div>
                      <div className="text-[10px] text-slate-400 font-mono">{t.sesiId}</div>
                    </td>
                    <td className="p-3.5 font-bold text-slate-800">{formatClassLabel(t.kelas, true)}</td>
                    <td className="p-3.5 text-center">
                      <span className="font-mono font-black text-sm text-amber-700 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-lg">
                        {t.token}
                      </span>
                    </td>
                    <td className="p-3.5 font-mono text-slate-600">{t.waktuDibuat}</td>
                    <td className="p-3.5 font-mono text-slate-600">{t.kedaluwarsa}</td>
                    <td className="p-3.5 text-slate-800">{t.proktor}</td>
                    <td className="p-3.5 text-center">
                      <span className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                        t.status === 'Aktif' 
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' 
                          : t.status === 'Kedaluwarsa'
                          ? 'bg-slate-100 text-slate-600'
                          : 'bg-rose-100 text-rose-800'
                      }`}>
                        {t.status}
                      </span>
                    </td>
                    <td className="p-3.5 pr-4 text-center">
                      <button
                        onClick={() => handleToggleStatus(t.id)}
                        className={`px-3 py-1 rounded-xl text-xs font-bold transition shadow-2xs ${
                          t.status === 'Aktif'
                            ? 'bg-rose-50 hover:bg-rose-100 text-rose-700'
                            : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700'
                        }`}
                      >
                        {t.status === 'Aktif' ? 'Nonaktifkan' : 'Aktifkan'}
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Reset Login Siswa Terputus Tool */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-cyan-50 text-cyan-600 flex items-center justify-center font-bold">
                <Unlock size={15} />
              </div>
              <h3 className="text-sm font-black text-slate-900">Reset Sesi Login Peserta Terputus</h3>
            </div>
            <p className="text-xs text-slate-500">
              Buka kunci login untuk siswa yang koneksinya mati atau browsernya tidak sengaja tertutup agar dapat melanjutkan ujian.
            </p>
          </div>

          <div className="w-full sm:w-72">
            <input
              type="text"
              placeholder="Cari nama siswa / NISN..."
              value={studentSearch}
              onChange={(e) => setStudentSearch(e.target.value)}
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500/20"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
          {filteredStudents.slice(0, 6).map((s) => (
            <div 
              key={s.id}
              className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-between gap-2 hover:bg-white transition"
            >
              <div>
                <div className="font-bold text-slate-900 text-xs truncate max-w-[150px]">{s.name}</div>
                <div className="text-[10px] text-slate-500">
                  NISN: {s.nisn || '-'} • {formatClassLabel(s.class, true)}
                </div>
              </div>

              {resetSuccessId === s.id ? (
                <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 font-bold text-[10px] rounded-lg flex items-center gap-1">
                  <Check size={11} /> Reset OK
                </span>
              ) : (
                <button
                  onClick={() => handleResetStudentLogin(s.id)}
                  className="px-2.5 py-1 bg-amber-100 hover:bg-amber-200 text-amber-900 font-bold text-[10px] rounded-lg transition"
                >
                  Buka Kunci
                </button>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
