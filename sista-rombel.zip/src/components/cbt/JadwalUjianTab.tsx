import React, { useState, useMemo } from 'react';
import { 
  Calendar, Plus, Search, X, Eye, Edit, Trash2, 
  Save, AlertTriangle, Clock, Users, Play, CheckCircle2, 
  Shuffle, FileQuestion, BookOpen
} from 'lucide-react';
import { useStore } from '../../store';
import { getAllClasses, matchClass, formatClassLabel, STANDARD_CLASSES } from '../../lib/utils';

interface JadwalUjianTabProps {
  ujianList: any[];
  setUjianList: React.Dispatch<React.SetStateAction<any[]>>;
  onSaveDb: (list: any[]) => void;
}

export default function JadwalUjianTab({ 
  ujianList, 
  setUjianList, 
  onSaveDb 
}: JadwalUjianTabProps) {
  const { teachers, students } = useStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterKelas, setFilterKelas] = useState('');
  const [filterJenis, setFilterJenis] = useState('');
  const [filterStatus, setFilterStatus] = useState('');

  // Modals
  const [createModalOpen, setCreateModalOpen] = useState(false);
  const [editModal, setEditModal] = useState<any | null>(null);
  const [viewDetailModal, setViewDetailModal] = useState<any | null>(null);
  const [deleteModal, setDeleteModal] = useState<any | null>(null);

  const availableClasses = useMemo(() => {
    return Array.from(new Set([...getAllClasses(students), ...STANDARD_CLASSES])).sort((a, b) =>
      a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' })
    );
  }, [students]);

  // Form State for new session
  const [formState, setFormState] = useState({
    id: `SES-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
    mapel: 'Pendidikan Pancasila',
    kelas: '1A',
    jenis: 'Sumatif Harian',
    tgl: new Date().toISOString().slice(0, 10),
    jamMulai: '07:30',
    jamSelesai: '09:00',
    durasi: '90 Menit',
    peserta: 28,
    proktor: teachers[0]?.name || 'Guru Pengampu / Proktor',
    acakSoal: true,
    acakOpsi: true,
    tampilkanNilai: true,
    status: 'Terjadwal',
    soal: '35 Soal (30 PG, 5 Esai)',
    avg: 0
  });

  const filteredList = useMemo(() => {
    return ujianList.filter((u: any) => {
      const q = searchTerm.toLowerCase();
      const mapel = String(u.mapel || '').toLowerCase();
      const kelas = String(u.kelas || '').toLowerCase();
      const jenis = String(u.jenis || '').toLowerCase();
      const id = String(u.id || '').toLowerCase();

      const matchesQ = !searchTerm || mapel.includes(q) || kelas.includes(q) || jenis.includes(q) || id.includes(q);
      const matchesKelas = !filterKelas || matchClass(u.kelas, filterKelas);
      const matchesJenis = !filterJenis || u.jenis === filterJenis;
      const matchesStatus = !filterStatus || u.status === filterStatus;

      return matchesQ && matchesKelas && matchesJenis && matchesStatus;
    });
  }, [ujianList, searchTerm, filterKelas, filterJenis, filterStatus]);

  // Actions
  const handleCreateSession = (e: React.FormEvent) => {
    e.preventDefault();
    const newSession = {
      ...formState,
      peserta: Number(formState.peserta) || 28,
      durasi: formState.durasi.includes('Menit') ? formState.durasi : `${formState.durasi} Menit`
    };

    const updated = [newSession, ...ujianList];
    setUjianList(updated);
    onSaveDb(updated);
    setCreateModalOpen(false);

    // Reset Form
    setFormState({
      id: `SES-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`,
      mapel: 'Pendidikan Pancasila',
      kelas: 'Kelas 1A',
      jenis: 'Sumatif Harian',
      tgl: new Date().toISOString().slice(0, 10),
      jamMulai: '07:30',
      jamSelesai: '09:00',
      durasi: '90 Menit',
      peserta: 28,
      proktor: teachers[0]?.name || 'Guru Pengampu / Proktor',
      acakSoal: true,
      acakOpsi: true,
      tampilkanNilai: true,
      status: 'Terjadwal',
      soal: '35 Soal (30 PG, 5 Esai)',
      avg: 0
    });
  };

  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editModal) return;
    const updated = ujianList.map(u => u.id === editModal.id ? { 
      ...u, 
      ...editModal, 
      peserta: Number(editModal.peserta) || u.peserta,
      avg: Number(editModal.avg) || u.avg
    } : u);
    setUjianList(updated);
    onSaveDb(updated);
    setEditModal(null);
  };

  const handleConfirmDelete = () => {
    if (!deleteModal) return;
    const updated = ujianList.filter(u => u.id !== deleteModal.id);
    setUjianList(updated);
    onSaveDb(updated);
    setDeleteModal(null);
  };

  const handleToggleStatus = (id: string, currentStatus: string) => {
    let nextStatus = 'Berlangsung';
    if (currentStatus === 'Berlangsung') nextStatus = 'Selesai';
    else if (currentStatus === 'Selesai') nextStatus = 'Terjadwal';

    const updated = ujianList.map(u => u.id === id ? { ...u, status: nextStatus } : u);
    setUjianList(updated);
    onSaveDb(updated);
  };

  return (
    <div className="space-y-6 animate-in fade-in">
      {/* Header & Quick Action */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-cyan-50 text-cyan-600 flex items-center justify-center font-bold">
              <Calendar size={18} />
            </div>
            <h2 className="text-lg font-black text-slate-900">Jadwal & Sesi Pelaksanaan Ujian</h2>
          </div>
          <p className="text-xs text-slate-500">
            Atur kalender sesi ujian online, rombel kelas, alokasi waktu, serta parameter pengacakan butir soal.
          </p>
        </div>

        <button
          onClick={() => setCreateModalOpen(true)}
          className="px-4 py-2.5 bg-cyan-600 hover:bg-cyan-700 text-white rounded-2xl text-xs font-bold shadow-sm transition flex items-center gap-2 active:scale-95 whitespace-nowrap"
        >
          <Plus size={16} />
          <span>Tambah Sesi Ujian Baru</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
          <div className="relative flex-1">
            <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input 
              type="text" 
              placeholder="Cari mata pelajaran, kode sesi, pengawas..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 pr-8 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
            />
            {searchTerm && (
              <button onClick={() => setSearchTerm('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                <X size={14} />
              </button>
            )}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={filterKelas}
              onChange={(e) => setFilterKelas(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
            >
              <option value="">Semua Kelas</option>
              {availableClasses.map(cls => (
                <option key={cls} value={cls}>{formatClassLabel(cls, true)}</option>
              ))}
            </select>

            <select
              value={filterJenis}
              onChange={(e) => setFilterJenis(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
            >
              <option value="">Semua Jenis Ujian</option>
              <option value="Sumatif Harian">Sumatif Harian</option>
              <option value="STS (Tengah Semester)">STS (Tengah Semester)</option>
              <option value="ASAS (Akhir Semester)">ASAS (Akhir Semester)</option>
              <option value="Tryout ANBK">Tryout ANBK</option>
            </select>

            <select
              value={filterStatus}
              onChange={(e) => setFilterStatus(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
            >
              <option value="">Semua Status</option>
              <option value="Terjadwal">Terjadwal</option>
              <option value="Berlangsung">Sedang Berlangsung</option>
              <option value="Selesai">Selesai</option>
            </select>

            <span className="text-[11px] font-bold text-slate-500 bg-slate-100 px-3 py-2 rounded-xl">
              {filteredList.length} Sesi Terdata
            </span>
          </div>
        </div>

        {/* Sesi Ujian Table */}
        <div className="overflow-x-auto rounded-2xl border border-slate-200/80">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50/90 text-slate-600 uppercase font-bold text-[11px] border-b border-slate-200">
              <tr>
                <th className="p-3.5 pl-4">Kode Sesi</th>
                <th className="p-3.5">Mata Pelajaran</th>
                <th className="p-3.5">Rombel / Kelas</th>
                <th className="p-3.5">Jenis Asesmen</th>
                <th className="p-3.5">Jadwal & Waktu</th>
                <th className="p-3.5">Durasi</th>
                <th className="p-3.5">Pengawas / Proktor</th>
                <th className="p-3.5 text-center">Status</th>
                <th className="p-3.5 pr-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
              {filteredList.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-10 text-center text-slate-400">
                    <Calendar size={32} className="mx-auto text-slate-300 mb-2" />
                    <p className="font-bold text-slate-600 text-sm">Tidak Ada Sesi Ujian</p>
                    <p className="text-xs text-slate-400 mt-0.5">Silakan buat sesi ujian baru dengan menekan tombol di atas.</p>
                  </td>
                </tr>
              ) : (
                filteredList.map((u: any) => (
                  <tr key={u.id} className="hover:bg-slate-50/80 transition">
                    <td className="p-3.5 pl-4 font-mono font-bold text-cyan-700">{u.id}</td>
                    <td className="p-3.5">
                      <div className="font-bold text-slate-900 text-sm">{u.mapel}</div>
                      <div className="text-[10px] text-slate-400 flex items-center gap-1.5 mt-0.5">
                        <FileQuestion size={11} /> {u.soal || '35 Butir Soal'}
                      </div>
                    </td>
                    <td className="p-3.5 font-bold text-slate-800">
                      <span className="px-2 py-0.5 bg-slate-100 rounded-md">{formatClassLabel(u.kelas, true)}</span>
                    </td>
                    <td className="p-3.5">
                      <span className="px-2 py-0.5 bg-cyan-50 text-cyan-700 font-bold rounded-md text-[10px] border border-cyan-200/60">
                        {u.jenis}
                      </span>
                    </td>
                    <td className="p-3.5">
                      <div className="font-bold text-slate-800">{u.tgl}</div>
                      <div className="text-[10px] text-slate-500 font-mono">
                        {u.jamMulai ? `${u.jamMulai} - ${u.jamSelesai || 'Selesai'}` : u.durasi}
                      </div>
                    </td>
                    <td className="p-3.5 font-mono font-semibold text-slate-700">{u.durasi}</td>
                    <td className="p-3.5 text-slate-700">{u.proktor || 'Guru Kelas'}</td>
                    <td className="p-3.5 text-center">
                      <button
                        onClick={() => handleToggleStatus(u.id, u.status)}
                        className={`px-2.5 py-1 rounded-full font-bold text-[10px] transition cursor-pointer hover:opacity-80 ${
                          u.status === 'Berlangsung' 
                            ? 'bg-amber-100 text-amber-800 border border-amber-300' 
                            : u.status === 'Selesai' 
                            ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' 
                            : 'bg-slate-100 text-slate-700 border border-slate-200'
                        }`}
                        title="Klik untuk ubah status cepat"
                      >
                        {u.status}
                      </button>
                    </td>
                    <td className="p-3.5 pr-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => setViewDetailModal(u)}
                          className="p-1.5 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg font-bold text-xs transition"
                          title="Lihat Detail Sesi"
                        >
                          <Eye size={13} />
                        </button>
                        <button
                          onClick={() => setEditModal({ ...u })}
                          className="p-1.5 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg font-bold text-xs transition"
                          title="Edit Sesi"
                        >
                          <Edit size={13} />
                        </button>
                        <button
                          onClick={() => setDeleteModal({ id: u.id, name: `${u.mapel} - ${u.kelas}` })}
                          className="p-1.5 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg font-bold text-xs transition"
                          title="Hapus Sesi"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* CREATE MODAL */}
      {createModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-5 animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-cyan-50 text-cyan-600 flex items-center justify-center font-bold">
                  <Calendar size={18} />
                </div>
                <h3 className="text-base font-black text-slate-900">Buat Sesi Ujian CBT Baru</h3>
              </div>
              <button 
                onClick={() => setCreateModalOpen(false)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleCreateSession} className="space-y-4 max-h-[65vh] overflow-y-auto pr-1">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Mata Pelajaran</label>
                <input
                  type="text"
                  required
                  value={formState.mapel}
                  onChange={(e) => setFormState({ ...formState, mapel: e.target.value })}
                  placeholder="Misal: Bahasa Indonesia, IPAS, Matematika"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Rombel / Kelas</label>
                  <select
                    value={formState.kelas}
                    onChange={(e) => setFormState({ ...formState, kelas: e.target.value })}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
                  >
                    {availableClasses.map(cls => (
                      <option key={cls} value={cls}>{formatClassLabel(cls, true)}</option>
                    ))}
                  </select>
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Jenis Ujian</label>
                  <select
                    value={formState.jenis}
                    onChange={(e) => setFormState({ ...formState, jenis: e.target.value })}
                    className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
                  >
                    <option value="Sumatif Harian">Sumatif Harian</option>
                    <option value="STS (Tengah Semester)">STS (Tengah Semester)</option>
                    <option value="ASAS (Akhir Semester)">ASAS (Akhir Semester)</option>
                    <option value="Tryout ANBK">Tryout ANBK</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Tanggal Ujian</label>
                  <input
                    type="date"
                    required
                    value={formState.tgl}
                    onChange={(e) => setFormState({ ...formState, tgl: e.target.value })}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Durasi Pengerjaan</label>
                  <input
                    type="text"
                    value={formState.durasi}
                    onChange={(e) => setFormState({ ...formState, durasi: e.target.value })}
                    placeholder="90 Menit"
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Jam Mulai</label>
                  <input
                    type="time"
                    value={formState.jamMulai}
                    onChange={(e) => setFormState({ ...formState, jamMulai: e.target.value })}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Jam Selesai</label>
                  <input
                    type="time"
                    value={formState.jamSelesai}
                    onChange={(e) => setFormState({ ...formState, jamSelesai: e.target.value })}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
                  />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Pengawas / Proktor</label>
                <select
                  value={formState.proktor}
                  onChange={(e) => setFormState({ ...formState, proktor: e.target.value })}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
                >
                  {teachers.map(t => (
                    <option key={t.id} value={t.name}>{t.name} ({t.nip || 'Guru'})</option>
                  ))}
                  <option value="Tim Proktor Utama">Tim Proktor Utama</option>
                </select>
              </div>

              {/* Toggles */}
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 text-xs">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={formState.acakSoal} 
                    onChange={(e) => setFormState({ ...formState, acakSoal: e.target.checked })}
                    className="rounded text-cyan-600 focus:ring-cyan-500" 
                  />
                  <span className="font-bold text-slate-800">Acak Urutan Butir Soal Antar Peserta</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={formState.acakOpsi} 
                    onChange={(e) => setFormState({ ...formState, acakOpsi: e.target.checked })}
                    className="rounded text-cyan-600 focus:ring-cyan-500" 
                  />
                  <span className="font-bold text-slate-800">Acak Opsi Pilihan Jawaban (A, B, C, D)</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="checkbox" 
                    checked={formState.tampilkanNilai} 
                    onChange={(e) => setFormState({ ...formState, tampilkanNilai: e.target.checked })}
                    className="rounded text-cyan-600 focus:ring-cyan-500" 
                  />
                  <span className="font-bold text-slate-800">Tampilkan Nilai Akhir ke Siswa Setelah Submit</span>
                </label>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setCreateModalOpen(false)}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-cyan-600 hover:bg-cyan-700 text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center gap-1.5"
                >
                  <Save size={14} />
                  <span>Simpan Sesi Ujian</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DETAIL MODAL */}
      {viewDetailModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-5 animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-cyan-50 text-cyan-600 flex items-center justify-center font-bold">
                  <Eye size={18} />
                </div>
                <h3 className="text-base font-black text-slate-900">Detail Sesi Ujian: {viewDetailModal.mapel}</h3>
              </div>
              <button 
                onClick={() => setViewDetailModal(null)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition"
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-2.5 max-h-[60vh] overflow-y-auto pr-1 text-xs">
              <div className="p-3 bg-slate-50 rounded-2xl flex justify-between">
                <span className="font-bold text-slate-500">Kode Sesi:</span>
                <span className="font-mono font-bold text-cyan-700">{viewDetailModal.id}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-2xl flex justify-between">
                <span className="font-bold text-slate-500">Mata Pelajaran:</span>
                <span className="font-extrabold text-slate-900">{viewDetailModal.mapel}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-2xl flex justify-between">
                <span className="font-bold text-slate-500">Rombel Kelas:</span>
                <span className="font-bold text-slate-900">{formatClassLabel(viewDetailModal.kelas, true)}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-2xl flex justify-between">
                <span className="font-bold text-slate-500">Jenis Asesmen:</span>
                <span className="font-bold text-cyan-800 bg-cyan-100 px-2 py-0.5 rounded">{viewDetailModal.jenis}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-2xl flex justify-between">
                <span className="font-bold text-slate-500">Tanggal Pelaksanaan:</span>
                <span className="font-bold text-slate-800">{viewDetailModal.tgl}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-2xl flex justify-between">
                <span className="font-bold text-slate-500">Durasi Pengerjaan:</span>
                <span className="font-bold text-slate-800">{viewDetailModal.durasi}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-2xl flex justify-between">
                <span className="font-bold text-slate-500">Pengawas / Proktor:</span>
                <span className="font-bold text-slate-800">{viewDetailModal.proktor || 'Proktor Sekolah'}</span>
              </div>
              <div className="p-3 bg-slate-50 rounded-2xl flex justify-between">
                <span className="font-bold text-slate-500">Status Sesi:</span>
                <span className="font-bold text-emerald-700">{viewDetailModal.status}</span>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setViewDetailModal(null)}
                className="px-5 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800 transition"
              >
                Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* EDIT MODAL */}
      {editModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 space-y-5 animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
                  <Edit size={18} />
                </div>
                <h3 className="text-base font-black text-slate-900">Edit Sesi: {editModal.mapel}</h3>
              </div>
              <button 
                onClick={() => setEditModal(null)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-4 max-h-[60vh] overflow-y-auto pr-1">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Mata Pelajaran</label>
                <input
                  type="text"
                  value={editModal.mapel || ''}
                  onChange={(e) => setEditModal({ ...editModal, mapel: e.target.value })}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Kelas</label>
                  <select
                    value={editModal.kelas || ''}
                    onChange={(e) => setEditModal({ ...editModal, kelas: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
                  >
                    {availableClasses.map(cls => (
                      <option key={cls} value={cls}>{formatClassLabel(cls, true)}</option>
                    ))}
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Jenis Asesmen</label>
                  <select
                    value={editModal.jenis || 'Sumatif Harian'}
                    onChange={(e) => setEditModal({ ...editModal, jenis: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
                  >
                    <option value="Sumatif Harian">Sumatif Harian</option>
                    <option value="STS (Tengah Semester)">STS (Tengah Semester)</option>
                    <option value="ASAS (Akhir Semester)">ASAS (Akhir Semester)</option>
                    <option value="Tryout ANBK">Tryout ANBK</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Tanggal Ujian</label>
                  <input
                    type="date"
                    value={editModal.tgl || ''}
                    onChange={(e) => setEditModal({ ...editModal, tgl: e.target.value })}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Durasi</label>
                  <input
                    type="text"
                    value={editModal.durasi || ''}
                    onChange={(e) => setEditModal({ ...editModal, durasi: e.target.value })}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Status</label>
                  <select
                    value={editModal.status || 'Terjadwal'}
                    onChange={(e) => setEditModal({ ...editModal, status: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
                  >
                    <option value="Terjadwal">Terjadwal</option>
                    <option value="Berlangsung">Berlangsung</option>
                    <option value="Selesai">Selesai</option>
                  </select>
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Pengawas</label>
                  <input
                    type="text"
                    value={editModal.proktor || ''}
                    onChange={(e) => setEditModal({ ...editModal, proktor: e.target.value })}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-cyan-500/20"
                  />
                </div>
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditModal(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-cyan-600 hover:bg-cyan-700 text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center gap-1.5"
                >
                  <Save size={14} />
                  <span>Simpan Perubahan</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL */}
      {deleteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 space-y-4 animate-in zoom-in-95">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto border border-rose-100">
              <AlertTriangle size={24} />
            </div>
            
            <div className="text-center space-y-1">
              <h3 className="text-base font-black text-slate-900">Hapus Sesi Ujian</h3>
              <p className="text-xs text-slate-500">
                Apakah Anda yakin ingin menghapus sesi ujian <strong className="text-slate-800">"{deleteModal.name}"</strong>?
              </p>
            </div>

            <div className="pt-2 flex items-center justify-center gap-2.5">
              <button
                type="button"
                onClick={() => setDeleteModal(null)}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex-1"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center justify-center gap-1.5 flex-1"
              >
                <Trash2 size={14} />
                <span>Ya, Hapus</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
