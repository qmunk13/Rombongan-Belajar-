/**
 * Utility Service untuk Sinkronisasi Realtime 2-Arah dengan Google Apps Script (56 Sheet)
 * Mendukung JSONP Fallback untuk menghindari CORS issue pada browser!
 */

export const STORAGE_KEY_GAS_URL = 'sista_gas_url';
export const STORAGE_KEY_SPREADSHEET_URL = 'sista_spreadsheet_url';

let inMemoryGasUrl = '';
let inMemorySpreadsheetUrl = 'https://docs.google.com/spreadsheets/d/1XTfNFkele0iVbb7W8qlJDujWKFbq-bqJO5VabY82bCk/edit?usp=drive_link';
let inMemoryLastSiswaCount = 0;

export function isValidGasUrl(url: string): boolean {
  if (!url || typeof url !== 'string') return false;
  const trimmed = url.trim();
  return trimmed.startsWith('https://') && !trimmed.includes('AKfycbx_SISTA_ROMBEL_56_TABLES');
}

export function getStoredGasUrl(): string {
  if (!isValidGasUrl(inMemoryGasUrl)) return '';
  return inMemoryGasUrl;
}

export function saveStoredGasUrl(url: string): void {
  inMemoryGasUrl = url.trim();
}

export function getStoredSpreadsheetUrl(): string {
  return inMemorySpreadsheetUrl;
}

export function saveStoredSpreadsheetUrl(url: string): void {
  inMemorySpreadsheetUrl = url.trim();
}

function extractSheetMap(data: any): Record<string, any[]> {
  if (!data || typeof data !== 'object') return {};
  let current = data;
  let iterations = 0;
  while (current && typeof current === 'object' && iterations < 5) {
    iterations++;
    // If current object directly contains known table keys or array values, we found the dictionary
    if (current.SISWA || current.GURU || current.ABSENSI || current.USERS || current.siswa) {
      break;
    }
    if (current.data && typeof current.data === 'object' && !Array.isArray(current.data)) {
      current = current.data;
    } else {
      break;
    }
  }
  return (current && typeof current === 'object') ? current : {};
}

// Track last known remote counts to prevent accidental data overwrites
export const STORAGE_KEY_LAST_SISWA_COUNT = 'sista_last_siswa_count';

/**
 * Smart Merge untuk menggabungkan data lokal & data dari Google Sheets tanpa menghapus data lokal (seperti 378 siswa yang diimpor)
 */
export function smartMergeDbData(prevLocal: Record<string, any[]>, newRemote: Record<string, any[]>): Record<string, any[]> {
  if (!newRemote || typeof newRemote !== 'object') return prevLocal;
  const merged: Record<string, any[]> = { ...prevLocal };

  Object.keys(newRemote).forEach((sheetKey) => {
    const remoteList = newRemote[sheetKey];
    if (!Array.isArray(remoteList)) return;

    const upperKey = sheetKey.toUpperCase();
    const localList = prevLocal[upperKey] || prevLocal[sheetKey] || [];

    // Track total siswa dari remote jika ini sheet SISWA
    if (upperKey === 'SISWA' && remoteList.length > 0) {
      if (remoteList.length > inMemoryLastSiswaCount) {
        inMemoryLastSiswaCount = remoteList.length;
      }
    }

    // Rule 1: Jika remote kosong, JANGAN pernah menimpa daftar lokal yang ada datanya
    if (remoteList.length === 0) {
      if (localList.length > 0) {
        merged[upperKey] = localList;
        merged[sheetKey] = localList;
      }
      return;
    }

    // Rule 2: Jika lokal kosong, langsung gunakan remote
    if (localList.length === 0) {
      merged[upperKey] = remoteList;
      merged[sheetKey] = remoteList;
      return;
    }

    // Rule 3: Cari field primary key unik
    const sample = localList[0] || remoteList[0] || {};
    const keyCandidates = [
      'nopdkt', 'NISN', 'id', 'biayaId', 'KasID', 'idNotif', 'username',
      'NO_JADWAL', 'ID_HASIL', 'idFile', 'idAgenda', 'idTugas', 'PengeluaranID',
      'idBackup', 'idArsip', 'NO_LOG', 'idPemeliharaan'
    ];
    const keyField = keyCandidates.find((k) => k in sample || (remoteList[0] && k in remoteList[0]));

    if (keyField) {
      const map = new Map<string, any>();
      // 1. Masukkan semua data lokal terlebih dahulu
      localList.forEach((item) => {
        const val = String(item[keyField] ?? '');
        if (val && val !== '-') {
          map.set(val, item);
        }
      });
      // 2. Gabungkan data remote: perbarui jika ada, tambahkan jika belum ada
      remoteList.forEach((item) => {
        const val = String(item[keyField] ?? '');
        if (val && val !== '-') {
          const existing = map.get(val);
          map.set(val, existing ? { ...existing, ...item } : item);
        }
      });
      const combined = Array.from(map.values());
      merged[upperKey] = combined;
      merged[sheetKey] = combined;
    } else {
      // Jika tidak ada key unik & lokal memiliki baris jauh lebih banyak, pertahankan lokal agar tidak terhapus
      if (localList.length > remoteList.length) {
        merged[upperKey] = localList;
        merged[sheetKey] = localList;
      } else {
        merged[upperKey] = remoteList;
        merged[sheetKey] = remoteList;
      }
    }
  });

  return merged;
}

/**
 * Memanggil GET_ALL_SHEETS menggunakan JSONP Fallback jika standard fetch terhalang CORS
 */
export async function pullAllSheetsFromGas(gasUrl?: string): Promise<{ success: boolean; data?: Record<string, any[]>; message: string }> {
  let url = (gasUrl?.trim() || getStoredGasUrl()).trim();
  if (!isValidGasUrl(url)) {
    return { success: false, message: 'URL Google Apps Script belum diatur atau belum valid.' };
  }

  // Jika user menyalin URL berakhiran /dev, ganti ke /exec agar tidak terhalang otentikasi developer Google
  if (url.endsWith('/dev')) {
    url = url.substring(0, url.length - 4) + '/exec';
  }

  return new Promise((resolve) => {
    let isResolved = false;
    const callbackName = `gas_callback_${Math.floor(Math.random() * 1000000)}`;
    const script = document.createElement('script');
    script.crossOrigin = 'anonymous';

    // Timeout 25 detik agar Google Apps Script memiliki waktu cukup membaca 56 sheet saat cold boot
    const timeout = setTimeout(() => {
      if (!isResolved) {
        isResolved = true;
        cleanup();
        resolve({
          success: false,
          message: 'Timeout koneksi Google Apps Script (25s). Pastikan Web App dipublikasikan dengan akses "Anyone" (Siapa saja) dan URL berakhiran "/exec". Coba klik Sync Now sekali lagi.'
        });
      }
    }, 25000);

    const cleanup = () => {
      // Set fungsi aman tanpa error di window jika callback terpanggil secara terlambat
      (window as any)[callbackName] = () => {
        try {
          delete (window as any)[callbackName];
        } catch {
          // ignore
        }
      };
      if (script.parentNode) {
        script.parentNode.removeChild(script);
      }
      clearTimeout(timeout);
    };

    // Callback JSONP
    (window as any)[callbackName] = (data: any) => {
      if (!isResolved) {
        isResolved = true;
        cleanup();
        const extracted = extractSheetMap(data);
        if (data && (data.status === 'success' || data.data || Object.keys(extracted).length > 0)) {
          resolve({
            success: true,
            data: extracted,
            message: '✓ Berhasil memperbarui 56 Sheet via Sync Google Apps Script!'
          });
        } else {
          resolve({
            success: false,
            message: data?.message || 'Respon Google Apps Script tidak berisi data yang valid.'
          });
        }
      }
    };

    // Method 1: Standard Fetch (Percobaan Langsung)
    const separator = url.includes('?') ? '&' : '?';
    const fetchUrl = `${url}${separator}action=GET_ALL_SHEETS&t=${Date.now()}`;
    
    fetch(fetchUrl, { method: 'GET', headers: { 'Accept': 'application/json' } })
      .then(async (res) => {
        if (!isResolved && res.ok) {
          try {
            const json = await res.json();
            const extracted = extractSheetMap(json);
            if (json && (json.status === 'success' || json.data || Object.keys(extracted).length > 0)) {
              isResolved = true;
              cleanup();
              resolve({
                success: true,
                data: extracted,
                message: '✓ Berhasil memperbarui 56 Sheet dari Google Spreadsheet!'
              });
            }
          } catch {
            // Jika res.json() gagal (karena redirect HTML), biarkan JSONP bekerja
          }
        }
      })
      .catch(() => {
        // Jika fetch terhalang CORS, JSONP yang berjalan secara paralel akan memprosesnya
      });

    // Method 2: JSONP Fallback (Bypass CORS)
    script.src = `${url}${separator}action=GET_ALL_SHEETS&callback=${callbackName}&t=${Date.now()}`;
    script.onerror = (e) => {
      if (typeof e === 'object' && e !== null && 'stopPropagation' in e && typeof (e as Event).stopPropagation === 'function') {
        (e as Event).stopPropagation();
      }
      // Jangan langsung gagalkan jika fetch standard masih berpotensi berhasil
    };

    try {
      document.head.appendChild(script);
    } catch {
      // Abaikan jika penambahan script gagal, fetch akan menangani
    }
  });
}

/**
 * Mengirim & Menyingkronkan Massal 56 Sheet ke Google Apps Script (POST Instan)
 */
export async function pushAllSheetsToGas(dbData: Record<string, any[]>, gasUrl?: string): Promise<{ success: boolean; message: string }> {
  const url = gasUrl?.trim() || getStoredGasUrl();
  if (!isValidGasUrl(url)) {
    return { success: false, message: 'URL Google Apps Script tidak diset atau belum valid.' };
  }

  // Protection Guard: Jangan izinkan push jika data siswa lokal hanya contoh/sample kecil (< 10) padahal sebelumnya ada 10+ siswa
  const siswaList = dbData.SISWA || dbData.siswa || [];
  const lastKnownSiswaCount = inMemoryLastSiswaCount;
  
  if (lastKnownSiswaCount > 10 && siswaList.length <= 5) {
    console.warn(`[Protection] Auto-push dibatalkan untuk mencegah penimpaan data Sheet (${lastKnownSiswaCount} siswa di Sheet vs ${siswaList.length} siswa lokal).`);
    return {
      success: false,
      message: `Aplikasi menolak menimpa Google Sheets (${lastKnownSiswaCount} data di Sheet) dengan sampel data lokal yang lebih sedikit. Mengambil data terbaru dari Sheet...`
    };
  }

  const payloadData = {
    action: 'MASS_SYNC_ALL',
    allDataJson: JSON.stringify(dbData)
  };

  try {
    // Standard fast no-cors POST payload
    await fetch(url, {
      method: 'POST',
      mode: 'no-cors',
      headers: { 'Content-Type': 'text/plain;charset=utf-8' },
      body: JSON.stringify(payloadData)
    });

    return {
      success: true,
      message: '⚡ Data 56 Sheet terkirim & disinkronkan ke Google Spreadsheet!'
    };
  } catch (err) {
    console.error('Push to GAS error:', err);
    return {
      success: false,
      message: 'Gagal mengirim data ke Google Apps Script: ' + (err instanceof Error ? err.message : String(err))
    };
  }
}
