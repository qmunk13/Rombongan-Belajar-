import { db } from '../data/db';

export interface SemesterEntity {
  id: string;
  code: string;
  name: string;
  tahunPelajaran: string;
  semesterType: 'Ganjil' | 'Genap';
  isActive: boolean;
  startDate: string;
  endDate: string;
  deskripsi?: string;
}

export const DEFAULT_SEMESTERS: SemesterEntity[] = [
  {
    id: 'SEM-2026-1',
    code: '2026/2027-1',
    name: 'Semester 1 (Ganjil)',
    tahunPelajaran: '2026/2027',
    semesterType: 'Ganjil',
    isActive: true,
    startDate: '2026-07-13',
    endDate: '2026-12-19',
    deskripsi: 'Semester Ganjil Tahun Ajaran 2026/2027'
  },
  {
    id: 'SEM-2026-2',
    code: '2026/2027-2',
    name: 'Semester 2 (Genap)',
    tahunPelajaran: '2026/2027',
    semesterType: 'Genap',
    isActive: false,
    startDate: '2027-01-04',
    endDate: '2027-06-19',
    deskripsi: 'Semester Genap Tahun Ajaran 2026/2027'
  },
  {
    id: 'SEM-2025-1',
    code: '2025/2026-1',
    name: 'Semester 1 (Ganjil)',
    tahunPelajaran: '2025/2026',
    semesterType: 'Ganjil',
    isActive: false,
    startDate: '2025-07-14',
    endDate: '2025-12-20',
    deskripsi: 'Semester Ganjil Tahun Ajaran 2025/2026'
  },
  {
    id: 'SEM-2025-2',
    code: '2025/2026-2',
    name: 'Semester 2 (Genap)',
    tahunPelajaran: '2025/2026',
    semesterType: 'Genap',
    isActive: false,
    startDate: '2026-01-05',
    endDate: '2026-06-20',
    deskripsi: 'Semester Genap Tahun Ajaran 2025/2026'
  }
];

export function getSemestersList(): SemesterEntity[] {
  const stored = db.get<SemesterEntity>('semester');
  if (stored && stored.length > 0) {
    // If stored contains active semester, ensure 2026/2027 is present
    const has2026 = stored.some(s => s.tahunPelajaran === '2026/2027');
    if (!has2026) {
      const merged = [...DEFAULT_SEMESTERS];
      db.set('semester', merged);
      return merged;
    }
    return stored;
  }
  db.set('semester', DEFAULT_SEMESTERS);
  return DEFAULT_SEMESTERS;
}

export function getActiveSemester(preferredTahun?: string): SemesterEntity {
  const list = getSemestersList();
  if (preferredTahun) {
    const match = list.find(s => s.tahunPelajaran === preferredTahun && s.isActive) ||
                  list.find(s => s.tahunPelajaran === preferredTahun);
    if (match) return match;
  }
  const active = list.find(s => s.isActive);
  if (active) return active;
  if (list.length > 0) {
    list[0].isActive = true;
    db.set('semester', list);
    return list[0];
  }
  return DEFAULT_SEMESTERS[0];
}

export function setActiveSemesterInDb(semesterId: string): SemesterEntity[] {
  const list = getSemestersList();
  const updated = list.map(s => ({
    ...s,
    isActive: s.id === semesterId
  }));
  db.set('semester', updated);
  return updated;
}

export function saveSemesterInDb(semester: SemesterEntity): SemesterEntity[] {
  const list = getSemestersList();
  const index = list.findIndex(s => s.id === semester.id);
  let updated: SemesterEntity[];
  if (index !== -1) {
    updated = list.map(s => (s.id === semester.id ? semester : s));
  } else {
    updated = [...list, semester];
  }
  db.set('semester', updated);
  return updated;
}
