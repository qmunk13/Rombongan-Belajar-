// GOOGLE APPS SCRIPT TEMPLATE & 72-TABLE MASTER SCHEMA

export const GAS_TEMPLATE = `// ============================================================================
// GOOGLE APPS SCRIPT - MASTER DATABASE ENGINE & GOOGLE DRIVE INTEGRATION
// Sistem Informasi Manajemen & ERP Rombel Terintegrasi
// ============================================================================
// CARA MENGATASI 'Akses ditolak: DriveApp' (Izin Google Drive):
// 1. Buka spreadsheet Google Anda, klik menu 'Ekstensi' > 'Apps Script'
// 2. Paste seluruh kode ini ke dalam editor
// 3. Klik tombol Simpan (Disket)
// 4. DI TOOLBAR ATAS: Pilih fungsi 'otorisasiDrive' (atau 'setup')
// 5. KLIK TOMBOL 'Jalankan' (Run ▶)
// 6. Klik 'Tinjau Izin' > Pilih Akun Google Anda > Klik 'Lanjutan (Advanced)'
//    > Klik 'Buka project (tidak aman)' > Klik 'Izinkan (Allow)'
// 7. Klik tombol 'Terapkan (Deploy)' di kanan atas > 'Deployment baru' (New deployment)
//    - Jenis: Aplikasi Web (Web App)
//    - Eksekusi sebagai: Saya (Me) [Wajib]
//    - Siapa yang memiliki akses: Siapa saja (Anyone) [Wajib]
// 8. Salin URL Web App dan tempelkan ke Pengaturan Aplikasi!
// ============================================================================

/**
 * FUNGSI UTAMA UNTUK OTORISASI IZIN GOOGLE DRIVE
 * Jalankan fungsi ini sekali dari Editor Apps Script jika muncul error 'Akses ditolak: DriveApp'
 */
function otorisasiDrive() {
  try {
    const root = DriveApp.getRootFolder();
    const folderIter = DriveApp.getFoldersByName("BERKAS_SISWA_MASTER");
    let targetFolder;
    if (folderIter.hasNext()) {
      targetFolder = folderIter.next();
    } else {
      targetFolder = DriveApp.createFolder("BERKAS_SISWA_MASTER");
      try {
        targetFolder.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
      } catch (e) {}
    }
    Logger.log("✅ SUKSES! Izin DriveApp telah AKTIF. Folder Berkas ID: " + targetFolder.getId());
    return "✅ SUKSES! Izin Google Drive berhasil diaktifkan. Folder Berkas: " + targetFolder.getName();
  } catch (err) {
    Logger.log("❌ Error otorisasi Drive: " + err.toString());
    throw new Error("Gagal otorisasi DriveApp: " + err.toString());
  }
}

const MASTER_SCHEMAS = {
  // 1. SISTEM & AUTENTIKASI
  "SETTING": ["Key", "Value"],
  "REFERENSI": ["Kategori", "Kode", "Nama", "Aktif"],
  "USERS": ["UserID", "Username", "Password", "RoleID", "Nama", "NIP_NISN", "Email", "NoHP", "Status", "LastLogin", "Token", "CreatedAt", "UpdatedAt"],
  "ROLE": ["RoleID", "NamaRole", "Keterangan"],
  "MENU": ["MenuID", "ParentID", "NamaMenu", "Icon", "URL", "Urutan", "Status"],
  "HAK_AKSES": ["HakAksesID", "RoleID", "MenuID", "Create", "Read", "Update", "Delete", "Approve", "Export", "Import"],
  "SESSION": ["SessionID", "UserID", "Token", "IPAddress", "Device", "LoginAt", "ExpiredAt", "Status"],
  "LOG": ["LogID", "UserID", "Tanggal", "Aktivitas", "IP", "Device", "Browser"],
  "AUDIT_LOG": ["AuditID", "UserID", "Tabel", "RecordID", "Field", "ValueLama", "ValueBaru", "Tanggal"],
  "NOTIFIKASI": ["NotifID", "UserID", "Judul", "Pesan", "Jenis", "Status", "Tanggal"],

  // 2. KESISWAAN & GTK
  "SISWA": [
    "nopdkt", "TahunMasuk", "NISN", "NamaLengkap", "JenisKelamin", "Tempat Lahir", "TanggalLahir", 
    "NIK", "Anak ke", "Saudara", "Agama", "Golongan Darah", "TinggiBadan(cm)", "BeratBadan(kg)", 
    "Prestasi", "Hobi", "Catatan Penting", "Alamat", "RT", "RW", "Kelurahan", "Kecamatan", "Kota", 
    "Provinsi", "KodePos", "JenisTinggal", "AlatTransportasi", "NomorHP", "E-Mail", "AsalSekolah", 
    "SKHUN", "PenerimaKPS", "PasFoto", "NomorKartuKeluarga", "NamaAyah", "NIKAyah", "TempatLahirAyah", 
    "TanggalLahirAyah", "PendidikanAyah", "PekerjaanAyah", "PenghasilanAyah", "TlpAyah", "StatusAyah", "NamaIbu", 
    "NIKIbu", "TempatLahirIbu", "TanggalLahirIbu", "PendidikanIbu", "PekerjaanIbu", "PenghasilanIbu", 
    "TlpIbu", "StatusIbu", "StatusYatim", "NamaWali", "TempatLahirWali", "TglLahirWali", "PendidikanWali", "PekerjaanWali", 
    "PenghasilanWali", "Hubungan", "Tlp.Wali", "AktaKelahiran", "KartuKeluarga", "KIA", "KTPAyah", 
    "KTPIbu", "Ijazah", "KTPWali", "Rapor", "S.Pindah", "SuKet", "S.Domisili", "Status", "KelasSaatini"
  ],
  "GURU": [
    "GuruID", "NIK", "NIP", "NUPTK", "Nama", "Gelar", "JenisKelamin", "TempatLahir", "TanggalLahir", 
    "Agama", "Alamat", "NoHP", "Email", "Jabatan", "StatusKepegawaian", "Pendidikan", "Jurusan", "TMT", "Status", "Foto", "CreatedAt", "UpdatedAt"
  ],
  "ORANG_TUA": ["OrtuID", "SiswaID", "Hubungan", "Nama", "NIK", "Pekerjaan", "NoHP", "Alamat"],

  // 3. AKADEMIK & KURIKULUM
  "KELAS": ["KelasID", "NamaKelas", "JenjangID", "Tingkat", "WaliKelasID", "NamaTutor", "Ruangan", "Status"],
  "JENJANG": ["JenjangID", "Kode", "NamaJenjang", "Keterangan"],
  "MAPEL": ["MapelID", "Kode", "NamaMapel", "KKM", "GuruID", "Kelompok", "Status", "Jenjang", "Kelas", "GuruPengampu", "BebanJP"],
  "TAHUN_AJARAN": ["TAID", "Nama", "TanggalMulai", "TanggalSelesai", "Aktif"],
  "SEMESTER": ["SemesterID", "Nama", "TahunAjaranID", "Aktif"],
  "HARI_LIBUR": ["HariLiburID", "Tanggal", "Nama", "Jenis", "Keterangan"],
  "JADWAL": ["JadwalID", "Hari", "JamMulai", "JamSelesai", "KelasID", "MapelID", "GuruID", "TAID", "SemesterID", "Status", "CreatedAt", "UpdatedAt"],
  "AGENDA": ["AgendaID", "Tanggal", "GuruID", "MapelID", "KelasID", "Materi", "Pertemuan", "Metode", "Catatan", "Status", "CreatedAt", "UpdatedAt"],
  "NILAI": ["NilaiID", "SiswaID", "MapelID", "GuruID", "KelasID", "SemesterID", "TAID", "JenisNilai", "Nilai", "KKM", "Predikat", "Deskripsi", "TanggalInput", "CreatedAt", "UpdatedAt"],
  "RAPOR": ["RaporID", "SiswaID", "SemesterID", "TahunAjaranID", "RataRata", "Ranking", "NaikKelas", "CatatanWaliKelas", "TanggalCetak", "CreatedAt", "UpdatedAt"],
  "KENAIKAN_KELAS": ["KenaikanID", "SiswaID", "KelasAsalID", "KelasTujuanID", "SemesterID", "TahunAjaranID", "Status", "Keputusan", "Tanggal", "CreatedAt", "UpdatedAt"],
  "KELULUSAN": ["KelulusanID", "SiswaID", "NomorSKL", "TanggalLulus", "NilaiAkhir", "Predikat", "Status", "Keterangan", "CreatedAt", "UpdatedAt"],

  // 4. PRESENSI & QR CODE
  "ABSENSI": ["AbsenID", "Tanggal", "SiswaID", "KelasID", "JamMasuk", "JamPulang", "Status", "Keterangan", "Lokasi", "Latitude", "Longitude", "QRCode", "PetugasID", "CreatedAt", "UpdatedAt"],
  "ABSENSI_GURU": ["AbsenGuruID", "Tanggal", "GuruID", "JamMasuk", "JamPulang", "Status", "Lokasi", "Latitude", "Longitude", "Keterangan", "CreatedAt", "UpdatedAt"],
  "QR_LOG": ["QRLogID", "Tanggal", "UserID", "QRCode", "Latitude", "Longitude", "Device", "Browser", "Status", "Keterangan", "CreatedAt"],

  // 5. CBT & UJIAN ONLINE
  "BANK_SOAL": ["BankSoalID", "MapelID", "GuruID", "Bab", "SubBab", "Kompetensi", "Tingkat", "JenisSoal", "Soal", "PilihanA", "PilihanB", "PilihanC", "PilihanD", "PilihanE", "Jawaban", "Bobot", "Status", "CreatedAt", "UpdatedAt"],
  "UJIAN": ["UjianID", "NamaUjian", "MapelID", "KelasID", "GuruID", "Tanggal", "JamMulai", "JamSelesai", "Durasi", "JumlahSoal", "AcakSoal", "AcakJawaban", "Token", "Status", "CreatedAt", "UpdatedAt"],
  "TOKEN": ["TokenID", "UjianID", "Token", "Tanggal", "JamMulai", "JamSelesai", "Status", "CreatedAt"],
  "SOAL": ["DetailSoalID", "UjianID", "BankSoalID", "Nomor", "Bobot", "CreatedAt"],
  "JAWABAN": ["JawabanID", "UjianID", "SiswaID", "BankSoalID", "Jawaban", "Benar", "Nilai", "Tanggal", "CreatedAt"],
  "HASIL_UJIAN": ["HasilUjianID", "UjianID", "SiswaID", "Benar", "Salah", "Kosong", "Nilai", "Peringkat", "Durasi", "Status", "CreatedAt"],
  "ANALISIS_SOAL": ["AnalisisID", "BankSoalID", "JumlahPeserta", "Benar", "Salah", "PersentaseBenar", "PersentaseSalah", "TingkatKesukaran", "DayaPembeda", "CreatedAt"],

  // 6. SPMB & PENDAFTARAN
  "PENDAFTAR": ["PendaftarID", "NoPendaftaran", "Nama", "NIK", "NISN", "TempatLahir", "TanggalLahir", "JK", "Agama", "Alamat", "AsalSekolah", "Program", "Jalur", "NoHP", "Email", "Status", "TanggalDaftar", "CreatedAt", "UpdatedAt"],
  "BERKAS": ["BerkasID", "PendaftarID", "JenisBerkas", "NamaFile", "URL", "Status", "Verifikator", "TanggalUpload", "TanggalVerifikasi", "Catatan", "CreatedAt", "UpdatedAt"],
  "SELEKSI": ["SeleksiID", "PendaftarID", "NilaiAdministrasi", "NilaiTes", "NilaiWawancara", "NilaiTotal", "Status", "Keterangan", "Tanggal", "CreatedAt", "UpdatedAt"],
  "DAFTAR_ULANG": ["DaftarUlangID", "PendaftarID", "Tanggal", "PetugasID", "Nominal", "Status", "Keterangan", "CreatedAt", "UpdatedAt"],

  // 7. KEUANGAN, TAGIHAN & KAS
  "BIAYA": ["BiayaID", "KodeBiaya", "NamaBiaya", "Kategori", "Jenjang", "Target_Kelas", "KelasID", "Nominal", "Periode", "Wajib", "Status", "Keterangan", "CreatedAt", "UpdatedAt", "JurusanID"],
  "TAGIHAN": ["TagihanID", "InvoiceID", "SiswaID", "BiayaID", "TahunAjaranID", "SemesterID", "TanggalTagihan", "TanggalJatuhTempo", "Nominal", "Diskon", "Denda", "TotalTagihan", "TotalBayar", "SisaTagihan", "Status", "PetugasID", "CreatedAt", "UpdatedAt"],
  "PEMBAYARAN": ["PembayaranID", "TagihanID", "InvoiceID", "SiswaID", "Tanggal", "Nominal", "MetodePembayaran", "NoReferensi", "Bank", "PetugasID", "Keterangan", "Status", "CreatedAt", "UpdatedAt"],
  "TABUNGAN": ["TabunganID", "SiswaID", "Tanggal", "JenisTransaksi", "Debit", "Kredit", "Saldo", "PetugasID", "Keterangan", "Status", "CreatedAt", "UpdatedAt"],
  "KAS": ["KasID", "Tanggal", "Jenis", "Kategori", "Nominal", "Keterangan", "Referensi", "PetugasID", "Status", "CreatedAt", "UpdatedAt"],
  "PENGELUARAN": ["PengeluaranID", "Tanggal", "Kategori", "NamaPengeluaran", "Nominal", "Penerima", "MetodePembayaran", "Bukti", "PetugasID", "Keterangan", "Status", "CreatedAt", "UpdatedAt"],
  "INVOICE": ["InvoiceID", "NomorInvoice", "Tanggal", "SiswaID", "Total", "Diskon", "Denda", "GrandTotal", "Status", "TanggalBayar", "PetugasID", "CreatedAt", "UpdatedAt"],
  "JURNAL_UMUM": ["JurnalID", "Tanggal", "KodeAkun", "NamaAkun", "Keterangan", "Debit", "Kredit", "Referensi", "UserID", "CreatedAt", "UpdatedAt"],

  // 8. BK (BIMBINGAN KONSELING)
  "BIMBINGAN": ["BimbinganID", "Tanggal", "SiswaID", "GuruBKID", "JenisBimbingan", "Permasalahan", "Solusi", "TindakLanjut", "Status", "Catatan", "CreatedAt", "UpdatedAt"],
  "PELANGGARAN": ["PelanggaranID", "Tanggal", "SiswaID", "Kategori", "JenisPelanggaran", "Poin", "Sanksi", "GuruID", "Keterangan", "Status", "CreatedAt", "UpdatedAt"],

  // 9. PERPUSTAKAAN
  "BUKU": ["BukuID", "ISBN", "KodeBuku", "Judul", "Penulis", "Penerbit", "TahunTerbit", "Kategori", "Rak", "Jumlah", "Stok", "Status", "CreatedAt", "UpdatedAt"],
  "PEMINJAMAN": ["PeminjamanID", "BukuID", "SiswaID", "GuruID", "TanggalPinjam", "TanggalKembali", "TanggalPengembalian", "Status", "Denda", "PetugasID", "CreatedAt", "UpdatedAt"],
  "DENDA": ["DendaID", "PeminjamanID", "Tanggal", "Nominal", "Status", "TanggalBayar", "PetugasID", "Keterangan", "CreatedAt", "UpdatedAt"],

  // 10. SARPRAS & INVENTARIS
  "BARANG": ["BarangID", "KodeBarang", "NamaBarang", "Kategori", "Merk", "Tipe", "SerialNumber", "Jumlah", "Satuan", "Lokasi", "Kondisi", "Status", "CreatedAt", "UpdatedAt"],
  "PEMELIHARAAN": ["PemeliharaanID", "BarangID", "Tanggal", "Jenis", "Biaya", "Pelaksana", "Hasil", "Keterangan", "Status", "CreatedAt", "UpdatedAt"],
  "PEMINJAMAN_BARANG": ["PeminjamanBarangID", "BarangID", "Peminjam", "Unit", "TanggalPinjam", "TanggalKembali", "TanggalPengembalian", "Jumlah", "Status", "PetugasID", "CreatedAt", "UpdatedAt"],

  // 11. ARSIP & DOKUMEN
  "FILE": ["FileID", "Kategori", "Modul", "NamaFile", "NamaAsli", "URL", "Ukuran", "TipeFile", "UploadBy", "TanggalUpload", "Status", "Keterangan", "CreatedAt", "UpdatedAt"],
  "ARSIP": ["ArsipID", "Kategori", "NomorArsip", "Judul", "Tanggal", "Lokasi", "FileID", "Status", "Keterangan", "CreatedAt", "UpdatedAt"],

  // 12. DASHBOARD, BACKUP & KOMUNITAS
  "DASHBOARD_CACHE": ["DashboardID", "Tanggal", "TotalSiswa", "TotalGuru", "TotalKelas", "TotalMapel", "TotalHadir", "TotalIzin", "TotalSakit", "TotalAlpa", "TotalPendaftar", "TotalDiterima", "TotalTagihan", "TotalPembayaran", "TotalTabungan", "TotalKas", "TotalPengeluaran", "TotalBuku", "TotalBarang", "UserUpdate", "UpdatedAt"],
  "BACKUP": ["BackupID", "NamaBackup", "Tanggal", "Jam", "UkuranFile", "LokasiFile", "Jenis", "Status", "UserID", "Keterangan", "CreatedAt", "UpdatedAt"],
  "SUARA_KOMUNITAS": ["id", "nama", "peran", "teks", "status", "tanggal", "createdAt"],

  // 13. ALUMNI & LOG UJIAN
  "ALUMNI": ["Nama", "NISN", "Jenis Kelamin", "Kelas Terakhir", "Tahun Lulus", "Kontak"],
  "LOG_UJIAN": ["NO_LOG", "NISN", "NAMA_SISWA", "JENJANG", "KELAS", "STATUS", "Waktu", "Pelanggaran", "TOKEN", "ID_JADWAL"],
  "DRAFT_JAWABAN": ["timestamp", "examId", "username", "jawaban", "sisaWaktu"],

  // 14. FORM BUILDER, CMS & VALIDASI DAPODIK
  "FORM_FIELDS": ["key", "label", "type", "grid", "required", "show", "options"],
  "WEB_CONFIG": ["appName", "judulSidebar", "logoUrl", "heroImageUrl", "teksHero", "heroBaris1", "heroBaris2", "heroSubteks", "footerJudul", "footerAlamat", "footerTelepon", "footerEmail", "footerHakCipta", "linkFb", "linkIg", "linkYt", "pendaftaranStatus", "alur1_judul", "alur1_desc", "alur2_judul", "alur2_desc", "alur3_judul", "alur3_desc", "alur4_judul", "alur4_desc"],
  "SESSIONS": ["Token", "Identifier", "Role", "Expiry"],
  "DAPODIK_VALIDASI": ["ValidasiID", "SiswaID", "NISN", "NIK", "NoKK", "NamaSiswa", "NamaIbuKandung", "TanggalLahir", "StatusDapodik", "CatatanInvalid", "TglValidasi", "UpdatedAt"],

  // 15. ALUR SPMB MODEREN & DAFTAR ULANG
  "SPMB_PENDAFTAR": ["NoRegistrasi", "NamaCalonSiswa", "NISN", "JenisKelamin", "JalurMasuk", "StatusBerkas", "SkorSeleksi", "HasilKeputusan", "NoPDKT", "Kontak", "AsalSekolah", "Alamat", "TanggalDaftar"],
  "SPMB_VERIFIKASI": ["NoRegistrasi", "NamaCalonSiswa", "NISN", "StatusBerkas", "AktaKelahiran", "KartuKeluarga", "Ijazah", "KTPOrtu", "CatatanVerifikasi", "Verifikator", "TanggalVerifikasi"],
  "SPMB_SELEKSI": ["NoRegistrasi", "NamaCalonSiswa", "JalurMasuk", "NilaiAkademik", "NilaiWawancara", "NilaiPrestasi", "SkorSeleksi", "Ranking", "Rekomendasi", "StatusSeleksi"],
  "SPMB_PENGUMUMAN": ["NoRegistrasi", "NamaCalonSiswa", "NISN", "JalurMasuk", "SkorSeleksi", "HasilKeputusan", "NomorSK", "TanggalPengumuman"],
  "SPMB_DAFTAR_ULANG": ["NoRegistrasi", "NamaCalonSiswa", "NISN", "NoPDKT", "KelompokMPLS", "StatusDaftarUlang", "TanggalDaftarUlang", "UkuranSeragam", "Catatan"],

  // 16. MODUL TAMBAHAN APLIKASI
  "TUGAS": ["TugasID", "Judul", "Mapel", "Kelas", "Guru", "Tenggat", "Kategori", "Petunjuk", "Status", "CreatedAt", "UpdatedAt"],
  "PENGUMPULAN_TUGAS": ["PengumpulanID", "TugasID", "SiswaID", "NamaSiswa", "Kelas", "Status", "Nilai", "CatatanGuru", "FileUrl", "WaktuKumpul", "CreatedAt"],
  "PRESTASI_SISWA": ["PrestasiID", "SiswaID", "NamaSiswa", "Kelas", "NamaPrestasi", "Tingkat", "Peringkat", "Tahun", "Penyelenggara", "SertifikatUrl", "Status", "CreatedAt"],
  "SURAT_MASUK": ["SuratMasukID", "NoSurat", "Pengirim", "Perihal", "TanggalSurat", "TanggalDiterima", "FileUrl", "Status", "Disposisi", "CreatedAt"],
  "SURAT_KELUAR": ["SuratKeluarID", "NoSurat", "Tujuan", "Perihal", "TanggalSurat", "Penandatangan", "FileUrl", "Status", "Keterangan", "CreatedAt"],
  "YATIM_PIATU": ["YatimID", "NoPDKT", "NISN", "NamaSiswa", "Kelas", "StatusYatim", "NamaAyah", "StatusAyah", "NamaIbu", "StatusIbu", "NamaWali", "NoHPWali", "Alamat", "PenerimaKPS_PIP", "Keterangan", "CreatedAt", "UpdatedAt"]
};

// Fungsi helper membuka Spreadsheet target (berdasarkan ID atau active spreadsheet)
function getSpreadsheetInstance(payload, e) {
  var targetId = (payload && payload.spreadsheetId) || (e && e.parameter && e.parameter.spreadsheetId) || "1sT0_RCMEbLAfZVj3fTHXgWLHJBoKWKF-WdqbjbjzwLc";
  if (targetId && String(targetId).trim().length >= 20) {
    try {
      return SpreadsheetApp.openById(String(targetId).trim());
    } catch(err) {
      Logger.log("openById error: " + err);
    }
  }
  return SpreadsheetApp.getActiveSpreadsheet();
}

// Fungsi setup otomatis seluruh tabel master database lengkap
function setupMasterDatabase(ssOptional) {
  const ss = ssOptional || SpreadsheetApp.getActiveSpreadsheet();
  let createdCount = 0;
  let updatedCount = 0;

  const tableNames = Object.keys(MASTER_SCHEMAS);
  tableNames.forEach((sheetName) => {
    const headers = MASTER_SCHEMAS[sheetName];
    let sheet = ss.getSheetByName(sheetName);

    if (!sheet) {
      sheet = ss.insertSheet(sheetName);
      sheet.appendRow(headers);
      const headerRange = sheet.getRange(1, 1, 1, headers.length);
      headerRange.setFontWeight("bold");
      headerRange.setBackground("#1e293b");
      headerRange.setFontColor("#ffffff");
      sheet.setFrozenRows(1);
      sheet.autoResizeColumns(1, Math.min(headers.length, 25));
      createdCount++;
    } else {
      ensureHeaders(sheet, headers);
      updatedCount++;
    }
  });

  // Hapus Sheet1 default jika ada
  try {
    const defaultSheet = ss.getSheetByName("Sheet1");
    if (defaultSheet && ss.getSheets().length > 1) {
      ss.deleteSheet(defaultSheet);
    }
  } catch(e) {}

  // Pancing otorisasi Google Drive
  try { DriveApp.getRootFolder(); } catch(e) {}

  return { success: true, message: "Berhasil setup " + tableNames.length + " tabel master database lengkap!", total: tableNames.length, created: createdCount, updated: updatedCount };
}

function setup() {
  return setupMasterDatabase();
}

function ensureHeaders(sheet, standardHeaders) {
  const lastCol = Math.max(sheet.getLastColumn(), 1);
  let currentHeaders = sheet.getRange(1, 1, 1, lastCol).getValues()[0];
  
  if (!currentHeaders || !currentHeaders[0]) {
    sheet.getRange(1, 1, 1, standardHeaders.length).setValues([standardHeaders]);
    const headerRange = sheet.getRange(1, 1, 1, standardHeaders.length);
    headerRange.setFontWeight("bold").setBackground("#1e293b").setFontColor("#ffffff");
    sheet.setFrozenRows(1);
    return standardHeaders;
  }

  // 1. Perbaiki casing header agar persis sesuai standardHeaders
  let updated = false;
  let headers = currentHeaders.map(function(h) {
    if (!h) return '';
    const clean = String(h).trim();
    for (let k = 0; k < standardHeaders.length; k++) {
      if (standardHeaders[k].toLowerCase().replace(/[^a-z0-9]/g, '') === clean.toLowerCase().replace(/[^a-z0-9]/g, '')) {
        if (clean !== standardHeaders[k]) {
          updated = true;
          return standardHeaders[k];
        }
        return standardHeaders[k];
      }
    }
    return clean;
  });

  // 2. Tambahkan kolom standar baru yang belum ada di sheet
  standardHeaders.forEach(function(sh) {
    const shNormalized = sh.toLowerCase().replace(/[^a-z0-9]/g, '');
    const exists = headers.some(function(h) {
      return String(h).trim().toLowerCase().replace(/[^a-z0-9]/g, '') === shNormalized;
    });
    if (!exists) {
      headers.push(sh);
      updated = true;
    }
  });

  if (updated) {
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    const headerRange = sheet.getRange(1, 1, 1, headers.length);
    headerRange.setFontWeight("bold").setBackground("#1e293b").setFontColor("#ffffff");
    sheet.setFrozenRows(1);
  }
  return headers;
}

function doGet(e) {
  try {
    const ss = getSpreadsheetInstance(null, e);
    const action = (e && e.parameter && e.parameter.action) || "pull";
    const tableName = (e && e.parameter && e.parameter.table) || "SISWA";
    const callback = e && e.parameter && e.parameter.callback;

    if (action === "setup" || action === "setupDatabase" || action === "setupMasterDatabase") {
      const res = setupMasterDatabase(ss);
      return jsonResponse(res, callback);
    }

    if (action === "GET_ALL_SHEETS") {
      const result = {};
      const sheets = ss.getSheets();
      sheets.forEach(sh => {
        const name = sh.getName();
        result[name] = readSheetRecords(sh);
      });
      return jsonResponse({ status: "success", data: result, totalSheets: sheets.length }, callback);
    }

    if (action === "getTable" || action === "readTable") {
      const sheet = ss.getSheetByName(tableName) || ss.getSheetByName("Data" + tableName);
      if (!sheet) return jsonResponse({ error: "Sheet " + tableName + " tidak ditemukan." }, callback);
      const values = sheet.getDataRange().getDisplayValues();
      const records = [];
      if (values.length > 1) {
        const headers = values[0];
        for (let i = 1; i < values.length; i++) {
          const row = values[i];
          const obj = {};
          for (let j = 0; j < headers.length; j++) {
            if (headers[j]) obj[headers[j]] = row[j];
          }
          records.push(obj);
        }
      }
      return jsonResponse({ table: tableName, data: records, total: records.length }, callback);
    }

    // Default Full Pull (SISWA & GURU)
    return handlePullAll(ss, callback);

  } catch(err) {
    return jsonResponse({ error: err.toString() }, e && e.parameter && e.parameter.callback);
  }
}

function doPost(e) {
  try {
    const payload = JSON.parse(e.postData.contents);
    const ss = getSpreadsheetInstance(payload, null);
    
    if (payload.action === "upload") {
      return handleUpload(payload, ss);
    }

    if (payload.action === "setupDriveFolders" || payload.action === "setupFolders") {
      const res = setupDriveFolders(payload);
      return jsonResponse(res);
    }

    if (payload.action === "AUTO_POPULATE_ORTU_YATIM") {
      const res = autoPopulateOrangTuaAndYatimFromSiswa(ss);
      return jsonResponse(res);
    }

    if (payload.action === "setup" || payload.action === "setupDatabase" || payload.action === "setupMasterDatabase") {
      const res = setupMasterDatabase(ss);
      return jsonResponse(res);
    }

    if (payload.action === "MASS_SYNC_ALL") {
      const allData = typeof payload.allDataJson === "string" ? JSON.parse(payload.allDataJson) : (payload.allData || {});
      let syncedCount = 0;
      Object.keys(allData).forEach(tblName => {
        const recs = allData[tblName];
        if (Array.isArray(recs)) {
          let sheet = ss.getSheetByName(tblName);
          const headers = MASTER_SCHEMAS[tblName] || (recs.length > 0 ? Object.keys(recs[0]) : []);
          if (!sheet) {
            sheet = ss.insertSheet(tblName);
            sheet.appendRow(headers);
            sheet.setFrozenRows(1);
          }
          const curHeaders = ensureHeaders(sheet, headers);
          if (sheet.getLastRow() > 1) {
            sheet.getRange(2, 1, sheet.getLastRow() - 1, sheet.getLastColumn()).clearContent();
          }
          if (recs.length > 0) {
            const rows = recs.map(r => curHeaders.map(h => formatCellValue(getRecordValue(r, h, tblName))));
            sheet.getRange(2, 1, rows.length, curHeaders.length).setValues(rows);
          }
          syncedCount++;
        }
      });
      return jsonResponse({ success: true, message: "Berhasil menyingkronkan " + syncedCount + " tabel ke Google Sheets!" });
    }

    if (payload.action === "syncTable") {
      const tableName = payload.table;
      const records = payload.data || [];
      const headers = MASTER_SCHEMAS[tableName] || (records.length > 0 ? Object.keys(records[0]) : []);
      
      let sheet = ss.getSheetByName(tableName);
      if (!sheet) {
        sheet = ss.insertSheet(tableName);
        sheet.appendRow(headers);
        sheet.setFrozenRows(1);
      }
      
      const currentHeaders = ensureHeaders(sheet, headers);
      if (sheet.getLastRow() > 1) {
        sheet.getRange(2, 1, sheet.getLastRow() - 1, sheet.getLastColumn()).clearContent();
      }
      
      if (records.length > 0) {
        const rows = records.map(r => currentHeaders.map(h => formatCellValue(getRecordValue(r, h, tableName))));
        const targetRange = sheet.getRange(2, 1, rows.length, currentHeaders.length);
        targetRange.setNumberFormat("@");
        targetRange.setValues(rows);
      }
      return jsonResponse({ success: true, message: "Sinkronisasi tabel " + tableName + " berhasil (" + records.length + " data)!" });
    }

    if (payload.action === "sync") {
      return handleSyncAll(ss, payload);
    }

    if (payload.action === "pull") {
      return handlePullAll(ss);
    }

  } catch (error) {
    return jsonResponse({ error: error.toString() });
  }
}

function formatCellValue(val) {
  if (val === undefined || val === null) return "";
  if (typeof val === "object") {
    try { return JSON.stringify(val); } catch(e) { return String(val); }
  }
  const str = String(val).trim();
  // Cegah Google Sheets mengubah NIK (16 digit), NISN (10 digit), NoHP, dll menjadi format scientific exponential (3.201E+15)
  if (/^[0-9]{8,}$/.test(str) || /^0[0-9]{8,}$/.test(str)) {
    return "'" + str;
  }
  return str;
}

function getRecordValue(rec, headerName, tableName) {
  if (!rec) return "";
  if (rec[headerName] !== undefined && rec[headerName] !== null && String(rec[headerName]).trim() !== "") {
    return rec[headerName];
  }

  // Coba cari case-insensitive & tanpa spasi/simbol
  const hClean = String(headerName).toLowerCase().replace(/[^a-z0-9]/g, "");
  const keys = Object.keys(rec);
  for (let i = 0; i < keys.length; i++) {
    const k = keys[i];
    const kClean = k.toLowerCase().replace(/[^a-z0-9]/g, "");
    if (kClean === hClean) {
      if (rec[k] !== undefined && rec[k] !== null && String(rec[k]).trim() !== "") {
        return rec[k];
      }
    }
  }

  // Alias cerdas per entitas
  const tbl = (tableName || "").toUpperCase();

  // 1. SISWA
  if (tbl === "SISWA" || tbl === "DATASISWA") {
    if (hClean === "nopdkt" || hClean === "nis") return rec.nis || rec.id || rec.nopdkt || rec.NIS || "";
    if (hClean === "tahunmasuk") return rec.tahunMasuk || rec.TahunMasuk || rec["Tahun Masuk"] || rec.angkatan || "";
    if (hClean === "nisn") return rec.nisn || rec.NISN || "";
    if (hClean === "namalengkap" || hClean === "nama") return rec.name || rec.nama || rec.NamaLengkap || "";
    if (hClean === "jeniskelamin" || hClean === "jk") return rec.gender || rec.jenisKelamin || rec.JenisKelamin || "L";
    if (hClean === "tempatlahir") return rec.pob || rec.tempatLahir || rec.TempatLahir || "";
    if (hClean === "tanggallahir") return rec.dob || rec.tanggalLahir || rec.TanggalLahir || "";
    if (hClean === "nik") return rec.nik || rec.NIK || "";
    if (hClean === "anakke") return rec.anakKe || rec.AnakKe || "";
    if (hClean === "saudara") return rec.saudara || rec.Saudara || "";
    if (hClean === "agama") return rec.agama || rec.Agama || "Islam";
    if (hClean === "golongandarah") return rec.golonganDarah || rec.GolonganDarah || "";
    if (hClean === "tinggibadancm" || hClean === "tinggibadan") return rec.tinggiBadan || rec.TinggiBadan || "";
    if (hClean === "beratbadankg" || hClean === "beratbadan") return rec.beratBadan || rec.BeratBadan || "";
    if (hClean === "prestasi") return rec.prestasi || rec.Prestasi || "";
    if (hClean === "hobi") return rec.hobi || rec.Hobi || "";
    if (hClean === "catatanpenting") return rec.catatanPenting || rec.CatatanPenting || "";
    if (hClean === "alamat") return rec.address || rec.alamat || rec.Alamat || "";
    if (hClean === "rt") return rec.rt || "";
    if (hClean === "rw") return rec.rw || "";
    if (hClean === "kelurahan") return rec.kelurahan || "";
    if (hClean === "kecamatan") return rec.kecamatan || "";
    if (hClean === "kota") return rec.kota || "";
    if (hClean === "provinsi") return rec.provinsi || "";
    if (hClean === "kodepos") return rec.kodePos || "";
    if (hClean === "jenistinggal") return rec.jenisTinggal || "";
    if (hClean === "alattransportasi") return rec.alatTransportasi || "";
    if (hClean === "nomorhp" || hClean === "nohp") return rec.noHp || rec.phone || rec.NomorHP || rec.tlpAyah || rec.tlpIbu || "";
    if (hClean === "email") return rec.email || rec["E-Mail"] || "";
    if (hClean === "asalsekolah" || hClean === "sekolahasal") return rec.sekolahAsal || rec.AsalSekolah || "";
    if (hClean === "skhun") return rec.skhun || rec.SKHUN || "";
    if (hClean === "penerimakps") return rec.penerimaKps || (rec.isKps ? "Ya" : "Tidak");
    if (hClean === "pasfoto" || hClean === "foto") return rec.fotoUrl || rec.pasFoto || rec.PasFoto || "";
    if (hClean === "nomorkartukeluarga" || hClean === "nokk") return rec.noKk || rec.NomorKartuKeluarga || "";
    if (hClean === "namaayah") return rec.namaAyah || rec.parentName || rec.fatherName || rec.NamaAyah || "";
    if (hClean === "nikayah") return rec.nikAyah || rec.NIKAyah || "";
    if (hClean === "tempatlahirayah") return rec.tempatLahirAyah || rec.TempatLahirAyah || "";
    if (hClean === "tanggallahirayah") return rec.tanggalLahirAyah || rec.TanggalLahirAyah || "";
    if (hClean === "pendidikanayah") return rec.pendidikanAyah || rec.PendidikanAyah || "";
    if (hClean === "pekerjaanayah") return rec.pekerjaanAyah || rec.fatherJob || rec.PekerjaanAyah || "";
    if (hClean === "penghasilanayah") return rec.penghasilanAyah || rec.PenghasilanAyah || "";
    if (hClean === "tlpayah") return rec.tlpAyah || rec.TlpAyah || "";
    if (hClean === "statusayah") return rec.statusAyah || rec.StatusAyah || "Masih Hidup";
    if (hClean === "namaibu") return rec.namaIbu || rec.NamaIbu || rec.NamaIbu || "";
    if (hClean === "nikibu") return rec.nikIbu || rec.NIKIbu || "";
    if (hClean === "tempatlahiribu") return rec.tempatLahirIbu || rec.TempatLahirIbu || "";
    if (hClean === "tanggallahiribu") return rec.tanggalLahirIbu || rec.TanggalLahirIbu || "";
    if (hClean === "pendidikanibu") return rec.pendidikanIbu || rec.PendidikanIbu || "";
    if (hClean === "pekerjaanibu") return rec.pekerjaanIbu || rec.motherJob || rec.PekerjaanIbu || "";
    if (hClean === "penghasilanibu") return rec.penghasilanIbu || rec.PenghasilanIbu || "";
    if (hClean === "tlpibu") return rec.tlpIbu || rec.TlpIbu || "";
    if (hClean === "statusibu") return rec.statusIbu || rec.StatusIbu || "Masih Hidup";
    if (hClean === "statusyatim") {
      if (rec.statusYatim) return rec.statusYatim;
      if (rec.StatusYatim) return rec.StatusYatim;
      const aDead = (rec.statusAyah && (rec.statusAyah.toLowerCase().includes("meninggal") || rec.statusAyah.toLowerCase().includes("almarhum")));
      const iDead = (rec.statusIbu && (rec.statusIbu.toLowerCase().includes("meninggal") || rec.statusIbu.toLowerCase().includes("almarhumah")));
      if (aDead && iDead) return "Yatim Piatu";
      if (aDead) return "Yatim";
      if (iDead) return "Piatu";
      return "Lengkap";
    }
    if (hClean === "namawali") return rec.namaWali || rec.NamaWali || "";
    if (hClean === "tempatlahirwali") return rec.tempatLahirWali || rec.TempatLahirWali || "";
    if (hClean === "tgllahirwali" || hClean === "tanggallahirwali") return rec.tglLahirWali || rec.TglLahirWali || "";
    if (hClean === "pendidikanwali") return rec.pendidikanWali || rec.PendidikanWali || "";
    if (hClean === "pekerjaanwali") return rec.pekerjaanWali || rec.PekerjaanWali || "";
    if (hClean === "penghasilanwali") return rec.penghasilanWali || rec.PenghasilanWali || "";
    if (hClean === "hubungan" || hClean === "hubunganwali") return rec.hubunganWali || rec.Hubungan || "";
    if (hClean === "tlpwali") return rec.tlpWali || rec.parentPhone || rec["Tlp.Wali"] || "";
    if (hClean === "aktakelahiran") return rec.aktaKelahiranUrl || rec.akteUrl || rec.AktaKelahiran || "";
    if (hClean === "kartukeluarga") return rec.kartuKeluargaUrl || rec.kkUrl || rec.KartuKeluarga || "";
    if (hClean === "kia") return rec.kiaUrl || rec.ktpAnakUrl || rec.KIA || "";
    if (hClean === "ktpayah") return rec.ktpAyahUrl || rec.KTPAyah || "";
    if (hClean === "ktpibu") return rec.ktpIbuUrl || rec.KTPIbu || "";
    if (hClean === "ijazah") return rec.ijazahUrl || rec.Ijazah || "";
    if (hClean === "ktpwali") return rec.ktpWaliUrl || rec.KTPWali || "";
    if (hClean === "rapor") return rec.raporUrl || rec.rapotUrl || rec.Rapor || "";
    if (hClean === "spindah") return rec.suratPindahUrl || rec["S.Pindah"] || "";
    if (hClean === "suket") return rec.suKetUrl || rec.dokumenLainUrl || rec.SuKet || "";
    if (hClean === "sdomisili") return rec.suratDomisiliUrl || rec["S.Domisili"] || "";
    if (hClean === "status") return rec.status || rec.Status || "Aktif";
    if (hClean === "kelassaatini" || hClean === "kelas") return rec.class || rec.kelas || rec.Kelas || rec.kelasSaatIni || "1A";
  }

  // 1.5. ORANG_TUA
  if (tbl === "ORANG_TUA" || tbl === "ORANGTUA" || tbl === "DATAORANGTUA") {
    if (hClean === "ortuid") return rec.OrtuID || rec.ortuId || rec.id || "";
    if (hClean === "siswaid") return rec.SiswaID || rec.siswaId || rec.studentId || rec.nisn || rec.nis || "";
    if (hClean === "hubungan") return rec.Hubungan || rec.hubungan || rec.relation || rec.relationType || "Orang Tua";
    if (hClean === "nama") return rec.Nama || rec.nama || rec.parentName || rec.name || "";
    if (hClean === "nik") return rec.NIK || rec.nik || "-";
    if (hClean === "pekerjaan") return rec.Pekerjaan || rec.pekerjaan || rec.job || "-";
    if (hClean === "nohp") return rec.NoHP || rec.noHp || rec.phone || "-";
    if (hClean === "alamat") return rec.Alamat || rec.alamat || rec.address || "-";
  }

  // 1.6. YATIM_PIATU
  if (tbl === "YATIM_PIATU" || tbl === "YATIMPIATU" || tbl === "YATIM") {
    if (hClean === "yatimid") return rec.YatimID || rec.yatimId || rec.id || "";
    if (hClean === "nopdkt") return rec.NoPDKT || rec.noPdkt || rec.siswaId || rec.nis || "";
    if (hClean === "nisn") return rec.NISN || rec.nisn || "-";
    if (hClean === "namasiswa") return rec.NamaSiswa || rec.namaSiswa || rec.name || rec.nama || "";
    if (hClean === "kelas") return rec.Kelas || rec.kelas || rec.class || "-";
    if (hClean === "statusyatim") return rec.StatusYatim || rec.statusYatim || "Lengkap";
    if (hClean === "namaayah") return rec.NamaAyah || rec.namaAyah || rec.fatherName || "-";
    if (hClean === "statusayah") return rec.StatusAyah || rec.statusAyah || "Masih Hidup";
    if (hClean === "namaibu") return rec.NamaIbu || rec.namaIbu || rec.NamaIbu || "-";
    if (hClean === "statusibu") return rec.StatusIbu || rec.statusIbu || "Masih Hidup";
    if (hClean === "namawali") return rec.NamaWali || rec.namaWali || "-";
    if (hClean === "nohpwali") return rec.NoHPWali || rec.noHpWali || rec.parentPhone || rec.phone || "-";
    if (hClean === "alamat") return rec.Alamat || rec.alamat || rec.address || "-";
    if (hClean === "penerimakps_pip" || hClean === "penerimakps") return rec.PenerimaKPS_PIP || rec.penerimaKps || "Tidak";
    if (hClean === "keterangan") return rec.Keterangan || rec.keterangan || "-";
  }

  // 2. GURU
  if (tbl === "GURU" || tbl === "DATAGURU") {
    if (hClean === "guruid") return rec.id || rec.guruId || rec.GuruID || "";
    if (hClean === "nik") return rec.nik || rec.NIK || "";
    if (hClean === "nip") return rec.nip || rec.NIP || "";
    if (hClean === "nuptk") return rec.nuptk || rec.NUPTK || "";
    if (hClean === "nama") return rec.name || rec.nama || rec.Nama || rec.NamaLengkap || "";
    if (hClean === "gelar") return rec.gelar || rec.Gelar || "";
    if (hClean === "jeniskelamin") return rec.gender || rec.jenisKelamin || rec.JenisKelamin || "L";
    if (hClean === "tempatlahir") return rec.tempatLahir || rec.pob || rec.TempatLahir || "";
    if (hClean === "tanggallahir") return rec.tanggalLahir || rec.dob || rec.TanggalLahir || "";
    if (hClean === "agama") return rec.agama || rec.Agama || "Islam";
    if (hClean === "alamat") return rec.alamat || rec.address || rec.Alamat || "";
    if (hClean === "nohp") return rec.phone || rec.noHp || rec.NoHP || "";
    if (hClean === "email") return rec.email || rec.Email || "";
    if (hClean === "jabatan") return rec.class || rec.jabatan || rec.Jabatan || "None";
    if (hClean === "statuskepegawaian") return rec.statusKepegawaian || rec.StatusKepegawaian || "Tetap";
    if (hClean === "pendidikan") return rec.pendidikan || rec.Pendidikan || "S1";
    if (hClean === "jurusan") return rec.jurusan || rec.Jurusan || "";
    if (hClean === "tmt") return rec.tmt || rec.TMT || "";
    if (hClean === "status") return rec.status || rec.Status || "Aktif";
    if (hClean === "foto") return rec.fotoUrl || rec.foto || rec.Foto || "";
  }

  // 3. KELAS
  if (tbl === "KELAS") {
    if (hClean === "kelasid") return rec.id || rec.kelasId || rec.KelasID || rec.cls || "";
    if (hClean === "namakelas") return rec.name || rec.namaKelas || rec.NamaKelas || rec.cls || "";
    if (hClean === "jenjangid") return rec.jenjangId || rec.jenjangID || rec.JenjangID || "";
    if (hClean === "tingkat") return rec.tingkat || rec.Tingkat || "";
    if (hClean === "walikelasid") return rec.waliKelasId || rec.WaliKelasID || rec.guruId || "";
    if (hClean === "namatutor" || hClean === "walikelas") return rec.namatutor || rec.namaTutor || rec.wali || rec.WaliKelas || "";
    if (hClean === "ruangan") return rec.ruangan || rec.Ruangan || "";
    if (hClean === "status") return rec.status || rec.Status || "AKTIF";
  }

  // 4. MAPEL
  if (tbl === "MAPEL") {
    if (hClean === "mapelid") return rec.id || rec.mapelId || rec.MapelID || rec.kode || "";
    if (hClean === "kode") return rec.code || rec.kode || rec.Kode || rec.mapelId || "";
    if (hClean === "namamapel") return rec.name || rec.namaMapel || rec.nama || rec.NamaMapel || "";
    if (hClean === "kkm") return rec.kkm || rec.KKM || 75;
    if (hClean === "guruid") return rec.guruId || rec.guru || rec.GuruID || "";
    if (hClean === "kelompok") return rec.kelompok || rec.kategori || rec.Kelompok || "Wajib Nasional";
    if (hClean === "status") return rec.status || rec.Status || "AKTIF";
    if (hClean === "jenjang") return rec.jenjang || rec.Jenjang || "";
    if (hClean === "kelas") return rec.kelas || rec.Kelas || "";
    if (hClean === "gurupengampu") return rec.guruPengampu || rec.guru || rec.namatutor || rec.GuruPengampu || "";
    if (hClean === "bebanjp" || hClean === "jp") return rec.bebanJP || rec.jp || rec.BebanJP || 2;
  }

  // 4b. TAHUN AJARAN & SEMESTER & HARI LIBUR
  if (tbl === "TAHUN_AJARAN") {
    if (hClean === "tahunid" || hClean === "id") return rec.id || rec.tahunId || rec.TahunID || "";
    if (hClean === "tahun" || hClean === "tahunajaran") return rec.tahun || rec.tahunAjaran || rec.name || "";
    if (hClean === "semester") return rec.semester || rec.Semester || "Ganjil & Genap";
    if (hClean === "status") return rec.status || rec.Status || "AKTIF";
    if (hClean === "kurikulum") return rec.kurikulum || rec.Kurikulum || "Kurikulum Merdeka";
  }
  if (tbl === "SEMESTER") {
    if (hClean === "semesterid" || hClean === "id") return rec.id || rec.semesterId || rec.SemesterID || "";
    if (hClean === "namasemester" || hClean === "nama") return rec.nama || rec.namaSemester || rec.name || "";
    if (hClean === "tahunajaran" || hClean === "tahun") return rec.tahunAjaran || rec.tahun || "";
    if (hClean === "status") return rec.status || rec.Status || "NONAKTIF";
  }
  if (tbl === "HARI_LIBUR") {
    if (hClean === "liburid" || hClean === "id") return rec.id || rec.liburId || rec.LiburID || "";
    if (hClean === "tanggal" || hClean === "tgl") return rec.tanggal || rec.tgl || rec.date || "";
    if (hClean === "agenda" || hClean === "keterangan") return rec.agenda || rec.keterangan || rec.name || "";
    if (hClean === "jenis" || hClean === "kategori") return rec.jenis || rec.kategori || "Nasional";
  }
  if (tbl === "BIAYA" || tbl === "TARIF") {
    if (hClean.includes("id")) return rec.id || rec.tarifId || rec.biayaId || rec.TarifID || "";
    if (hClean === "namapos" || hClean === "namabiaya") return rec.namaPos || rec.nama || rec.name || rec.NamaPos || "";
    if (hClean === "nominal") return rec.nominal || rec.jumlah || rec.Nominal || 0;
    if (hClean === "kategori") return rec.kategori || rec.Kategori || "Operasional";
    if (hClean === "targetkelas" || hClean === "kelas") return rec.targetKelas || rec.kelas || rec.Target_Kelas || "Semua Kelas";
  }

  // 5. NILAI / RAPOR
  if (tbl === "NILAI") {
    if (hClean === "nilaiid") return rec.id || rec.nilaiId || rec.NilaiID || "";
    if (hClean === "siswaid") return rec.siswaId || rec.nisn || rec.nis || rec.SiswaID || "";
    if (hClean === "mapelid") return rec.mapelId || rec.mapel || rec.MapelID || "";
    if (hClean === "nilai") return rec.nilai || rec.score || rec.Nilai || 0;
  }

  // 6. ABSENSI
  if (tbl === "ABSENSI") {
    if (hClean === "absenid") return rec.id || rec.absenId || rec.AbsenID || "";
    if (hClean === "tanggal") return rec.tanggal || rec.date || rec.Tanggal || "";
    if (hClean === "siswaid") return rec.siswaId || rec.nisn || rec.nis || rec.SiswaID || "";
    if (hClean === "status") return rec.status || rec.Status || "Hadir";
  }

  // 7. KEUANGAN / TAGIHAN / PEMBAYARAN / TABUNGAN / KAS / BIAYA / PENGELUARAN
  if (tbl === "TAGIHAN") {
    if (hClean === "tagihanid" || hClean === "id") return rec.id || rec.tagihanId || rec.TagihanID || "";
    if (hClean === "invoiceid") return rec.invoiceId || rec.InvoiceID || "";
    if (hClean === "siswaid") return rec.siswaId || rec.studentId || rec.nisn || rec.nis || rec.SiswaID || "";
    if (hClean === "namasiswa" || hClean === "namalengkap") return rec.studentName || rec.namaSiswa || rec.name || rec.NamaSiswa || rec["Nama Siswa"] || "";
    if (hClean === "kelasid" || hClean === "kelas") return rec.kelasId || rec.studentClass || rec.class || rec.kelas || rec.KelasID || "";
    if (hClean === "biayaid") return rec.biayaId || rec.BiayaID || "";
    if (hClean === "namabiaya" || hClean === "namapos") return rec.namaBiaya || rec.namaPos || rec.NamaBiaya || "";
    if (hClean === "tahunajaranid" || hClean === "tahunajaran") return rec.tahunAjaranId || rec.tahunAjaran || rec.TahunAjaranID || "";
    if (hClean === "semesterid" || hClean === "semester") return rec.semesterId || rec.semester || rec.SemesterID || "";
    if (hClean === "tanggaltagihan" || hClean === "periode" || hClean === "tanggal") return rec.periode || rec.tanggalTagihan || rec.TanggalTagihan || rec.createdAt || "";
    if (hClean === "tanggaljatuhtempo" || hClean === "jatuhtempo") return rec.jatuhTempo || rec.tanggalJatuhTempo || rec.TanggalJatuhTempo || "";
    if (hClean === "nominal") return rec.nominal || rec.amount || rec.Nominal || 0;
    if (hClean === "diskon") return rec.diskon || rec.Diskon || 0;
    if (hClean === "denda") return rec.denda || rec.Denda || 0;
    if (hClean === "totaltagihan") return rec.totalTagihan || rec.nominal || rec.TotalTagihan || 0;
    if (hClean === "totalbayar" || hClean === "paidamount") return rec.paidAmount || rec.totalBayar || rec.TotalBayar || 0;
    if (hClean === "sisatagihan" || hClean === "remainingamount") return rec.remainingAmount || rec.sisaTagihan || rec.SisaTagihan || 0;
    if (hClean === "status") return rec.status || rec.Status || "BELUM";
    if (hClean === "petugasid" || hClean === "paidby") return rec.paidBy || rec.petugasId || rec.PetugasID || "";
  }

  if (tbl === "PEMBAYARAN" || tbl === "INVOICE") {
    if (hClean === "pembayaranid" || hClean === "id") return rec.id || rec.pembayaranId || rec.PembayaranID || "";
    if (hClean === "tagihanid") return rec.tagihanId || rec.TagihanID || "";
    if (hClean === "invoiceid" || hClean === "nomorinvoice") return rec.invoiceId || rec.nomorInvoice || rec.InvoiceID || rec.NomorInvoice || "";
    if (hClean === "siswaid") return rec.siswaId || rec.studentId || rec.nisn || rec.nis || rec.SiswaID || "";
    if (hClean === "namasiswa" || hClean === "namalengkap") return rec.studentName || rec.namaSiswa || rec.name || rec["Nama Siswa"] || rec.NamaSiswa || "";
    if (hClean === "kelasid" || hClean === "kelas") return rec.kelasId || rec.studentClass || rec.class || rec.kelas || rec.KelasID || "";
    if (hClean === "tanggal" || hClean === "tglbayar") return rec.tglBayar || rec.tanggal || rec.Tanggal || rec.createdAt || "";
    if (hClean === "nominal" || hClean === "total" || hClean === "grandtotal") return rec.total || rec.nominal || rec.grandTotal || rec.Nominal || 0;
    if (hClean === "metodepembayaran" || hClean === "metode") return rec.metode || rec.metodePembayaran || rec.MetodePembayaran || "CASH";
    if (hClean === "noreferensi") return rec.noReferensi || rec.NoReferensi || "-";
    if (hClean === "bank") return rec.bank || rec.Bank || "-";
    if (hClean === "petugasid" || hClean === "createdby") return rec.createdBy || rec.petugasId || rec.PetugasID || "";
    if (hClean === "keterangan") return rec.keterangan || rec.catatan || rec.Keterangan || "";
    if (hClean === "status") return rec.status || rec.Status || "PAID";
  }

  if (tbl === "TABUNGAN") {
    if (hClean === "tabunganid" || hClean === "id") return rec.id || rec.tabunganId || rec.TabunganID || "";
    if (hClean === "siswaid") return rec.siswaId || rec.studentId || rec.nisn || rec.nis || rec.SiswaID || "";
    if (hClean === "namasiswa" || hClean === "namalengkap") return rec.studentName || rec.namaSiswa || rec.name || rec["NAMA SISWA"] || rec.NamaSiswa || "";
    if (hClean === "kelas") return rec.studentClass || rec.class || rec.kelas || rec.KELAS || "";
    if (hClean === "tanggal") return rec.tanggal || rec.Tanggal || "";
    if (hClean === "jenistransaksi" || hClean === "jenis") return rec.jenis || rec.jenisTransaksi || rec.JenisTransaksi || "SETOR";
    if (hClean === "debit") return rec.debit || (rec.jenis === "SETOR" ? rec.nominal : 0) || rec.Debit || 0;
    if (hClean === "kredit") return rec.kredit || (rec.jenis === "TARIK" ? rec.nominal : 0) || rec.Kredit || 0;
    if (hClean === "nominal") return rec.nominal || rec.Debit || rec.Kredit || 0;
    if (hClean === "saldo" || hClean === "saldosetelah") return rec.saldoSetelah || rec.saldo || rec.Saldo || 0;
    if (hClean === "petugasid") return rec.petugasId || rec.PetugasID || "";
    if (hClean === "keterangan") return rec.keterangan || rec.Keterangan || "";
    if (hClean === "status") return rec.status || rec.Status || "SUCCESS";
  }

  if (tbl === "KAS" || tbl === "PENGELUARAN") {
    if (hClean.includes("id")) return rec.id || rec.kasId || rec.pengeluaranId || "";
    if (hClean === "tanggal") return rec.tanggal || rec.date || rec.Tanggal || "";
    if (hClean === "jenis") return rec.jenis || rec.Jenis || "MASUK";
    if (hClean === "kategori") return rec.kategori || rec.Kategori || "Operasional";
    if (hClean === "namapengeluaran") return rec.namaPengeluaran || rec.nama || rec.NamaPengeluaran || "";
    if (hClean === "nominal") return rec.nominal || rec.amount || rec.jumlah || rec.Nominal || 0;
    if (hClean === "penerima") return rec.penerima || rec.Penerima || "-";
    if (hClean === "metodepembayaran") return rec.metodePembayaran || rec.metode || rec.MetodePembayaran || "Tunai";
    if (hClean === "keterangan") return rec.keterangan || rec.catatan || rec.Keterangan || "";
    if (hClean === "petugasid" || hClean === "petugas") return rec.petugas || rec.petugasId || rec.PetugasID || "";
    if (hClean === "status") return rec.status || rec.Status || "Aktif";
  }

  if (tbl === "SETTING") {
    if (hClean === "key") return rec.Key || rec.key || "";
    if (hClean === "value") return rec.Value || rec.value || "";
  }

  // 8. SPMB
  if (tbl.includes("SPMB") || tbl === "PENDAFTAR") {
    if (hClean === "noregistrasi" || hClean === "pendaftarid") return rec.noRegistrasi || rec.id || rec.pendaftarId || rec.NoRegistrasi || "";
    if (hClean === "namacalonsiswa" || hClean === "nama") return rec.name || rec.nama || rec.namaCalonSiswa || rec.NamaCalonSiswa || "";
    if (hClean === "nisn") return rec.nisn || rec.NISN || "";
    if (hClean === "asalsekolah") return rec.asalSekolah || rec.AsalSekolah || "";
  }

  // 9. SARPRAS / PERPUS / BK / SURAT
  if (tbl === "BARANG") {
    if (hClean === "barangid") return rec.id || rec.barangId || rec.BarangID || "";
    if (hClean === "namabarang") return rec.name || rec.namaBarang || rec.nama || rec.NamaBarang || "";
  }
  if (tbl === "BUKU") {
    if (hClean === "bukuid") return rec.id || rec.bukuId || rec.BukuID || "";
    if (hClean === "judul") return rec.judul || rec.title || rec.name || rec.Judul || "";
  }
  if (tbl === "BIMBINGAN" || tbl === "PELANGGARAN") {
    if (hClean.includes("id")) return rec.id || rec.bimbinganId || rec.pelanggaranId || "";
  }
  if (tbl === "SURAT_MASUK" || tbl === "SURAT_KELUAR") {
    if (hClean.includes("id")) return rec.id || rec.suratMasukId || rec.suratKeluarId || "";
    if (hClean === "nosurat") return rec.noSurat || rec.nomorSurat || rec.NoSurat || "";
  }
  if (tbl === "PRESTASI_SISWA") {
    if (hClean === "prestasiid") return rec.id || rec.prestasiId || rec.PrestasiID || "";
    if (hClean === "namaprestasi") return rec.namaPrestasi || rec.name || rec.NamaPrestasi || "";
  }

  return "";
}

function handlePullAll(ss, callback) {
  // Siswa sheet (bisa bernama SISWA atau DataSiswa)
  let sheetSiswa = ss.getSheetByName("SISWA") || ss.getSheetByName("DataSiswa");
  let sheetGuru = ss.getSheetByName("GURU") || ss.getSheetByName("DataGuru");
  
  if (!sheetSiswa || !sheetGuru) {
    setupMasterDatabase(ss);
    sheetSiswa = ss.getSheetByName("SISWA") || ss.getSheetByName("DataSiswa");
    sheetGuru = ss.getSheetByName("GURU") || ss.getSheetByName("DataGuru");
  }

  const students = readSheetRecords(sheetSiswa, "SISWA");
  const teachers = readSheetRecords(sheetGuru, "GURU");

  return jsonResponse({
    data: students,
    students: students,
    teachers: teachers
  }, callback);
}

function handleSyncAll(ss, payload) {
  let sheetSiswa = ss.getSheetByName("SISWA") || ss.getSheetByName("DataSiswa");
  let sheetGuru = ss.getSheetByName("GURU") || ss.getSheetByName("DataGuru");

  if (!sheetSiswa || !sheetGuru) {
    setupMasterDatabase(ss);
    sheetSiswa = ss.getSheetByName("SISWA") || ss.getSheetByName("DataSiswa");
    sheetGuru = ss.getSheetByName("GURU") || ss.getSheetByName("DataGuru");
  }

  // 1. Sync Siswa
  const records = payload.data || payload.students;
  if (records && sheetSiswa) {
    const defaultHeaders = MASTER_SCHEMAS["SISWA"];
    const headers = ensureHeaders(sheetSiswa, defaultHeaders);
    if (sheetSiswa.getLastRow() > 1) {
      sheetSiswa.getRange(2, 1, sheetSiswa.getLastRow() - 1, sheetSiswa.getLastColumn()).clearContent();
    }
    if (records.length > 0) {
      const rows = records.map(r => headers.map(h => formatCellValue(getRecordValue(r, h, "SISWA"))));
      sheetSiswa.getRange(2, 1, rows.length, headers.length).setValues(rows);
    }
  }

  // Otomatis sinkronkan sheet ORANG_TUA dan YATIM_PIATU saat data SISWA berubah
  try {
    if (typeof autoPopulateOrangTuaAndYatimFromSiswa === 'function') {
      autoPopulateOrangTuaAndYatimFromSiswa();
    }
  } catch (ePop) {
    // Abaikan jika belum tersedia
  }

  // 2. Sync Guru
  const teachers = payload.teachers;
  if (teachers && sheetGuru) {
    const defaultGuruHeaders = MASTER_SCHEMAS["GURU"];
    const headers = ensureHeaders(sheetGuru, defaultGuruHeaders);
    if (sheetGuru.getLastRow() > 1) {
      sheetGuru.getRange(2, 1, sheetGuru.getLastRow() - 1, sheetGuru.getLastColumn()).clearContent();
    }
    if (teachers.length > 0) {
      const rows = teachers.map(t => headers.map(h => formatCellValue(getRecordValue(t, h, "GURU"))));
      sheetGuru.getRange(2, 1, rows.length, headers.length).setValues(rows);
    }
  }

  return jsonResponse({ success: true, message: "Sinkronisasi Master Seluruh Tabel Database Berhasil!" });
}

function readSheetRecords(sheet, optionalTableName) {
  if (!sheet) return [];
  const displayValues = sheet.getDataRange().getDisplayValues();
  const records = [];
  if (displayValues.length > 1) {
    const headers = displayValues[0];
    const sheetName = (optionalTableName || sheet.getName() || "").toUpperCase();

    for (let i = 1; i < displayValues.length; i++) {
      const row = displayValues[i];
      // Skip totally empty rows
      if (row.every(c => !c || String(c).trim() === "")) continue;

      const obj = {};
      for (let j = 0; j < headers.length; j++) {
        const headerName = headers[j];
        if (headerName) {
          const val = row[j] !== undefined && row[j] !== null ? String(row[j]).trim() : '';
          obj[headerName] = val;
          
          const hLower = headerName.toLowerCase().replace(/[^a-z0-9]/g, '');
          
          // Bidirectional mapping kembali ke format universal
          if (sheetName.includes("SISWA")) {
            if (hLower === "nopdkt" || hLower === "nis" || hLower === "id") { obj["id"] = val; obj["nis"] = val; obj["nopdkt"] = val; }
            else if (hLower === "tahunmasuk" || hLower === "thnmasuk" || hLower === "tahunangkatan" || hLower === "angkatan") { obj["tahunMasuk"] = val; obj["TahunMasuk"] = val; }
            else if (hLower === "nisn") { obj["nisn"] = val; obj["NISN"] = val; }
            else if (hLower === "namalengkap" || hLower === "nama") { obj["name"] = val; obj["NamaLengkap"] = val; }
            else if (hLower === "jeniskelamin" || hLower === "jk") { obj["gender"] = val; obj["JenisKelamin"] = val; }
            else if (hLower === "tempatlahir") { obj["pob"] = val; obj["tempatLahir"] = val; }
            else if (hLower === "tanggallahir") { obj["dob"] = val; obj["tanggalLahir"] = val; }
            else if (hLower === "nik") obj["nik"] = val;
            else if (hLower === "anakke") obj["anakKe"] = val;
            else if (hLower === "saudara") obj["saudara"] = val;
            else if (hLower === "agama") obj["agama"] = val;
            else if (hLower === "golongandarah") obj["golonganDarah"] = val;
            else if (hLower === "tinggibadancm" || hLower === "tinggibadan") obj["tinggiBadan"] = val;
            else if (hLower === "beratbadankg" || hLower === "beratbadan") obj["beratBadan"] = val;
            else if (hLower === "prestasi") obj["prestasi"] = val;
            else if (hLower === "hobi") obj["hobi"] = val;
            else if (hLower === "catatanpenting") obj["catatanPenting"] = val;
            else if (hLower === "alamat") { obj["address"] = val; obj["alamat"] = val; }
            else if (hLower === "rt") obj["rt"] = val;
            else if (hLower === "rw") obj["rw"] = val;
            else if (hLower === "kelurahan") obj["kelurahan"] = val;
            else if (hLower === "kecamatan") obj["kecamatan"] = val;
            else if (hLower === "kota") obj["kota"] = val;
            else if (hLower === "provinsi") obj["provinsi"] = val;
            else if (hLower === "kodepos") obj["kodePos"] = val;
            else if (hLower === "jenistinggal") obj["jenisTinggal"] = val;
            else if (hLower === "alattransportasi") obj["alatTransportasi"] = val;
            else if (hLower === "nohp" || hLower === "nomorhp" || hLower === "phone") obj["noHp"] = val;
            else if (hLower === "email") obj["email"] = val;
            else if (hLower === "sekolahasal" || hLower === "asalsekolah") obj["sekolahAsal"] = val;
            else if (hLower === "skhun") obj["skhun"] = val;
            else if (hLower === "penerimakps") obj["penerimaKps"] = val;
            else if (hLower === "pasfoto" || hLower === "foto") { obj["fotoUrl"] = val; obj["pasFoto"] = val; }
            else if (hLower === "nokk" || hLower === "nomorkartukeluarga") obj["noKk"] = val;
            else if (hLower === "namaayah") { obj["namaAyah"] = val; if (!obj["parentName"]) obj["parentName"] = val; }
            else if (hLower === "nikayah") obj["nikAyah"] = val;
            else if (hLower === "tempatlahirayah") obj["tempatLahirAyah"] = val;
            else if (hLower === "tanggallahirayah") obj["tanggalLahirAyah"] = val;
            else if (hLower === "pendidikanayah") obj["pendidikanAyah"] = val;
            else if (hLower === "pekerjaanayah") obj["pekerjaanAyah"] = val;
            else if (hLower === "penghasilanayah") obj["penghasilanAyah"] = val;
            else if (hLower === "tlpayah") obj["tlpAyah"] = val;
            else if (hLower === "statusayah") obj["statusAyah"] = val;
            else if (hLower === "namaibu") obj["namaIbu"] = val;
            else if (hLower === "nikibu") obj["nikIbu"] = val;
            else if (hLower === "tempatlahiribu") obj["tempatLahirIbu"] = val;
            else if (hLower === "tanggallahiribu") obj["tanggalLahirIbu"] = val;
            else if (hLower === "pendidikanibu") obj["pendidikanIbu"] = val;
            else if (hLower === "pekerjaanibu") obj["pekerjaanIbu"] = val;
            else if (hLower === "penghasilanibu") obj["penghasilanIbu"] = val;
            else if (hLower === "tlpibu") obj["tlpIbu"] = val;
            else if (hLower === "statusibu") obj["statusIbu"] = val;
            else if (hLower === "statusyatim") obj["statusYatim"] = val;
            else if (hLower === "namawali") { obj["namaWali"] = val; if (!obj["parentName"]) obj["parentName"] = val; }
            else if (hLower === "tempatlahirwali") obj["tempatLahirWali"] = val;
            else if (hLower === "tgllahirwali" || hLower === "tanggallahirwali") obj["tglLahirWali"] = val;
            else if (hLower === "pendidikanwali") obj["pendidikanWali"] = val;
            else if (hLower === "pekerjaanwali") obj["pekerjaanWali"] = val;
            else if (hLower === "penghasilanwali") obj["penghasilanWali"] = val;
            else if (hLower === "hubungan" || hLower === "hubunganwali") obj["hubunganWali"] = val;
            else if (hLower === "tlpwali") obj["tlpWali"] = val;
            else if (hLower === "aktakelahiran") { obj["aktaKelahiranUrl"] = val; obj["akteUrl"] = val; }
            else if (hLower === "kartukeluarga") { obj["kartuKeluargaUrl"] = val; obj["kkUrl"] = val; }
            else if (hLower === "kia") obj["kiaUrl"] = val;
            else if (hLower === "ktpayah") obj["ktpAyahUrl"] = val;
            else if (hLower === "ktpibu") obj["ktpIbuUrl"] = val;
            else if (hLower === "ijazah") obj["ijazahUrl"] = val;
            else if (hLower === "ktpwali") obj["ktpWaliUrl"] = val;
            else if (hLower === "rapor" || hLower === "rapot") { obj["raporUrl"] = val; obj["rapotUrl"] = val; }
            else if (hLower === "spindah") obj["suratPindahUrl"] = val;
            else if (hLower === "suket") { obj["suKetUrl"] = val; obj["dokumenLainUrl"] = val; }
            else if (hLower === "sdomisili") obj["suratDomisiliUrl"] = val;
            else if (hLower === "status") obj["status"] = val;
            else if (hLower === "kelassaatini" || hLower === "kelas") { obj["class"] = val; obj["kelasSaatIni"] = val; }
          } else if (sheetName.includes("GURU") || sheetName.includes("GTK")) {
            if (hLower === "guruid" || hLower === "id") { obj["id"] = val; obj["guruId"] = val; }
            else if (hLower === "nama" || hLower === "namalengkap") obj["name"] = val;
            else if (hLower === "nip") obj["nip"] = val;
            else if (hLower === "nik") obj["nik"] = val;
            else if (hLower === "nuptk") obj["nuptk"] = val;
            else if (hLower === "jeniskelamin") obj["gender"] = val;
            else if (hLower === "nohp" || hLower === "telepon") obj["phone"] = val;
            else if (hLower === "jabatan" || hLower === "kelas") { obj["class"] = val; obj["jabatan"] = val; }
            else if (hLower === "foto" || hLower === "fotourl") obj["fotoUrl"] = val;
          } else if (sheetName === "KELAS") {
            if (hLower === "kelasid" || hLower === "id") obj["id"] = val;
            else if (hLower === "namakelas") obj["name"] = val;
          } else if (sheetName === "MAPEL") {
            if (hLower === "mapelid" || hLower === "id") obj["id"] = val;
            else if (hLower === "namamapel" || hLower === "nama") obj["name"] = val;
            else if (hLower === "kode") obj["code"] = val;
          } else if (sheetName.includes("SPMB") || sheetName === "PENDAFTAR") {
            if (hLower === "noregistrasi" || hLower === "pendaftarid" || hLower === "id") obj["id"] = val;
            else if (hLower === "namacalonsiswa" || hLower === "nama") obj["name"] = val;
          } else if (sheetName === "BARANG") {
            if (hLower === "barangid" || hLower === "id") obj["id"] = val;
            else if (hLower === "namabarang" || hLower === "nama") obj["name"] = val;
          } else if (sheetName === "BUKU") {
            if (hLower === "bukuid" || hLower === "id") obj["id"] = val;
            else if (hLower === "judul") obj["title"] = val;
          }
        }
      }
      records.push(obj);
    }
  }
  return records;
}

function handleUpload(payload, ssInstance) {
  try {
    const ss = ssInstance || SpreadsheetApp.getActiveSpreadsheet();
    let rootFolder = null;
    const targetFolderId = payload.folderId || (payload.folderName && String(payload.folderName).length >= 25 && /^[a-zA-Z0-9_-]+$/.test(String(payload.folderName).trim()) ? String(payload.folderName).trim() : null);
    
    if (targetFolderId && String(targetFolderId).trim() !== "") {
      try {
        rootFolder = DriveApp.getFolderById(String(targetFolderId).trim());
      } catch (e) {
        rootFolder = null; // Fallback jika ID folder tidak ditemukan / tidak ada izin
      }
    }
    
    if (!rootFolder) {
      const rootFolderName = (payload.folderName && payload.folderName.length < 25) ? payload.folderName : "BERKAS_SISWA_MASTER";
      const folders = DriveApp.getFoldersByName(rootFolderName);
      if (folders.hasNext()) {
        rootFolder = folders.next();
      } else {
        rootFolder = DriveApp.createFolder(rootFolderName);
        try {
          rootFolder.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
        } catch (e) {}
      }
    }
    
    if (!rootFolder) {
      return jsonResponse({ error: "Gagal mengakses folder Google Drive. Pastikan izin DriveApp telah diotorisasi dengan menjalankan fungsi otorisasiDrive() sekali di Apps Script." });
    }

    // Helper untuk mencari atau membuat subfolder di Google Drive
    function getOrCreateSubFolder(parent, name) {
      if (!name || !String(name).trim()) return parent;
      const cleanName = String(name).trim();
      const iter = parent.getFoldersByName(cleanName);
      if (iter.hasNext()) {
        return iter.next();
      }
      const created = parent.createFolder(cleanName);
      try {
        created.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
      } catch (e) {}
      return created;
    }

    // Sistem Folder Otomatis Terstruktur: Siswa, Guru/GTK, Kurikulum, Keuangan, Sarpras, Kegiatan, Pengumuman, Surat, SPMB, Akreditasi
    let targetFolder = rootFolder;
    const subFolderName = payload.subFolder || "";
    const modulType = String(payload.modul || payload.kategori || "").toUpperCase();

    if (subFolderName && String(subFolderName).trim() !== "") {
      // Jika subFolder mengandung path bertingkat (misal: "06_DOKUMEN_KEGIATAN/2026-08")
      const normalizedSub = String(subFolderName).split(String.fromCharCode(92)).join("/");
      const parts = normalizedSub.split("/").filter(function(p) { return p && p.trim() !== ""; });
      let cur = rootFolder;
      for (let i = 0; i < parts.length; i++) {
        cur = getOrCreateSubFolder(cur, parts[i]);
      }
      targetFolder = cur;
    } else if (payload.studentName || payload.studentId || payload.nopdkt || modulType.includes("SISWA") || modulType.includes("BERKAS_SISWA")) {
      // 01. Berkas Siswa Aktif: 01_BERKAS_SISWA_AKTIF / [NOPDKT] Nama Siswa
      const nopdkt = String(payload.nopdkt || payload.studentId || "").trim();
      const sName = String(payload.studentName || "Siswa").trim();
      const sFolder = (nopdkt ? ("[" + nopdkt + "] ") : "") + sName;
      const catFolder = getOrCreateSubFolder(rootFolder, "01_BERKAS_SISWA_AKTIF");
      targetFolder = getOrCreateSubFolder(catFolder, sFolder);
    } else if (payload.teacherName || payload.guruName || payload.nip || payload.nuptk || payload.teacherId || modulType.includes("GURU") || modulType.includes("GTK")) {
      // 02. Berkas Pendidik & Tenaga Kependidikan: 02_BERKAS_GURU_GTK / [NIP] Nama Lengkap
      const nip = String(payload.nip || payload.nuptk || payload.teacherId || "").trim();
      const tName = String(payload.teacherName || payload.guruName || payload.name || "Guru").trim();
      const tFolder = (nip ? ("[" + nip + "] ") : "") + tName;
      const catFolder = getOrCreateSubFolder(rootFolder, "02_BERKAS_GURU_GTK");
      targetFolder = getOrCreateSubFolder(catFolder, tFolder);
    } else if (modulType.includes("AKADEMIK") || modulType.includes("KURIKULUM") || modulType.includes("RAPOR") || modulType.includes("NILAI")) {
      // 03. Akademik & Kurikulum: 03_AKADEMIK_DAN_KURIKULUM / [Tahun_Ajaran] / [Kelas/Mapel]
      const catFolder = getOrCreateSubFolder(rootFolder, "03_AKADEMIK_DAN_KURIKULUM");
      const ta = String(payload.tahunAjaran || payload.tahun || new Date().getFullYear()).split("/").join("-");
      const taFolder = getOrCreateSubFolder(catFolder, "TA_" + ta);
      const subTarget = String(payload.kelas || payload.mapel || "Rapor_Leger").split(" ").join("_");
      targetFolder = getOrCreateSubFolder(taFolder, subTarget);
    } else if (modulType.includes("KEUANGAN") || modulType.includes("TAGIHAN") || modulType.includes("INVOICE") || modulType.includes("KWITANSI") || modulType.includes("BOS")) {
      // 04. Keuangan & Tagihan: 04_KEUANGAN_DAN_TAGIHAN / [YYYY-MM]
      const now = new Date();
      const yr = payload.tahun || now.getFullYear();
      const mo = String(payload.bulan || (now.getMonth() + 1)).padStart(2, '0');
      const catFolder = getOrCreateSubFolder(rootFolder, "04_KEUANGAN_DAN_TAGIHAN");
      targetFolder = getOrCreateSubFolder(catFolder, "Periode_" + yr + "-" + mo);
    } else if (modulType.includes("INVENTARIS") || modulType.includes("SARPRAS") || modulType.includes("ASET")) {
      // 05. Sarana & Prasarana: 05_SARANA_PRASARANA / [Kategori]
      const catFolder = getOrCreateSubFolder(rootFolder, "05_SARANA_PRASARANA");
      const katAset = String(payload.kategori || "Aset_Lembaga").split(" ").join("_");
      targetFolder = getOrCreateSubFolder(catFolder, katAset);
    } else if (payload.kegiatanNama || payload.activityName || modulType.includes("KEGIATAN") || modulType.includes("BERITA")) {
      // 06. Dokumen Kegiatan Per Bulan: 06_DOKUMEN_KEGIATAN / [YYYY-MM] Nama Kegiatan
      const now = new Date();
      const yr = payload.tahun || now.getFullYear();
      const mo = String(payload.bulan || (now.getMonth() + 1)).padStart(2, '0');
      const kegName = String(payload.kegiatanNama || payload.activityName || payload.judul || "Dokumentasi").trim();
      const kFolder = "[" + yr + "-" + mo + "] " + kegName;
      const catFolder = getOrCreateSubFolder(rootFolder, "06_DOKUMEN_KEGIATAN");
      targetFolder = getOrCreateSubFolder(catFolder, kFolder);
    } else if (payload.pengumumanJudul || modulType.includes("PENGUMUMAN") || modulType.includes("EDARAN")) {
      // 07. Pengumuman & Surat Edaran: 07_PENGUMUMAN_DAN_EDARAN / [YYYY-MM]
      const now = new Date();
      const yr = payload.tahun || now.getFullYear();
      const mo = String(payload.bulan || (now.getMonth() + 1)).padStart(2, '0');
      const pFolder = "[" + yr + "-" + mo + "] " + String(payload.pengumumanJudul || "Pengumuman").trim();
      const catFolder = getOrCreateSubFolder(rootFolder, "07_PENGUMUMAN_DAN_EDARAN");
      targetFolder = getOrCreateSubFolder(catFolder, pFolder);
    } else if (payload.noSurat || modulType.includes("SURAT") || modulType.includes("DOKUMEN") || modulType.includes("TU")) {
      // 08. Persuratan & Tata Usaha: 08_PERSURATAN_DAN_TU / [Jenis_Tahun]
      const now = new Date();
      const yr = String(payload.tahun || now.getFullYear());
      const catFolder = getOrCreateSubFolder(rootFolder, "08_PERSURATAN_DAN_TU");
      const jenisSurat = String(payload.jenisSurat || payload.kategori || "Surat_Masuk_Keluar").split(" ").join("_");
      targetFolder = getOrCreateSubFolder(catFolder, jenisSurat + "_" + yr);
    } else if (payload.noPendaftaran || payload.calonSiswaName || modulType.includes("SPMB") || modulType.includes("PPDB")) {
      // 09. SPMB & PPDB Pendaftaran: 09_SPMB_PENDAFTARAN / [Tahun] / [NoDaftar] Nama Calon
      const now = new Date();
      const yr = String(payload.tahun || now.getFullYear());
      const noDaftar = String(payload.noPendaftaran || payload.regId || "").trim();
      const cName = String(payload.calonSiswaName || payload.name || "Pendaftar").trim();
      const spmbFolder = (noDaftar ? ("[" + noDaftar + "] ") : "") + cName;
      const catFolder = getOrCreateSubFolder(rootFolder, "09_SPMB_PENDAFTARAN");
      const yrFolder = getOrCreateSubFolder(catFolder, "Tahun_" + yr);
      targetFolder = getOrCreateSubFolder(yrFolder, spmbFolder);
    } else if (modulType.includes("AKREDITASI") || modulType.includes("BANSM") || modulType.includes("IASP")) {
      // 10. Arsip Akreditasi BAN-S/M: 10_ARSIP_AKREDITASI_BANSM / [Standar]
      const catFolder = getOrCreateSubFolder(rootFolder, "10_ARSIP_AKREDITASI_BANSM");
      const standarName = String(payload.standar || payload.komponen || "Dokumen_Akreditasi").split(" ").join("_");
      targetFolder = getOrCreateSubFolder(catFolder, standarName);
    } else if (modulType.includes("CBT") || modulType.includes("UJIAN") || modulType.includes("SOAL")) {
      // CBT & Bank Soal: 11_CBT_DAN_BANK_SOAL / [Mapel]
      const catFolder = getOrCreateSubFolder(rootFolder, "11_CBT_DAN_BANK_SOAL");
      const mapel = String(payload.mapel || "Bank_Soal").split(" ").join("_");
      targetFolder = getOrCreateSubFolder(catFolder, mapel);
    }
    
    const cleanBase64 = String(payload.base64 || "").replace(/^data:.*?;base64,/, '').trim();
    if (!cleanBase64) {
      return jsonResponse({ error: "Data file (base64) kosong atau tidak valid." });
    }
    
    const decodedBytes = Utilities.base64Decode(cleanBase64);
    const mime = payload.mimeType || "application/octet-stream";
    const fname = payload.filename || ("upload_" + new Date().getTime());
    
    const blob = Utilities.newBlob(decodedBytes, mime, fname);
    const file = targetFolder.createFile(blob);
    try {
      file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    } catch (e) {}
    
    const fileId = file.getId();
    const fileUrl = file.getUrl();
    const directUrl = "https://lh3.googleusercontent.com/d/" + fileId;
    const nowIso = new Date().toISOString();

    // 1. Catat ke Tabel FILE (Arsip Otomatis)
    try {
      let sheetFile = ss.getSheetByName("FILE");
      if (!sheetFile) {
        sheetFile = ss.insertSheet("FILE");
        const fHeaders = MASTER_SCHEMAS["FILE"];
        sheetFile.appendRow(fHeaders);
        sheetFile.setFrozenRows(1);
      }
      sheetFile.appendRow([
        "FILE-" + Date.now().toString().slice(-6),
        payload.kategori || "Dokumen Siswa",
        payload.modul || "BERKAS_SISWA",
        file.getName(),
        fname,
        fileUrl,
        file.getSize() || 0,
        mime,
        payload.uploadedBy || "Admin",
        nowIso,
        "Tersimpan",
        (payload.studentName ? ("Siswa: " + payload.studentName + " | ") : "") + "Folder: " + targetFolder.getName(),
        nowIso,
        nowIso
      ]);
    } catch (eFile) {}

    // 2. Catat ke Tabel SISWA jika ada studentId / nisn / docKey
    try {
      if (payload.studentId || payload.nisn || payload.docKey) {
        let sheetSiswa = ss.getSheetByName("SISWA") || ss.getSheetByName("DataSiswa");
        if (sheetSiswa) {
          const docKeyMap = {
            aktaKelahiranUrl: "AktaKelahiran",
            akteUrl: "AktaKelahiran",
            kartuKeluargaUrl: "KartuKeluarga",
            kkUrl: "KartuKeluarga",
            kiaUrl: "KIA",
            ktpAnakUrl: "KIA",
            ktpAyahUrl: "KTPAyah",
            ktpIbuUrl: "KTPIbu",
            ijazahUrl: "Ijazah",
            ktpWaliUrl: "KTPWali",
            raporUrl: "Rapor",
            rapotUrl: "Rapor",
            suratPindahUrl: "S.Pindah",
            suKetUrl: "SuKet",
            dokumenLainUrl: "SuKet",
            suratDomisiliUrl: "S.Domisili",
            pasFotoUrl: "PasFoto",
            fotoUrl: "PasFoto"
          };
          const targetColName = docKeyMap[payload.docKey] || payload.docKey;
          const sValues = sheetSiswa.getDataRange().getDisplayValues();
          if (sValues.length > 1) {
            const sHeaders = sValues[0];
            const targetColIdx = sHeaders.indexOf(targetColName);
            const nisIdx = sHeaders.indexOf("nopdkt");
            const nisnIdx = sHeaders.indexOf("NISN");

            if (targetColIdx !== -1) {
              for (let r = 1; r < sValues.length; r++) {
                const rowNis = nisIdx !== -1 ? sValues[r][nisIdx] : "";
                const rowNisn = nisnIdx !== -1 ? sValues[r][nisnIdx] : "";
                if (
                  (payload.studentId && (rowNis === String(payload.studentId) || rowNisn === String(payload.studentId))) ||
                  (payload.nisn && rowNisn === String(payload.nisn))
                ) {
                  sheetSiswa.getRange(r + 1, targetColIdx + 1).setValue(fileUrl);
                  break;
                }
              }
            }
          }
        }
      }
    } catch (eSiswa) {}
    
    return jsonResponse({ 
      success: true, 
      url: fileUrl, 
      fileId: fileId,
      directUrl: directUrl,
      fileName: file.getName(),
      folderName: targetFolder.getName(),
      folderUrl: targetFolder.getUrl(),
      folderId: targetFolder.getId()
    });
  } catch (err) {
    const errStr = err.toString();
    if (errStr.indexOf("DriveApp") !== -1 || errStr.indexOf("Akses ditolak") !== -1 || errStr.indexOf("Access denied") !== -1) {
      return jsonResponse({ 
        error: "Upload failed: Akses Google Drive Ditolak (DriveApp). Solusi: Buka editor Google Apps Script di spreadsheet Anda, pilih fungsi 'otorisasiDrive' di toolbar atas, klik 'Jalankan' (Run ▶) untuk mengizinkan akses Drive, lalu klik 'Deploy' > 'Deployment baru' (Jalankan sebagai: Saya, Akses: Siapa saja)." 
      });
    }
    return jsonResponse({ error: "Upload failed: " + errStr });
  }
}

function setupDriveFolders(payload) {
  try {
    var root = null;
    var rawId = payload && (payload.folderId || payload.folderName || "");
    var targetFolderId = (rawId && String(rawId).trim().length >= 20) ? String(rawId).trim() : null;
    if (targetFolderId && targetFolderId !== "BERKAS_SISWA_MASTER") {
      try {
        root = DriveApp.getFolderById(targetFolderId);
      } catch (e) {
        root = null;
      }
    }
    if (!root) {
      var rootFolderName = (payload && payload.folderName && payload.folderName.length < 25) ? payload.folderName : "BERKAS_SISWA_MASTER";
      var folders = DriveApp.getFoldersByName(rootFolderName);
      if (folders.hasNext()) {
        root = folders.next();
      } else {
        root = DriveApp.createFolder(rootFolderName);
        try {
          root.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
        } catch (e) {}
      }
    }

    function getSub(parent, name) {
      if (!name || !String(name).trim()) return parent;
      var cleanName = String(name).trim();
      var iter = parent.getFoldersByName(cleanName);
      if (iter.hasNext()) return iter.next();
      var created = parent.createFolder(cleanName);
      try {
        created.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
      } catch (e) {}
      return created;
    }

    var standardFolders = [
      { name: "01_BERKAS_SISWA_AKTIF", desc: "Folder berkas siswa aktif per [NOPDKT] Nama Siswa (Akta, KK, KIA, Foto, Ijazah)" },
      { name: "02_BERKAS_GURU_GTK", desc: "Folder berkas pendidik & GTK per [NIP] Nama Lengkap (SK, Ijazah, Sertifikat)" },
      { name: "03_AKADEMIK_DAN_KURIKULUM", desc: "Arsip Rapor, Leger Nilai, dan Modul Perangkat Pembelajaran" },
      { name: "04_KEUANGAN_DAN_TAGIHAN", desc: "Kwitansi Pembayaran Kasir, Nota Tagihan & Dokumen BOS/BOSP" },
      { name: "05_SARANA_PRASARANA", desc: "Inventaris Barang, Kartu Inventaris Ruangan & Foto Fisik Gedung" },
      { name: "06_DOKUMEN_KEGIATAN", desc: "Dokumentasi Foto & Video Kegiatan Sekolah Per Bulan" },
      { name: "07_PENGUMUMAN_DAN_EDARAN", desc: "Arsip Surat Edaran, Pengumuman & Berita Sekolah" },
      { name: "08_PERSURATAN_DAN_TU", desc: "Arsip Surat Masuk & Surat Keluar Tata Usaha" },
      { name: "09_SPMB_PENDAFTARAN", desc: "Arsip Berkas Pendaftar Siswa Baru (PPDB Online)" },
      { name: "10_ARSIP_AKREDITASI_BANSM", desc: "Dokumen 4 Komponen IASP / 8 Standar Nasional Pendidikan" },
      { name: "11_CBT_DAN_BANK_SOAL", desc: "Bank Soal, Kisi-kisi, Rubrik & Naskah Asesmen Ujian" }
    ];

    var createdList = [];
    for (var i = 0; i < standardFolders.length; i++) {
      var item = standardFolders[i];
      var f = getSub(root, item.name);
      createdList.push({
        name: item.name,
        desc: item.desc,
        id: f.getId(),
        url: f.getUrl()
      });
    }

    return {
      success: true,
      rootName: root.getName(),
      rootUrl: root.getUrl(),
      rootId: root.getId(),
      folders: createdList,
      message: "Sukses! 11 Struktur Sub-Folder Master Google Drive berhasil dibuat & tertata rapi."
    };
  } catch (err) {
    return {
      success: false,
      error: "Gagal membuat struktur folder di Google Drive: " + err.toString()
    };
  }
}

/**
 * Otomatisasi Ekstraksi & Sinkronisasi Sheet ORANG_TUA dan YATIM_PIATU dari Data SISWA
 */
function autoPopulateOrangTuaAndYatimFromSiswa(targetSs) {
  try {
    var ss = targetSs || SpreadsheetApp.getActiveSpreadsheet();
    if (!ss) {
      return { status: 'error', message: 'Spreadsheet tidak dapat diakses' };
    }

    var sheetSiswa = ss.getSheetByName('SISWA') || ss.getSheetByName('DataSiswa');
    if (!sheetSiswa) {
      return { status: 'error', message: 'Sheet SISWA belum tersedia' };
    }

    var siswaValues = sheetSiswa.getDataRange().getValues();
    if (siswaValues.length <= 1) {
      return { status: 'error', message: 'Sheet SISWA masih kosong' };
    }

    var sHeaders = siswaValues[0];
    var colMap = {};
    sHeaders.forEach(function(h, idx) {
      colMap[String(h).toLowerCase().trim()] = idx;
    });

    function getVal(row, possibleKeys) {
      for (var i = 0; i < possibleKeys.length; i++) {
        var k = possibleKeys[i].toLowerCase();
        if (colMap.hasOwnProperty(k) && row[colMap[k]] !== undefined && row[colMap[k]] !== '') {
          return String(row[colMap[k]]).trim();
        }
      }
      return '';
    }

    var ortuRows = [];
    var yatimRows = [];
    var ortuCounter = 1;
    var yatimCounter = 1;

    for (var r = 1; r < siswaValues.length; r++) {
      var row = siswaValues[r];
      var siswaId = getVal(row, ['siswai', 'id', 'nopdkt', 'nisn', 'nis', 'no']);
      var namaSiswa = getVal(row, ['namalengkap', 'namasiswa', 'nama']);
      if (!namaSiswa && !siswaId) continue;

      var kelas = getVal(row, ['kelas', 'rombel', 'tingkat', 'kelassaatini']);
      var jalan = getVal(row, ['alamat', 'tempattinggal', 'alamatdomisili', 'jalan', 'dusun']);
      var rtVal = getVal(row, ['rt']);
      var rwVal = getVal(row, ['rw']);
      var kelVal = getVal(row, ['kelurahan', 'desa', 'kel']);
      var kecVal = getVal(row, ['kecamatan', 'kec']);
      var kotaVal = getVal(row, ['kota', 'kabupaten', 'kotakab']);
      var posVal = getVal(row, ['kodepos']);

      var addrParts = [];
      if (jalan && jalan !== '-') addrParts.push(jalan);
      if (rtVal && rwVal && rtVal !== '-' && rwVal !== '-') addrParts.push('RT ' + rtVal + '/RW ' + rwVal);
      else if (rtVal && rtVal !== '-') addrParts.push('RT ' + rtVal);
      else if (rwVal && rwVal !== '-') addrParts.push('RW ' + rwVal);

      if (kelVal && kelVal !== '-') {
        addrParts.push(kelVal.toLowerCase().indexOf('kel') === 0 || kelVal.toLowerCase().indexOf('desa') === 0 ? kelVal : ('Kel. ' + kelVal));
      }
      if (kecVal && kecVal !== '-') {
        addrParts.push(kecVal.toLowerCase().indexOf('kec') === 0 ? kecVal : ('Kec. ' + kecVal));
      }
      if (kotaVal && kotaVal !== '-') addrParts.push(kotaVal);
      if (posVal && posVal !== '-') addrParts.push(posVal);

      var alamat = addrParts.length > 0 ? addrParts.join(', ') : (jalan || '-');

      // Data Ayah
      var namaAyah = getVal(row, ['namaayah', 'ayah', 'fathername', 'namaorangtua']);
      var nikAyah = getVal(row, ['nikayah']);
      var jobAyah = getVal(row, ['pekerjaanayah', 'jobayah']);
      var hpAyah = getVal(row, ['nohpayah', 'tlpayah', 'teleponayah', 'nohportu', 'nohp']);
      var statusAyah = getVal(row, ['statusayah']);

      // Data Ibu
      var namaIbu = getVal(row, ['namaibu', 'namaibukandung', 'ibu', 'NamaIbu']);
      var nikIbu = getVal(row, ['nikibu']);
      var jobIbu = getVal(row, ['pekerjaanibu', 'jobibu']);
      var hpIbu = getVal(row, ['nohpibu', 'tlpibu', 'teleponibu']);
      var statusIbu = getVal(row, ['statusibu']);

      // Data Wali
      var namaWali = getVal(row, ['namawali', 'wali', 'guardianname']);
      var nikWali = getVal(row, ['nikwali']);
      var jobWali = getVal(row, ['pekerjaanwali']);
      var hpWali = getVal(row, ['nohpwali', 'tlpwali']);
      var hubunganWali = getVal(row, ['hubunganwali', 'hubungan']);

      // Status Yatim Piatu
      var statusYatim = getVal(row, ['statusyatim', 'status_yatim', 'kondisiorangtua']);
      if (!statusYatim) {
        var aDead = statusAyah.toLowerCase().indexOf('meninggal') !== -1 || statusAyah.toLowerCase().indexOf('almarhum') !== -1;
        var iDead = statusIbu.toLowerCase().indexOf('meninggal') !== -1 || statusIbu.toLowerCase().indexOf('almarhumah') !== -1;
        if (aDead && iDead) statusYatim = 'Yatim Piatu';
        else if (aDead) statusYatim = 'Yatim';
        else if (iDead) statusYatim = 'Piatu';
        else statusYatim = 'Lengkap';
      }

      // Populate ORANG_TUA
      // Headers: ["OrtuID", "SiswaID", "Hubungan", "Nama", "NIK", "Pekerjaan", "NoHP", "Alamat"]
      if (namaAyah) {
        ortuRows.push([
          'ORTU-' + String(1000 + ortuCounter++).slice(1),
          siswaId ? "'" + String(siswaId) : ('SISWA-' + r),
          'Ayah Kandung',
          namaAyah,
          nikAyah ? "'" + String(nikAyah) : '-',
          jobAyah || '-',
          hpAyah ? "'" + String(hpAyah) : '-',
          alamat || '-'
        ]);
      }

      if (namaIbu) {
        ortuRows.push([
          'ORTU-' + String(1000 + ortuCounter++).slice(1),
          siswaId ? "'" + String(siswaId) : ('SISWA-' + r),
          'Ibu Kandung',
          namaIbu,
          nikIbu ? "'" + String(nikIbu) : '-',
          jobIbu || '-',
          hpIbu ? "'" + String(hpIbu) : '-',
          alamat || '-'
        ]);
      }

      if (namaWali && namaWali !== namaAyah && namaWali !== namaIbu) {
        ortuRows.push([
          'ORTU-' + String(1000 + ortuCounter++).slice(1),
          siswaId ? "'" + String(siswaId) : ('SISWA-' + r),
          hubunganWali || 'Wali',
          namaWali,
          nikWali ? "'" + String(nikWali) : '-',
          jobWali || '-',
          hpWali ? "'" + String(hpWali) : '-',
          alamat || '-'
        ]);
      }

      // Populate YATIM_PIATU
      // Headers: ["YatimID", "NoPDKT", "NISN", "NamaSiswa", "Kelas", "StatusYatim", "NamaAyah", "StatusAyah", "NamaIbu", "StatusIbu", "NamaWali", "NoHPWali", "Alamat", "PenerimaKPS_PIP", "Keterangan", "CreatedAt", "UpdatedAt"]
      var noPdkt = getVal(row, ['nopdkt', 'nis', 'no']);
      var nisn = getVal(row, ['nisn']);
      var penerimaKps = getVal(row, ['penerimakps', 'penerimakps_pip', 'kps', 'pip', 'kip']);
      var nowIso = new Date().toISOString();

      yatimRows.push([
        'YTM-' + String(1000 + yatimCounter++).slice(1),
        noPdkt ? "'" + String(noPdkt) : (siswaId ? "'" + String(siswaId) : ('SISWA-' + r)),
        nisn ? "'" + String(nisn) : '-',
        namaSiswa,
        kelas || '-',
        statusYatim,
        namaAyah || '-',
        statusAyah || (statusYatim === 'Yatim' || statusYatim === 'Yatim Piatu' ? 'Meninggal Dunia' : 'Masih Hidup'),
        namaIbu || '-',
        statusIbu || (statusYatim === 'Piatu' || statusYatim === 'Yatim Piatu' ? 'Meninggal Dunia' : 'Masih Hidup'),
        namaWali || '-',
        hpWali || hpAyah || hpIbu ? "'" + (hpWali || hpAyah || hpIbu) : '-',
        alamat || '-',
        penerimaKps || 'Tidak',
        'Data otomatis diekstrak dari Master Siswa',
        nowIso,
        nowIso
      ]);
    }

    // Tulis ke Sheet ORANG_TUA
    var sheetOrtu = ss.getSheetByName('ORANG_TUA');
    var ortuHeaders = MASTER_SCHEMAS['ORANG_TUA'] || ['OrtuID', 'SiswaID', 'Hubungan', 'Nama', 'NIK', 'Pekerjaan', 'NoHP', 'Alamat'];
    if (!sheetOrtu) {
      sheetOrtu = ss.insertSheet('ORANG_TUA');
      sheetOrtu.appendRow(ortuHeaders);
      sheetOrtu.setFrozenRows(1);
    }
    if (sheetOrtu.getLastRow() > 1) {
      sheetOrtu.getRange(2, 1, sheetOrtu.getLastRow() - 1, sheetOrtu.getLastColumn()).clearContent();
    }
    if (ortuRows.length > 0) {
      var ortuRange = sheetOrtu.getRange(2, 1, ortuRows.length, ortuHeaders.length);
      ortuRange.setNumberFormat("@");
      ortuRange.setValues(ortuRows);
    }

    // Tulis ke Sheet YATIM_PIATU
    var sheetYatim = ss.getSheetByName('YATIM_PIATU');
    var yatimHeaders = MASTER_SCHEMAS['YATIM_PIATU'] || ['YatimID', 'NoPDKT', 'NISN', 'NamaSiswa', 'Kelas', 'StatusYatim', 'NamaAyah', 'StatusAyah', 'NamaIbu', 'StatusIbu', 'NamaWali', 'NoHPWali', 'Alamat', 'PenerimaKPS_PIP', 'Keterangan', 'CreatedAt', 'UpdatedAt'];
    if (!sheetYatim) {
      sheetYatim = ss.insertSheet('YATIM_PIATU');
      sheetYatim.appendRow(yatimHeaders);
      sheetYatim.setFrozenRows(1);
    }
    if (sheetYatim.getLastRow() > 1) {
      sheetYatim.getRange(2, 1, sheetYatim.getLastRow() - 1, sheetYatim.getLastColumn()).clearContent();
    }
    if (yatimRows.length > 0) {
      var yatimRange = sheetYatim.getRange(2, 1, yatimRows.length, yatimHeaders.length);
      yatimRange.setNumberFormat("@");
      yatimRange.setValues(yatimRows);
    }

    return {
      status: 'success',
      success: true,
      ortuCount: ortuRows.length,
      yatimCount: yatimRows.length,
      message: 'Berhasil mengekstrak ' + ortuRows.length + ' data Orang Tua & ' + yatimRows.length + ' data Status Yatim/Piatu ke Spreadsheet.'
    };
  } catch (err) {
    return {
      status: 'error',
      success: false,
      message: 'Gagal auto-populate: ' + err.toString()
    };
  }
}

function jsonResponse(obj, callback) {
  const jsonStr = JSON.stringify(obj);
  if (callback && typeof callback === "string" && callback.trim() !== "") {
    return ContentService.createTextOutput(callback + "(" + jsonStr + ");")
      .setMimeType(ContentService.MimeType.JAVASCRIPT);
  }
  return ContentService.createTextOutput(jsonStr)
    .setMimeType(ContentService.MimeType.JSON);
}
`;
