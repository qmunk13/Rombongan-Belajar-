import { Student } from '../types';
import { DEFAULT_APP_CONFIG } from '../data/config';

// Converts a File to Base64
export const fileToBase64 = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = error => reject(error);
  });
};

export const fetchFromGAS = async (url: string, payload: any) => {
  if (!url) throw new Error("Google Apps Script URL is not configured. Go to Settings.");
  
  const targetSpreadsheetId = payload?.spreadsheetId || DEFAULT_APP_CONFIG.spreadsheetId || "1XTfNFkele0iVbb7W8qlJDujWKFbq-bqJO5VabY82bCk";
  const enrichedPayload = {
    spreadsheetId: targetSpreadsheetId,
    ...payload
  };

  try {
    // Attempt 1: Direct fetch
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'text/plain;charset=utf-8'
      },
      body: JSON.stringify(enrichedPayload)
    });

    if (response.ok) {
      const text = await response.text();
      let data: any;
      try {
        data = JSON.parse(text);
      } catch (e) {
        data = { raw: text };
      }

      if (data && data.error) {
        throw new Error(data.error);
      }
      return data;
    }
  } catch (directErr: any) {
    // Silent fallback to server proxy without spamming console
  }

  // Attempt 2: Fallback via backend proxy (/api/gas-proxy)
  try {
    const proxyRes = await fetch('/api/gas-proxy', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        url,
        payload: enrichedPayload,
      }),
    });

    if (!proxyRes.ok) {
      throw new Error(`Server Proxy Error: ${proxyRes.statusText}`);
    }

    const data = await proxyRes.json();
    if (data && data.error) {
      throw new Error(data.error);
    }
    return data;
  } catch (proxyErr: any) {
    throw new Error(proxyErr.message || "Gagal menghubungi Google Apps Script. Pastikan URL Web App benar dan Deployment disetel ke 'Anyone'.");
  }
};

export const uploadFileToGAS = async (
  url: string, 
  file: File, 
  folderNameOrFolderId: string = "SI_Siswa_Uploads", 
  customFilename?: string,
  extraMeta?: {
    studentId?: string;
    nopdkt?: string;
    studentName?: string;
    studentClass?: string;
    subFolder?: string;
    nisn?: string;
    docKey?: string;
    modul?: string;
    kategori?: string;
    uploadedBy?: string;
    nip?: string;
    teacherName?: string;
    [key: string]: any;
  }
): Promise<{ success: boolean; url: string; fileId?: string; directUrl?: string; folderName?: string; folderUrl?: string; folderId?: string }> => {
  const base64Data = await fileToBase64(file);
  // Remove data:image/png;base64, or any mime prefix cleanly
  const base64Content = base64Data.includes(',') ? base64Data.split(',')[1] : base64Data;
  
  // Google Drive folder ID is typically 25+ alphanumeric characters (may contain _ and -) without whitespace
  const trimmedFolder = (folderNameOrFolderId || "").trim();
  const isLikelyFolderId = trimmedFolder.length >= 25 && /^[a-zA-Z0-9_-]+$/.test(trimmedFolder);
  
  const payload = {
    action: 'upload',
    filename: customFilename || file.name,
    mimeType: file.type || 'application/octet-stream',
    base64: base64Content,
    folderName: isLikelyFolderId ? "SI_Siswa_Uploads" : (trimmedFolder || "SI_Siswa_Uploads"),
    folderId: isLikelyFolderId ? trimmedFolder : undefined,
    ...(extraMeta || {})
  };

  const res = await fetchFromGAS(url, payload);
  if (res && res.error) {
    let errMsg = String(res.error);
    if (errMsg.includes('DriveApp') || errMsg.includes('Akses ditolak') || errMsg.includes('Access denied')) {
      errMsg = "Izin Google Drive (DriveApp) belum aktif pada Google Apps Script Anda. Buka editor Apps Script, pilih fungsi 'otorisasiDrive' (atau 'setup') di toolbar atas, klik 'Jalankan' (Run ▶) lalu izinkan akses, kemudian klik 'Deploy' > 'Deployment Baru'.";
    }
    throw new Error(errMsg);
  }
  return res; // Return response object { success: true, url: "...", fileId: "...", directUrl: "..." }
};
