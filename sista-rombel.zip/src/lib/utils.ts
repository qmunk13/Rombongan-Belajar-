import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function generateId() {
  return Math.random().toString(36).substring(2, 9) + Date.now().toString(36);
}

export const CLASSES: string[] = ['4', '5', '6', '7', '8', '9', '10', '11', '12'];

export const STANDARD_CLASSES = [...CLASSES];

export const STATUSES = ["Aktif", "Lulus", "Pindah", "Keluar"]; // Pindah represents mutasi

export function standardizeDate(value: any): string {
  if (value === null || value === undefined) return '';

  // 1. If value is a JavaScript Date object
  if (value instanceof Date) {
    if (isNaN(value.getTime())) return '';
    // If created as UTC midnight or near UTC midnight
    if (value.getUTCHours() === 0 && value.getUTCMinutes() === 0) {
      const y = value.getUTCFullYear();
      const m = String(value.getUTCMonth() + 1).padStart(2, '0');
      const d = String(value.getUTCDate()).padStart(2, '0');
      return `${y}-${m}-${d}`;
    }
    // Otherwise use local date getters
    const y = value.getFullYear();
    const m = String(value.getMonth() + 1).padStart(2, '0');
    const d = String(value.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }

  // 2. If it's a number or numeric string (Excel serial number e.g. 43620)
  if (
    typeof value === 'number' ||
    (typeof value === 'string' && /^\d+(\.\d+)?$/.test(value.trim()) && Number(value) > 1000 && Number(value) < 100000)
  ) {
    const num = Number(value);
    // Excel base epoch: Dec 30, 1899 (compensates for 1900 leap year bug)
    const excelEpoch = new Date(Date.UTC(1899, 11, 30));
    const date = new Date(excelEpoch.getTime() + Math.round(num) * 24 * 60 * 60 * 1000);
    if (!isNaN(date.getTime())) {
      const y = date.getUTCFullYear();
      const m = String(date.getUTCMonth() + 1).padStart(2, '0');
      const d = String(date.getUTCDate()).padStart(2, '0');
      return `${y}-${m}-${d}`;
    }
  }

  let str = String(value).trim();
  if (!str || str === '-') return '';

  // 3. String matches YYYY-MM-DD or YYYY/MM/DD or YYYY.MM.DD (e.g. 2019-06-04)
  const ymdMatch = str.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
  if (ymdMatch) {
    const year = ymdMatch[1];
    const month = ymdMatch[2].padStart(2, '0');
    const day = ymdMatch[3].padStart(2, '0');
    return `${year}-${month}-${day}`;
  }

  // 4. String matches DD-MM-YYYY or DD/MM/YYYY or DD.MM.YYYY (Indonesian format e.g. 04/06/2019)
  const dmYMatch = str.match(/^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2,4})/);
  if (dmYMatch) {
    const day = dmYMatch[1].padStart(2, '0');
    const month = dmYMatch[2].padStart(2, '0');
    let year = dmYMatch[3];
    if (year.length === 2) {
      const yNum = parseInt(year, 10);
      year = yNum > 30 ? `19${year}` : `20${year}`;
    }
    return `${year}-${month}-${day}`;
  }

  // 5. Handle ISO timestamp string with T e.g. "2019-06-04T00:00:00.000Z"
  if (str.includes('T')) {
    const datePart = str.split('T')[0];
    const ymd = datePart.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})/);
    if (ymd) {
      return `${ymd[1]}-${ymd[2].padStart(2, '0')}-${ymd[3].padStart(2, '0')}`;
    }
  }

  // 6. Fallback native date parsing
  try {
    const parsed = new Date(str);
    if (!isNaN(parsed.getTime())) {
      const y = parsed.getFullYear();
      const m = String(parsed.getMonth() + 1).padStart(2, '0');
      const d = String(parsed.getDate()).padStart(2, '0');
      return `${y}-${m}-${d}`;
    }
  } catch (e) {
    // fallback
  }

  return str;
}

export function formatDate(dateString: string | null | undefined): string {
  if (!dateString) return '-';
  const cleanDate = standardizeDate(dateString);
  if (!cleanDate) return String(dateString);

  try {
    const match = cleanDate.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (match) {
      const year = parseInt(match[1], 10);
      const month = parseInt(match[2], 10) - 1;
      const day = parseInt(match[3], 10);
      // Create local date object explicitly to avoid UTC timezone offset shifts
      const d = new Date(year, month, day);
      return d.toLocaleDateString('id-ID', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
      });
    }

    const d = new Date(cleanDate);
    if (isNaN(d.getTime())) return String(dateString);
    return d.toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'long',
      year: 'numeric'
    });
  } catch (e) {
    return String(dateString);
  }
}

export function calculateAge(dobString: string | null | undefined): { years: number; months: number } | null {
  if (!dobString) return null;
  const cleanDate = standardizeDate(dobString);
  if (!cleanDate) return null;

  try {
    let birthDate: Date;
    const match = cleanDate.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (match) {
      const year = parseInt(match[1], 10);
      const month = parseInt(match[2], 10) - 1;
      const day = parseInt(match[3], 10);
      birthDate = new Date(year, month, day);
    } else {
      birthDate = new Date(cleanDate);
    }
    if (isNaN(birthDate.getTime())) return null;

    const today = new Date();
    let years = today.getFullYear() - birthDate.getFullYear();
    let months = today.getMonth() - birthDate.getMonth();
    let days = today.getDate() - birthDate.getDate();

    if (days < 0) {
      months -= 1;
    }
    if (months < 0) {
      years -= 1;
      months += 12;
    }

    return { years, months };
  } catch (e) {
    return null;
  }
}

export function formatAge(dobString: string | null | undefined): string {
  const age = calculateAge(dobString);
  if (!age) return '-';
  return `${age.years} tahun ${age.months} bulan`;
}

export function extractGoogleDriveFileId(url: string | null | undefined): string {
  if (!url) return '';
  const cleanUrl = String(url).trim().replace(/['"]/g, '');
  
  // Format /file/d/FILE_ID/
  const fileDMatch = cleanUrl.match(/\/file\/d\/([a-zA-Z0-9_-]+)/);
  if (fileDMatch && fileDMatch[1]) return fileDMatch[1];

  // Format /d/FILE_ID/
  const dMatch = cleanUrl.match(/\/d\/([a-zA-Z0-9_-]+)/);
  if (dMatch && dMatch[1]) return dMatch[1];

  // Format ?id=FILE_ID atau &id=FILE_ID
  const idMatch = cleanUrl.match(/[?&]id=([a-zA-Z0-9_-]+)/);
  if (idMatch && idMatch[1]) return idMatch[1];

  // Format uc?export=view&id=FILE_ID
  const ucMatch = cleanUrl.match(/\/uc\?.*id=([a-zA-Z0-9_-]+)/);
  if (ucMatch && ucMatch[1]) return ucMatch[1];

  // Format open?id=FILE_ID
  const openMatch = cleanUrl.match(/\/open\?id=([a-zA-Z0-9_-]+)/);
  if (openMatch && openMatch[1]) return openMatch[1];

  return '';
}

export function getGoogleDriveDirectImageUrl(url: string | null | undefined): string {
  if (!url) return '';
  const cleanUrl = String(url).trim().replace(/['"]/g, '');
  if (cleanUrl.startsWith('data:image') || cleanUrl.startsWith('blob:')) return cleanUrl;

  const id = extractGoogleDriveFileId(cleanUrl);
  if (id) {
    // lh3.googleusercontent.com/d/ID atau drive.google.com/thumbnail
    return `https://lh3.googleusercontent.com/d/${id}`;
  }
  return cleanUrl;
}

export function getGoogleDriveThumbnailUrl(url: string | null | undefined): string {
  if (!url) return '';
  const cleanUrl = String(url).trim().replace(/['"]/g, '');
  if (cleanUrl.startsWith('data:image') || cleanUrl.startsWith('blob:')) return cleanUrl;

  const id = extractGoogleDriveFileId(cleanUrl);
  if (id) {
    return `https://drive.google.com/thumbnail?id=${id}&sz=w1000`;
  }
  return cleanUrl;
}

export function normalizeClassName(className: string | null | undefined): string {
  if (!className) return '';
  const str = String(className).trim();
  if (str.toUpperCase() === 'NONE' || str.toUpperCase() === 'TANPA KELAS') return 'None';
  return str
    .toUpperCase()
    .replace(/\bKELAS\b/gi, '')
    .replace(/[-_]/g, '')
    .replace(/\s+/g, '')
    .trim();
}

export const PKBM_PACKAGES = [
  { id: 'PAKET_A', name: 'PAKET A (SD KELAS 4 - 6)', jenjang: 'SD / Paket A', classes: ['4', '5', '6'] },
  { id: 'PAKET_B', name: 'PAKET B (SMP KELAS 7 - 9)', jenjang: 'SMP / Paket B', classes: ['7', '8', '9'] },
  { id: 'PAKET_C', name: 'PAKET C (SMA KELAS 10 - 12)', jenjang: 'SMA / Paket C', classes: ['10', '11', '12'] },
];

export const DEFAULT_CLASSES = [...CLASSES];

export function sortClasses(classes: string[]): string[] {
  return [...classes].sort((a, b) => {
    return a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' });
  });
}

export function getPaketNameByClass(className: string | null | undefined): string {
  const clean = normalizeClassName(className);
  if (['4', '5', '6'].includes(clean)) return 'SD / PAKET A';
  if (['7', '8', '9'].includes(clean)) return 'SMP / PAKET B';
  if (['10', '11', '12'].includes(clean)) return 'SMA / PAKET C';
  return '';
}

export function formatClassLabel(className: string | null | undefined, withPrefix: boolean = true): string {
  if (!className) return 'Tanpa Kelas';
  const str = String(className).trim();
  if (str === 'Semua' || str === 'Semua Kelas' || str === 'ALL') return 'Semua Kelas';
  const clean = normalizeClassName(className);
  if (!clean || clean === 'NONE' || clean === 'None' || clean === 'Tanpa Kelas') return 'Tanpa Kelas';
  return withPrefix ? `Kelas ${clean}` : clean;
}

export function matchClass(studentClass: string | null | undefined, targetClass: string | null | undefined): boolean {
  if (!targetClass || targetClass === 'Semua' || targetClass === 'Semua Kelas' || targetClass === 'ALL' || targetClass === '') return true;
  if (!studentClass) return targetClass === 'None' || targetClass === 'Tanpa Kelas';
  const cleanStudent = normalizeClassName(studentClass);
  const cleanTarget = normalizeClassName(targetClass);
  if (cleanStudent === cleanTarget) return true;
  // Handle multiple classes separated by comma or semicolon in targetClass or studentClass
  if (targetClass.includes(',') || targetClass.includes(';')) {
    const list = targetClass.split(/[,;]/).map(c => normalizeClassName(c));
    return list.includes(cleanStudent);
  }
  return false;
}

export function matchStatusActive(status: string | null | undefined): boolean {
  if (!status) return true; // Default aktif jika kosong
  const cleanStatus = String(status).trim().toLowerCase();
  // Siswa Aktif, Tidak Aktif (jarang masuk), dan Belum (belum masuk dapodik) adalah siswa terdaftar yang aktif berkegiatan
  if (cleanStatus.includes('pindah') || cleanStatus.includes('mutasi')) return false;
  if (cleanStatus.includes('lulus') || cleanStatus.includes('alumni')) return false;
  if (cleanStatus.includes('keluar') || cleanStatus.includes('do') || cleanStatus.includes('dropout')) return false;
  return true;
}

export function getActiveClasses(students: any[]): string[] {
  const set = new Set<string>();
  if (Array.isArray(students) && students.length > 0) {
    students.forEach(s => {
      if (s && matchStatusActive(s.status) && s.class) {
        const clean = normalizeClassName(s.class);
        if (clean && clean !== 'None' && clean !== 'NONE') set.add(clean);
      }
    });
  }
  if (set.size === 0) {
    DEFAULT_CLASSES.forEach(c => set.add(c));
  }
  return sortClasses(Array.from(set));
}

export function getAllClasses(students: any[]): string[] {
  const set = new Set<string>();
  if (Array.isArray(students) && students.length > 0) {
    students.forEach(s => {
      if (s && s.class) {
        const clean = normalizeClassName(s.class);
        if (clean && clean !== 'None' && clean !== 'NONE') set.add(clean);
      }
    });
  }
  if (set.size === 0) {
    DEFAULT_CLASSES.forEach(c => set.add(c));
  }
  return sortClasses(Array.from(set));
}

export function fileToBase64WithCompression(file: File, maxWidth: number = 400, maxHeight: number = 500, quality: number = 0.85): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
        } else {
          if (height > maxHeight) {
            width = Math.round((width * maxHeight) / height);
            height = maxHeight;
          }
        }

        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve(e.target?.result as string);
          return;
        }
        ctx.drawImage(img, 0, 0, width, height);
        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve(dataUrl);
      };
      img.onerror = () => {
        resolve(e.target?.result as string);
      };
      img.src = e.target?.result as string;
    };
    reader.onerror = (error) => reject(error);
    reader.readAsDataURL(file);
  });
}

// -------------------------------------------------------------
// STATUS YATIM PIATU DEFINISI & HELPER
// Yatim: Bapak/Ayah sudah meninggal
// Piatu: Ibu sudah meninggal
// Yatim Piatu: Ayah dan Ibu keduanya sudah meninggal
// Lengkap: Kedua orang tua masih hidup
// -------------------------------------------------------------
export type YatimStatus = 'Lengkap' | 'Yatim' | 'Piatu' | 'Yatim Piatu';

export function getStudentStatusYatim(student?: any): YatimStatus {
  if (!student) return 'Lengkap';

  const rawStatusYatim = String(student.statusYatim || student.status_yatim || '').trim().toLowerCase();
  if (
    rawStatusYatim === 'yatim piatu' ||
    rawStatusYatim.includes('yatim piatu') ||
    rawStatusYatim.includes('yatimpiatu') ||
    rawStatusYatim.includes('yatim-piatu')
  ) {
    return 'Yatim Piatu';
  }
  if (rawStatusYatim === 'yatim') {
    return 'Yatim';
  }
  if (rawStatusYatim === 'piatu') {
    return 'Piatu';
  }
  if (rawStatusYatim === 'lengkap' || rawStatusYatim === 'bukan yatim' || rawStatusYatim === 'ada') {
    return 'Lengkap';
  }

  // Cek berdasarkan status hidup ayah dan status hidup ibu
  const sAyah = String(student.statusAyah || student.status_ayah || '').toLowerCase();
  const sIbu = String(student.statusIbu || student.status_ibu || '').toLowerCase();
  const nAyah = String(student.namaAyah || student.parentName || '').toLowerCase();
  const nIbu = String(student.namaIbu || '').toLowerCase();

  const ayahMeninggal = sAyah.includes('meninggal') || sAyah.includes('alm') || nAyah.includes('alm.') || nAyah.includes('(alm)');
  const ibuMeninggal = sIbu.includes('meninggal') || sIbu.includes('alm') || nIbu.includes('alm.') || nIbu.includes('almh') || nIbu.includes('(alm)');

  if (ayahMeninggal && ibuMeninggal) return 'Yatim Piatu';
  if (ayahMeninggal) return 'Yatim';
  if (ibuMeninggal) return 'Piatu';

  return 'Lengkap';
}

export function getYatimStatusInfo(status: YatimStatus | string) {
  const norm = String(status || '').trim().toLowerCase();
  if (norm.includes('yatim piatu') || norm.includes('yatimpiatu') || norm.includes('yatim-piatu')) {
    return {
      status: 'Yatim Piatu' as YatimStatus,
      label: 'Yatim Piatu',
      sublabel: 'Ayah & Ibu Meninggal',
      description: 'Ayah dan Ibu keduanya sudah meninggal dunia',
      badgeClass: 'bg-slate-900 text-white border-slate-950 shadow-xs',
      chipClass: 'bg-slate-800 text-white font-bold',
      lightBg: 'bg-slate-100 text-slate-900 border border-slate-300',
      pillClass: 'bg-slate-100 text-slate-800 border-slate-300',
      textColor: 'text-slate-900',
      icon: '🖤'
    };
  }
  if (norm === 'yatim' || norm.includes('yatim')) {
    return {
      status: 'Yatim' as YatimStatus,
      label: 'Yatim',
      sublabel: 'Ayah Meninggal',
      description: 'Bapak / Ayah sudah meninggal dunia',
      badgeClass: 'bg-purple-600 text-white border-purple-700 shadow-xs',
      chipClass: 'bg-purple-600 text-white font-bold',
      lightBg: 'bg-purple-50 text-purple-900 border border-purple-200',
      pillClass: 'bg-purple-50 text-purple-800 border-purple-200',
      textColor: 'text-purple-700',
      icon: '💜'
    };
  }
  if (norm === 'piatu' || norm.includes('piatu')) {
    return {
      status: 'Piatu' as YatimStatus,
      label: 'Piatu',
      sublabel: 'Ibu Meninggal',
      description: 'Ibu sudah meninggal dunia',
      badgeClass: 'bg-pink-600 text-white border-pink-700 shadow-xs',
      chipClass: 'bg-pink-600 text-white font-bold',
      lightBg: 'bg-pink-50 text-pink-900 border border-pink-200',
      pillClass: 'bg-pink-50 text-pink-800 border-pink-200',
      textColor: 'text-pink-700',
      icon: '🌸'
    };
  }
  return {
    status: 'Lengkap' as YatimStatus,
    label: 'Lengkap',
    sublabel: 'Orang Tua Masih Hidup',
    description: 'Kedua orang tua (Ayah & Ibu) masih hidup',
    badgeClass: 'bg-emerald-600 text-white border-emerald-700 shadow-xs',
    chipClass: 'bg-emerald-600 text-white font-bold',
    lightBg: 'bg-emerald-50 text-emerald-900 border border-emerald-200',
    pillClass: 'bg-emerald-50 text-emerald-800 border-emerald-200',
    textColor: 'text-emerald-700',
    icon: '🌿'
  };
}


