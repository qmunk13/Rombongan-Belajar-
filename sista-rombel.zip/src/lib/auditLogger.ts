import { db } from '../data/db';
import { AuditLogItem } from '../data/auditSeed';
import { getActiveRole } from './permissions';

export function logActivity(params: {
  user?: string;
  role?: string;
  modul: AuditLogItem['modul'];
  aksi: AuditLogItem['aksi'];
  target: string;
  rincian: string;
  status?: 'SUKSES' | 'PERINGATAN' | 'GAGAL';
  ipAddress?: string;
}): void {
  try {
    const now = new Date();
    const pad = (n: number) => String(n).padStart(2, '0');
    const timestampStr = `${now.getFullYear()}-${pad(now.getMonth() + 1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
    
    const activeRole = getActiveRole();
    const activeRoleName = activeRole?.namaRole || 'Administrator';
    const activeUserName = 'Staf Admin';

    const newLog: AuditLogItem = {
      id: `LOG-${Date.now()}-${Math.floor(Math.random() * 900) + 100}`,
      timestamp: timestampStr,
      user: params.user || activeUserName,
      role: params.role || activeRoleName,
      modul: params.modul,
      aksi: params.aksi,
      target: params.target,
      rincian: params.rincian,
      ipAddress: params.ipAddress || '192.168.1.1',
      status: params.status || 'SUKSES'
    };

    const currentLogs = db.get<AuditLogItem>('audit_logs') || [];
    const updatedLogs = [newLog, ...currentLogs.slice(0, 499)]; // keep latest 500
    db.set('audit_logs', updatedLogs);
  } catch (err) {
    console.error('Failed to write audit log:', err);
  }
}
