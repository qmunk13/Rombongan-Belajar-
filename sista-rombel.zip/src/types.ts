export type Gender = 'L' | 'P';
export type StudentStatus = 'AKTIF' | 'TIDAK AKTIF' | 'BELUM' | 'PINDAH' | 'KELUAR' | 'LULUS' | 'DROP_OUT' | 'MENINGGAL' | 'Aktif' | 'Nonaktif' | string;
export type AttendanceStatus = 'Hadir' | 'Sakit' | 'Izin' | 'Alpa' | 'Terlambat';
export type PaymentStatus = 'Lunas' | 'Belum Lunas' | 'Menunggu' | string;

export interface Rombel {
  id: string;
  name: string;
  gradeLevel: number;
  walikelasId: string;
  walikelasName?: string;
  homeroomTeacher?: string;
  academicYear: string;
  quota?: number;
}

export interface Subject {
  id: string;
  code?: string;
  name: string;
  category?: string;
  kkm: number;
  teacherName?: string;
}

export interface AttendanceRecord {
  id: string;
  studentId: string;
  classId: string;
  date: string;
  status: AttendanceStatus;
  time?: string;
  note?: string;
}

export interface GradeRecord {
  id: string;
  studentId: string;
  subjectId: string;
  semester: 'Ganjil' | 'Genap';
  academicYear: string;
  nilaiTugas: number;
  nilaiUTS: number;
  nilaiUAS: number;
  nilaiAkhir: number;
  predikat: 'A' | 'B' | 'C' | 'D';
  catatan?: string;
}

export interface BehaviorRecord {
  id: string;
  studentId: string;
  type: 'Prestasi' | 'Pelanggaran';
  category?: string;
  reporter?: string;
  points: number;
  description: string;
  date: string;
}

export interface FeePayment {
  id: string;
  studentId: string;
  month: string;
  amount: number;
  status: PaymentStatus;
  paymentDate?: string;
  invoiceNo?: string;
}

export interface ScheduleItem {
  id: string;
  rombelId: string;
  subjectId: string;
  teacherName: string;
  day: string;
  startTime: string;
  endTime: string;
  room?: string;
}

export interface SchoolInfo {
  name: string;
  address: string;
  city: string;
  province: string;
  npsn: string;
  phone: string;
  email: string;
  academicYear: string;
  semesterActive: string;
}

export interface Student {
  id: string;
  nis: string;
  nisn?: string;
  nik?: string;
  name: string;
  class: string; // 1A-6C / KelasSaatini
  gender: Gender;
  pob?: string; // Tempat Lahir
  dob: string;  // Tanggal Lahir (YYYY-MM-DD)
  
  // Data Dapodik & Tambahan Siswa
  tahunMasuk?: string;
  TahunMasuk?: string;
  anakKe?: string | number;
  saudara?: string | number;
  agama?: string;
  golonganDarah?: string;
  tinggiBadan?: string | number;
  beratBadan?: string | number;
  prestasi?: string;
  hobi?: string;
  catatanPenting?: string;
  
  // Alamat & Domisili
  address: string;
  rt?: string;
  rw?: string;
  kelurahan?: string;
  kecamatan?: string;
  kota?: string;
  provinsi?: string;
  kodePos?: string;
  jenisTinggal?: string;
  alatTransportasi?: string;
  noHp?: string;
  phone?: string;
  email?: string;
  
  // Sekolah & Kelulusan
  sekolahAsal?: string;
  skhun?: string;
  penerimaKps?: string;
  sekolahTujuan?: string;
  tanggalMutasi?: string;
  ijazahNo?: string;
  status: StudentStatus;

  // Data Orang Tua / Wali
  parentName: string;
  parentPhone?: string;
  fatherName?: string;
  NamaIbu?: string;
  fatherJob?: string;
  motherJob?: string;
  noKk?: string;
  namaAyah?: string;
  nikAyah?: string;
  tempatLahirAyah?: string;
  tanggalLahirAyah?: string;
  pendidikanAyah?: string;
  pekerjaanAyah?: string;
  penghasilanAyah?: string;
  tlpAyah?: string;
  statusAyah?: 'Masih Hidup' | 'Meninggal' | string;

  namaIbu?: string;
  nikIbu?: string;
  tempatLahirIbu?: string;
  tanggalLahirIbu?: string;
  pendidikanIbu?: string;
  pekerjaanIbu?: string;
  penghasilanIbu?: string;
  tlpIbu?: string;
  statusIbu?: 'Masih Hidup' | 'Meninggal' | string;

  statusYatim?: 'Lengkap' | 'Yatim' | 'Piatu' | 'Yatim Piatu' | string;

  namaWali?: string;
  tempatLahirWali?: string;
  tglLahirWali?: string;
  pendidikanWali?: string;
  pekerjaanWali?: string;
  penghasilanWali?: string;
  hubunganWali?: string;
  tlpWali?: string;

  // Link Berkas Digital Google Drive (12 Berkas Resmi)
  fotoUrl?: string;          // 1. Pas Foto Siswa (3x4 / 4x6)
  pasFoto?: string;          // alias
  aktaKelahiranUrl?: string; // 2. Akta Kelahiran
  akteUrl?: string;          // alias
  kartuKeluargaUrl?: string; // 3. Kartu Keluarga (KK)
  kkUrl?: string;            // alias
  kiaUrl?: string;           // 4. KIA / KTP Anak
  ktpAnakUrl?: string;       // alias
  ktpAyahUrl?: string;       // 5. KTP Ayah Kandung
  ktpIbuUrl?: string;        // 6. KTP Ibu Kandung
  ijazahUrl?: string;        // 7. Ijazah / SKL
  ktpWaliUrl?: string;       // 8. KTP Wali Murid
  raporUrl?: string;         // 9. Buku Rapor / Nilai
  rapotUrl?: string;         // alias
  suratPindahUrl?: string;   // 10. Surat Pindah / Mutasi
  suKetUrl?: string;         // 11. Surat Keterangan (SuKet)
  dokumenLainUrl?: string;   // alias
  dokumenLainName?: string;
  suratDomisiliUrl?: string; // 12. Surat Domisili / KIP / Lainnya
  kipUrl?: string;
  berkasUrl?: string;

  createdAt: string;
  updatedAt: string;
  [key: string]: any;
}

export interface Teacher {
  id: string;
  nip: string;
  nik?: string;
  nuptk?: string;
  name: string;
  gelar?: string;
  gender: 'L' | 'P';
  tempatLahir?: string;
  tanggalLahir?: string;
  agama?: string;
  alamat?: string;
  class: string; // Walikelas kelas berapa, e.g. "1A", "None", atau Jabatan
  phone: string;
  email: string;
  pendidikan?: string;
  jurusan?: string;
  jabatan?: string;
  waliKelas?: string;
  statusKepegawaian?: string;
  tmt?: string;
  status: 'Aktif' | 'Nonaktif';
  fotoUrl?: string;
  createdAt: string;
  updatedAt: string;
  [key: string]: any;
}

export interface Settings {
  scriptUrl: string;
  spreadsheetId?: string;
  folderId?: string;
  folderSiswaId?: string;
  appName?: string;
  adminUsername?: string;
  adminPassword?: string;
  schoolLogoUrl?: string;
  logoUrl?: string;
  tahunPelajaran?: string;
  semester?: string;
  schoolName?: string;
  namaSekolah?: string;
  npsn?: string;
  alamat?: string;
  desa?: string;
  kecamatan?: string;
  kabupaten?: string;
  provinsi?: string;
  kodePos?: string;
  telepon?: string;
  kontak?: string;
  email?: string;
  website?: string;
  kepalaSekolah?: string;
  nipKepalaSekolah?: string;
  [key: string]: any;
}

export interface AppState {
  isAuthenticated: boolean;
  students: Student[];
  teachers: Teacher[];
  settings: Settings;
  isLoading: boolean;
  error: string | null;
  login: () => void;
  logout: () => void;
  setStudents: (students: Student[]) => void;
  addStudent: (student: Student) => void;
  updateStudent: (id: string, data: Partial<Student>) => void;
  updateStudentsBulk: (updates: {id: string, data: Partial<Student>}[]) => void;
  deleteStudent: (id: string) => void;
  setTeachers: (teachers: Teacher[]) => void;
  addTeacher: (teacher: Teacher) => void;
  updateTeacher: (id: string, data: Partial<Teacher>) => void;
  deleteTeacher: (id: string) => void;
  setSettings: (settings: Settings) => void;
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  lastSyncedAt?: string | null;
  isSyncingGlobal?: boolean;
  setLastSyncedAt: (time: string | null) => void;
  setIsSyncingGlobal: (syncing: boolean) => void;
  clearAllData: () => void;
}

export interface SPMBPendaftar {
  kodePendaftaran: string;
  nama: string;
  nisn?: string;
  nik?: string;
  jk?: string;
  tglLahir?: string;
  status: 'Pending' | 'Diterima' | 'Ditolak' | string;
  tanggalDaftar: string;
  agama?: string;
  alamat?: string;
  namaAyah?: string;
  namaIbu?: string;
  noHp?: string;
  fileUrls?: Record<string, string>;
  [key: string]: any;
}

export interface WebConfig {
  appName?: string;
  subJudulNavbar?: string;
  judulSidebar?: string;
  logoUrl?: string;
  profileImageUrl?: string;
  kepalaSekolahImageUrl?: string;
  beritaImageUrl?: string;
  heroImageUrl?: string;
  teksHero?: string;
  heroBaris1?: string;
  heroBaris2?: string;
  heroSubteks?: string;
  footerJudul?: string;
  footerAlamat?: string;
  footerTelepon?: string;
  footerEmail?: string;
  footerHakCipta?: string;
  linkFb?: string;
  linkIg?: string;
  linkYt?: string;
  linkTg?: string;
  pendaftaranStatus?: 'dibuka' | 'ditutup' | 'buka' | 'tutup' | string;
  runningText?: string;
  alur1_judul?: string;
  alur1_desc?: string;
  alur2_judul?: string;
  alur2_desc?: string;
  alur3_judul?: string;
  alur3_desc?: string;
  alur4_judul?: string;
  alur4_desc?: string;
  visi?: string;
  misi?: string;
  [key: string]: any;
}

export interface FormFieldConfig {
  key: string;
  label: string;
  type: 'text' | 'number' | 'date' | 'dropdown' | 'file' | 'textarea' | string;
  options?: string;
  show: boolean;
  required: boolean;
  grid?: string | number;
}

// 1. Perpustakaan Digital (E-Perpus)
export interface BookItem {
  id: string;
  kodeBuku: string;
  isbn?: string;
  judul: string;
  pengarang: string;
  penerbit: string;
  tahunTerbit: string;
  kategori: 'Buku Paket/Pelajaran' | 'Referensi/Kamus' | 'Novel/Fiksi' | 'Ensiklopedia' | 'Karya Ilmiah' | 'Majalah' | 'Lainnya';
  lokasiRak: string;
  stokTotal: number;
  stokTersedia: number;
  deskripsi?: string;
  coverUrl?: string;
  createdAt?: string;
}

export interface BookLoan {
  id: string;
  kodePeminjaman: string;
  bukuId: string;
  judulBuku: string;
  peminjamId: string;
  namaPeminjam: string;
  tipePeminjam: 'Siswa' | 'Guru' | 'Staf';
  kelasOrDepartemen?: string;
  tanggalPinjam: string;
  tenggatKembali: string;
  tanggalKembali?: string;
  status: 'Dipinjam' | 'Kembali' | 'Terlambat' | 'Hilang';
  denda?: number;
  catatan?: string;
}

// 2. Notifikasi WhatsApp Gateway
export interface WhatsAppMessage {
  id: string;
  kategori: 'Presensi' | 'Tagihan' | 'Pengumuman' | 'Akademik' | 'SPMB' | 'Darurat' | 'Lainnya';
  penerimaNama: string;
  penerimaRole: 'Orang Tua' | 'Siswa' | 'Guru' | 'Semua';
  nomorHp: string;
  isiPesan: string;
  status: 'Draft' | 'Terkirim' | 'Gagal';
  waktuKirim: string;
  pengirim?: string;
}

// 3. Ekstrakurikuler & OSIS
export interface EkskulItem {
  id: string;
  kodeEkskul: string;
  nama: string;
  kategori: 'Wajib' | 'Pilihan' | 'Keolahragaan' | 'Kesenian & Budaya' | 'Keagamaan' | 'Sains & Teknologi' | 'Kepemimpinan/OSIS';
  pembinaId?: string;
  namaPembina: string;
  hariLatihan: string;
  waktuLatihan: string;
  tempatLatihan: string;
  kuota?: number;
  deskripsi?: string;
  status: 'Aktif' | 'Nonaktif';
}

export interface EkskulMember {
  id: string;
  ekskulId: string;
  namaEkskul: string;
  studentId: string;
  nis: string;
  namaSiswa: string;
  kelas: string;
  jabatan: 'Ketua' | 'Wakil Ketua' | 'Sekretaris' | 'Bendahara' | 'Anggota';
  tanggalGabung: string;
  nilai?: 'A' | 'B' | 'C' | 'D';
  keterangan?: string;
}

// 4. Mading & Berita Digital Sekolah
export interface MadingItem {
  id: string;
  judul: string;
  kategori: 'Pengumuman' | 'Berita' | 'Prestasi' | 'Agenda' | 'Artikel Siswa' | 'Karya Seni';
  konten: string;
  penulis: string;
  peranPenulis: 'Admin' | 'Guru' | 'OSIS' | 'Siswa';
  tanggal: string;
  status: 'Publish' | 'Draft';
  prioritas: 'Normal' | 'Penting' | 'Urgent';
  gambarUrl?: string;
  lampiranUrl?: string;
  targetAudiens: 'Semua' | 'Siswa' | 'Orang Tua' | 'Guru' | 'Publik';
}


