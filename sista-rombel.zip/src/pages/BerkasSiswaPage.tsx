import React, { useState, useRef } from 'react';
import { useStore } from '../store';
import { Student } from '../types';
import { cn, matchClass, getActiveClasses, getAllClasses, formatClassLabel, getGoogleDriveDirectImageUrl, STANDARD_CLASSES } from '../lib/utils';
import { 
  FolderOpen, CheckCircle2, AlertCircle, Search, Filter, Upload, Download, 
  Eye, Trash2, ExternalLink, RefreshCw, X, Printer, Check, ChevronRight,
  User, ShieldCheck, FileCheck, FileSpreadsheet, Paperclip, Clock, Info,
  Image as ImageIcon, FileQuestion, ArrowUpRight, FileText, CloudUpload,
  AlertTriangle, CheckCircle, Sparkles, Smartphone, Layers
} from 'lucide-react';
import { fileToBase64, uploadFileToGAS, fetchFromGAS } from '../lib/api';
import { exportToExcel } from '../lib/excel';

export interface DocItemConfig {
  key: keyof Student;
  label: string;
  shortLabel: string;
  category: string;
  required: boolean;
  color: string;
  badgeBg: string;
  badgeText: string;
  badgeBorder: string;
  description: string;
}

export const STUDENT_DOC_CONFIGS: DocItemConfig[] = [
  {
    key: 'fotoUrl',
    label: '1. Pas Foto Siswa (3x4 / 4x6) (PasFoto)',
    shortLabel: 'Pas Foto',
    category: 'Identitas Siswa',
    required: true,
    color: 'amber',
    badgeBg: 'bg-amber-50',
    badgeText: 'text-amber-700',
    badgeBorder: 'border-amber-200',
    description: 'Pas Foto resmi siswa ukuran 3x4 atau 4x6'
  },
  {
    key: 'aktaKelahiranUrl',
    label: '2. Akta Kelahiran (AktaKelahiran)',
    shortLabel: 'Akta',
    category: 'Identitas Pokok',
    required: true,
    color: 'emerald',
    badgeBg: 'bg-emerald-50',
    badgeText: 'text-emerald-700',
    badgeBorder: 'border-emerald-200',
    description: 'Surat Akta Kelahiran resmi dari Dukcapil'
  },
  {
    key: 'kartuKeluargaUrl',
    label: '3. Kartu Keluarga (KartuKeluarga)',
    shortLabel: 'KK',
    category: 'Identitas Pokok',
    required: true,
    color: 'indigo',
    badgeBg: 'bg-indigo-50',
    badgeText: 'text-indigo-700',
    badgeBorder: 'border-indigo-200',
    description: 'Kartu Keluarga terbaru yang memuat nama siswa'
  },
  {
    key: 'kiaUrl',
    label: '4. KIA / KTP Anak (KIA)',
    shortLabel: 'KIA',
    category: 'Identitas Siswa',
    required: false,
    color: 'blue',
    badgeBg: 'bg-blue-50',
    badgeText: 'text-blue-700',
    badgeBorder: 'border-blue-200',
    description: 'Kartu Identitas Anak (KIA) atau KTP anak usia di bawah 17 tahun'
  },
  {
    key: 'ktpAyahUrl',
    label: '5. KTP Ayah Kandung (KTPAyah)',
    shortLabel: 'KTP Ayah',
    category: 'Identitas Orang Tua',
    required: false,
    color: 'sky',
    badgeBg: 'bg-sky-50',
    badgeText: 'text-sky-700',
    badgeBorder: 'border-sky-200',
    description: 'KTP Asli / Scan Ayah Kandung'
  },
  {
    key: 'ktpIbuUrl',
    label: '6. KTP Ibu Kandung (KTPIbu)',
    shortLabel: 'KTP Ibu',
    category: 'Identitas Orang Tua',
    required: false,
    color: 'pink',
    badgeBg: 'bg-pink-50',
    badgeText: 'text-pink-700',
    badgeBorder: 'border-pink-200',
    description: 'KTP Asli / Scan Ibu Kandung'
  },
  {
    key: 'ijazahUrl',
    label: '7. Ijazah / SKL (Ijazah)',
    shortLabel: 'Ijazah',
    category: 'Riwayat Pendidikan',
    required: false,
    color: 'purple',
    badgeBg: 'bg-purple-50',
    badgeText: 'text-purple-700',
    badgeBorder: 'border-purple-200',
    description: 'Ijazah / SKL jenjang TK / PAUD / SD sebelumnya'
  },
  {
    key: 'ktpWaliUrl',
    label: '8. KTP Wali Murid (KTPWali)',
    shortLabel: 'KTP Wali',
    category: 'Identitas Orang Tua',
    required: false,
    color: 'amber',
    badgeBg: 'bg-amber-50',
    badgeText: 'text-amber-700',
    badgeBorder: 'border-amber-200',
    description: 'KTP Wali Murid penanggung jawab siswa (jika ada)'
  },
  {
    key: 'raporUrl',
    label: '9. Buku Rapor / Nilai (Rapor)',
    shortLabel: 'Rapor',
    category: 'Riwayat Pendidikan',
    required: false,
    color: 'cyan',
    badgeBg: 'bg-cyan-50',
    badgeText: 'text-cyan-700',
    badgeBorder: 'border-cyan-200',
    description: 'Scan / Foto lembar rapor terakhir siswa'
  },
  {
    key: 'suratPindahUrl',
    label: '10. Surat Pindah / Mutasi (S.Pindah)',
    shortLabel: 'S.Pindah',
    category: 'Mutasi & Legalitas',
    required: false,
    color: 'rose',
    badgeBg: 'bg-rose-50',
    badgeText: 'text-rose-700',
    badgeBorder: 'border-rose-200',
    description: 'Surat mutasi dari sekolah asal (jika siswa pindahan)'
  },
  {
    key: 'suKetUrl',
    label: '11. Surat Keterangan / SuKet (SuKet)',
    shortLabel: 'SuKet',
    category: 'Pendukung Tambahan',
    required: false,
    color: 'teal',
    badgeBg: 'bg-teal-50',
    badgeText: 'text-teal-700',
    badgeBorder: 'border-teal-200',
    description: 'KIP, KPS, PKH, Piagam Prestasi, atau Surat Keterangan'
  },
  {
    key: 'suratDomisiliUrl',
    label: '12. Surat Domisili / KIP (S.Domisili)',
    shortLabel: 'S.Domisili',
    category: 'Identitas Pokok',
    required: false,
    color: 'violet',
    badgeBg: 'bg-violet-50',
    badgeText: 'text-violet-700',
    badgeBorder: 'border-violet-200',
    description: 'Surat Keterangan Domisili atau Kartu Indonesia Pintar'
  }
];

export default function BerkasSiswaPage() {
  const { students, updateStudent, settings, setLoading, setIsSyncingGlobal, setLastSyncedAt } = useStore();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterClass, setFilterClass] = useState('');
  const [filterTahunMasuk, setFilterTahunMasuk] = useState('');
  const [filterStatus, setFilterStatus] = useState<'incomplete' | 'all' | 'complete'>('incomplete');
  
  // Modal State for Managing Student Documents
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  
  // Preview State
  const [previewDoc, setPreviewDoc] = useState<{ title: string; url: string; studentName: string } | null>(null);

  // Uploading state inside modal
  const [isUploading, setIsUploading] = useState<string | null>(null); // holds docKey
  const [manualUrlInput, setManualUrlInput] = useState<{ [docKey: string]: string }>({});
  const [activeUrlTab, setActiveUrlTab] = useState<{ [docKey: string]: 'file' | 'link' }>({});
  
  const fileInputRefs = useRef<{ [key: string]: HTMLInputElement | null }>({});

  const [filterStudentStatus, setFilterStudentStatus] = useState<string>('ALL');
  
  const availableClasses = React.useMemo(() => {
    return Array.from(new Set([...getAllClasses(students), ...STANDARD_CLASSES])).sort((a, b) =>
      a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' })
    );
  }, [students]);

  // Available Entry Years
  const availableTahunMasuk = React.useMemo(() => {
    const yearsSet = new Set<string>();
    students.forEach((s: any) => {
      const raw = String(s.tahunMasuk || s['TahunMasuk'] || s['ThnMasuk'] || s['tahun_masuk'] || '').trim();
      if (raw && raw !== '-' && raw !== 'null' && raw !== 'undefined') {
        const match = raw.match(/\b(20\d{2}|19\d{2})\b/);
        if (match) yearsSet.add(match[1]);
        else yearsSet.add(raw);
      }
    });
    [2027, 2026, 2025, 2024, 2023].forEach(y => yearsSet.add(String(y)));
    return Array.from(yearsSet).sort((a, b) => b.localeCompare(a));
  }, [students]);

  // Helper to calculate student completeness
  const getStudentCompleteness = (student: Student) => {
    let uploadedCount = 0;
    let requiredUploaded = 0;
    const requiredTotal = STUDENT_DOC_CONFIGS.filter(d => d.required).length;

    STUDENT_DOC_CONFIGS.forEach(doc => {
      let val = student[doc.key];
      // Fallback aliases check
      if (!val || typeof val !== 'string' || val.trim() === '') {
        if (doc.key === 'fotoUrl') val = student.pasFoto;
        else if (doc.key === 'aktaKelahiranUrl') val = student.akteUrl;
        else if (doc.key === 'kartuKeluargaUrl') val = student.kkUrl;
        else if (doc.key === 'kiaUrl') val = student.ktpAnakUrl;
        else if (doc.key === 'raporUrl') val = student.rapotUrl;
        else if (doc.key === 'suKetUrl') val = student.dokumenLainUrl || student.berkasUrl;
        else if (doc.key === 'suratDomisiliUrl') val = student.kipUrl;
      }

      if (val && typeof val === 'string' && val.trim() !== '') {
        uploadedCount++;
        if (doc.required) requiredUploaded++;
      }
    });

    const isComplete = requiredUploaded === requiredTotal && uploadedCount >= 3;
    const totalPossible = STUDENT_DOC_CONFIGS.length;
    const percent = Math.round((uploadedCount / totalPossible) * 100);

    return {
      uploadedCount,
      totalPossible,
      requiredUploaded,
      requiredTotal,
      isComplete,
      percent,
      missingRequired: requiredTotal - requiredUploaded,
      missingTotal: totalPossible - uploadedCount
    };
  };

  // Filter students
  const filteredStudents = students.filter(student => {
    // Student Status filter
    if (filterStudentStatus !== 'ALL') {
      const st = String(student.status || 'Aktif').toLowerCase().trim();
      if (filterStudentStatus === 'Aktif') {
        if (st.includes('tidak') || st === 'nonaktif' || st.includes('belum') || st === 'pindah' || st === 'lulus' || st === 'keluar') return false;
      } else if (filterStudentStatus === 'Tidak Aktif') {
        if (!st.includes('tidak') && st !== 'nonaktif') return false;
      } else if (filterStudentStatus === 'Belum') {
        if (!st.includes('belum') && !st.includes('pending')) return false;
      } else if (filterStudentStatus === 'Pindah') {
        if (st !== 'pindah' && !st.includes('mutasi')) return false;
      } else if (filterStudentStatus === 'Lulus') {
        if (st !== 'lulus') return false;
      } else if (filterStudentStatus === 'Keluar') {
        if (st !== 'keluar' && !st.includes('do')) return false;
      }
    }

    // Search
    const search = searchTerm.toLowerCase();
    const matchesSearch = 
      student.name.toLowerCase().includes(search) ||
      (student.nis && student.nis.toLowerCase().includes(search)) ||
      (student.nisn && student.nisn.toLowerCase().includes(search)) ||
      (student.parentName && student.parentName.toLowerCase().includes(search));

    // Class
    const matchesClass = filterClass ? matchClass(student.class, filterClass) : true;

    // Tahun Masuk
    const rawYr = String(student.tahunMasuk || student.TahunMasuk || (student as any)['ThnMasuk'] || (student as any)['tahun_masuk'] || '').trim();
    const matchYr = rawYr.match(/\b(20\d{2}|19\d{2})\b/);
    const normalizedYr = matchYr ? matchYr[1] : rawYr;
    const matchesTahun = !filterTahunMasuk || normalizedYr === filterTahunMasuk;

    // Completeness Status
    const stats = getStudentCompleteness(student);
    const matchesStatus = 
      filterStatus === 'all' ? true :
      filterStatus === 'complete' ? stats.isComplete :
      !stats.isComplete;

    return matchesSearch && matchesClass && matchesTahun && matchesStatus;
  });

  // Overall Statistics
  const totalStudents = students.length;
  const completeCount = students.filter(s => getStudentCompleteness(s).isComplete).length;
  const incompleteCount = totalStudents - completeCount;
  const totalUploadedDocs = students.reduce((acc, s) => acc + getStudentCompleteness(s).uploadedCount, 0);

  // Sync to GAS helper
  const triggerAutoSync = async (updatedStudent: Student) => {
    if (!settings.scriptUrl) return;
    try {
      setLoading(true);
      setIsSyncingGlobal(true);
      const allStudents = useStore.getState().students.map(s => s.id === updatedStudent.id ? updatedStudent : s);
      await fetchFromGAS(settings.scriptUrl, {
        action: 'sync',
        data: allStudents,
        teachers: useStore.getState().teachers,
        spreadsheetId: settings.spreadsheetId
      });
      setLastSyncedAt(new Date().toLocaleTimeString('id-ID'));
    } catch (e) {
      console.error("Sync document update failed:", e);
    } finally {
      setLoading(false);
      setIsSyncingGlobal(false);
    }
  };

  // Upload handler to Google Drive
  const handleFileUpload = async (student: Student, docConfig: DocItemConfig, e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setIsUploading(String(docConfig.key));
      let fileUrl = '';

      if (settings.scriptUrl) {
        const nopdkt = (student.nis || (student as any).noPDKT || (student as any).nopdkt || student.id || '').toString().trim();
        const studentCleanName = (student.name || 'Siswa').trim();
        // Format subfolder persis: [nopdkt] / Nama Lengkap (misal: "01_BERKAS_SISWA_AKTIF/[2026001] AHMAD FAUZI" atau "[2026001] AHMAD FAUZI")
        const studentFolderName = nopdkt ? `[${nopdkt}] ${studentCleanName}` : studentCleanName;
        const fileExt = file.name.includes('.') ? file.name.split('.').pop() : '';
        const customFilename = `${nopdkt ? '[' + nopdkt + ']_' : ''}${docConfig.shortLabel}_${studentCleanName.replace(/[^a-zA-Z0-9]/g, '_')}${fileExt ? '.' + fileExt : ''}`;

        try {
          // Upload to Google Drive via GAS endpoint with dedicated student folder
          const targetFolderId = settings.folderSiswaId || settings.folderId || 'BERKAS_SISWA_MASTER';
          const res = await uploadFileToGAS(
            settings.scriptUrl, 
            file, 
            targetFolderId, 
            customFilename,
            {
              studentId: student.id,
              nopdkt: nopdkt,
              studentName: student.name,
              studentClass: student.class,
              subFolder: studentFolderName,
              nisn: student.nisn,
              docKey: String(docConfig.key),
              modul: 'BERKAS_SISWA',
              kategori: docConfig.label,
              uploadedBy: 'Admin'
            }
          );
          fileUrl = res?.url || (typeof res === 'string' ? res : '');
        } catch (gasErr: any) {
          console.warn("GAS DriveApp upload failed, falling back to local base64:", gasErr);
          fileUrl = await fileToBase64(file);
          alert(
            "⚠️ Berkas berhasil disimpan di lokal, namun gagal terkirim ke Google Drive karena izin DriveApp belum aktif.\n\n" +
            "💡 Solusi Cepat (1 Menit):\n" +
            "1. Buka spreadsheet Google Anda -> Menu 'Ekstensi' -> 'Apps Script'\n" +
            "2. Di toolbar atas, pilih fungsi 'otorisasiDrive' (atau 'setup')\n" +
            "3. Klik tombol 'Jalankan' (Run ▶) lalu klik 'Tinjau Izin' -> 'Lanjutan' -> 'Buka project (tidak aman)' -> 'Izinkan'\n" +
            "4. Klik 'Deploy (Terapkan)' -> 'Deployment baru' (Eksekusi sebagai: Saya, Akses: Siapa saja)."
          );
        }
      } else {
        // Local offline fallback
        fileUrl = await fileToBase64(file);
      }

      const updated = {
        ...student,
        [docConfig.key]: fileUrl,
        updatedAt: new Date().toISOString()
      };

      updateStudent(student.id, { [docConfig.key]: fileUrl, updatedAt: updated.updatedAt });
      setSelectedStudent(updated);
      await triggerAutoSync(updated);
    } catch (err: any) {
      alert("Gagal mengunggah berkas ke Google Drive: " + (err.message || 'Terjadi kesalahan'));
    } finally {
      setIsUploading(null);
      if (e.target) e.target.value = '';
    }
  };

  // Save manual URL link (e.g. direct Google Drive link)
  const handleSaveManualUrl = async (student: Student, docConfig: DocItemConfig) => {
    const url = manualUrlInput[docConfig.key]?.trim();
    if (!url) return;

    const updated = {
      ...student,
      [docConfig.key]: url,
      updatedAt: new Date().toISOString()
    };

    updateStudent(student.id, { [docConfig.key]: url, updatedAt: updated.updatedAt });
    setSelectedStudent(updated);
    setManualUrlInput(prev => ({ ...prev, [docConfig.key]: '' }));
    await triggerAutoSync(updated);
  };

  // Remove document
  const handleRemoveDoc = async (student: Student, docConfig: DocItemConfig) => {
    if (!window.confirm(`Hapus berkas ${docConfig.label} untuk siswa ${student.name}?`)) return;

    const updated = {
      ...student,
      [docConfig.key]: '',
      updatedAt: new Date().toISOString()
    };

    updateStudent(student.id, { [docConfig.key]: '', updatedAt: updated.updatedAt });
    setSelectedStudent(updated);
    await triggerAutoSync(updated);
  };

  // Export recap to Excel
  const handleExportRecap = () => {
    const dataToExport = filteredStudents.map((s, idx) => {
      const stats = getStudentCompleteness(s);
      return {
        'No': idx + 1,
        'NIS': s.nis || '-',
        'NISN': s.nisn || '-',
        'Nama Siswa': s.name,
        'Kelas': s.class || '-',
        'Status Berkas': stats.isComplete ? 'LENGKAP' : 'BELUM LENGKAP',
        'Kelengkapan (%)': `${stats.percent}%`,
        'Total Terunggah': `${stats.uploadedCount}/${stats.totalPossible}`,
        'Akta Kelahiran': (s.aktaKelahiranUrl || s.akteUrl) ? 'ADA' : 'BELUM',
        'Kartu Keluarga': (s.kartuKeluargaUrl || s.kkUrl) ? 'ADA' : 'BELUM',
        'KIA / KTP Anak': (s.kiaUrl || s.ktpAnakUrl) ? 'ADA' : 'BELUM',
        'KTP Ayah': s.ktpAyahUrl ? 'ADA' : 'BELUM',
        'KTP Ibu': s.ktpIbuUrl ? 'ADA' : 'BELUM',
        'KTP Wali': s.ktpWaliUrl ? 'ADA' : 'BELUM',
        'Ijazah': s.ijazahUrl ? 'ADA' : 'BELUM',
        'Rapor': (s.raporUrl || s.rapotUrl) ? 'ADA' : 'BELUM',
        'Surat Pindah': s.suratPindahUrl ? 'ADA' : 'BELUM',
        'Surat Keterangan': (s.suKetUrl || s.dokumenLainUrl || s.berkasUrl) ? 'ADA' : 'BELUM',
      };
    });

    exportToExcel(dataToExport, `Rekap_Berkas_Dokumen_Siswa_${filterClass || 'Semua_Kelas'}_${new Date().toISOString().slice(0, 10)}.xlsx`, 'Berkas Siswa');
  };

  return (
    <div className="space-y-5 max-w-7xl mx-auto pb-12">
      {/* Page Header */}
      <div className="bg-white/95 p-4 sm:p-5 rounded-3xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-200/80 shadow-2xs flex-shrink-0">
            <FolderOpen size={22} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg sm:text-xl font-black text-slate-900">
                Berkas & Dokumen Siswa
              </h1>
              <span className="hidden sm:inline-block px-2.5 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-extrabold">
                Google Drive Sync
              </span>
            </div>
            <p className="text-xs text-slate-500 font-medium mt-0.5 line-clamp-1 sm:line-clamp-none">
              Arsip digital 8 berkas: Akte, KK, KTP/KIA, KTP Ortu, Ijazah, Rapor, Mutasi, & Dokumen Lainnya.
            </p>
          </div>
        </div>
      </div>

      {/* Top Stat Cards - 2x2 Grid on Mobile, 4-Col on Desktop */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5 sm:gap-4">
        {/* Incomplete Card (Highlighted by Default) */}
        <div 
          onClick={() => setFilterStatus('incomplete')}
          className={cn(
            "p-3.5 sm:p-5 rounded-2xl sm:rounded-3xl border transition-all cursor-pointer shadow-xs active:scale-95 relative overflow-hidden",
            filterStatus === 'incomplete' 
              ? "bg-amber-500 text-white border-amber-500 shadow-md shadow-amber-200 ring-2 ring-amber-400" 
              : "bg-white text-slate-800 border-slate-200/80 hover:border-amber-300"
          )}
        >
          <div className="flex items-center justify-between">
            <span className={cn("text-[10px] sm:text-xs font-black uppercase tracking-wider", filterStatus === 'incomplete' ? "text-amber-100" : "text-amber-600")}>
              Kurang
            </span>
            <div className={cn("w-6 h-6 sm:w-8 sm:h-8 rounded-xl flex items-center justify-center text-xs", filterStatus === 'incomplete' ? "bg-white/20 text-white" : "bg-amber-50 text-amber-600")}>
              <AlertCircle size={15} />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black mt-1 sm:mt-2">
            <span className={filterStatus === 'incomplete' ? "text-white" : "text-amber-600"}>{incompleteCount}</span>
            <span className={cn("text-[11px] sm:text-xs font-bold ml-1.5", filterStatus === 'incomplete' ? "text-amber-100" : "text-slate-400")}>
              Siswa
            </span>
          </div>
          <p className={cn("text-[10px] sm:text-xs mt-0.5 sm:mt-1 font-medium truncate", filterStatus === 'incomplete' ? "text-amber-100" : "text-slate-400")}>
            Prioritas dilengkapi
          </p>
        </div>

        {/* Complete Card */}
        <div 
          onClick={() => setFilterStatus('complete')}
          className={cn(
            "p-3.5 sm:p-5 rounded-2xl sm:rounded-3xl border transition-all cursor-pointer shadow-xs active:scale-95",
            filterStatus === 'complete' 
              ? "bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-200 ring-2 ring-emerald-400" 
              : "bg-white text-slate-800 border-slate-200/80 hover:border-emerald-300"
          )}
        >
          <div className="flex items-center justify-between">
            <span className={cn("text-[10px] sm:text-xs font-black uppercase tracking-wider", filterStatus === 'complete' ? "text-emerald-100" : "text-emerald-600")}>
              Lengkap
            </span>
            <div className={cn("w-6 h-6 sm:w-8 sm:h-8 rounded-xl flex items-center justify-center text-xs", filterStatus === 'complete' ? "bg-white/20 text-white" : "bg-emerald-50 text-emerald-600")}>
              <CheckCircle2 size={15} />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black mt-1 sm:mt-2">
            <span className={filterStatus === 'complete' ? "text-white" : "text-emerald-600"}>{completeCount}</span>
            <span className={cn("text-[11px] sm:text-xs font-bold ml-1.5", filterStatus === 'complete' ? "text-emerald-100" : "text-slate-400")}>
              ({totalStudents > 0 ? Math.round((completeCount / totalStudents) * 100) : 0}%)
            </span>
          </div>
          <p className={cn("text-[10px] sm:text-xs mt-0.5 sm:mt-1 font-medium truncate", filterStatus === 'complete' ? "text-emerald-100" : "text-slate-400")}>
            Foto, Akte & KK terverifikasi
          </p>
        </div>

        {/* Total Students Card */}
        <div 
          onClick={() => setFilterStatus('all')}
          className={cn(
            "p-3.5 sm:p-5 rounded-2xl sm:rounded-3xl border transition-all cursor-pointer shadow-xs active:scale-95",
            filterStatus === 'all' 
              ? "bg-indigo-600 text-white border-indigo-600 shadow-md shadow-indigo-200 ring-2 ring-indigo-400" 
              : "bg-white text-slate-800 border-slate-200/80 hover:border-indigo-300"
          )}
        >
          <div className="flex items-center justify-between">
            <span className={cn("text-[10px] sm:text-xs font-black uppercase tracking-wider", filterStatus === 'all' ? "text-indigo-100" : "text-slate-500")}>
              Semua Siswa
            </span>
            <div className={cn("w-6 h-6 sm:w-8 sm:h-8 rounded-xl flex items-center justify-center text-xs", filterStatus === 'all' ? "bg-white/20 text-white" : "bg-indigo-50 text-indigo-600")}>
              <User size={15} />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black mt-1 sm:mt-2">{totalStudents}</div>
          <p className={cn("text-[10px] sm:text-xs mt-0.5 sm:mt-1 font-medium truncate", filterStatus === 'all' ? "text-indigo-100" : "text-slate-400")}>
            Total siswa terdaftar
          </p>
        </div>

        {/* Total Uploaded Docs Card */}
        <div className="p-3.5 sm:p-5 rounded-2xl sm:rounded-3xl bg-white border border-slate-200/80 shadow-xs">
          <div className="flex items-center justify-between text-indigo-600">
            <span className="text-[10px] sm:text-xs font-black uppercase tracking-wider text-slate-500">
              Total Berkas
            </span>
            <div className="w-6 h-6 sm:w-8 sm:h-8 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
              <FileCheck size={15} />
            </div>
          </div>
          <div className="text-2xl sm:text-3xl font-black text-slate-900 mt-1 sm:mt-2">{totalUploadedDocs}</div>
          <p className="text-[10px] sm:text-xs text-slate-400 mt-0.5 sm:mt-1 font-medium truncate">
            Dokumen di Cloud
          </p>
        </div>
      </div>

      {/* Main Filter & Search Action Bar */}
      <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-3">
        <div className="flex flex-col sm:flex-row gap-2.5 sm:gap-3 items-stretch sm:items-center justify-between">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" size={16} />
            <input
              type="text"
              placeholder="Cari nama siswa, NIS, NISN, atau wali..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-8 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-medium text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition"
            />
            {searchTerm && (
              <button 
                onClick={() => setSearchTerm('')} 
                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X size={14} />
              </button>
            )}
          </div>

          {/* Class Filter, Student Status & Document Completeness Switch */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Status Siswa Filter */}
            <select
              value={filterStudentStatus}
              onChange={(e) => setFilterStudentStatus(e.target.value)}
              className="px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition cursor-pointer"
            >
              <option value="ALL">Status: Semua</option>
              <option value="Aktif">✅ Aktif</option>
              <option value="Tidak Aktif">⚠️ Tidak Aktif</option>
              <option value="Belum">⏳ Belum</option>
              <option value="Pindah">🚚 Pindah</option>
              <option value="Lulus">🎓 Lulus</option>
              <option value="Keluar">🚪 Keluar</option>
            </select>

            <select
              value={filterClass}
              onChange={(e) => setFilterClass(e.target.value)}
              className="px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition cursor-pointer"
            >
              <option value="">Semua Kelas</option>
              {availableClasses.map((cls) => (
                <option key={cls} value={cls}>{formatClassLabel(cls, true)}</option>
              ))}
            </select>

            {/* Filter Tahun Masuk */}
            <select
              value={filterTahunMasuk}
              onChange={(e) => setFilterTahunMasuk(e.target.value)}
              className="px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-amber-500/20 focus:border-amber-500 transition cursor-pointer"
            >
              <option value="">📅 Semua Tahun Masuk</option>
              {availableTahunMasuk.map((yr) => (
                <option key={yr} value={yr}>Tahun Masuk {yr}</option>
              ))}
            </select>

            {/* Quick Status Filter Tabs with Focus on 'Kurang' */}
            <div className="flex items-center bg-slate-100 p-1 rounded-2xl border border-slate-200/80 text-xs font-bold">
              <button
                onClick={() => setFilterStatus('incomplete')}
                className={cn(
                  "px-2.5 sm:px-3 py-1.5 rounded-xl transition-all flex items-center gap-1 text-[11px]",
                  filterStatus === 'incomplete' 
                    ? "bg-amber-500 text-white shadow-xs font-black" 
                    : "text-amber-800 hover:text-amber-900"
                )}
              >
                <AlertCircle size={12} />
                <span>Kurang</span>
                {incompleteCount > 0 && (
                  <span className={cn(
                    "px-1 py-0.2 text-[9px] rounded-full font-bold",
                    filterStatus === 'incomplete' ? "bg-white/25 text-white" : "bg-amber-200 text-amber-900"
                  )}>
                    {incompleteCount}
                  </span>
                )}
              </button>

              <button
                onClick={() => setFilterStatus('all')}
                className={cn(
                  "px-2.5 sm:px-3 py-1.5 rounded-xl transition-all text-[11px]",
                  filterStatus === 'all' ? "bg-white text-indigo-700 shadow-xs font-bold" : "text-slate-600 hover:text-slate-900"
                )}
              >
                Semua
              </button>

              <button
                onClick={() => setFilterStatus('complete')}
                className={cn(
                  "px-2.5 sm:px-3 py-1.5 rounded-xl transition-all flex items-center gap-1 text-[11px]",
                  filterStatus === 'complete' ? "bg-emerald-600 text-white shadow-xs font-bold" : "text-emerald-700 hover:text-emerald-900"
                )}
              >
                <CheckCircle2 size={12} />
                <span>Lengkap</span>
              </button>
            </div>
          </div>
        </div>

        {/* Informative Legend Pill Bar */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-slate-100 text-[10px] sm:text-[11px] font-medium text-slate-500">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="font-bold text-slate-700 mr-1">12 Berkas Resmi:</span>
            {STUDENT_DOC_CONFIGS.map(doc => (
              <span key={doc.key} className={cn("px-1.5 py-0.5 rounded-md border text-[10px]", doc.badgeBg, doc.badgeText, doc.badgeBorder)}>
                {doc.shortLabel} {doc.required ? '*' : ''}
              </span>
            ))}
          </div>

          <div className="text-[10px] text-slate-400 font-medium hidden sm:block">
            💡 Pas Foto, Akta, KK & 9 dokumen lainnya tersimpan aman di Cloud
          </div>
        </div>
      </div>

      {/* ================================================================= */}
      {/* 1. MOBILE RESPONSIVE STUDENT CARDS (Visible on Small Screens)    */}
      {/* ================================================================= */}
      <div className="md:hidden space-y-3">
        <div className="flex justify-between items-center px-1 text-xs font-bold text-slate-600">
          <span>Menampilkan {filteredStudents.length} Siswa</span>
          <span>{filterStatus === 'incomplete' ? 'Status: Kurang' : filterStatus === 'complete' ? 'Status: Lengkap' : 'Semua'}</span>
        </div>

        {filteredStudents.length === 0 ? (
          <div className="p-8 text-center bg-white rounded-3xl border border-slate-200/80 shadow-xs space-y-2">
            <CheckCircle2 size={32} className="mx-auto text-emerald-500" />
            <p className="text-xs font-bold text-slate-800">
              {filterStatus === 'incomplete' 
                ? 'Semua berkas siswa telah lengkap!' 
                : 'Tidak ada data siswa yang cocok dengan filter.'}
            </p>
          </div>
        ) : (
          filteredStudents.map((student) => {
            const stats = getStudentCompleteness(student);
            return (
              <div 
                key={student.id} 
                className="bg-white p-4 rounded-3xl border border-slate-200/80 shadow-xs space-y-3 transition-all"
              >
                {/* Header info */}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-2.5">
                    <div className="w-10 h-10 rounded-2xl bg-indigo-50 border border-indigo-100 text-indigo-700 font-black flex items-center justify-center flex-shrink-0 overflow-hidden text-sm">
                      {student.fotoUrl ? (
                        <img 
                          src={getGoogleDriveDirectImageUrl(student.fotoUrl)} 
                          alt={student.name}
                          className="w-full h-full object-cover rounded-2xl"
                          onError={(e) => { (e.target as any).style.display = 'none'; }}
                        />
                      ) : (
                        student.name.charAt(0).toUpperCase()
                      )}
                    </div>
                    <div>
                      <div className="flex items-center gap-1.5">
                        <h3 className="font-extrabold text-slate-900 text-sm">{student.name}</h3>
                        <span className={cn(
                          "text-[9px] px-1 py-0.2 rounded font-bold",
                          student.gender === 'L' ? "bg-blue-50 text-blue-600" : "bg-pink-50 text-pink-600"
                        )}>
                          {student.gender === 'L' ? 'L' : 'P'}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-400 font-medium flex items-center gap-1.5 mt-0.5">
                        <span className="font-bold text-slate-600">{formatClassLabel(student.class, true)}</span>
                        <span>•</span>
                        <span>NIS: {student.nis || '-'}</span>
                      </div>
                    </div>
                  </div>

                  {/* Status Badge */}
                  <div>
                    {stats.isComplete ? (
                      <span className="px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-300 font-black text-[10px] flex items-center gap-1 shadow-2xs">
                        <CheckCircle2 size={11} className="text-emerald-600" />
                        <span>Lengkap</span>
                      </span>
                    ) : (
                      <span className="px-2.5 py-1 rounded-full bg-orange-50 text-orange-700 border border-orange-300 font-black text-[10px] flex items-center gap-1 shadow-2xs">
                        <AlertCircle size={11} className="text-orange-600" />
                        <span>Kurang ({stats.uploadedCount}/8)</span>
                      </span>
                    )}
                  </div>
                </div>

                {/* Progress bar */}
                <div>
                  <div className="flex justify-between items-center text-[10px] font-bold text-slate-400 mb-1">
                    <span>Kelengkapan Berkas</span>
                    <span className={stats.isComplete ? "text-emerald-600" : "text-amber-600"}>{stats.percent}% ({stats.uploadedCount} dari 8)</span>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                    <div 
                      className={cn("h-full transition-all rounded-full", stats.isComplete ? "bg-emerald-500" : "bg-orange-500")}
                      style={{ width: `${stats.percent}%` }}
                    />
                  </div>
                </div>

                {/* Document Chips Grid */}
                <div className="grid grid-cols-4 gap-1.5 pt-1">
                  {STUDENT_DOC_CONFIGS.map(doc => {
                    const val = student[doc.key];
                    const isPresent = Boolean(val && typeof val === 'string' && val.trim() !== '');

                    return (
                      <button
                        key={doc.key}
                        onClick={() => {
                          if (isPresent && typeof val === 'string') {
                            setPreviewDoc({ title: doc.label, url: val, studentName: student.name });
                          } else {
                            setSelectedStudent(student);
                          }
                        }}
                        className={cn(
                          "py-1.5 px-1 rounded-xl text-[10px] font-bold transition-all border flex flex-col items-center justify-center text-center active:scale-95",
                          isPresent
                            ? "bg-emerald-50/90 text-emerald-800 border-emerald-200 shadow-2xs"
                            : "bg-slate-50 text-slate-400 border-slate-200/80 hover:border-amber-300"
                        )}
                        title={`${doc.label}: ${isPresent ? 'Ada (Klik preview)' : 'Belum Ada (Klik upload)'}`}
                      >
                        <span className="flex items-center gap-0.5 text-[9px] truncate max-w-full">
                          {isPresent ? <Check size={10} className="text-emerald-600 stroke-[3]" /> : <span className="w-1 h-1 rounded-full bg-slate-300"></span>}
                          {doc.shortLabel}
                        </span>
                      </button>
                    );
                  })}
                </div>

                {/* Action Upload Button */}
                <button
                  onClick={() => setSelectedStudent(student)}
                  className={cn(
                    "w-full py-2.5 px-4 rounded-2xl text-xs font-black transition-all active:scale-98 border shadow-2xs flex items-center justify-center gap-2",
                    stats.isComplete 
                      ? "bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200" 
                      : "bg-amber-500 hover:bg-amber-600 text-white border-amber-600 shadow-amber-200"
                  )}
                >
                  <CloudUpload size={15} />
                  <span>{stats.isComplete ? 'Lihat & Kelola Berkas' : 'Upload Berkas Sekarang'}</span>
                </button>
              </div>
            );
          })
        )}
      </div>

      {/* ================================================================= */}
      {/* 2. DESKTOP MODERN TABLE (Visible on Screen >= md)                 */}
      {/* ================================================================= */}
      <div className="hidden md:block bg-white rounded-3xl border border-slate-200/80 shadow-xs overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
          <div className="text-xs font-bold text-slate-700">
            Menampilkan <span className="text-amber-600 font-extrabold">{filteredStudents.length}</span> Siswa
            {filterClass ? ` di ${formatClassLabel(filterClass, true)}` : ''}
            {filterStatus === 'incomplete' ? ' (Status: Kurang)' : filterStatus === 'complete' ? ' (Status: Lengkap)' : ' (Semua)'}
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-50 text-slate-500 uppercase font-bold tracking-wider border-b border-slate-200">
              <tr>
                <th className="p-3.5 pl-5 w-12 text-center">No</th>
                <th className="p-3.5 min-w-[200px]">Data Siswa</th>
                <th className="p-3.5 text-center w-20">Kelas</th>
                <th className="p-3.5 text-center min-w-[150px]">Status Kelengkapan</th>
                <th className="p-3.5 min-w-[340px]">Status 12 Dokumen</th>
                <th className="p-3.5 pr-5 text-right w-36">Aksi Upload</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredStudents.length === 0 ? (
                <tr>
                  <td colSpan={6} className="p-12 text-center">
                    <div className="flex flex-col items-center justify-center space-y-3">
                      <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-500 flex items-center justify-center">
                        <CheckCircle2 size={28} />
                      </div>
                      <p className="text-sm font-bold text-slate-800">
                        {filterStatus === 'incomplete' 
                          ? 'Hebat! Semua berkas siswa telah berstatus Lengkap.' 
                          : 'Tidak ada data siswa yang cocok dengan filter saat ini.'}
                      </p>
                      <p className="text-xs text-slate-400 max-w-sm">
                        {filterStatus === 'incomplete' 
                          ? 'Anda dapat beralih ke tab "Semua" atau "Lengkap" untuk meninjau seluruh data dokumen siswa.'
                          : 'Silakan reset pencarian atau ganti filter rombel kelas.'}
                      </p>
                    </div>
                  </td>
                </tr>
              ) : (
                filteredStudents.map((student, idx) => {
                  const stats = getStudentCompleteness(student);
                  return (
                    <tr 
                      key={student.id} 
                      className="hover:bg-amber-50/20 transition-colors group"
                    >
                      <td className="p-3.5 pl-5 text-center text-slate-400 font-semibold">{idx + 1}</td>
                      
                      {/* Student Info */}
                      <td className="p-3.5">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-2xl bg-indigo-50 border border-indigo-100 text-indigo-600 font-bold flex items-center justify-center flex-shrink-0 overflow-hidden">
                            {student.fotoUrl ? (
                              <img 
                                src={getGoogleDriveDirectImageUrl(student.fotoUrl)} 
                                alt={student.name}
                                className="w-full h-full object-cover rounded-2xl"
                                onError={(e) => { (e.target as any).style.display = 'none'; }}
                              />
                            ) : (
                              student.name.charAt(0).toUpperCase()
                            )}
                          </div>
                          <div>
                            <div className="font-extrabold text-slate-900 text-sm flex items-center gap-1.5">
                              <span>{student.name}</span>
                              <span className={cn(
                                "text-[10px] px-1.5 py-0.2 rounded font-bold",
                                student.gender === 'L' ? "bg-blue-50 text-blue-600" : "bg-pink-50 text-pink-600"
                              )}>
                                {student.gender === 'L' ? 'L' : 'P'}
                              </span>
                            </div>
                            <div className="text-[11px] text-slate-400 flex items-center gap-2 mt-0.5">
                              <span>NIS: {student.nis || '-'}</span>
                              <span>•</span>
                              <span>NISN: {student.nisn || '-'}</span>
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Class */}
                      <td className="p-3.5 text-center">
                        <span className="px-2.5 py-1 rounded-xl bg-slate-100 border border-slate-200 text-slate-800 font-black text-xs">
                          {formatClassLabel(student.class, true)}
                        </span>
                      </td>

                      {/* Status Column */}
                      <td className="p-3.5 text-center">
                        <div className="flex flex-col items-center gap-1">
                          {stats.isComplete ? (
                            <span className="px-3 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-300 font-black text-xs flex items-center gap-1.5 shadow-2xs">
                              <CheckCircle2 size={13} className="text-emerald-600" />
                              <span>Lengkap</span>
                            </span>
                          ) : (
                            <span className="px-3 py-1 rounded-full bg-orange-50 text-orange-700 border border-orange-300 font-black text-xs flex items-center gap-1.5 shadow-2xs">
                              <AlertCircle size={13} className="text-orange-600" />
                              <span>Kurang ({stats.uploadedCount}/12)</span>
                            </span>
                          )}
                          
                          {/* Progress bar */}
                          <div className="w-24 bg-slate-100 rounded-full h-1.5 overflow-hidden mt-0.5">
                            <div 
                              className={cn("h-full transition-all rounded-full", stats.isComplete ? "bg-emerald-500" : "bg-orange-500")}
                              style={{ width: `${stats.percent}%` }}
                            />
                          </div>
                          <span className="text-[9px] text-slate-400 font-bold">{stats.percent}% Terisi</span>
                        </div>
                      </td>

                      {/* Document Matrix Chips */}
                      <td className="p-3.5">
                        <div className="flex flex-wrap gap-1.5 items-center">
                          {STUDENT_DOC_CONFIGS.map(doc => {
                            const val = student[doc.key];
                            const isPresent = Boolean(val && typeof val === 'string' && val.trim() !== '');

                            return (
                              <button
                                key={doc.key}
                                onClick={() => {
                                  if (isPresent && typeof val === 'string') {
                                    setPreviewDoc({ title: doc.label, url: val, studentName: student.name });
                                  } else {
                                    setSelectedStudent(student);
                                  }
                                }}
                                title={`${doc.label}: ${isPresent ? 'Sudah Diunggah (Klik untuk lihat)' : 'Belum Ada (Klik untuk upload)'}`}
                                className={cn(
                                  "px-2 py-1 rounded-lg text-[10px] font-bold transition-all border flex items-center gap-1 active:scale-95",
                                  isPresent
                                    ? cn(doc.badgeBg, doc.badgeText, doc.badgeBorder, "hover:shadow-xs")
                                    : "bg-slate-50 text-slate-400 border-slate-200/80 hover:bg-amber-50 hover:text-amber-800 hover:border-amber-200 opacity-70"
                                )}
                              >
                                {isPresent ? <Check size={11} className="stroke-[3]" /> : <span className="w-1.5 h-1.5 rounded-full bg-slate-300"></span>}
                                <span>{doc.shortLabel}</span>
                              </button>
                            );
                          })}
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="p-3.5 pr-5 text-right">
                        <button
                          onClick={() => setSelectedStudent(student)}
                          className={cn(
                            "px-3.5 py-2 rounded-xl text-xs font-bold transition-all active:scale-95 border shadow-2xs inline-flex items-center gap-1.5",
                            stats.isComplete 
                              ? "bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200" 
                              : "bg-amber-500 hover:bg-amber-600 text-white border-amber-600 shadow-amber-200"
                          )}
                        >
                          <CloudUpload size={14} />
                          <span>Kelola Berkas</span>
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* ========================================================= */}
      {/* MODAL: DETAIL CHECKLIST & UPLOAD BERKAS KE GOOGLE DRIVE    */}
      {/* ========================================================= */}
      {selectedStudent && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
          <div className="bg-white rounded-3xl max-w-3xl w-full shadow-2xl overflow-hidden animate-in zoom-in-95 my-auto max-h-[92vh] flex flex-col">
            {/* Modal Header */}
            <div className="p-4 sm:p-6 bg-gradient-to-r from-amber-600 via-orange-600 to-indigo-700 text-white flex justify-between items-start flex-shrink-0">
              <div className="flex items-center gap-3 sm:gap-4">
                <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 flex items-center justify-center text-white text-xl font-black flex-shrink-0 overflow-hidden">
                  {selectedStudent.fotoUrl ? (
                    <img 
                      src={getGoogleDriveDirectImageUrl(selectedStudent.fotoUrl)} 
                      alt={selectedStudent.name}
                      className="w-full h-full object-cover rounded-2xl"
                    />
                  ) : (
                    selectedStudent.name.charAt(0).toUpperCase()
                  )}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-full bg-white/20 text-white text-[10px] sm:text-[11px] font-extrabold tracking-wide">
                      {formatClassLabel(selectedStudent.class, true)}
                    </span>
                    <span className="text-xs text-amber-100 font-medium">
                      NISN: {selectedStudent.nisn || '-'}
                    </span>
                  </div>
                  <h2 className="text-lg sm:text-2xl font-black mt-0.5 tracking-tight text-white">
                    {selectedStudent.name}
                  </h2>
                  <p className="text-[11px] sm:text-xs text-amber-100/90 mt-0.5 line-clamp-1 sm:line-clamp-none">
                    Wali: {selectedStudent.parentName || '-'} • Alamat: {selectedStudent.address || '-'}
                  </p>
                </div>
              </div>

              <button
                onClick={() => setSelectedStudent(null)}
                className="w-8 h-8 sm:w-9 sm:h-9 rounded-2xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition"
              >
                <X size={18} />
              </button>
            </div>

            {/* Modal Progress Summary Banner */}
            {(() => {
              const stats = getStudentCompleteness(selectedStudent);
              return (
                <div className="px-4 sm:px-6 py-3 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 flex-shrink-0">
                  <div className="flex items-center gap-2.5">
                    <div className={cn(
                      "w-8 h-8 rounded-xl flex items-center justify-center font-black text-xs",
                      stats.isComplete ? "bg-emerald-100 text-emerald-700" : "bg-orange-100 text-orange-700"
                    )}>
                      {stats.percent}%
                    </div>
                    <div>
                      <div className="text-xs font-bold text-slate-800">
                        Status: <span className={stats.isComplete ? "text-emerald-600 font-black" : "text-orange-600 font-black"}>
                          {stats.isComplete ? 'LENGKAP' : `KURANG ${stats.missingTotal} DOKUMEN`}
                        </span>
                      </div>
                      <div className="text-[10px] text-slate-500">
                        {stats.uploadedCount} dari 12 berkas resmi terunggah di Google Drive
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => window.print()}
                      className="px-3 py-1.5 rounded-xl bg-white border border-slate-200 text-slate-700 text-xs font-bold hover:bg-slate-100 transition flex items-center gap-1.5 shadow-2xs"
                    >
                      <Printer size={13} />
                      <span>Cetak</span>
                    </button>
                  </div>
                </div>
              );
            })()}

            {/* Modal Document Upload Checklist Body */}
            <div className="p-4 sm:p-6 space-y-3 sm:space-y-4 overflow-y-auto flex-1">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
                {STUDENT_DOC_CONFIGS.map(doc => {
                  const currentVal = selectedStudent[doc.key] as string | undefined;
                  const isPresent = Boolean(currentVal && currentVal.trim() !== '');
                  const isBusy = isUploading === doc.key;
                  const currentMode = activeUrlTab[doc.key] || 'file';

                  return (
                    <div 
                      key={doc.key}
                      className={cn(
                        "p-3.5 sm:p-4 rounded-2xl border transition-all space-y-2.5",
                        isPresent 
                          ? "bg-white border-emerald-200 shadow-2xs" 
                          : doc.required 
                            ? "bg-amber-50/50 border-amber-300" 
                            : "bg-slate-50/60 border-slate-200"
                      )}
                    >
                      {/* Card Header */}
                      <div className="flex items-start justify-between gap-2">
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="font-extrabold text-slate-900 text-xs">
                              {doc.label}
                            </span>
                            {doc.required && (
                              <span className="px-1.5 py-0.2 rounded text-[9px] font-black bg-rose-100 text-rose-700 uppercase">
                                Wajib
                              </span>
                            )}
                          </div>
                          <p className="text-[10px] sm:text-[11px] text-slate-400 leading-tight mt-0.5">
                            {doc.description}
                          </p>
                        </div>

                        {isPresent ? (
                          <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold text-[10px] flex items-center gap-1 flex-shrink-0">
                            <CheckCircle2 size={11} />
                            <span>Ada</span>
                          </span>
                        ) : (
                          <span className="px-2 py-0.5 rounded-full bg-orange-100 text-orange-800 font-bold text-[10px] flex items-center gap-1 flex-shrink-0">
                            <AlertCircle size={11} />
                            <span>Kurang</span>
                          </span>
                        )}
                      </div>

                      {/* Card Action & Preview Area */}
                      {isPresent ? (
                        <div className="p-2.5 sm:p-3 bg-slate-50 rounded-xl border border-slate-200/80 flex items-center justify-between gap-2">
                          <div className="flex items-center gap-2 overflow-hidden">
                            <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center flex-shrink-0">
                              <FileText size={16} />
                            </div>
                            <div className="overflow-hidden">
                              <p className="text-[11px] font-bold text-slate-800 truncate">
                                Berkas Terverifikasi
                              </p>
                              <p className="text-[10px] text-slate-400 truncate">
                                {currentVal?.startsWith('data:') ? 'Tersimpan di Sistem' : currentVal}
                              </p>
                            </div>
                          </div>

                          <div className="flex items-center gap-1 flex-shrink-0">
                            <button
                              onClick={() => setPreviewDoc({ title: doc.label, url: currentVal!, studentName: selectedStudent.name })}
                              className="p-1.5 rounded-lg bg-white border border-slate-200 text-indigo-600 hover:bg-indigo-50 transition"
                              title="Lihat Berkas"
                            >
                              <Eye size={14} />
                            </button>
                            
                            {!currentVal?.startsWith('data:') && (
                              <a
                                href={currentVal}
                                target="_blank"
                                rel="noreferrer"
                                className="p-1.5 rounded-lg bg-white border border-slate-200 text-slate-600 hover:bg-slate-100 transition"
                                title="Buka Link Google Drive"
                              >
                                <ExternalLink size={14} />
                              </a>
                            )}

                            <button
                              onClick={() => handleRemoveDoc(selectedStudent, doc)}
                              className="p-1.5 rounded-lg bg-white border border-slate-200 text-rose-600 hover:bg-rose-50 transition"
                              title="Hapus Berkas"
                            >
                              <Trash2 size={14} />
                            </button>
                          </div>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {/* Tab switch between file upload & Link */}
                          <div className="flex items-center justify-between text-[10px] font-bold text-slate-500">
                            <div className="flex gap-2">
                              <button
                                type="button"
                                onClick={() => setActiveUrlTab(prev => ({ ...prev, [doc.key]: 'file' as const }))}
                                className={cn("transition pb-0.5", currentMode === 'file' ? "text-amber-700 border-b-2 border-amber-600 font-extrabold" : "hover:text-slate-800")}
                              >
                                Upload PDF / Foto
                              </button>
                              <button
                                type="button"
                                onClick={() => setActiveUrlTab(prev => ({ ...prev, [doc.key]: 'link' as const }))}
                                className={cn("transition pb-0.5", currentMode === 'link' ? "text-amber-700 border-b-2 border-amber-600 font-extrabold" : "hover:text-slate-800")}
                              >
                                Link Google Drive
                              </button>
                            </div>
                          </div>

                          {currentMode === 'file' ? (
                            <div>
                              <input
                                type="file"
                                accept="image/*,application/pdf"
                                ref={el => { fileInputRefs.current[doc.key] = el; }}
                                onChange={(e) => handleFileUpload(selectedStudent, doc, e)}
                                className="hidden"
                              />
                              <button
                                type="button"
                                disabled={isBusy}
                                onClick={() => fileInputRefs.current[doc.key]?.click()}
                                className="w-full py-2.5 px-3 rounded-xl border border-dashed border-amber-300 hover:border-amber-500 bg-amber-50/50 hover:bg-amber-50 text-amber-800 text-xs font-bold transition flex items-center justify-center gap-2 active:scale-98 disabled:opacity-50 shadow-2xs"
                              >
                                {isBusy ? (
                                  <>
                                    <RefreshCw size={14} className="animate-spin text-amber-600" />
                                    <span>Mengunggah ke GDrive...</span>
                                  </>
                                ) : (
                                  <>
                                    <CloudUpload size={14} className="text-amber-600" />
                                    <span>Pilih File PDF / Foto</span>
                                  </>
                                )}
                              </button>
                            </div>
                          ) : (
                            <div className="flex gap-1.5">
                              <input
                                type="url"
                                placeholder="https://drive.google.com/file/d/..."
                                value={manualUrlInput[doc.key] || ''}
                                onChange={(e) => setManualUrlInput(prev => ({ ...prev, [doc.key]: e.target.value }))}
                                className="flex-1 px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-amber-500"
                              />
                              <button
                                type="button"
                                onClick={() => handleSaveManualUrl(selectedStudent, doc)}
                                className="px-3 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold shadow-xs active:scale-95"
                              >
                                Simpan
                              </button>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Modal Footer */}
            <div className="p-3 sm:p-4 px-6 bg-slate-50 border-t border-slate-200 flex justify-end items-center flex-shrink-0">
              <button
                onClick={() => setSelectedStudent(null)}
                className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold rounded-xl transition active:scale-95 shadow-sm"
              >
                Selesai & Tutup
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: PREVIEW FILE DOKUMEN                                */}
      {/* ========================================================= */}
      {previewDoc && (
        <div className="fixed inset-0 bg-slate-900/80 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-3xl max-w-4xl w-full max-h-[90vh] shadow-2xl overflow-hidden flex flex-col animate-in zoom-in-95">
            <div className="p-3.5 sm:p-4 px-5 sm:px-6 bg-slate-900 text-white flex justify-between items-center flex-shrink-0">
              <div>
                <h3 className="font-bold text-xs sm:text-sm text-white flex items-center gap-2">
                  <FileText size={16} className="text-amber-400" />
                  <span>{previewDoc.title}</span>
                </h3>
                <p className="text-[11px] text-slate-400">Siswa: {previewDoc.studentName}</p>
              </div>

              <div className="flex items-center gap-2">
                <a
                  href={previewDoc.url}
                  target="_blank"
                  rel="noreferrer"
                  download
                  className="p-1.5 sm:p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold flex items-center gap-1.5 transition"
                >
                  <Download size={14} />
                  <span className="hidden sm:inline">Buka Asli</span>
                </a>
                <button
                  onClick={() => setPreviewDoc(null)}
                  className="p-1.5 sm:p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition"
                >
                  <X size={16} />
                </button>
              </div>
            </div>

            <div className="p-3 sm:p-4 flex-1 overflow-auto bg-slate-100 flex items-center justify-center min-h-[300px]">
              {previewDoc.url.startsWith('data:image') || previewDoc.url.match(/\.(jpeg|jpg|gif|png|webp)($|\?)/i) ? (
                <img 
                  src={getGoogleDriveDirectImageUrl(previewDoc.url)} 
                  alt={previewDoc.title}
                  className="max-h-[70vh] max-w-full object-contain rounded-xl shadow-md bg-white"
                />
              ) : previewDoc.url.startsWith('data:application/pdf') || previewDoc.url.includes('.pdf') ? (
                <iframe
                  src={previewDoc.url}
                  title={previewDoc.title}
                  className="w-full h-[70vh] rounded-xl border border-slate-300 bg-white"
                />
              ) : (
                <div className="text-center p-6 sm:p-8 bg-white rounded-2xl border border-slate-200 shadow-sm max-w-md space-y-3">
                  <FileQuestion size={36} className="mx-auto text-amber-500" />
                  <h4 className="font-bold text-slate-800 text-sm">Preview Tautan Eksternal</h4>
                  <p className="text-xs text-slate-500">
                    Berkas ini tersimpan pada tautan Google Drive / Cloud. Klik tombol di bawah untuk membukanya.
                  </p>
                  <a
                    href={previewDoc.url}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition shadow-sm"
                  >
                    <span>Buka Berkas di Tab Baru</span>
                    <ArrowUpRight size={14} />
                  </a>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
