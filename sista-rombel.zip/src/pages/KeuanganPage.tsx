import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, CreditCard, Receipt, Wallet, BarChart3, Layers, Trash2, CheckCircle2
} from 'lucide-react';
import { useStore } from '../store';
import { db } from '../data/db';
import { initKeuanganDefaultData } from '../data/keuanganSeed';

// Sub Tabs Components
import DashboardKeuanganTab from '../components/keuangan/DashboardKeuanganTab';
import MasterBiayaTab from '../components/keuangan/MasterBiayaTab';
import TagihanTunggakanTab from '../components/keuangan/TagihanTunggakanTab';
import PembayaranInvoiceTab from '../components/keuangan/PembayaranInvoiceTab';
import TabunganSiswaTab from '../components/keuangan/TabunganSiswaTab';
import LaporanKeuanganTab from '../components/keuangan/LaporanKeuanganTab';

// Modals
import KwitansiInvoiceModal from '../components/keuangan/KwitansiInvoiceModal';
import LaporanPdfModal from '../components/keuangan/LaporanPdfModal';
import DetailSiswaKeuanganModal from '../components/keuangan/DetailSiswaKeuanganModal';

export default function KeuanganPage() {
  const { students } = useStore();
  const [activeTab, setActiveTab] = useState<string>('biaya');
  const [refreshKey, setRefreshKey] = useState<number>(0);
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [clearSuccessMsg, setClearSuccessMsg] = useState(false);

  // Modal Triggers
  const [printInvoiceId, setPrintInvoiceId] = useState<string | null>(null);
  const [pdfReportFilter, setPdfReportFilter] = useState<any | null>(null);
  const [detailSiswaId, setDetailSiswaId] = useState<string | null>(null);

  // Clean old dummy data on mount if present
  useEffect(() => {
    try {
      const tagihan = db.get('keuangan_tagihan');
      const hasDummyTagihan = tagihan.some((t: any) => t.id === 'TGH_001' || t.siswaId === '001' || t.namaSiswa === 'RIZKY KURNIAWAN');
      
      const invoices = db.get('keuangan_invoices');
      const hasDummyInvoices = invoices.some((i: any) => i.id === 'INV_5c2ed7821b6e45b2' || i.invoiceId === 'INV-E578D');
      
      const tabungan = db.get('keuangan_tabungan');
      const hasDummyTabungan = tabungan.some((t: any) => t.id === 'TAB_001' || t.namaSiswa === 'RIZKY KURNIAWAN');

      const biaya = db.get('keuangan_biaya');
      const hasDummyBiaya = biaya.some((b: any) => b.id === 'BIAYA_001' || b.kodeBiaya === 'A4_Modul24');

      if (hasDummyTagihan || hasDummyInvoices || hasDummyTabungan || hasDummyBiaya) {
        if (hasDummyTagihan) db.set('keuangan_tagihan', []);
        if (hasDummyInvoices) {
          db.set('keuangan_invoices', []);
          db.set('keuangan_pembayaran', []);
        }
        if (hasDummyTabungan) db.set('keuangan_tabungan', []);
        if (hasDummyBiaya) db.set('keuangan_biaya', []);
        setRefreshKey(prev => prev + 1);
      }
    } catch (e) {
      console.error('Error auto-cleaning dummy data:', e);
    }
    initKeuanganDefaultData(students);
  }, [students]);

  const handleRefresh = () => {
    setRefreshKey(prev => prev + 1);
  };

  const handleClearAllKeuangan = () => {
    db.set('keuangan_biaya', []);
    db.set('keuangan_tagihan', []);
    db.set('keuangan_pembayaran', []);
    db.set('keuangan_invoices', []);
    db.set('keuangan_tabungan', []);
    db.set('keuangan_kas', []);
    db.set('keuangan_pengeluaran', []);
    db.set('keuangan_jurnal', []);
    setShowClearConfirm(false);
    setClearSuccessMsg(true);
    setRefreshKey(prev => prev + 1);
    setTimeout(() => setClearSuccessMsg(false), 3500);
  };

  const navTabs = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'biaya', label: 'Tarif & Biaya', icon: Layers },
    { id: 'tagihan', label: 'Tagihan & Kasir', icon: CreditCard },
    { id: 'invoices', label: 'Pembayaran', icon: Receipt },
    { id: 'tabungan', label: 'Tabungan', icon: Wallet },
    { id: 'laporan', label: 'Laporan Rekap', icon: BarChart3 },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Top Header Card */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white/90 p-5 rounded-3xl border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-100/80 shadow-2xs flex-shrink-0">
            <CreditCard size={22} />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">
              Sistem Keuangan
            </h1>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              Kelola master pos biaya, penagihan Iuran, kasir & kuitansi sah, mutasi tabungan Siswa, dan ekspor database.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {clearSuccessMsg && (
            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 text-emerald-700 text-xs font-bold rounded-xl border border-emerald-200">
              <CheckCircle2 size={14} />
              <span>Data Keuangan Bersih!</span>
            </div>
          )}
          <button
            onClick={() => setShowClearConfirm(true)}
            className="flex items-center gap-2 px-3 py-2 bg-rose-50 text-rose-600 hover:bg-rose-100 hover:text-rose-700 border border-rose-200/80 rounded-xl text-xs font-bold transition active:scale-95"
            title="Kosongkan seluruh data keuangan lokal"
          >
            <Trash2 size={14} />
            <span>Kosongkan / Reset Keuangan</span>
          </button>
        </div>
      </div>

      {/* Clear Confirmation Modal */}
      {showClearConfirm && (
        <div className="fixed inset-0 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center z-50 p-4">
          <div className="bg-white max-w-md w-full rounded-2xl p-6 shadow-xl border border-slate-200 space-y-4">
            <div className="flex items-center gap-3 text-rose-600">
              <div className="w-10 h-10 rounded-xl bg-rose-50 flex items-center justify-center border border-rose-100">
                <Trash2 size={20} />
              </div>
              <div>
                <h3 className="font-bold text-slate-900">Konfirmasi Kosongkan Data</h3>
                <p className="text-xs text-slate-500">Tindakan ini tidak dapat dibatalkan</p>
              </div>
            </div>
            <p className="text-xs text-slate-600 leading-relaxed">
              Apakah Anda yakin ingin mengosongkan seluruh data transaksi keuangan lokal (Tarif Biaya, Tagihan, Pembayaran/Invoice, Tabungan Siswa, dan Kas)?
            </p>
            <div className="flex justify-end gap-2 pt-2">
              <button
                onClick={() => setShowClearConfirm(false)}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl transition"
              >
                Batal
              </button>
              <button
                onClick={handleClearAllKeuangan}
                className="px-4 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 rounded-xl shadow-xs transition"
              >
                Ya, Bersihkan Semua
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Navigation Sub-Tabs Bar */}
      <div className="bg-white p-1.5 rounded-2xl border border-slate-200/80 shadow-xs flex items-center gap-1 overflow-x-auto">
        {navTabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 py-2.5 rounded-xl font-black text-xs transition flex items-center gap-2 whitespace-nowrap active:scale-98 ${
                isActive 
                  ? 'bg-slate-900 text-white shadow-xs' 
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Icon size={15} className={isActive ? 'text-emerald-400' : 'text-slate-400'} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Content Renderer */}
      <div key={refreshKey}>
        {activeTab === 'dashboard' && (
          <DashboardKeuanganTab onNavigateTab={(tab) => setActiveTab(tab)} />
        )}

        {activeTab === 'biaya' && (
          <MasterBiayaTab />
        )}

        {activeTab === 'tagihan' && (
          <TagihanTunggakanTab
            onPrintInvoice={(invId) => setPrintInvoiceId(invId)}
            onRefreshAll={handleRefresh}
          />
        )}

        {activeTab === 'invoices' && (
          <PembayaranInvoiceTab
            onPrintInvoice={(invId) => setPrintInvoiceId(invId)}
          />
        )}

        {activeTab === 'tabungan' && (
          <TabunganSiswaTab />
        )}

        {activeTab === 'laporan' && (
          <LaporanKeuanganTab
            onOpenPdfReport={(filterState) => setPdfReportFilter(filterState)}
            onOpenStudentDetail={(sId) => setDetailSiswaId(sId)}
          />
        )}
      </div>

      {/* Global Modals */}
      {printInvoiceId && (
        <KwitansiInvoiceModal
          invoiceId={printInvoiceId}
          onClose={() => setPrintInvoiceId(null)}
        />
      )}

      {pdfReportFilter && (
        <LaporanPdfModal
          filterState={pdfReportFilter}
          onClose={() => setPdfReportFilter(null)}
        />
      )}

      {detailSiswaId && (
        <DetailSiswaKeuanganModal
          siswaId={detailSiswaId}
          onClose={() => setDetailSiswaId(null)}
          onPrintInvoice={(invId) => setPrintInvoiceId(invId)}
        />
      )}
    </div>
  );
}
