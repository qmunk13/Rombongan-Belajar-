import React, { useState, useMemo, useEffect } from 'react';
import { 
  CheckSquare, FileText, CheckCircle2, Search, Plus, Filter, X, Clock, Calendar, Check,
  Eye, Edit, Trash2, Save, AlertTriangle, Users, Award, BookOpen, AlertCircle, RefreshCw, Send
} from 'lucide-react';
import { db } from '../data/db';
import { useStore } from '../store';
import { matchClass, matchStatusActive, getAllClasses, formatClassLabel, STANDARD_CLASSES } from '../lib/utils';

interface TugasItem {
  id: string;
  judul: string;
  mapel: string;
  kelas: string;
  tenggat: string;
  kategori?: string;
  deskripsi?: string;
  kumpul: number;
  totalSiswa: number;
  status: 'Aktif Mengumpulkan' | 'Menunggu Penilaian' | 'Selesai Dinilai';
  avg: number;
  createdAt: string;
}

interface SubmissionItem {
  tugasId: string;
  studentId: string;
  studentName: string;
  nisn: string;
  kelas: string;
  status: 'Sudah Mengumpulkan' | 'Belum Mengumpulkan' | 'Terlambat';
  submittedAt?: string;
  nilai?: number | null;
  catatanGuru?: string;
}

export default function PenugasanPage() {
  const { students } = useStore();
  const [activeSubTab, setActiveSubTab] = useState('dashboard');
  const [searchTerm, setSearchTerm] = useState('');
  const [filterKelas, setFilterKelas] = useState('');
  const [filterStatus, setFilterStatus] = useState('');
  const [filterKategori, setFilterKategori] = useState('');

  // Modals
  const [showAddModal, setShowAddModal] = useState(false);
  const [viewDetailModal, setViewDetailModal] = useState<TugasItem | null>(null);
  const [editModal, setEditModal] = useState<TugasItem | null>(null);
  const [deleteModal, setDeleteModal] = useState<{ id: string; name: string } | null>(null);

  // New Tugas Form State
  const [newTugas, setNewTugas] = useState({
    judul: '',
    mapel: '',
    kelas: '',
    tenggat: '',
    kategori: 'Tugas Individu',
    deskripsi: '',
  });

  // Selected Tugas for Pengumpulan Tab
  const [selectedTugasId, setSelectedTugasId] = useState<string>('');
  
  // Stored Tugas & Submissions
  const [tugasList, setTugasList] = useState<TugasItem[]>(() => {
    return (db.get('tugas_kbm') as TugasItem[]) || [];
  });

  const [submissions, setSubmissions] = useState<SubmissionItem[]>(() => {
    return (db.get('hasil_tugas_kbm') as SubmissionItem[]) || [];
  });

  // Unique Classes from students or defaults
  const availableClasses = useMemo(() => {
    return Array.from(new Set([...getAllClasses(students), ...STANDARD_CLASSES])).sort((a, b) =>
      a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' })
    );
  }, [students]);

  // Sync with DB on changes
  const saveTugasList = (updated: TugasItem[]) => {
    setTugasList(updated);
    db.set('tugas_kbm', updated);
  };

  const saveSubmissions = (updated: SubmissionItem[]) => {
    setSubmissions(updated);
    db.set('hasil_tugas_kbm', updated);
  };

  // Filtered Tugas List
  const filteredTugas = useMemo(() => {
    return tugasList.filter((t) => {
      const q = String(searchTerm || '').toLowerCase();
      const judul = String(t.judul || '').toLowerCase();
      const mapel = String(t.mapel || '').toLowerCase();
      const kelas = String(t.kelas || '').toLowerCase();
      const matchesQ = !searchTerm || judul.includes(q) || mapel.includes(q) || kelas.includes(q);
      const matchesKelas = !filterKelas || matchClass(t.kelas, filterKelas);
      const matchesStatus = !filterStatus || t.status === filterStatus;
      const matchesKategori = !filterKategori || t.kategori === filterKategori;
      return matchesQ && matchesKelas && matchesStatus && matchesKategori;
    });
  }, [tugasList, searchTerm, filterKelas, filterStatus, filterKategori]);

  // Dynamic Statistics
  const stats = useMemo(() => {
    const totalTugas = tugasList.length;
    const tugasAktif = tugasList.filter(t => t.status === 'Aktif Mengumpulkan').length;
    const tugasSelesai = tugasList.filter(t => t.status === 'Selesai Dinilai').length;
    
    let totalKumpul = 0;
    let totalTarget = 0;
    let sumAvg = 0;
    let countAvg = 0;

    tugasList.forEach(t => {
      totalKumpul += Number(t.kumpul || 0);
      totalTarget += Number(t.totalSiswa || 0);
      if (t.avg && t.avg > 0) {
        sumAvg += Number(t.avg);
        countAvg += 1;
      }
    });

    const tingkatPenyerahan = totalTarget > 0 ? ((totalKumpul / totalTarget) * 100).toFixed(1) : '0';
    const overallAvg = countAvg > 0 ? (sumAvg / countAvg).toFixed(1) : '-';

    return {
      totalTugas,
      tugasAktif,
      tugasSelesai,
      totalKumpul,
      tingkatPenyerahan,
      overallAvg
    };
  }, [tugasList]);

  // Set default selected task for submission tab if not set
  useEffect(() => {
    if (tugasList.length > 0 && !selectedTugasId) {
      setSelectedTugasId(tugasList[0].id);
    }
  }, [tugasList, selectedTugasId]);

  const subTabs = [
    { id: 'dashboard', label: 'Dashboard Tugas', icon: CheckSquare },
    { id: 'daftar-tugas', label: 'Daftar Tugas KBM', icon: FileText },
    { id: 'pengumpulan', label: 'Hasil Pengumpulan & Nilai', icon: CheckCircle2 },
  ];

  const handleSubTabChange = (tabId: string) => {
    setActiveSubTab(tabId);
    setSearchTerm('');
    setFilterKelas('');
    setFilterStatus('');
    setFilterKategori('');
    window.scrollTo({ top: 0, behavior: 'instant' });
  };

  // Create Task Action
  const handleCreateTugas = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTugas.judul.trim() || !newTugas.mapel.trim() || !newTugas.kelas || !newTugas.tenggat) {
      alert('Mohon lengkapi Judul, Mata Pelajaran, Kelas, dan Tenggat Waktu tugas.');
      return;
    }

    const classStudentsCount = students.filter(s => matchStatusActive(s.status) && matchClass(s.class, newTugas.kelas)).length;
    const totalSiswa = classStudentsCount > 0 ? classStudentsCount : 30; // fallback if student count not registered

    const id = `TGS-${String(Date.now()).slice(-4)}`;
    const createdItem: TugasItem = {
      id,
      judul: newTugas.judul.trim(),
      mapel: newTugas.mapel.trim(),
      kelas: newTugas.kelas,
      tenggat: newTugas.tenggat,
      kategori: newTugas.kategori || 'Tugas Individu',
      deskripsi: newTugas.deskripsi.trim() || 'Selesaikan sesuai instruksi guru mata pelajaran di kelas.',
      kumpul: 0,
      totalSiswa,
      status: 'Aktif Mengumpulkan',
      avg: 0,
      createdAt: new Date().toISOString().split('T')[0]
    };

    const updated = [createdItem, ...tugasList];
    saveTugasList(updated);

    // Initialize blank submission records for this class
    const matchingStudents = students.filter(s => matchStatusActive(s.status) && matchClass(s.class, newTugas.kelas));
    if (matchingStudents.length > 0) {
      const newSubs: SubmissionItem[] = matchingStudents.map(st => ({
        tugasId: id,
        studentId: st.id,
        studentName: st.name,
        nisn: st.nisn || '-',
        kelas: st.class,
        status: 'Belum Mengumpulkan',
        nilai: null,
        catatanGuru: ''
      }));
      saveSubmissions([...submissions, ...newSubs]);
    }

    setNewTugas({
      judul: '',
      mapel: '',
      kelas: '',
      tenggat: '',
      kategori: 'Tugas Individu',
      deskripsi: '',
    });
    setShowAddModal(false);
    setActiveSubTab('daftar-tugas');
  };

  // Edit Task Action
  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editModal) return;
    const updated = tugasList.map(t => t.id === editModal.id ? { ...t, ...editModal, avg: Number(editModal.avg || 0) } : t);
    saveTugasList(updated);
    setEditModal(null);
  };

  // Delete Task Action
  const handleConfirmDelete = () => {
    if (!deleteModal) return;
    const updated = tugasList.filter(t => t.id !== deleteModal.id);
    saveTugasList(updated);
    // Also clean up submissions
    const cleanSubs = submissions.filter(s => s.tugasId !== deleteModal.id);
    saveSubmissions(cleanSubs);
    if (selectedTugasId === deleteModal.id) {
      setSelectedTugasId(updated[0]?.id || '');
    }
    setDeleteModal(null);
  };

  // Grading / Submission update for a student
  const handleUpdateStudentSubmission = (
    studentId: string, 
    status: 'Sudah Mengumpulkan' | 'Belum Mengumpulkan' | 'Terlambat', 
    nilai: number | null, 
    catatanGuru: string
  ) => {
    if (!selectedTugasId) return;

    let updatedSubs = [...submissions];
    const existingIndex = updatedSubs.findIndex(s => s.tugasId === selectedTugasId && s.studentId === studentId);
    
    if (existingIndex >= 0) {
      updatedSubs[existingIndex] = {
        ...updatedSubs[existingIndex],
        status,
        nilai,
        catatanGuru,
        submittedAt: status !== 'Belum Mengumpulkan' ? (updatedSubs[existingIndex].submittedAt || new Date().toLocaleString('id-ID')) : undefined
      };
    } else {
      const student = students.find(s => s.id === studentId);
      updatedSubs.push({
        tugasId: selectedTugasId,
        studentId,
        studentName: student?.name || 'Siswa',
        nisn: student?.nisn || '-',
        kelas: student?.class || '',
        status,
        nilai,
        catatanGuru,
        submittedAt: status !== 'Belum Mengumpulkan' ? new Date().toLocaleString('id-ID') : undefined
      });
    }

    saveSubmissions(updatedSubs);

    // Recalculate parent task kumpul & avg
    const taskSubs = updatedSubs.filter(s => s.tugasId === selectedTugasId);
    const kumpulCount = taskSubs.filter(s => s.status === 'Sudah Mengumpulkan' || s.status === 'Terlambat').length;
    const gradedSubs = taskSubs.filter(s => s.nilai !== null && s.nilai !== undefined);
    const avgScore = gradedSubs.length > 0 
      ? Math.round(gradedSubs.reduce((acc, curr) => acc + Number(curr.nilai || 0), 0) / gradedSubs.length)
      : 0;

    const taskStatus = kumpulCount >= (taskSubs.length || 1) && gradedSubs.length === taskSubs.length 
      ? 'Selesai Dinilai' 
      : kumpulCount > 0 ? 'Menunggu Penilaian' : 'Aktif Mengumpulkan';

    const updatedTugas = tugasList.map(t => {
      if (t.id === selectedTugasId) {
        return {
          ...t,
          kumpul: kumpulCount,
          avg: avgScore,
          status: taskStatus as any
        };
      }
      return t;
    });

    saveTugasList(updatedTugas);
  };

  const selectedTugas = tugasList.find(t => t.id === selectedTugasId);
  const studentsInSelectedClass = useMemo(() => {
    if (!selectedTugas) return [];
    return students
      .filter(s => matchStatusActive(s.status) && matchClass(s.class, selectedTugas.kelas))
      .sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'id'));
  }, [students, selectedTugas]);

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Title & Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white/90 p-5 rounded-3xl border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center border border-rose-100/80 shadow-2xs flex-shrink-0">
            <CheckSquare size={22} />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">
              Penugasan KBM Siswa
            </h1>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              Manajemen pembagian tugas KBM, pemantauan status pengumpulan, & pemberian umpan balik nilai.
            </p>
          </div>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-2xl text-xs font-bold shadow-md shadow-rose-200 transition active:scale-95 flex-shrink-0"
        >
          <Plus size={16} />
          <span>Buat Tugas Baru</span>
        </button>
      </div>

      {/* Sub-Navigation */}
      <div className="md:hidden bg-white p-3 rounded-2xl border border-slate-200/80 shadow-xs">
        <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">
          Pilih Sub-Menu Penugasan:
        </label>
        <div className="relative">
          <select
            value={activeSubTab}
            onChange={(e) => handleSubTabChange(e.target.value)}
            className="w-full pl-3.5 pr-10 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 appearance-none transition"
          >
            {subTabs.map((tab) => (
              <option key={tab.id} value={tab.id}>
                {tab.label}
              </option>
            ))}
          </select>
          <div className="absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
            ▼
          </div>
        </div>
      </div>

      <div className="hidden md:flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {subTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => handleSubTabChange(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all whitespace-nowrap active:scale-95 ${
                isActive
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-200'
                  : 'bg-white/80 text-slate-600 hover:bg-white hover:text-rose-600 border border-slate-200/80'
              }`}
            >
              <Icon size={16} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* DASHBOARD TAB */}
      {activeSubTab === 'dashboard' && (
        <div className="space-y-6 animate-in fade-in">
          {/* Dynamic KPI Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div 
              onClick={() => handleSubTabChange('daftar-tugas')}
              className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-1.5 cursor-pointer hover:border-rose-300 transition group"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-500">Tugas Terdaftar</span>
                <span className="p-1.5 rounded-xl bg-rose-50 text-rose-600">
                  <FileText size={16} />
                </span>
              </div>
              <div className="text-3xl font-black text-rose-600">
                {stats.totalTugas} <span className="text-xs font-bold text-slate-400">Tugas</span>
              </div>
              <p className="text-[11px] text-rose-600 font-bold group-hover:underline flex items-center gap-1">
                <span>{stats.tugasAktif} Tugas Aktif</span> &rarr;
              </p>
            </div>

            <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-500">Tingkat Penyerahan</span>
                <span className="p-1.5 rounded-xl bg-emerald-50 text-emerald-600">
                  <CheckCircle2 size={16} />
                </span>
              </div>
              <div className="text-3xl font-black text-emerald-600">
                {stats.tingkatPenyerahan}%
              </div>
              <p className="text-[11px] text-slate-500 font-medium">
                {stats.totalKumpul} lembar tugas diserahkan
              </p>
            </div>

            <div 
              onClick={() => handleSubTabChange('pengumpulan')}
              className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-1.5 cursor-pointer hover:border-purple-300 transition group"
            >
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-500">Tugas Selesai Dinilai</span>
                <span className="p-1.5 rounded-xl bg-purple-50 text-purple-600">
                  <Award size={16} />
                </span>
              </div>
              <div className="text-3xl font-black text-purple-600">
                {stats.tugasSelesai} <span className="text-xs font-bold text-slate-400">Tugas</span>
              </div>
              <p className="text-[11px] text-purple-600 font-bold group-hover:underline flex items-center gap-1">
                <span>Rata-rata Nilai: {stats.overallAvg}</span> &rarr;
              </p>
            </div>
          </div>

          {/* Quick Actions & Recent Tasks */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h2 className="text-sm font-black text-slate-800 flex items-center gap-2">
                <Clock size={16} className="text-rose-600" />
                Daftar Tugas KBM Terkini
              </h2>
              {tugasList.length > 0 && (
                <button 
                  onClick={() => handleSubTabChange('daftar-tugas')}
                  className="text-xs font-bold text-rose-600 hover:underline"
                >
                  Lihat Semua ({tugasList.length})
                </button>
              )}
            </div>

            {tugasList.length === 0 ? (
              <div className="py-10 text-center space-y-3">
                <div className="w-14 h-14 bg-rose-50 text-rose-500 rounded-2xl flex items-center justify-center mx-auto border border-rose-100">
                  <CheckSquare size={28} />
                </div>
                <div>
                  <h4 className="text-sm font-black text-slate-800">Belum Ada Tugas KBM</h4>
                  <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                    Buat tugas pembelajaran pertama untuk memulai pembagian tugas dan penilaian siswa.
                  </p>
                </div>
                <button
                  onClick={() => setShowAddModal(true)}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-xs transition"
                >
                  <Plus size={14} />
                  <span>Tambah Tugas KBM</span>
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
                {tugasList.slice(0, 6).map((t) => (
                  <div 
                    key={t.id}
                    className="p-4 rounded-2xl bg-slate-50/70 border border-slate-200/80 hover:bg-white hover:border-rose-300 transition space-y-3"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <span className="px-2 py-0.5 rounded-md bg-rose-100/70 text-rose-700 font-mono font-bold text-[10px]">
                        {t.id}
                      </span>
                      <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                        t.status === 'Selesai Dinilai' ? 'bg-emerald-100 text-emerald-800' :
                        t.status === 'Menunggu Penilaian' ? 'bg-amber-100 text-amber-800' :
                        'bg-sky-100 text-sky-800'
                      }`}>
                        {t.status}
                      </span>
                    </div>

                    <div>
                      <h4 className="font-extrabold text-slate-900 text-sm line-clamp-1">{t.judul}</h4>
                      <p className="text-xs text-slate-500 font-medium mt-0.5 flex items-center gap-1.5">
                        <span>{t.mapel}</span> &bull; 
                        <span className="font-bold text-slate-700">{formatClassLabel(t.kelas, true)}</span>
                      </p>
                    </div>

                    <div className="pt-2 border-t border-slate-200/60 flex items-center justify-between text-[11px] text-slate-500">
                      <span className="flex items-center gap-1">
                        <Calendar size={12} className="text-slate-400" />
                        Tenggat: {t.tenggat}
                      </span>
                      <span className="font-bold text-slate-700">
                        {t.kumpul}/{t.totalSiswa} Terkumpul
                      </span>
                    </div>

                    <div className="pt-1 flex items-center gap-2">
                      <button
                        onClick={() => {
                          setSelectedTugasId(t.id);
                          setActiveSubTab('pengumpulan');
                        }}
                        className="w-full py-1.5 bg-white hover:bg-rose-50 border border-slate-200 hover:border-rose-200 text-rose-600 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1"
                      >
                        <CheckCircle2 size={13} />
                        <span>Nilai Pengumpulan</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* DAFTAR TUGAS KBM TAB */}
      {activeSubTab === 'daftar-tugas' && (
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-5">
          {/* Smart Filter Bar */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-slate-50/80 p-3.5 rounded-2xl border border-slate-200/70">
            <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto flex-1">
              <div className="relative flex-1 sm:w-64">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Cari judul tugas, mapel, kelas..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-9 pr-8 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                />
                {searchTerm && (
                  <button onClick={() => setSearchTerm('')} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                    <X size={13} />
                  </button>
                )}
              </div>

              <select
                value={filterKelas}
                onChange={(e) => setFilterKelas(e.target.value)}
                className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
              >
                <option value="">Semua Rombel / Kelas ({students.filter(s => matchStatusActive(s.status)).length} Siswa)</option>
                {availableClasses.map(c => {
                  const count = students.filter(s => matchStatusActive(s.status) && matchClass(s.class, c)).length;
                  return (
                    <option key={c} value={c}>{formatClassLabel(c, true)} ({count} Siswa)</option>
                  );
                })}
              </select>

              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value)}
                className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
              >
                <option value="">Semua Status Pengumpulan</option>
                <option value="Aktif Mengumpulkan">Aktif Mengumpulkan</option>
                <option value="Menunggu Penilaian">Menunggu Penilaian</option>
                <option value="Selesai Dinilai">Selesai Dinilai</option>
              </select>

              <select
                value={filterKategori}
                onChange={(e) => setFilterKategori(e.target.value)}
                className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
              >
                <option value="">Semua Kategori</option>
                <option value="Tugas Individu">Tugas Individu</option>
                <option value="Tugas Kelompok">Tugas Kelompok</option>
                <option value="Pekerjaan Rumah (PR)">Pekerjaan Rumah (PR)</option>
                <option value="Praktik & Portofolio">Praktik & Portofolio</option>
                <option value="Proyek Siswa">Proyek Siswa</option>
              </select>
            </div>

            <span className="text-[11px] font-bold text-slate-500 bg-white px-3 py-1.5 rounded-xl border border-slate-200 flex-shrink-0">
              Menampilkan {filteredTugas.length} Tugas KBM
            </span>
          </div>

          {/* List Table */}
          <div className="overflow-x-auto rounded-2xl border border-slate-200/80">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50/90 text-slate-600 uppercase font-bold text-[11px] border-b border-slate-200">
                <tr>
                  <th className="p-3.5 pl-4">Kode</th>
                  <th className="p-3.5">Judul Tugas Pembelajaran</th>
                  <th className="p-3.5">Mata Pelajaran</th>
                  <th className="p-3.5">Kelas</th>
                  <th className="p-3.5">Tenggat Waktu</th>
                  <th className="p-3.5 text-center">Pengumpulan</th>
                  <th className="p-3.5 text-center">Status</th>
                  <th className="p-3.5 text-center">Rata-rata Nilai</th>
                  <th className="p-3.5 pr-4 text-center">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {filteredTugas.length === 0 ? (
                  <tr>
                    <td colSpan={9} className="p-12 text-center text-slate-400">
                      <CheckSquare size={36} className="mx-auto text-slate-300 mb-2.5" />
                      <p className="font-bold text-slate-700 text-sm">Tidak Ada Tugas KBM Ditemukan</p>
                      <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                        Belum ada tugas yang cocok dengan filter. Klik tombol "Buat Tugas Baru" untuk menambahkan.
                      </p>
                    </td>
                  </tr>
                ) : (
                  filteredTugas.map((t) => (
                    <tr key={t.id} className="hover:bg-slate-50/80 transition">
                      <td className="p-3.5 pl-4 font-mono font-bold text-rose-700">{t.id}</td>
                      <td className="p-3.5">
                        <div className="font-bold text-slate-900 text-sm">{t.judul}</div>
                        {t.kategori && (
                          <span className="text-[10px] text-slate-400 font-medium">{t.kategori}</span>
                        )}
                      </td>
                      <td className="p-3.5 font-semibold text-slate-800">{t.mapel}</td>
                      <td className="p-3.5">
                        <span className="px-2 py-0.5 bg-slate-100 text-slate-700 font-bold rounded-md text-[10px]">
                          {formatClassLabel(t.kelas, true)}
                        </span>
                      </td>
                      <td className="p-3.5">
                        <span className="font-mono text-slate-700 flex items-center gap-1">
                          <Calendar size={12} className="text-slate-400" />
                          {t.tenggat}
                        </span>
                      </td>
                      <td className="p-3.5 text-center font-bold text-slate-800 font-mono">
                        {t.kumpul}/{t.totalSiswa}
                      </td>
                      <td className="p-3.5 text-center">
                        <span className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                          t.status === 'Selesai Dinilai' ? 'bg-emerald-100 text-emerald-800' :
                          t.status === 'Menunggu Penilaian' ? 'bg-amber-100 text-amber-800' :
                          'bg-sky-100 text-sky-800'
                        }`}>
                          {t.status}
                        </span>
                      </td>
                      <td className="p-3.5 text-center font-bold text-rose-700">
                        {t.avg > 0 ? t.avg : '-'}
                      </td>
                      <td className="p-3.5 pr-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => {
                              setSelectedTugasId(t.id);
                              setActiveSubTab('pengumpulan');
                            }}
                            className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                            title="Penilaian"
                          >
                            <CheckCircle2 size={12} />
                            <span className="hidden sm:inline">Nilai</span>
                          </button>
                          <button
                            onClick={() => setViewDetailModal(t)}
                            className="px-2 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                            title="Lihat Detail"
                          >
                            <Eye size={12} />
                            <span className="hidden sm:inline">Lihat</span>
                          </button>
                          <button
                            onClick={() => setEditModal({ ...t })}
                            className="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                            title="Edit Data"
                          >
                            <Edit size={12} />
                            <span className="hidden sm:inline">Edit</span>
                          </button>
                          <button
                            onClick={() => setDeleteModal({ id: t.id, name: t.judul })}
                            className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                            title="Hapus Data"
                          >
                            <Trash2 size={12} />
                            <span className="hidden sm:inline">Hapus</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* HASIL PENGUMPULAN & NILAI TAB */}
      {activeSubTab === 'pengumpulan' && (
        <div className="space-y-5 animate-in fade-in">
          {/* Task Selector Card */}
          <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
            <div className="space-y-1">
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block">
                Pilih Tugas KBM untuk Penilaian:
              </label>
              {tugasList.length === 0 ? (
                <p className="text-xs text-rose-600 font-bold">Belum ada tugas dibuat. Silakan buat tugas terlebih dahulu.</p>
              ) : (
                <select
                  value={selectedTugasId}
                  onChange={(e) => setSelectedTugasId(e.target.value)}
                  className="px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                >
                  {tugasList.map(t => (
                    <option key={t.id} value={t.id}>
                      [{t.id}] {t.judul} - {formatClassLabel(t.kelas, true)} ({t.mapel})
                    </option>
                  ))}
                </select>
              )}
            </div>

            {selectedTugas && (
              <div className="flex flex-wrap items-center gap-3 text-xs bg-slate-50 p-3 rounded-2xl border border-slate-100">
                <div>
                  <span className="text-slate-400 block text-[10px] font-bold">Tenggat Waktu</span>
                  <span className="font-bold text-slate-800">{selectedTugas.tenggat}</span>
                </div>
                <div className="h-6 w-px bg-slate-200" />
                <div>
                  <span className="text-slate-400 block text-[10px] font-bold">Terkumpul</span>
                  <span className="font-bold text-rose-600">{selectedTugas.kumpul} Siswa</span>
                </div>
                <div className="h-6 w-px bg-slate-200" />
                <div>
                  <span className="text-slate-400 block text-[10px] font-bold">Rata-rata Nilai</span>
                  <span className="font-bold text-emerald-600">{selectedTugas.avg > 0 ? selectedTugas.avg : '-'}</span>
                </div>
              </div>
            )}
          </div>

          {/* Student Grading List */}
          {selectedTugas ? (
            <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <div>
                  <h3 className="text-sm font-black text-slate-900">Lembar Pengumpulan & Nilai Siswa ({formatClassLabel(selectedTugas.kelas, true)})</h3>
                  <p className="text-xs text-slate-500 mt-0.5">Input nilai dan status penyerahan untuk setiap siswa di kelas ini.</p>
                </div>
                <span className="text-xs font-bold text-slate-600 bg-slate-100 px-3 py-1.5 rounded-xl">
                  Total Siswa: {studentsInSelectedClass.length}
                </span>
              </div>

              {studentsInSelectedClass.length === 0 ? (
                <div className="py-12 text-center text-slate-400">
                  <Users size={32} className="mx-auto text-slate-300 mb-2" />
                  <p className="font-bold text-slate-700 text-sm">Belum Ada Siswa Terdaftar di {formatClassLabel(selectedTugas.kelas, true)}</p>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Silakan daftarkan siswa melalui menu Data Siswa / SPMB.
                  </p>
                </div>
              ) : (
                <div className="overflow-x-auto rounded-2xl border border-slate-200/80">
                  <table className="w-full text-xs text-left">
                    <thead className="bg-slate-50 text-slate-600 uppercase font-bold text-[11px] border-b border-slate-200">
                      <tr>
                        <th className="p-3.5 pl-4">No</th>
                        <th className="p-3.5">NISN / ID</th>
                        <th className="p-3.5">Nama Siswa</th>
                        <th className="p-3.5 text-center">Status Pengumpulan</th>
                        <th className="p-3.5 text-center">Waktu Kumpul</th>
                        <th className="p-3.5 text-center">Nilai (0-100)</th>
                        <th className="p-3.5 pr-4">Catatan / Umpan Balik Guru</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                      {studentsInSelectedClass.map((student, idx) => {
                        const sub = submissions.find(s => s.tugasId === selectedTugasId && s.studentId === student.id);
                        const currentStatus = sub?.status || 'Belum Mengumpulkan';
                        const currentNilai = sub?.nilai ?? '';
                        const currentCatatan = sub?.catatanGuru || '';

                        return (
                          <tr key={student.id} className="hover:bg-slate-50/80 transition">
                            <td className="p-3.5 pl-4 font-bold text-slate-400">{idx + 1}</td>
                            <td className="p-3.5 font-mono text-slate-600">{student.nisn || student.id}</td>
                            <td className="p-3.5 font-bold text-slate-900">{student.name}</td>
                            <td className="p-3.5 text-center">
                              <select
                                value={currentStatus}
                                onChange={(e) => handleUpdateStudentSubmission(
                                  student.id, 
                                  e.target.value as any, 
                                  currentNilai !== '' ? Number(currentNilai) : null, 
                                  currentCatatan
                                )}
                                className={`px-2.5 py-1 rounded-lg text-xs font-bold border ${
                                  currentStatus === 'Sudah Mengumpulkan' ? 'bg-emerald-50 text-emerald-800 border-emerald-200' :
                                  currentStatus === 'Terlambat' ? 'bg-amber-50 text-amber-800 border-amber-200' :
                                  'bg-rose-50 text-rose-700 border-rose-200'
                                }`}
                              >
                                <option value="Belum Mengumpulkan">Belum Mengumpulkan</option>
                                <option value="Sudah Mengumpulkan">Sudah Mengumpulkan</option>
                                <option value="Terlambat">Terlambat</option>
                              </select>
                            </td>
                            <td className="p-3.5 text-center font-mono text-[11px] text-slate-500">
                              {sub?.submittedAt || '-'}
                            </td>
                            <td className="p-3.5 text-center">
                              <input
                                type="number"
                                min="0"
                                max="100"
                                placeholder="0-100"
                                value={currentNilai}
                                onChange={(e) => handleUpdateStudentSubmission(
                                  student.id, 
                                  currentStatus, 
                                  e.target.value !== '' ? Number(e.target.value) : null, 
                                  currentCatatan
                                )}
                                className="w-20 px-2.5 py-1 text-center bg-slate-50 border border-slate-200 rounded-lg font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                              />
                            </td>
                            <td className="p-3.5 pr-4">
                              <input
                                type="text"
                                placeholder="Tulis masukan untuk siswa..."
                                value={currentCatatan}
                                onChange={(e) => handleUpdateStudentSubmission(
                                  student.id, 
                                  currentStatus, 
                                  currentNilai !== '' ? Number(currentNilai) : null, 
                                  e.target.value
                                )}
                                className="w-full px-2.5 py-1 bg-slate-50 border border-slate-200 rounded-lg text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                              />
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          ) : (
            <div className="bg-white p-12 rounded-3xl border border-slate-200/80 text-center text-slate-400">
              <CheckSquare size={36} className="mx-auto text-slate-300 mb-2" />
              <p className="font-bold text-slate-700">Pilih Tugas KBM untuk Menampilkan Lembar Penilaian</p>
            </div>
          )}
        </div>
      )}

      {/* CREATE MODAL (TAMBAH TUGAS) */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-150 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center font-bold">
                  <Plus size={18} />
                </div>
                <h3 className="text-base font-black text-slate-900">Buat Tugas KBM Baru</h3>
              </div>
              <button 
                onClick={() => setShowAddModal(false)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleCreateTugas} className="space-y-3.5 max-h-[65vh] overflow-y-auto pr-1">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                  Judul Tugas <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: Portofolio Mengarang Bahasa Indonesia"
                  value={newTugas.judul}
                  onChange={(e) => setNewTugas({ ...newTugas, judul: e.target.value })}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                    Mata Pelajaran <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="Contoh: Matematika, IPA"
                    value={newTugas.mapel}
                    onChange={(e) => setNewTugas({ ...newTugas, mapel: e.target.value })}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                    Kelas / Rombel <span className="text-rose-500">*</span>
                  </label>
                  <select
                    required
                    value={newTugas.kelas}
                    onChange={(e) => setNewTugas({ ...newTugas, kelas: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                  >
                    <option value="">Pilih Kelas...</option>
                    {availableClasses.map(c => {
                      const count = students.filter(s => matchStatusActive(s.status) && matchClass(s.class, c)).length;
                      return (
                        <option key={c} value={c}>{formatClassLabel(c, true)} ({count} Siswa)</option>
                      );
                    })}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                    Tenggat Waktu <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    required
                    value={newTugas.tenggat}
                    onChange={(e) => setNewTugas({ ...newTugas, tenggat: e.target.value })}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                    Kategori Tugas
                  </label>
                  <select
                    value={newTugas.kategori}
                    onChange={(e) => setNewTugas({ ...newTugas, kategori: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                  >
                    <option value="Tugas Individu">Tugas Individu</option>
                    <option value="Tugas Kelompok">Tugas Kelompok</option>
                    <option value="Pekerjaan Rumah (PR)">Pekerjaan Rumah (PR)</option>
                    <option value="Praktik & Portofolio">Praktik & Portofolio</option>
                    <option value="Proyek Siswa">Proyek Siswa</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                  Petunjuk & Uraian Pengerjaan
                </label>
                <textarea
                  rows={3}
                  placeholder="Tuliskan petunjuk pengerjaan atau instruksi tugas..."
                  value={newTugas.deskripsi}
                  onChange={(e) => setNewTugas({ ...newTugas, deskripsi: e.target.value })}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500/20 resize-none"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center gap-1.5"
                >
                  <Plus size={14} />
                  <span>Simpan Tugas</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DETAIL MODAL (LIHAT) */}
      {viewDetailModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-150 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center font-bold">
                  <Eye size={18} />
                </div>
                <h3 className="text-base font-black text-slate-900">Detail Tugas KBM Siswa</h3>
              </div>
              <button 
                onClick={() => setViewDetailModal(null)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition"
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-2.5 max-h-[60vh] overflow-y-auto pr-1">
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 flex justify-between items-center text-xs">
                <span className="font-bold text-slate-500">Kode Tugas</span>
                <span className="font-mono font-black text-rose-600">{viewDetailModal.id}</span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 flex justify-between items-center text-xs">
                <span className="font-bold text-slate-500">Judul Tugas</span>
                <span className="font-extrabold text-slate-900 text-right">{viewDetailModal.judul}</span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 flex justify-between items-center text-xs">
                <span className="font-bold text-slate-500">Mata Pelajaran</span>
                <span className="font-extrabold text-slate-900">{viewDetailModal.mapel}</span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 flex justify-between items-center text-xs">
                <span className="font-bold text-slate-500">Rombel / Kelas</span>
                <span className="font-extrabold text-slate-900">{formatClassLabel(viewDetailModal.kelas, true)}</span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 flex justify-between items-center text-xs">
                <span className="font-bold text-slate-500">Tenggat Waktu</span>
                <span className="font-extrabold text-slate-900">{viewDetailModal.tenggat}</span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 flex justify-between items-center text-xs">
                <span className="font-bold text-slate-500">Progres Pengumpulan</span>
                <span className="font-extrabold text-slate-900">{viewDetailModal.kumpul} / {viewDetailModal.totalSiswa} Siswa</span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 flex justify-between items-center text-xs">
                <span className="font-bold text-slate-500">Status Tugas</span>
                <span className="font-extrabold text-slate-900">{viewDetailModal.status}</span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 flex justify-between items-center text-xs">
                <span className="font-bold text-slate-500">Rata-rata Nilai</span>
                <span className="font-extrabold text-slate-900">{viewDetailModal.avg > 0 ? `${viewDetailModal.avg} Poin` : 'Belum Ada Nilai'}</span>
              </div>
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 space-y-1 text-xs">
                <span className="font-bold text-slate-500 block">Petunjuk Pengerjaan</span>
                <p className="font-medium text-slate-800 leading-relaxed">{viewDetailModal.deskripsi || '-'}</p>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setViewDetailModal(null)}
                className="px-5 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800 transition"
              >
                Tutup Tampilan
              </button>
            </div>
          </div>
        </div>
      )}

      {/* EDIT MODAL (EDIT) */}
      {editModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-150 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
                  <Edit size={18} />
                </div>
                <h3 className="text-base font-black text-slate-900">Edit Tugas: {editModal.judul}</h3>
              </div>
              <button 
                onClick={() => setEditModal(null)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-3.5 max-h-[60vh] overflow-y-auto pr-1">
              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Judul Tugas</label>
                <input
                  type="text"
                  required
                  value={editModal.judul || ''}
                  onChange={(e) => setEditModal({ ...editModal, judul: e.target.value })}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Mata Pelajaran</label>
                  <input
                    type="text"
                    required
                    value={editModal.mapel || ''}
                    onChange={(e) => setEditModal({ ...editModal, mapel: e.target.value })}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Kelas</label>
                  <select
                    value={editModal.kelas || ''}
                    onChange={(e) => setEditModal({ ...editModal, kelas: e.target.value })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                  >
                    {availableClasses.map(c => {
                      const count = students.filter(s => matchStatusActive(s.status) && matchClass(s.class, c)).length;
                      return (
                        <option key={c} value={c}>{formatClassLabel(c, true)} ({count} Siswa)</option>
                      );
                    })}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Tenggat Waktu</label>
                  <input
                    type="date"
                    required
                    value={editModal.tenggat || ''}
                    onChange={(e) => setEditModal({ ...editModal, tenggat: e.target.value })}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                  />
                </div>
                <div className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Status Tugas</label>
                  <select
                    value={editModal.status || 'Aktif Mengumpulkan'}
                    onChange={(e) => setEditModal({ ...editModal, status: e.target.value as any })}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                  >
                    <option value="Aktif Mengumpulkan">Aktif Mengumpulkan</option>
                    <option value="Menunggu Penilaian">Menunggu Penilaian</option>
                    <option value="Selesai Dinilai">Selesai Dinilai</option>
                  </select>
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">Petunjuk Pengerjaan</label>
                <textarea
                  rows={2}
                  value={editModal.deskripsi || ''}
                  onChange={(e) => setEditModal({ ...editModal, deskripsi: e.target.value })}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-rose-500/20 resize-none"
                />
              </div>

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditModal(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center gap-1.5"
                >
                  <Save size={14} />
                  <span>Simpan Perubahan</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* DELETE CONFIRMATION MODAL (HAPUS) */}
      {deleteModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-150 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto border border-rose-100">
              <AlertTriangle size={24} />
            </div>
            
            <div className="text-center space-y-1">
              <h3 className="text-base font-black text-slate-900">Hapus Tugas Pembelajaran</h3>
              <p className="text-xs text-slate-500">
                Apakah Anda yakin ingin menghapus tugas <strong className="text-slate-800">"{deleteModal.name}"</strong>? Seluruh data pengumpulan tugas ini juga akan dihapus.
              </p>
            </div>

            <div className="pt-2 flex items-center justify-center gap-2.5">
              <button
                type="button"
                onClick={() => setDeleteModal(null)}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex-1"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center justify-center gap-1.5 flex-1"
              >
                <Trash2 size={14} />
                <span>Ya, Hapus</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
