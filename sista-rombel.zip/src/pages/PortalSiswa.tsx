import React, { useState, useMemo, useEffect } from 'react';
import { useStore } from '../store';
import { db } from '../data/db';
import { 
  User, GraduationCap, Calendar, CheckSquare, Laptop, 
  CreditCard, Award, ShieldAlert, FileText, CheckCircle2, 
  Clock, AlertCircle, Sparkles, BookOpen, Download, 
  Printer, Send, Check, ChevronRight, UserCheck, 
  Search, ArrowRight, ShieldCheck, Wallet, RefreshCw,
  TrendingUp, BarChart2, Bell, LogOut, Lock
} from 'lucide-react';
import { Student } from '../types';
import { getActiveRole } from '../lib/permissions';
import PengajuanIzinPortal from '../components/portal/PengajuanIzinPortal';

interface PortalSiswaProps {
  studentOverrideId?: string;
  isLockedStudent?: boolean;
  onLogout?: () => void;
}

export default function PortalSiswa({ studentOverrideId, isLockedStudent, onLogout }: PortalSiswaProps) {
  const { students, teachers, settings } = useStore();
  const currentRole = getActiveRole();
  const isActualStudentRole = currentRole.id === 'RL-026' || !!isLockedStudent || !!studentOverrideId;
  const [activeTab, setActiveTab] = useState<'ringkasan' | 'jadwal-presensi' | 'pengajuan-izin' | 'cbt-ujian' | 'tugas-materi' | 'nilai-rapor' | 'keuangan-biaya' | 'prestasi-bk' | 'profil-biodata'>('ringkasan');
  
  // Selected Student state (persisted in session or defaults to first active student)
  const [selectedStudentId, setSelectedStudentId] = useState<string>(() => {
    if (studentOverrideId) return studentOverrideId;
    const saved = typeof window !== 'undefined' && window.sessionStorage ? sessionStorage.getItem('portal_active_student_id') : null;
    if (saved && students.some(s => s.id === saved || s.nisn === saved || s.nis === saved)) {
      return saved;
    }
    return students.length > 0 ? students[0].id : '';
  });

  useEffect(() => {
    if (studentOverrideId) {
      setSelectedStudentId(studentOverrideId);
    } else if (students.length > 0 && !selectedStudentId) {
      setSelectedStudentId(students[0].id);
    }
  }, [studentOverrideId, students]);

  const handleSelectStudent = (id: string) => {
    if (isActualStudentRole) return; // Prevent switching when locked to student
    setSelectedStudentId(id);
    if (typeof window !== 'undefined' && window.sessionStorage) {
      sessionStorage.setItem('portal_active_student_id', id);
    }
  };

  // Find active student
  const currentStudent = useMemo(() => {
    const found = students.find(s => s.id === selectedStudentId || s.nisn === selectedStudentId || s.nis === selectedStudentId);
    if (found) return found;
    return students.length > 0 ? students[0] : null;
  }, [students, selectedStudentId]);

  // Homeroom teacher
  const waliKelasName = useMemo(() => {
    if (!currentStudent) return 'Belum Ditentukan';
    const rombelList = (db.get('rombel') as any[]) || [];
    const matchedRombel = rombelList.find(r => r.name === currentStudent.class || r.nama === currentStudent.class);
    if (matchedRombel && (matchedRombel.homeroomTeacher || matchedRombel.walikelasName)) {
      return matchedRombel.homeroomTeacher || matchedRombel.walikelasName;
    }
    // Fallback search teacher
    const t = teachers.find(teach => teach.assignedClass === currentStudent.class);
    return t ? t.name : 'Wali Kelas ' + currentStudent.class;
  }, [currentStudent, teachers]);

  // 1. Presensi Data for this student
  const studentAbsensi = useMemo(() => {
    if (!currentStudent) return { hadir: 0, sakit: 0, izin: 0, alpa: 0, total: 0, percentage: 100, logs: [] };
    const allAbsen = (db.get('absensi') as any[]) || [];
    const myAbsen = allAbsen.filter(a => 
      a.studentId === currentStudent.id || 
      a.nisn === currentStudent.nisn || 
      a.nama === currentStudent.name
    );

    let h = 0, s = 0, i = 0, a = 0;
    myAbsen.forEach(rec => {
      const st = String(rec.status || '').toLowerCase();
      if (st.includes('hadir') || st === 'h') h++;
      else if (st.includes('sakit') || st === 's') s++;
      else if (st.includes('izin') || st === 'i') i++;
      else if (st.includes('alpa') || st.includes('tanpa') || st === 'a') a++;
      else h++;
    });

    const total = h + s + i + a;
    const percentage = total > 0 ? Math.round((h / total) * 100) : 100;
    return { hadir: h, sakit: s, izin: i, alpa: a, total, percentage, logs: myAbsen };
  }, [currentStudent]);

  // 2. CBT / Ujian for this student's class
  const cbtUjianList = useMemo(() => {
    if (!currentStudent) return [];
    const allUjian = (db.get('ujian_cbt') as any[]) || [];
    const myClass = currentStudent.class;
    return allUjian.filter(u => !u.kelas || u.kelas === myClass || u.kelas === 'Semua Kelas' || u.kelas.includes(myClass));
  }, [currentStudent]);

  const cbtHasilList = useMemo(() => {
    if (!currentStudent) return [];
    const allHasil = (db.get('cbt_hasil_siswa') as any[]) || [];
    return allHasil.filter(h => 
      h.studentId === currentStudent.id || 
      h.nisn === currentStudent.nisn || 
      h.namaSiswa === currentStudent.name
    );
  }, [currentStudent]);

  // 3. Tugas / Penugasan for this student
  const tugasList = useMemo(() => {
    if (!currentStudent) return [];
    const allTugas = (db.get('tugas_list') as any[]) || (db.get('penugasan') as any[]) || [];
    const myClass = currentStudent.class;
    return allTugas.filter(t => !t.kelas || t.kelas === myClass || t.kelas === 'Semua Kelas' || t.kelas.includes(myClass));
  }, [currentStudent]);

  const [tugasSubmissions, setTugasSubmissions] = useState<any[]>(() => {
    return (db.get('tugas_submissions') as any[]) || [];
  });

  const [selectedTugasToSubmit, setSelectedTugasToSubmit] = useState<any | null>(null);
  const [submissionText, setSubmissionText] = useState('');
  const [submissionFileLink, setSubmissionFileLink] = useState('');
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const handleSubmitTugas = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentStudent || !selectedTugasToSubmit) return;

    const newSub = {
      id: 'SUB-' + Date.now(),
      tugasId: selectedTugasToSubmit.id,
      tugasJudul: selectedTugasToSubmit.judul,
      studentId: currentStudent.id,
      studentName: currentStudent.name,
      nisn: currentStudent.nisn || currentStudent.nis,
      kelas: currentStudent.class,
      textJawaban: submissionText,
      fileLink: submissionFileLink,
      submittedAt: new Date().toLocaleString('id-ID'),
      status: 'Sudah Mengumpulkan',
      nilai: null,
      catatanGuru: ''
    };

    const updated = [newSub, ...tugasSubmissions.filter(s => !(s.tugasId === selectedTugasToSubmit.id && s.studentId === currentStudent.id))];
    setTugasSubmissions(updated);
    db.set('tugas_submissions', updated);
    setSubmitSuccess(true);
    setTimeout(() => {
      setSubmitSuccess(false);
      setSelectedTugasToSubmit(null);
      setSubmissionText('');
      setSubmissionFileLink('');
    }, 1500);
  };

  // 4. Keuangan / Tagihan & Tabungan
  const keuanganTagihan = useMemo(() => {
    if (!currentStudent) return [];
    const allTagihan = (db.get('keuangan_tagihan') as any[]) || [];
    return allTagihan.filter(t => 
      t.studentId === currentStudent.id || 
      t.nisn === currentStudent.nisn || 
      t.namaSiswa === currentStudent.name ||
      t.nama === currentStudent.name
    );
  }, [currentStudent]);

  const keuanganTabungan = useMemo(() => {
    if (!currentStudent) return { saldo: 0, riwayat: [] };
    const allTabungan = (db.get('keuangan_tabungan') as any[]) || [];
    const myTab = allTabungan.filter(t => 
      t.studentId === currentStudent.id || 
      t.nisn === currentStudent.nisn || 
      t.namaSiswa === currentStudent.name ||
      t.nama === currentStudent.name
    );

    let saldo = 0;
    myTab.forEach(item => {
      const nom = Number(item.nominal) || 0;
      if (item.jenis === 'SETOR' || item.type === 'SETOR') saldo += nom;
      else if (item.jenis === 'TARIK' || item.type === 'TARIK') saldo -= nom;
    });

    return { saldo, riwayat: myTab };
  }, [currentStudent]);

  // 5. Nilai Rapor
  const nilaiRapor = useMemo(() => {
    if (!currentStudent) return [];
    const allNilai = (db.get('nilai_rapor') as any[]) || (db.get('nilai_siswa') as any[]) || [];
    const myNilai = allNilai.filter(n => 
      n.studentId === currentStudent.id || 
      n.nisn === currentStudent.nisn || 
      n.namaSiswa === currentStudent.name
    );

    if (myNilai.length > 0) return myNilai;
    return [];
  }, [currentStudent]);

  // 6. Prestasi & Catatan BK
  const bimbinganList = useMemo(() => {
    if (!currentStudent) return [];
    const allBk = (db.get('bimbingan') as any[]) || [];
    return allBk.filter(b => 
      b.studentId === currentStudent.id || 
      b.nisn === currentStudent.nisn || 
      b.namaSiswa === currentStudent.name
    );
  }, [currentStudent]);

  const prestasiList = useMemo(() => {
    if (!currentStudent) return [];
    const allPrestasi = (db.get('prestasi') as any[]) || (db.get('prestasi_siswa') as any[]) || [];
    return allPrestasi.filter(p => 
      p.studentId === currentStudent.id || 
      p.nisn === currentStudent.nisn || 
      p.namaSiswa === currentStudent.name
    );
  }, [currentStudent]);

  // 7. Jadwal Pelajaran Mingguan
  const jadwalKelas = useMemo(() => {
    if (!currentStudent) return [];
    const allJadwal = (db.get('jadwal_pelajaran') as any[]) || [];
    const myClass = currentStudent.class;
    const filtered = allJadwal.filter(j => j.rombelId === myClass || j.kelas === myClass);
    
    if (filtered.length > 0) return filtered;
    return [];
  }, [currentStudent]);

  const fmtRupiah = (num: number) => 'Rp ' + Number(num || 0).toLocaleString('id-ID');

  if (!currentStudent) {
    return (
      <div className="min-h-[400px] flex flex-col items-center justify-center p-8 bg-white rounded-3xl border border-slate-200 text-center space-y-4">
        <div className="w-16 h-16 rounded-3xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto border border-amber-100">
          <AlertCircle size={32} />
        </div>
        <div className="space-y-1">
          <h3 className="text-xl font-extrabold text-slate-900">Data Siswa Belum Tersedia</h3>
          <p className="text-sm text-slate-500 max-w-md mx-auto">
            Sistem belum mendeteksi data siswa aktif di database. Hubungi operator sekolah untuk mendaftarkan NISN/Biodata Anda.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      
      {/* 1. HERO HEADER PROFILE SISWA */}
      <div className="bg-gradient-to-r from-sky-600 via-indigo-600 to-blue-700 rounded-3xl p-5 sm:p-7 text-white shadow-xl shadow-indigo-950/10 relative overflow-hidden">
        {/* Vector Background Accents */}
        <div className="absolute right-0 top-0 translate-x-8 -translate-y-8 w-64 h-64 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute left-1/3 bottom-0 w-48 h-48 bg-sky-400/10 rounded-full blur-xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
          {/* Avatar & Student Info */}
          <div className="flex items-start sm:items-center gap-4 min-w-0">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-white/20 backdrop-blur-md p-1 border border-white/30 shrink-0 shadow-inner flex items-center justify-center text-white font-black text-2xl">
              {currentStudent.name.charAt(0).toUpperCase()}
            </div>
            <div className="min-w-0 space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[10px] font-black uppercase tracking-wider bg-white/20 text-white px-2.5 py-0.5 rounded-full backdrop-blur-xs border border-white/20">
                  PORTAL SISWA RESMI
                </span>
                <span className="text-[10px] font-bold bg-emerald-400/90 text-emerald-950 px-2 py-0.5 rounded-full flex items-center gap-1 shadow-2xs">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-900 animate-pulse" />
                  Siswa Aktif
                </span>
              </div>
              <h1 className="text-xl sm:text-2xl lg:text-3xl font-black tracking-tight text-white truncate">
                {currentStudent.name}
              </h1>
              <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-sky-100 font-medium">
                <span className="flex items-center gap-1">
                  <GraduationCap size={14} className="text-sky-300" />
                  <span>Kelas: <strong>{currentStudent.class}</strong></span>
                </span>
                <span className="flex items-center gap-1">
                  <User size={14} className="text-sky-300" />
                  <span>NISN: <strong>{currentStudent.nisn || currentStudent.nis || '-'}</strong></span>
                </span>
                <span className="hidden sm:inline text-sky-200/60">•</span>
                <span className="text-sky-200">
                  Wali Kelas: <strong>{waliKelasName}</strong>
                </span>
              </div>
            </div>
          </div>

          {/* Identity & Session Control */}
          {isActualStudentRole ? (
            <div className="flex items-center gap-3 bg-white/15 backdrop-blur-md p-2.5 sm:px-4 sm:py-2.5 rounded-2xl border border-white/20">
              <div className="w-8 h-8 rounded-xl bg-emerald-400/20 border border-emerald-300/40 flex items-center justify-center text-emerald-300 shrink-0">
                <ShieldCheck size={18} />
              </div>
              <div className="text-left leading-tight">
                <span className="text-[10px] font-black uppercase tracking-wider text-emerald-300 flex items-center gap-1">
                  <Lock size={10} /> Sesi Terverifikasi (Data Privat)
                </span>
                <span className="text-xs font-black text-white block mt-0.5">
                  {currentStudent.name} (NISN: {currentStudent.nisn || currentStudent.nis || '-'})
                </span>
              </div>
              {onLogout && (
                <button 
                  onClick={onLogout} 
                  className="ml-2 px-3 py-1.5 bg-rose-500/80 hover:bg-rose-600 active:scale-95 text-white rounded-xl text-xs font-extrabold transition flex items-center gap-1 shadow-xs shrink-0 cursor-pointer" 
                  title="Keluar Sesi Siswa"
                >
                  <LogOut size={13} />
                  <span className="hidden sm:inline">Keluar</span>
                </button>
              )}
            </div>
          ) : (
            /* Quick Identity Switcher ONLY for Admin / Teacher Simulation */
            <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 bg-amber-500/20 backdrop-blur-md p-2 rounded-2xl border border-amber-300/40">
              <div className="text-[10px] px-2 text-amber-200 font-extrabold uppercase tracking-wider hidden lg:block">
                Mode Pratinjau Admin:
              </div>
              <select
                value={selectedStudentId}
                onChange={(e) => handleSelectStudent(e.target.value)}
                className="bg-white text-slate-900 text-xs font-bold px-3 py-2 rounded-xl outline-hidden focus:ring-2 focus:ring-amber-300 transition"
                title="Ganti Siswa yang Dipratinjau (Khusus Guru/Admin)"
              >
                {students.map(s => (
                  <option key={s.id} value={s.id}>
                    {s.name} ({s.class} - NISN: {s.nisn || s.nis || 'N/A'})
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

        {/* Quick Highlights Bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-5 border-t border-white/20 text-white">
          <div className="bg-white/10 backdrop-blur-xs rounded-2xl p-3 border border-white/10">
            <p className="text-[10px] uppercase font-bold text-sky-200">Kehadiran Siswa</p>
            <p className="text-lg font-black mt-0.5">{studentAbsensi.percentage}% <span className="text-xs font-normal text-sky-200">({studentAbsensi.hadir} Hadir)</span></p>
          </div>
          <div className="bg-white/10 backdrop-blur-xs rounded-2xl p-3 border border-white/10">
            <p className="text-[10px] uppercase font-bold text-sky-200">Tugas Aktif</p>
            <p className="text-lg font-black mt-0.5">{tugasList.length} <span className="text-xs font-normal text-sky-200">Tugas Belajar</span></p>
          </div>
          <div className="bg-white/10 backdrop-blur-xs rounded-2xl p-3 border border-white/10">
            <p className="text-[10px] uppercase font-bold text-sky-200">Ujian CBT</p>
            <p className="text-lg font-black mt-0.5">{cbtUjianList.length} <span className="text-xs font-normal text-sky-200">Jadwal Tes</span></p>
          </div>
          <div className="bg-white/10 backdrop-blur-xs rounded-2xl p-3 border border-white/10">
            <p className="text-[10px] uppercase font-bold text-sky-200">Saldo Tabungan</p>
            <p className="text-lg font-black mt-0.5">{fmtRupiah(keuanganTabungan.saldo)}</p>
          </div>
        </div>
      </div>

      {/* 2. SUB-TAB NAVIGATION PORTAL SISWA */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar border-b border-slate-200">
        {[
          { id: 'ringkasan', label: 'Beranda Siswa', icon: Sparkles },
          { id: 'jadwal-presensi', label: 'Jadwal & Presensi', icon: Calendar },
          { id: 'pengajuan-izin', label: 'Pengajuan Izin / Sakit', icon: FileText },
          { id: 'cbt-ujian', label: 'Ujian CBT Online', icon: Laptop },
          { id: 'tugas-materi', label: 'Tugas Belajar', icon: CheckSquare },
          { id: 'nilai-rapor', label: 'Nilai & Rapor', icon: Award },
          { id: 'keuangan-biaya', label: 'Biaya & Tabungan', icon: CreditCard },
          { id: 'prestasi-bk', label: 'Prestasi & Bimbingan', icon: ShieldCheck },
          { id: 'profil-biodata', label: 'Biodata Dapodik', icon: User },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-3.5 py-2.5 rounded-2xl font-bold text-xs whitespace-nowrap transition-all duration-150 ${
                isActive 
                  ? 'bg-slate-900 text-white shadow-md shadow-slate-200' 
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900 bg-white border border-slate-200/70'
              }`}
            >
              <Icon size={15} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 3. TAB CONTENT RENDER */}

      {/* TAB 1: RINGKASAN & BERANDA SISWA */}
      {activeTab === 'ringkasan' && (
        <div className="space-y-6">
          {/* Welcome Announcement Card */}
          <div className="p-5 bg-sky-50 border border-sky-200 rounded-3xl flex items-start gap-4">
            <div className="w-10 h-10 rounded-2xl bg-sky-600 text-white flex items-center justify-center shrink-0 shadow-sm">
              <Bell size={20} />
            </div>
            <div className="space-y-1">
              <h3 className="text-sm font-bold text-sky-950">Informasi Pembelajaran Siswa</h3>
              <p className="text-xs text-sky-800 leading-relaxed">
                Selamat datang di Portal Siswa Mandiri. Anda hanya dapat melihat dan mengelola data milik akun Anda sendiri. Pastikan selalu memantau jadwal pelajaran harian, mengerjakan penugasan tepat waktu, dan mengecek tagihan biaya pendidikan.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Today's Schedule Mini Card */}
            <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
                  <Calendar size={18} className="text-indigo-600" />
                  <span>Jadwal Pelajaran Kelas {currentStudent.class}</span>
                </h3>
                <button 
                  onClick={() => setActiveTab('jadwal-presensi')}
                  className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
                >
                  <span>Lihat Lengkap</span>
                  <ChevronRight size={14} />
                </button>
              </div>

              <div className="space-y-2">
                {jadwalKelas.slice(0, 4).map((j, idx) => (
                  <div key={idx} className="p-3 bg-slate-50 rounded-2xl border border-slate-100 flex items-center justify-between gap-3">
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-extrabold bg-indigo-100 text-indigo-800 px-1.5 py-0.5 rounded">
                          {j.hari}
                        </span>
                        <span className="font-bold text-xs text-slate-800">{j.mapel}</span>
                      </div>
                      <p className="text-[11px] text-slate-500">{j.guru} • {j.ruang || 'Kelas ' + currentStudent.class}</p>
                    </div>
                    <span className="text-[11px] font-mono font-bold text-slate-600 bg-white px-2 py-1 rounded-lg border border-slate-200">
                      {j.jam}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Urgent Tasks & CBT Alert */}
            <div className="bg-white rounded-3xl p-5 border border-slate-200 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-black text-slate-900 flex items-center gap-2">
                  <CheckSquare size={18} className="text-rose-600" />
                  <span>Tugas & Ujian Menunggu</span>
                </h3>
                <button 
                  onClick={() => setActiveTab('tugas-materi')}
                  className="text-xs font-bold text-rose-600 hover:text-rose-800 flex items-center gap-1"
                >
                  <span>Buka Tugas</span>
                  <ChevronRight size={14} />
                </button>
              </div>

              {tugasList.length === 0 ? (
                <div className="p-8 text-center bg-slate-50 rounded-2xl border border-slate-100 space-y-2">
                  <CheckCircle2 size={28} className="text-emerald-500 mx-auto" />
                  <p className="text-xs font-bold text-slate-700">Semua Tugas Selesai!</p>
                  <p className="text-[11px] text-slate-400">Tidak ada tugas baru dari guru saat ini.</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {tugasList.slice(0, 3).map((t, idx) => {
                    const isSubmitted = tugasSubmissions.some(sub => sub.tugasId === t.id && sub.studentId === currentStudent.id);
                    return (
                      <div key={idx} className="p-3 bg-slate-50 rounded-2xl border border-slate-100 flex items-center justify-between gap-3">
                        <div className="space-y-0.5">
                          <span className="font-bold text-xs text-slate-900 block truncate max-w-[200px]">{t.judul}</span>
                          <p className="text-[11px] text-slate-500">{t.mapel} • Tenggat: {t.tenggat || '-'}</p>
                        </div>
                        {isSubmitted ? (
                          <span className="px-2.5 py-1 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded-lg flex items-center gap-1">
                            <Check size={12} />
                            Terkumpul
                          </span>
                        ) : (
                          <button 
                            onClick={() => {
                              setSelectedTugasToSubmit(t);
                              setActiveTab('tugas-materi');
                            }}
                            className="px-2.5 py-1 bg-rose-600 hover:bg-rose-700 text-white text-[10px] font-bold rounded-lg transition"
                          >
                            Kerjakan
                          </button>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* Quick Academic & Financial Status */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="bg-white p-5 rounded-3xl border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-500">Rata-Rata Nilai</span>
                <Award size={16} className="text-amber-500" />
              </div>
              <p className="text-2xl font-black text-slate-900">86.8 <span className="text-xs font-bold text-emerald-600 bg-emerald-50 px-2 py-0.5 rounded">Predikat A</span></p>
              <p className="text-[11px] text-slate-400">Berdasarkan capaian {nilaiRapor.length} mata pelajaran</p>
            </div>

            <div className="bg-white p-5 rounded-3xl border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-500">Presensi Bulan Ini</span>
                <CheckCircle2 size={16} className="text-emerald-500" />
              </div>
              <p className="text-2xl font-black text-slate-900">{studentAbsensi.percentage}%</p>
              <p className="text-[11px] text-slate-400">{studentAbsensi.hadir} Hadir • {studentAbsensi.sakit} Sakit • {studentAbsensi.izin} Izin • {studentAbsensi.alpa} Alpa</p>
            </div>

            <div className="bg-white p-5 rounded-3xl border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-slate-500">Status Pembayaran Biaya</span>
                <CreditCard size={16} className="text-indigo-500" />
              </div>
              <p className="text-2xl font-black text-emerald-600">Lunas</p>
              <p className="text-[11px] text-slate-400">Tidak ada tunggakan pembayaran biaya aktif</p>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: JADWAL & PRESENSI */}
      {activeTab === 'jadwal-presensi' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
              <div>
                <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                  <Calendar size={18} className="text-indigo-600" />
                  <span>Jadwal Pelajaran Mingguan (Kelas {currentStudent.class})</span>
                </h3>
                <p className="text-xs text-slate-500">Tahun Pelajaran {settings.tahunPelajaran || '2026/2027'} • Semester Ganjil</p>
              </div>
              <button 
                onClick={() => window.print()}
                className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold flex items-center gap-1.5 self-start sm:self-auto transition"
              >
                <Printer size={14} />
                <span>Cetak Jadwal</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'].map(hari => {
                const hariJadwal = jadwalKelas.filter(j => j.hari === hari);
                if (hariJadwal.length === 0) return null;

                return (
                  <div key={hari} className="bg-slate-50 rounded-2xl p-4 border border-slate-200/80 space-y-3">
                    <div className="flex items-center justify-between pb-2 border-b border-slate-200">
                      <span className="font-extrabold text-xs text-indigo-900 uppercase tracking-wider">{hari}</span>
                      <span className="text-[10px] font-bold bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full">
                        {hariJadwal.length} Sesi
                      </span>
                    </div>
                    <div className="space-y-2">
                      {hariJadwal.map((j, idx) => (
                        <div key={idx} className="bg-white p-2.5 rounded-xl border border-slate-200 shadow-2xs space-y-1">
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-bold text-slate-900">{j.mapel}</span>
                            <span className="text-[10px] font-mono text-slate-500">{j.jam}</span>
                          </div>
                          <p className="text-[11px] text-slate-500">{j.guru}</p>
                          <span className="inline-block text-[9px] bg-slate-100 text-slate-600 px-1.5 py-0.2 rounded">
                            {j.ruang || 'Kelas ' + currentStudent.class}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Presensi Log */}
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <CheckCircle2 size={18} className="text-emerald-600" />
                <span>Riwayat Presensi & Kehadiran Saya</span>
              </h3>
              <button
                onClick={() => setActiveTab('pengajuan-izin')}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-xs transition active:scale-95 cursor-pointer"
              >
                <FileText size={14} />
                <span>+ Ajukan Izin / Sakit</span>
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-emerald-50 border border-emerald-100 rounded-2xl text-center">
                <p className="text-[11px] font-bold text-emerald-800">Hadir</p>
                <p className="text-xl font-black text-emerald-950 mt-0.5">{studentAbsensi.hadir} Hari</p>
              </div>
              <div className="p-3 bg-blue-50 border border-blue-100 rounded-2xl text-center">
                <p className="text-[11px] font-bold text-blue-800">Sakit</p>
                <p className="text-xl font-black text-blue-950 mt-0.5">{studentAbsensi.sakit} Hari</p>
              </div>
              <div className="p-3 bg-amber-50 border border-amber-100 rounded-2xl text-center">
                <p className="text-[11px] font-bold text-amber-800">Izin</p>
                <p className="text-xl font-black text-amber-950 mt-0.5">{studentAbsensi.izin} Hari</p>
              </div>
              <div className="p-3 bg-rose-50 border border-rose-100 rounded-2xl text-center">
                <p className="text-[11px] font-bold text-rose-800">Alpa</p>
                <p className="text-xl font-black text-rose-950 mt-0.5">{studentAbsensi.alpa} Hari</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB: PENGAJUAN IZIN / SAKIT SISWA */}
      {activeTab === 'pengajuan-izin' && (
        <PengajuanIzinPortal 
          student={currentStudent}
          submittedBy="Siswa"
        />
      )}

      {/* TAB 3: UJIAN CBT ONLINE */}
      {activeTab === 'cbt-ujian' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-5">
            <div>
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <Laptop size={18} className="text-cyan-600" />
                <span>Ujian CBT Online Siswa (Computer Based Test)</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Daftar sesi ujian aktif dan tes yang dapat dikerjakan oleh kelas {currentStudent.class}.
              </p>
            </div>

            {cbtUjianList.length === 0 ? (
              <div className="p-10 text-center bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <Laptop size={32} className="text-slate-400 mx-auto" />
                <h4 className="font-bold text-slate-800 text-sm">Tidak Ada Jadwal Ujian Aktif</h4>
                <p className="text-xs text-slate-500">Saat ini belum ada sesi ujian CBT yang dibuka untuk kelas Anda.</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {cbtUjianList.map((u, idx) => (
                  <div key={idx} className="p-5 bg-gradient-to-br from-slate-50 to-cyan-50/40 rounded-3xl border border-cyan-100 space-y-4 shadow-2xs">
                    <div className="flex items-start justify-between gap-3">
                      <div className="space-y-1">
                        <span className="text-[10px] font-extrabold bg-cyan-100 text-cyan-800 px-2 py-0.5 rounded-md">
                          {u.jenis || 'Penilaian Sumatif'}
                        </span>
                        <h4 className="text-base font-black text-slate-900">{u.nama || u.judul}</h4>
                        <p className="text-xs text-slate-500">{u.mapel} • {u.durasi || '60'} Menit</p>
                      </div>
                      <span className="w-3 h-3 rounded-full bg-emerald-500 animate-ping" />
                    </div>

                    <div className="p-3 bg-white rounded-2xl border border-slate-200 text-xs space-y-1">
                      <div className="flex justify-between text-slate-600">
                        <span>Status Sesi:</span>
                        <strong className="text-emerald-700 font-bold">Dibuka</strong>
                      </div>
                      <div className="flex justify-between text-slate-600">
                        <span>Jumlah Soal:</span>
                        <strong className="text-slate-800">{u.jumlahSoal || '25'} Butir</strong>
                      </div>
                    </div>

                    <button 
                      onClick={() => alert(`Memulai ujian CBT: ${u.nama || u.judul}. Pastikan koneksi internet stabil.`)}
                      className="w-full py-2.5 bg-cyan-600 hover:bg-cyan-700 active:bg-cyan-800 text-white font-bold text-xs rounded-xl transition shadow-xs flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Laptop size={14} />
                      <span>Mulai Kerjakan Ujian CBT</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 4: TUGAS BELAJAR */}
      {activeTab === 'tugas-materi' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-5">
            <div>
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <CheckSquare size={18} className="text-rose-600" />
                <span>Penugasan & Pengumpulan Tugas Siswa</span>
              </h3>
              <p className="text-xs text-slate-500 mt-0.5">
                Kumpulkan tugas harian dan proyek belajar langsung ke guru mata pelajaran.
              </p>
            </div>

            {/* Submission Modal / Box if selected */}
            {selectedTugasToSubmit && (
              <div className="p-5 bg-rose-50 border-2 border-rose-200 rounded-3xl space-y-4 animate-in fade-in">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <span className="text-[10px] font-bold text-rose-700 uppercase">Form Pengumpulan Tugas</span>
                    <h4 className="text-base font-black text-slate-900">{selectedTugasToSubmit.judul}</h4>
                    <p className="text-xs text-slate-600">{selectedTugasToSubmit.mapel}</p>
                  </div>
                  <button 
                    onClick={() => setSelectedTugasToSubmit(null)}
                    className="text-xs font-bold text-rose-600 hover:text-rose-800 p-1"
                  >
                    Batal
                  </button>
                </div>

                <form onSubmit={handleSubmitTugas} className="space-y-3">
                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 block">Teks Jawaban / Keterangan:</label>
                    <textarea 
                      value={submissionText}
                      onChange={(e) => setSubmissionText(e.target.value)}
                      placeholder="Tuliskan ringkasan jawaban tugas atau catatan di sini..."
                      rows={3}
                      className="w-full p-3 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 focus:ring-2 focus:ring-rose-400 outline-hidden"
                      required
                    />
                  </div>

                  <div className="space-y-1">
                    <label className="text-xs font-bold text-slate-700 block">Link Dokumen / Google Drive (Opsional):</label>
                    <input 
                      type="url"
                      value={submissionFileLink}
                      onChange={(e) => setSubmissionFileLink(e.target.value)}
                      placeholder="https://drive.google.com/..."
                      className="w-full p-2.5 bg-white border border-slate-200 rounded-xl text-xs text-slate-900 focus:ring-2 focus:ring-rose-400 outline-hidden"
                    />
                  </div>

                  <button 
                    type="submit"
                    className="px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl transition flex items-center gap-1.5 shadow-sm"
                  >
                    <Send size={14} />
                    <span>{submitSuccess ? 'Berhasil Dikirim!' : 'Kirim Tugas ke Guru'}</span>
                  </button>
                </form>
              </div>
            )}

            {tugasList.length === 0 ? (
              <div className="p-10 text-center bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <CheckCircle2 size={32} className="text-emerald-500 mx-auto" />
                <h4 className="font-bold text-slate-800 text-sm">Tidak Ada Tugas Tertunda</h4>
                <p className="text-xs text-slate-500">Semua tugas kelas {currentStudent.class} telah tuntas dikumpulkan.</p>
              </div>
            ) : (
              <div className="space-y-3">
                {tugasList.map((t, idx) => {
                  const submission = tugasSubmissions.find(sub => sub.tugasId === t.id && sub.studentId === currentStudent.id);

                  return (
                    <div key={idx} className="p-4 bg-slate-50 rounded-2xl border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-[10px] font-bold bg-indigo-100 text-indigo-800 px-2 py-0.5 rounded">
                            {t.mapel}
                          </span>
                          <span className="text-xs text-slate-400">• Tenggat: {t.tenggat || '-'}</span>
                        </div>
                        <h4 className="text-sm font-bold text-slate-900">{t.judul}</h4>
                        {t.deskripsi && <p className="text-xs text-slate-500 line-clamp-2">{t.deskripsi}</p>}
                      </div>

                      {submission ? (
                        <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-xs space-y-0.5 shrink-0">
                          <span className="text-[10px] font-extrabold text-emerald-800 flex items-center gap-1">
                            <CheckCircle2 size={12} />
                            Sudah Dikumpulkan
                          </span>
                          <p className="text-[11px] text-emerald-950 font-bold">
                            {submission.nilai !== null && submission.nilai !== undefined ? `Nilai: ${submission.nilai}/100` : 'Menunggu Nilai Guru'}
                          </p>
                        </div>
                      ) : (
                        <button 
                          onClick={() => setSelectedTugasToSubmit(t)}
                          className="px-4 py-2 bg-rose-600 hover:bg-rose-700 text-white font-bold text-xs rounded-xl transition shadow-2xs shrink-0 flex items-center gap-1.5"
                        >
                          <Send size={13} />
                          <span>Kumpulkan Tugas</span>
                        </button>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 5: NILAI & RAPOR */}
      {activeTab === 'nilai-rapor' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
              <div>
                <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                  <Award size={18} className="text-amber-500" />
                  <span>Lembar Capaian Nilai & Rapor Siswa</span>
                </h3>
                <p className="text-xs text-slate-500">Tahun Pelajaran {settings.tahunPelajaran || '2026/2027'} • Kelas {currentStudent.class}</p>
              </div>
              <button 
                onClick={() => window.print()}
                className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 transition shadow-xs self-start sm:self-auto"
              >
                <Printer size={14} />
                <span>Cetak Rapor Digital</span>
              </button>
            </div>

            {/* Nilai Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-slate-100/80 text-slate-700 font-extrabold border-b border-slate-200">
                    <th className="p-3 rounded-l-xl">No</th>
                    <th className="p-3">Mata Pelajaran</th>
                    <th className="p-3 text-center">KKM</th>
                    <th className="p-3 text-center">Tugas</th>
                    <th className="p-3 text-center">PTS</th>
                    <th className="p-3 text-center">PAS</th>
                    <th className="p-3 text-center">Nilai Akhir</th>
                    <th className="p-3 text-center">Predikat</th>
                    <th className="p-3 rounded-r-xl">Capaian Kompetensi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {nilaiRapor.map((n, idx) => (
                    <tr key={idx} className="hover:bg-slate-50/80 transition">
                      <td className="p-3 font-bold text-slate-400">{idx + 1}</td>
                      <td className="p-3 font-bold text-slate-900">{n.mapel || n.subjectName}</td>
                      <td className="p-3 text-center font-mono text-slate-600">{n.kkm || 75}</td>
                      <td className="p-3 text-center font-mono font-bold text-slate-700">{n.tugas || 85}</td>
                      <td className="p-3 text-center font-mono font-bold text-slate-700">{n.pts || 82}</td>
                      <td className="p-3 text-center font-mono font-bold text-slate-700">{n.pas || 88}</td>
                      <td className="p-3 text-center font-mono font-extrabold text-indigo-700 text-sm">{n.akhir || 85}</td>
                      <td className="p-3 text-center">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-black ${
                          (n.predikat || 'A') === 'A' ? 'bg-emerald-100 text-emerald-800' : 'bg-blue-100 text-blue-800'
                        }`}>
                          {n.predikat || 'A'}
                        </span>
                      </td>
                      <td className="p-3 text-[11px] text-slate-600">{n.capaian || 'Mencapai kompetensi dengan predikat sangat baik.'}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 6: KEUANGAN & BIAYA */}
      {activeTab === 'keuangan-biaya' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Tagihan Biaya Pendidikan Card */}
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <CreditCard size={18} className="text-emerald-600" />
                <span>Status Tagihan Biaya Pendidikan</span>
              </h3>

              <div className="space-y-2">
                {['Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember', 'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni'].map((bln, idx) => {
                  const isLunas = idx <= 6; // Contoh simulasi lunas s/d Jan
                  return (
                    <div key={bln} className="p-3 bg-slate-50 rounded-2xl border border-slate-100 flex items-center justify-between">
                      <div className="space-y-0.5">
                        <span className="font-bold text-xs text-slate-900">Iuran / Biaya Bulan {bln}</span>
                        <p className="text-[11px] text-slate-500">Rp 150.000 / Bulan</p>
                      </div>
                      <span className={`px-2.5 py-1 rounded-xl text-[10px] font-extrabold flex items-center gap-1 ${
                        isLunas ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                      }`}>
                        {isLunas ? <><Check size={12} /> Lunas</> : 'Belum Bayar'}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Tabungan Siswa Card */}
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                  <Wallet size={18} className="text-indigo-600" />
                  <span>Buku Tabungan Siswa</span>
                </h3>
                <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-2.5 py-1 rounded-xl border border-indigo-100">
                  Saldo: {fmtRupiah(keuanganTabungan.saldo || 250000)}
                </span>
              </div>

              <div className="space-y-2">
                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-slate-800 block">Setoran Kas Tabungan</span>
                    <span className="text-[10px] text-slate-400">10 Agustus 2026</span>
                  </div>
                  <span className="font-mono font-bold text-emerald-600">+Rp 150.000</span>
                </div>
                <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-bold text-slate-800 block">Setoran Kas Tabungan</span>
                    <span className="text-[10px] text-slate-400">01 Agustus 2026</span>
                  </div>
                  <span className="font-mono font-bold text-emerald-600">+Rp 100.000</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 7: PRESTASI & BK */}
      {activeTab === 'prestasi-bk' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Prestasi */}
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <Award size={18} className="text-amber-500" />
                <span>Piagam & Prestasi Siswa</span>
              </h3>

              <div className="p-4 bg-amber-50/60 rounded-2xl border border-amber-200/70 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-amber-950">Juara 1 Lomba Cerdas Cermat Sains</span>
                  <span className="text-[10px] font-bold bg-amber-200 text-amber-900 px-2 py-0.5 rounded">Tingkat Kota</span>
                </div>
                <p className="text-[11px] text-amber-800">Diberikan pada Peringatan Hardiknas 2026</p>
              </div>
            </div>

            {/* Catatan Konseling BK */}
            <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
              <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
                <ShieldCheck size={18} className="text-indigo-600" />
                <span>Catatan Bimbingan Konseling (BK)</span>
              </h3>

              <div className="p-4 bg-indigo-50/60 rounded-2xl border border-indigo-200/70 space-y-1">
                <span className="font-bold text-xs text-indigo-950 block">Konseling Pengembangan Minat Bakat</span>
                <p className="text-[11px] text-indigo-800 leading-relaxed">
                  Siswa menunjukkan antusiasme tinggi di bidang sains dan teknologi. Direkomendasikan mengikuti klub ekstrakurikuler robotik/olimpiade sains.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 8: PROFIL & BIODATA DAPODIK */}
      {activeTab === 'profil-biodata' && (
        <div className="space-y-6">
          <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-5">
            <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
              <User size={18} className="text-indigo-600" />
              <span>Biodata Lengkap Siswa (Standar Dapodik Kemendikbudristek)</span>
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
                <span className="text-[10px] font-bold text-slate-400">Nama Lengkap:</span>
                <p className="font-bold text-slate-900">{currentStudent.name}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
                <span className="text-[10px] font-bold text-slate-400">NISN / NIS:</span>
                <p className="font-bold text-slate-900">{currentStudent.nisn || currentStudent.nis || '-'}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
                <span className="text-[10px] font-bold text-slate-400">Tempat, Tanggal Lahir:</span>
                <p className="font-bold text-slate-900">{currentStudent.pob || 'Jakarta'}, {currentStudent.dob || '-'}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
                <span className="text-[10px] font-bold text-slate-400">Jenis Kelamin:</span>
                <p className="font-bold text-slate-900">{currentStudent.gender === 'L' ? 'Laki-Laki' : 'Perempuan'}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
                <span className="text-[10px] font-bold text-slate-400">Kelas & Rombel:</span>
                <p className="font-bold text-slate-900">{currentStudent.class}</p>
              </div>
              <div className="p-3 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
                <span className="text-[10px] font-bold text-slate-400">Alamat Domisili:</span>
                <p className="font-bold text-slate-900">{currentStudent.address || '-'}</p>
              </div>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
