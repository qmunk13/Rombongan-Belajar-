import React, { useState } from 'react';
import { 
  BookOpen, CheckCircle2, Award, Sparkles, GraduationCap, 
  FileText, ShieldCheck, Download, ExternalLink, Zap, Layers, Compass, Brain
} from 'lucide-react';

interface KurikulumProps {
  user?: any;
  isPublicView?: boolean;
}

export default function Kurikulum({ user, isPublicView }: KurikulumProps) {
  const [activeTab, setActiveTab] = useState<'struktur' | 'kemendikdasmen' | 'p5' | 'deeplearning'>('struktur');

  return (
    <div className="py-8 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center space-y-3">
        <span className="text-xs font-bold text-indigo-600 bg-indigo-50 px-3.5 py-1.5 rounded-full uppercase tracking-wider border border-indigo-100/80">
          Standar Kurikulum Nasional Kemendikdasmen Terbaru
        </span>
        <h1 className="text-2xl sm:text-4xl font-black text-slate-900">
          Kurikulum Merdeka & Pendekatan Deep Learning
        </h1>
        <p className="text-sm text-slate-600 max-w-3xl mx-auto leading-relaxed">
          Mengimplementasikan kerangka regulasi Permendikdasmen No. 12/2024, penyelarasan Capaian Pembelajaran (CP 2024/2025), serta prinsip <em>Mindful, Meaningful, & Joyful Learning</em> untuk melahirkan generasi emas yang berkarakter Pancasila dan berdaya saing global.
        </p>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex flex-wrap items-center justify-center gap-2 border-b border-slate-200 pb-3">
        <button
          onClick={() => setActiveTab('struktur')}
          className={`px-4 py-2 rounded-2xl text-xs font-bold transition flex items-center gap-1.5 ${
            activeTab === 'struktur' 
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200' 
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          <BookOpen size={14} />
          <span>Struktur Kurikulum & Fase</span>
        </button>

        <button
          onClick={() => setActiveTab('kemendikdasmen')}
          className={`px-4 py-2 rounded-2xl text-xs font-bold transition flex items-center gap-1.5 ${
            activeTab === 'kemendikdasmen' 
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200' 
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          <ShieldCheck size={14} />
          <span>Regulasi & Kebijakan Kemendikdasmen</span>
        </button>

        <button
          onClick={() => setActiveTab('deeplearning')}
          className={`px-4 py-2 rounded-2xl text-xs font-bold transition flex items-center gap-1.5 ${
            activeTab === 'deeplearning' 
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200' 
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          <Brain size={14} />
          <span>Pendekatan Deep Learning</span>
        </button>

        <button
          onClick={() => setActiveTab('p5')}
          className={`px-4 py-2 rounded-2xl text-xs font-bold transition flex items-center gap-1.5 ${
            activeTab === 'p5' 
              ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200' 
              : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
          }`}
        >
          <Sparkles size={14} />
          <span>Projek P5 & Karakter</span>
        </button>
      </div>

      {/* Tab 1: Struktur Kurikulum */}
      {activeTab === 'struktur' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-3">
              <div className="w-12 h-12 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center font-bold">
                <BookOpen size={24} />
              </div>
              <h3 className="font-extrabold text-slate-900 text-base">Fase A (Kelas 1 & 2)</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Pondasi literasi dasar, kesadaran fonik, numerasi konkret, pengenalan emosi diri, dan pembiasaan adab serta disiplin positif.
              </p>
              <div className="pt-2 border-t border-slate-100 text-[11px] font-bold text-indigo-700">
                Alokasi: ~28 JP / Minggu
              </div>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-3">
              <div className="w-12 h-12 bg-amber-50 text-amber-600 rounded-2xl flex items-center justify-center font-bold">
                <Layers size={24} />
              </div>
              <h3 className="font-extrabold text-slate-900 text-base">Fase B (Kelas 3 & 4)</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Penguatan literasi naratif & informasional, IPAS dasar (lingkungan & sains sederhana), penalaran matematis, dan kolaborasi tim.
              </p>
              <div className="pt-2 border-t border-slate-100 text-[11px] font-bold text-amber-700">
                Alokasi: ~32 JP / Minggu
              </div>
            </div>

            <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-3">
              <div className="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-2xl flex items-center justify-center font-bold">
                <GraduationCap size={24} />
              </div>
              <h3 className="font-extrabold text-slate-900 text-base">Fase C (Kelas 5 & 6)</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Berpikir kritis (HOTS), pengenalan literasi komputasional/coding dasar, riset sederhana, kepemimpinan, dan kesiapan jenjang SMP.
              </p>
              <div className="pt-2 border-t border-slate-100 text-[11px] font-bold text-emerald-700">
                Alokasi: ~32 JP / Minggu
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: Kebijakan Kemendikdasmen Terbaru */}
      {activeTab === 'kemendikdasmen' && (
        <div className="bg-white p-8 rounded-3xl border border-slate-200/80 shadow-xs space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
              <ShieldCheck size={22} />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-900">Pedoman Permendikdasmen & Kurikulum Nasional</h3>
              <p className="text-xs text-slate-500">Dasar hukum dan rujukan teknis kurikulum resmi.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-indigo-700">Permendikdasmen No. 12 Tahun 2024</span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black">Regulasi Utama</span>
              </div>
              <p className="text-slate-600">
                Menetapkan Kurikulum Merdeka sebagai Kurikulum Nasional pada Pendidikan Anak Usia Dini, Pendidikan Dasar, dan Pendidikan Menengah secara berkeadilan.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-indigo-700">Keputusan BSKAP No. 032/H/KR/2024</span>
                <span className="px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-800 text-[10px] font-black">Capaian CP</span>
              </div>
              <p className="text-slate-600">
                Pembaruan Capaian Pembelajaran (CP) untuk seluruh mata pelajaran pada Fase Fondasi, Fase A, Fase B, hingga Fase F.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-indigo-700">Panduan Pembelajaran & Asesmen (PPA 2024)</span>
                <span className="px-2 py-0.5 rounded-full bg-amber-100 text-amber-800 text-[10px] font-black">Panduan Teknis</span>
              </div>
              <p className="text-slate-600">
                Standarisasi asesmen formatif, sumatif (STS/SAS), KKTP (Kriteria Ketercapaian TP), dan pelaporan rapor deskriptif.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-bold text-indigo-700">Penguatan Matematika & Coding Sejak Dini</span>
                <span className="px-2 py-0.5 rounded-full bg-purple-100 text-purple-800 text-[10px] font-black">Inisiatif 2026/2027</span>
              </div>
              <p className="text-slate-600">
                Arahan Mendikdasmen terkait integrasi numerasi aplikatif, logika berpikir komputasi, dan pemanfaatan AI yang bijak di sekolah dasar.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Deep Learning Approach */}
      {activeTab === 'deeplearning' && (
        <div className="bg-white p-8 rounded-3xl border border-slate-200/80 shadow-xs space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
              <Brain size={22} />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-900">Pendekatan Pembelajaran Mendalam (Deep Learning)</h3>
              <p className="text-xs text-slate-500">Transformasi proses belajar mengajar: bukan sekadar hafalan, melainkan pemahaman bermakna.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div className="p-5 rounded-3xl bg-indigo-50/60 border border-indigo-200 space-y-2">
              <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white font-black flex items-center justify-center text-sm">
                1
              </div>
              <h4 className="font-black text-slate-900 text-sm">Mindful Learning</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Pembelajaran yang berkesadaran penuh, di mana siswa memahami <em>mengapa</em> mereka belajar, hadir secara mental, dan bebas dari tekanan berlebih.
              </p>
            </div>

            <div className="p-5 rounded-3xl bg-amber-50/60 border border-amber-200 space-y-2">
              <div className="w-10 h-10 rounded-xl bg-amber-600 text-white font-black flex items-center justify-center text-sm">
                2
              </div>
              <h4 className="font-black text-slate-900 text-sm">Meaningful Learning</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Pembelajaran bermakna yang mengaitkan materi secara kontekstual dengan kehidupan nyata siswa di lingkungan sekitar.
              </p>
            </div>

            <div className="p-5 rounded-3xl bg-emerald-50/60 border border-emerald-200 space-y-2">
              <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white font-black flex items-center justify-center text-sm">
                3
              </div>
              <h4 className="font-black text-slate-900 text-sm">Joyful Learning</h4>
              <p className="text-xs text-slate-600 leading-relaxed">
                Pembelajaran menggembirakan melalui eksplorasi, eksperimen praktis, games edukatif, dan ruang berkarya tanpa rasa takut salah.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: P5 */}
      {activeTab === 'p5' && (
        <div className="bg-white p-8 rounded-3xl border border-slate-200/80 shadow-xs space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
              <Sparkles size={22} />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-900">Tema Projek Penguatan Profil Pelajar Pancasila (P5)</h3>
              <p className="text-xs text-slate-500">Dimensi: Beriman & Bertakwa, Berkebinekaan Global, Gotong Royong, Mandiri, Bernalar Kritis, Kreatif.</p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
              <h4 className="font-black text-slate-900">1. Gaya Hidup Berkelanjutan</h4>
              <p className="text-slate-600">Pengelolaan bank sampah sekolah, daur ulang kreatif, dan pembibitan tanaman organik.</p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
              <h4 className="font-black text-slate-900">2. Kearifan Lokal</h4>
              <p className="text-slate-600">Pelestarian seni tari daerah, lagu tradisional Nusantara, dan kuliner khas nusantara.</p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
              <h4 className="font-black text-slate-900">3. Kewirausahaan Cilik</h4>
              <p className="text-slate-600">Market Day siswa untuk mengasah literasi finansial, kejujuran, dan komunikasi jual-beli.</p>
            </div>
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
              <h4 className="font-black text-slate-900">4. Bhinneka Tunggal Ika</h4>
              <p className="text-slate-600">Menghargai keragaman budaya, toleransi antarumat beragama, dan pencegahan perundungan (Anti-Bullying).</p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
