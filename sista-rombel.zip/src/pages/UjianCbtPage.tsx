import React, { useState, useMemo } from 'react';
import { 
  Laptop, Award, FileQuestion, Calendar, Key, 
  Eye, CheckCircle2
} from 'lucide-react';
import { db } from '../data/db';
import { useStore } from '../store';
import CbtDashboardTab from '../components/cbt/CbtDashboardTab';
import JadwalUjianTab from '../components/cbt/JadwalUjianTab';
import BankSoalTab from '../components/cbt/BankSoalTab';
import TokenUjianTab from '../components/cbt/TokenUjianTab';
import ProktorPengawasanTab from '../components/cbt/ProktorPengawasanTab';
import HasilUjianTab from '../components/cbt/HasilUjianTab';
import RaporPendidikanTab from '../components/cbt/RaporPendidikanTab';

export default function UjianCbtPage() {
  const { teachers } = useStore();
  const [activeSubTab, setActiveSubTab] = useState('dashboard');

  const subTabs = [
    { id: 'dashboard', label: 'CBT Dashboard', icon: Laptop },
    { id: 'jadwal-ujian', label: 'Jadwal & Sesi Ujian', icon: Calendar },
    { id: 'bank-soal', label: 'Bank Soal', icon: FileQuestion },
    { id: 'token-ujian', label: 'Token Ujian', icon: Key },
    { id: 'proktor', label: 'Pengawasan (Proktor)', icon: Eye },
    { id: 'hasil-ujian', label: 'Hasil Ujian', icon: CheckCircle2 },
    { id: 'rapor-pendidikan', label: 'Rapor Pendidikan', icon: Award },
  ];

  const handleSubTabChange = (tabId: string) => {
    setActiveSubTab(tabId);
    window.scrollTo({ top: 0, behavior: 'instant' });
    const scrollContainer = document.querySelector('.overflow-y-auto');
    if (scrollContainer) {
      scrollContainer.scrollTo({ top: 0, behavior: 'instant' });
    }
  };

  // Ujian List Persistence from db (no dummy data)
  const [ujianList, setUjianList] = useState<any[]>(() => {
    const fromDb = db.get('ujian_cbt');
    return Array.isArray(fromDb) ? fromDb : [];
  });

  const saveUjianDb = (list: any[]) => {
    setUjianList(list);
    db.set('ujian_cbt', list);
  };

  // Bank Soal list for dashboard summary count from db
  const bankSoalList = useMemo(() => {
    const fromDb = db.get('cbt_bank_soal');
    return Array.isArray(fromDb) ? fromDb : [];
  }, [activeSubTab]);

  // Dynamic token active
  const tokenActive = useMemo(() => {
    const tokens = db.get('cbt_token_history');
    const active = Array.isArray(tokens) ? tokens.find((t: any) => t.status === 'Aktif') : null;
    return active?.token || '-';
  }, [activeSubTab]);

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Title Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white/90 p-5 rounded-3xl border border-slate-200/80 shadow-xs no-print">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-cyan-50 text-cyan-600 flex items-center justify-center border border-cyan-100/80 shadow-2xs shrink-0">
            <Laptop size={22} />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">
              Ujian Online (CBT & Asesmen)
            </h1>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              Pelaksanaan ujian online berbasis komputer, bank butir soal, token dinamis, pengawasan proktor live, & analisis mutu Rapor Pendidikan.
            </p>
          </div>
        </div>
      </div>

      {/* Sub-Navigation: Mobile Dropdown Selector & Desktop Pill Tabs */}
      <div className="md:hidden bg-white p-3 rounded-2xl border border-slate-200/80 shadow-xs no-print">
        <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">
          Pilih Sub-Menu CBT:
        </label>
        <div className="relative">
          <select
            value={activeSubTab}
            onChange={(e) => handleSubTabChange(e.target.value)}
            className="w-full pl-3.5 pr-10 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black text-slate-800 focus:outline-none focus:ring-2 focus:ring-cyan-500/20 focus:border-cyan-500 appearance-none transition"
          >
            {subTabs.map((tab) => (
              <option key={tab.id} value={tab.id}>
                {tab.label}
              </option>
            ))}
          </select>
          <div className="absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
            ▼
          </div>
        </div>
      </div>

      {/* Desktop Sub Tabs Navigation */}
      <div className="hidden md:flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none no-print">
        {subTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => handleSubTabChange(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all whitespace-nowrap active:scale-95 ${
                isActive
                  ? 'bg-cyan-600 text-white shadow-md shadow-cyan-200'
                  : 'bg-white/80 text-slate-600 hover:bg-white hover:text-cyan-600 border border-slate-200/80'
              }`}
            >
              <Icon size={16} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* RENDER DEDICATED SUB-TAB VIEWS */}
      {activeSubTab === 'dashboard' && (
        <CbtDashboardTab 
          onNavigateTab={handleSubTabChange}
          ujianList={ujianList}
          bankSoalList={bankSoalList}
          tokenActive={tokenActive}
        />
      )}

      {activeSubTab === 'jadwal-ujian' && (
        <JadwalUjianTab 
          ujianList={ujianList}
          setUjianList={setUjianList}
          onSaveDb={saveUjianDb}
        />
      )}

      {activeSubTab === 'bank-soal' && (
        <BankSoalTab />
      )}

      {activeSubTab === 'token-ujian' && (
        <TokenUjianTab />
      )}

      {activeSubTab === 'proktor' && (
        <ProktorPengawasanTab />
      )}

      {activeSubTab === 'hasil-ujian' && (
        <HasilUjianTab />
      )}

      {activeSubTab === 'rapor-pendidikan' && (
        <RaporPendidikanTab />
      )}
    </div>
  );
}
