import React, { useState, useMemo, useEffect } from 'react';
import { useStore } from '../store';
import { db } from '../data/db';
import { cn, matchClass, matchStatusActive, getActiveClasses, getAllClasses, normalizeClassName, formatClassLabel, STANDARD_CLASSES } from '../lib/utils';
import { Student } from '../types';
import { 
  Users, ArrowUpCircle, CheckCircle2, AlertCircle, TrendingUp, 
  Sparkles, Check, RefreshCw, GraduationCap, XCircle, ArrowRight,
  Filter, CheckSquare, UserCheck, AlertTriangle
} from 'lucide-react';
import { fetchFromGAS } from '../lib/api';
import { PromotionOption, getPromotionOptionsForClass } from '../lib/promotionService';

export default function KenaikanKelas() {
  const { 
    students, updateStudentsBulk, settings, setLoading, 
    setIsSyncingGlobal, setLastSyncedAt 
  } = useStore();
  
  const activeClasses = useMemo(() => getActiveClasses(students), [students]);
  const allClasses = useMemo(() => {
    return Array.from(new Set([...getAllClasses(students), ...STANDARD_CLASSES])).sort((a, b) =>
      a.localeCompare(b, undefined, { numeric: true, sensitivity: 'base' })
    );
  }, [students]);

  const [selectedClass, setSelectedClass] = useState<string>(activeClasses[0] || '4');
  const [individualDecisions, setIndividualDecisions] = useState<{ [studentId: string]: PromotionOption }>({});
  const [isProcessing, setIsProcessing] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Promotion options for currently selected class
  const classPromotionOptions = useMemo(() => {
    return getPromotionOptionsForClass(selectedClass);
  }, [selectedClass]);

  const defaultOption: PromotionOption = useMemo(() => {
    return classPromotionOptions[0] || { value: 'Naik', label: 'Naik', action: 'Naik', targetClass: '5' };
  }, [classPromotionOptions]);

  // Active students in selected class
  const classStudents = useMemo(() => {
    if (!students) return [];
    return students
      .filter(s => matchStatusActive(s.status) && matchClass(s.class, selectedClass))
      .sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'id'));
  }, [students, selectedClass]);

  // Initialize individual decisions when class or student list changes
  useEffect(() => {
    const initial: { [key: string]: PromotionOption } = {};
    classStudents.forEach(s => {
      initial[s.id] = defaultOption;
    });
    setIndividualDecisions(initial);
  }, [classStudents, defaultOption]);

  const handleDecisionChange = (studentId: string, optionValue: string) => {
    const selectedOpt = classPromotionOptions.find(o => o.value === optionValue) || defaultOption;
    setIndividualDecisions(prev => ({
      ...prev,
      [studentId]: selectedOpt
    }));
  };

  const handleApplyToAll = (optionValue: string) => {
    const selectedOpt = classPromotionOptions.find(o => o.value === optionValue);
    if (!selectedOpt) return;
    const updated: { [key: string]: PromotionOption } = {};
    classStudents.forEach(s => {
      updated[s.id] = selectedOpt;
    });
    setIndividualDecisions(updated);
  };

  const handleExecutePromotion = async () => {
    if (classStudents.length === 0) {
      alert('Tidak ada siswa di kelas ini.');
      return;
    }

    const confirmMsg = `Konfirmasi eksekusi kenaikan / kelulusan untuk ${classStudents.length} siswa di Kelas ${selectedClass}?\n\nData kolom 'Kelas' dan 'Status' di data induk SISWA akan langsung diperbarui secara permanen.`;
    if (!window.confirm(confirmMsg)) return;

    setIsProcessing(true);

    try {
      const updates = classStudents.map(s => {
        const decision = individualDecisions[s.id] || defaultOption;
        
        if (decision.action === 'Lulus') {
          return { id: s.id, data: { status: 'Lulus' as const } };
        } else if (decision.action === 'Pindah') {
          return { id: s.id, data: { status: 'Pindah' as const } };
        } else if (decision.action === 'Keluar') {
          return { id: s.id, data: { status: 'Keluar' as const } };
        } else if (decision.action === 'Tinggal') {
          return { id: s.id, data: { class: decision.targetClass, status: 'Aktif' as const } };
        } else {
          return { id: s.id, data: { class: decision.targetClass, status: 'Aktif' as const } };
        }
      });

      // Update in-memory state
      updateStudentsBulk(updates);

      // Trigger cloud sync if scriptUrl is present
      if (settings.scriptUrl) {
        setIsSyncingGlobal(true);
        const updatedAll = useStore.getState().students;
        await fetchFromGAS(settings.scriptUrl, {
          action: 'sync',
          data: updatedAll,
          teachers: useStore.getState().teachers,
          spreadsheetId: settings.spreadsheetId
        });
        setLastSyncedAt(new Date().toLocaleTimeString('id-ID'));
        setIsSyncingGlobal(false);
      }

      setSuccessMessage(`Berhasil memperbarui data promosi ${classStudents.length} siswa Kelas ${selectedClass}!`);
      setTimeout(() => setSuccessMessage(null), 4000);
    } catch (e) {
      console.error("Error executing promotion:", e);
      alert("Terjadi kesalahan saat memproses data.");
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold border border-indigo-100/80 shadow-2xs">
            <TrendingUp size={22} />
          </div>
          <div>
            <h2 className="text-base font-black text-slate-900">Kenaikan Kelas & Kelulusan Terintegrasi</h2>
            <p className="text-xs text-slate-500 font-medium">
              Eksekusi promosi semester/akhir tahun ajaran yang otomatis memperbaharui kolom 'Kelas' & 'Status' pada data induk SISWA.
            </p>
          </div>
        </div>

        {successMessage && (
          <div className="px-4 py-2 bg-emerald-50 text-emerald-800 border border-emerald-200 rounded-2xl text-xs font-black flex items-center gap-2 animate-in fade-in">
            <CheckCircle2 size={16} className="text-emerald-600" />
            <span>{successMessage}</span>
          </div>
        )}
      </div>

      {/* Class Selector & Promotion Summary */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 items-center">
          {/* Origin Class */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-600 block">Pilih Kelas Asal:</label>
            <select 
              className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-black text-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 cursor-pointer"
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
            >
              {allClasses.map(c => {
                const count = students.filter(s => matchStatusActive(s.status) && matchClass(s.class, c)).length;
                return (
                  <option key={c} value={c}>{formatClassLabel(c, true)} ({count} Siswa)</option>
                );
              })}
            </select>
          </div>

          {/* Transition Icon */}
          <div className="flex flex-col items-center justify-center text-center">
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Target Standar</span>
            <div className="w-10 h-10 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center border border-indigo-100 shadow-2xs">
              <ArrowRight size={20} />
            </div>
          </div>

          {/* Destination Class Summary */}
          <div className="p-4 rounded-2xl bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-100 space-y-1">
            <span className="text-[10px] font-bold text-indigo-800 uppercase tracking-wider block">Opsi Standar:</span>
            <div className="text-lg font-black text-indigo-950">
              {defaultOption.label}
            </div>
            <p className="text-[11px] text-indigo-600/80">
              Target tujuan otomatis: <span className="font-bold">{defaultOption.targetClass ? formatClassLabel(defaultOption.targetClass, true) : '-'}</span>
            </p>
          </div>
        </div>

        {/* Student Table with Custom Individual Decisions */}
        <div className="space-y-3 pt-2 border-t border-slate-100">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <h3 className="font-black text-slate-900 text-xs uppercase tracking-wider flex items-center gap-2">
                <Users size={16} className="text-indigo-600" />
                <span>Daftar Siswa {formatClassLabel(selectedClass, true)} ({classStudents.length} Siswa)</span>
              </h3>
              <p className="text-[11px] text-slate-500 font-medium">
                Pilih keputusan promosi individual untuk setiap peserta didik di bawah:
              </p>
            </div>

            {/* Quick Bulk Set */}
            {classStudents.length > 0 && (
              <div className="flex items-center gap-2 bg-slate-50 px-3 py-1.5 rounded-xl border border-slate-200 text-xs">
                <span className="text-[11px] font-bold text-slate-600 whitespace-nowrap">Set Semua:</span>
                <select
                  onChange={(e) => handleApplyToAll(e.target.value)}
                  defaultValue=""
                  className="bg-white px-2.5 py-1 rounded-lg border border-slate-200 text-xs font-bold text-indigo-700 focus:outline-none"
                >
                  <option value="" disabled>Pilih Keputusan Massal...</option>
                  {classPromotionOptions.map(opt => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                  ))}
                </select>
              </div>
            )}
          </div>

          <div className="bg-slate-50/50 rounded-2xl border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto max-h-[380px]">
              <table className="w-full text-left text-xs border-collapse">
                <thead className="bg-slate-100/90 sticky top-0 z-10 text-slate-600 uppercase font-black text-[10px] tracking-wider border-b border-slate-200">
                  <tr>
                    <th className="p-3 pl-4 text-center w-12">No</th>
                    <th className="p-3">NIS / NISN</th>
                    <th className="p-3">Nama Lengkap Peserta Didik</th>
                    <th className="p-3 text-center">L/P</th>
                    <th className="p-3 text-center">Keputusan Kenaikan / Status</th>
                    <th className="p-3 pr-4 text-center">Hasil Akhir</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200/60 font-medium text-slate-700 bg-white">
                  {classStudents.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="p-10 text-center text-slate-400">
                        Tidak ada siswa terdaftar di Kelas {selectedClass}.
                      </td>
                    </tr>
                  ) : (
                    classStudents.map((s, idx) => {
                      const decision = individualDecisions[s.id] || defaultOption;
                      return (
                        <tr key={s.id} className="hover:bg-slate-50 transition">
                          <td className="p-3 pl-4 text-center font-mono font-bold text-slate-400">{idx + 1}</td>
                          <td className="p-3 font-mono text-slate-600">
                            <div>{s.nis || '-'}</div>
                            <div className="text-[10px] text-slate-400">{s.nisn || '-'}</div>
                          </td>
                          <td className="p-3 font-bold text-slate-900">{s.name}</td>
                          <td className="p-3 text-center">
                            <span className={`px-2 py-0.5 rounded-md font-bold text-[10px] ${
                              s.gender === 'L' ? 'bg-blue-50 text-blue-700' : 'bg-pink-50 text-pink-700'
                            }`}>
                              {s.gender || 'L'}
                            </span>
                          </td>
                          <td className="p-3 text-center">
                            <select
                              value={decision.value}
                              onChange={(e) => handleDecisionChange(s.id, e.target.value)}
                              className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl font-bold text-xs focus:ring-2 focus:ring-indigo-500 focus:outline-none cursor-pointer"
                            >
                              {classPromotionOptions.map(opt => (
                                <option key={opt.value} value={opt.value}>
                                  {opt.label}
                                </option>
                              ))}
                            </select>
                          </td>
                          <td className="p-3 pr-4 text-center">
                            <span className={`px-3 py-1 rounded-xl font-bold text-xs inline-block ${
                              decision.action === 'Naik' ? 'bg-indigo-50 text-indigo-700 border border-indigo-200' :
                              decision.action === 'Lulus' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                              decision.action === 'Tinggal' ? 'bg-amber-50 text-amber-700 border border-amber-200' :
                              decision.action === 'Pindah' ? 'bg-purple-50 text-purple-700 border border-purple-200' :
                              'bg-rose-50 text-rose-700 border border-rose-200'
                            }`}>
                              {decision.action === 'Naik' || decision.action === 'Tinggal' ? `Kelas ${decision.targetClass}` : decision.targetClass}
                            </span>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* Warning Callout */}
        <div className="flex items-start gap-3 p-4 bg-amber-50 rounded-2xl border border-amber-200 text-xs">
          <AlertCircle className="text-amber-600 flex-shrink-0 mt-0.5" size={18} />
          <div>
            <h4 className="font-bold text-amber-900">Peringatan Eksekusi Database:</h4>
            <p className="text-amber-800 mt-0.5 leading-relaxed">
              Setelah tombol dieksekusi, sistem akan langsung memperbarui kolom <strong>Kelas</strong> dan <strong>Status</strong> pada data induk siswa.
            </p>
          </div>
        </div>

        {/* Action Button */}
        <div className="pt-2 flex justify-end">
          <button 
            onClick={handleExecutePromotion}
            disabled={classStudents.length === 0 || isProcessing}
            className="w-full sm:w-auto px-8 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-black rounded-2xl text-xs shadow-md shadow-indigo-200 transition active:scale-95 disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
          >
            {isProcessing ? (
              <>
                <RefreshCw size={16} className="animate-spin" />
                <span>Memperbarui Database Siswa...</span>
              </>
            ) : (
              <>
                <CheckCircle2 size={16} />
                <span>Eksekusi Kenaikan Kelas ({classStudents.length} Siswa)</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
