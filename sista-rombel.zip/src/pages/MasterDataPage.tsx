import React, { useState, useMemo } from 'react';
import { useStore } from '../store';
import { Student } from '../types';
import { db } from '../data/db';
import { 
  Database, Users, GraduationCap, HeartHandshake, Heart, School, BookOpen, 
  Calendar, CalendarOff, DollarSign, Package, CheckCircle2, ShieldCheck, 
  Search, Plus, RefreshCw, Filter, Download, FolderOpen, FileText,
  Phone, MapPin, CheckCircle, AlertCircle, MessageCircle, ExternalLink,
  ChevronRight, X, Clock, Layers, Eye, Edit, Trash2, Save, AlertTriangle, UserCheck,
  FileSpreadsheet, Sparkles, Printer, Info, Check, ShieldAlert, UserPlus
} from 'lucide-react';
import StudentsList, { getStudentStatusYatim, getYatimStatusInfo } from './StudentsList';
import BerkasSiswaPage from './BerkasSiswaPage';
import TeachersList from './TeachersList';
import { exportToExcel, exportOrangTuaMasterToExcel, exportYatimPiatuToExcel } from '../lib/excel';
import { fetchFromGAS } from '../lib/api';
import { SEED_MAPEL, SEED_TAHUN_AJARAN, SEED_SEMESTER, SEED_HARI_LIBUR, SEED_TARIF_BIAYA } from '../data/seedMasterData';

/**
 * Format alamat domisili lengkap menggabungkan Jalan/Dusun, RT, RW, Kelurahan, Kecamatan, Kota/Kabupaten
 */
export function formatFullAddress(student: Partial<Student> | any): string {
  if (!student) return '-';
  const parts: string[] = [];

  const mainAddress = String(student.address || student.alamat || student.alamatDomisili || '').trim();
  if (mainAddress && mainAddress !== '-' && mainAddress !== 'null' && mainAddress !== 'undefined') {
    parts.push(mainAddress);
  }

  const rt = String(student.rt || student.RT || '').trim();
  const rw = String(student.rw || student.RW || '').trim();
  if (rt && rw && rt !== '-' && rw !== '-') {
    parts.push(`RT ${rt}/RW ${rw}`);
  } else if (rt && rt !== '-') {
    parts.push(`RT ${rt}`);
  } else if (rw && rw !== '-') {
    parts.push(`RW ${rw}`);
  }

  const kel = String(student.kelurahan || student.desa || student.Kelurahan || '').trim();
  if (kel && kel !== '-' && kel !== 'null') {
    parts.push(kel.toLowerCase().startsWith('kel') || kel.toLowerCase().startsWith('desa') ? kel : `Kel. ${kel}`);
  }

  const kec = String(student.kecamatan || student.Kecamatan || '').trim();
  if (kec && kec !== '-' && kec !== 'null') {
    parts.push(kec.toLowerCase().startsWith('kec') ? kec : `Kec. ${kec}`);
  }

  const kota = String(student.kota || student.kabupaten || student.Kota || student.Kabupaten || '').trim();
  if (kota && kota !== '-' && kota !== 'null') {
    parts.push(kota);
  }

  const kodePos = String(student.kodePos || student.KodePos || '').trim();
  if (kodePos && kodePos !== '-' && kodePos !== 'null') {
    parts.push(kodePos);
  }

  return parts.length > 0 ? parts.join(', ') : (mainAddress || '-');
}

interface MasterDataPageProps {
  initialSubTab?: string;
}

export default function MasterDataPage({ initialSubTab = 'dashboard' }: MasterDataPageProps) {
  const [activeSubTab, setActiveSubTab] = useState(initialSubTab);
  const { students, updateStudent, deleteStudent, teachers, settings } = useStore();

  // Smart Filter States for Subtabs
  const [searchQuery, setSearchQuery] = useState('');
  const [filterClass, setFilterClass] = useState('');
  const [filterTahunMasuk, setFilterTahunMasuk] = useState('');
  const [filterCategory, setFilterCategory] = useState('');

  // Parent and Yatim specific states
  const [parentRelationFilter, setParentRelationFilter] = useState<'all' | 'ayah' | 'ibu' | 'wali'>('all');
  const [filterStatusYatim, setFilterStatusYatim] = useState<string>('all');
  const [syncFeedback, setSyncFeedback] = useState<string | null>(null);
  const [isSyncingGAS, setIsSyncingGAS] = useState(false);

  // Universal Modals State
  const [viewDetailModal, setViewDetailModal] = useState<{ open: boolean; title: string; data: Record<string, any>; type: string } | null>(null);
  const [editModal, setEditModal] = useState<{ open: boolean; title: string; data: Record<string, any>; type: string } | null>(null);
  const [deleteModal, setDeleteModal] = useState<{ open: boolean; title: string; id: string; name: string; type: string } | null>(null);

  const subTabs = [
    { id: 'dashboard', label: 'Dashboard Master', icon: Database },
    { id: 'siswa', label: 'Data Siswa', icon: Users },
    { id: 'berkas-siswa', label: 'Berkas Dokumen Siswa', icon: FolderOpen },
    { id: 'guru', label: 'Data Guru', icon: GraduationCap },
    { id: 'orangtua', label: 'Orang Tua & Wali', icon: HeartHandshake },
    { id: 'yatim-piatu', label: 'Data Yatim & Piatu', icon: Heart },
    { id: 'kelas-wali', label: 'Kelas & Wali', icon: School },
    { id: 'mapel', label: 'Mata Pelajaran', icon: BookOpen },
    { id: 'tahun-ajaran', label: 'Tahun Ajaran', icon: Calendar },
    { id: 'semester', label: 'Semester', icon: Clock },
    { id: 'hari-libur', label: 'Hari Libur & Kalender', icon: CalendarOff },
    { id: 'tarif-biaya', label: 'Tarif & Pos Biaya', icon: DollarSign },
    { id: 'dapodik-2027', label: 'Validasi Dapodik 2027', icon: CheckCircle2 },
  ];

  const handleSubTabChange = (tabId: string) => {
    setActiveSubTab(tabId);
    setSearchQuery('');
    setFilterClass('');
    setFilterTahunMasuk('');
    setFilterCategory('');
    // Focus and scroll to top of page/container
    window.scrollTo({ top: 0, behavior: 'instant' });
    const scrollContainer = document.querySelector('.overflow-y-auto');
    if (scrollContainer) {
      scrollContainer.scrollTo({ top: 0, behavior: 'instant' });
    }
  };

  // Master Data Collections - Clean empty initial state
  const [masterMapelList, setMasterMapelList] = useState<any[]>(() => {
    return (db.get('mapel') as any[]) || [];
  });

  const [masterLiburList, setMasterLiburList] = useState<any[]>(() => {
    return (db.get('hari_libur') as any[]) || [];
  });

  const [masterClassesList, setMasterClassesList] = useState<any[]>(() => {
    const fromDb = db.get('rombel') as any[];
    if (Array.isArray(fromDb) && fromDb.length > 0) {
      return fromDb.map(item => ({
        ...item,
        kelasId: item.kelasId || item.id || `KLS_${item.cls || '1'}`,
        namaKelas: item.namaKelas || item.cls || item.cls,
        jenjangId: item.jenjangId || 'J001',
        tingkat: item.tingkat || `Kelas ${item.cls || ''}`,
        waliKelasId: item.waliKelasId || 'GR_001',
        namatutor: item.namatutor || item.namaTutor || item.wali || 'Belum Ditentukan',
        wali: item.wali || item.namatutor || item.namaTutor || 'Belum Ditentukan',
        ruangan: item.ruangan || '1',
        status: item.status || 'AKTIF',
        kapasitas: Number(item.kapasitas) || 32
      }));
    }
    return [];
  });

  const [masterTahunList, setMasterTahunList] = useState<any[]>(() => {
    const fromDb = db.get('tahun_ajaran') as any[];
    if (Array.isArray(fromDb) && fromDb.length > 0) {
      return fromDb.map(item => ({
        ...item,
        semester: item.semester || 'Semester Ganjil & Genap',
        rentang: item.rentang || item.rentangWaktu || item.periode || (item.tanggalMulai && item.tanggalSelesai ? `${item.tanggalMulai} s/d ${item.tanggalSelesai}` : (item.tahun ? `Juli ${item.tahun.split('/')[0]} - Juni ${item.tahun.split('/')[1]}` : 'Juli - Juni')),
        kurikulum: item.kurikulum || 'Kurikulum Merdeka',
        status: item.status || 'Aktif'
      }));
    }
    return [];
  });

  const [masterSemesterList, setMasterSemesterList] = useState<any[]>(() => {
    return (db.get('semester') as any[]) || [];
  });

  // Distinct classes
  const distinctClasses = useMemo(() => {
    const set = new Set<string>();
    masterClassesList.forEach(c => { if (c.cls) set.add(c.cls); });
    students.forEach(s => { if (s.class) set.add(s.class); });
    return Array.from(set).sort();
  }, [students, masterClassesList]);

  // Distinct Tahun Masuk
  const distinctTahunMasuk = useMemo(() => {
    const set = new Set<string>();
    students.forEach((s: any) => {
      const yr = String(s.tahunMasuk || s['TahunMasuk'] || s['ThnMasuk'] || s['tahun_masuk'] || '').trim();
      if (yr && yr !== '-' && yr !== 'null' && yr !== 'undefined') {
        const match = yr.match(/\b(20\d{2}|19\d{2})\b/);
        if (match) set.add(match[1]);
        else set.add(yr);
      }
    });
    return Array.from(set).sort((a, b) => b.localeCompare(a));
  }, [students]);

  const [masterTarifList, setMasterTarifList] = useState<any[]>(() => {
    return (db.get('tarif') as any[]) || [];
  });

  const [masterBarangList, setMasterBarangList] = useState<any[]>(() => {
    return (db.get('barang') as any[]) || [];
  });

  // State for universal Add Modal
  const [addModal, setAddModal] = useState<{
    open: boolean;
    title: string;
    type: 'kelas' | 'mapel' | 'tahun' | 'semester' | 'libur' | 'tarif' | 'barang';
    data: Record<string, any>;
  } | null>(null);

  // Derived filtered data for Parent/Orang Tua
  const allParentRecords = useMemo(() => {
    const records: Array<{
      id: string;
      studentId: string;
      studentName: string;
      studentNis: string;
      studentNisn: string;
      studentClass: string;
      parentName: string;
      relation: string;
      relationType: 'ayah' | 'ibu' | 'wali';
      statusKondisi: string;
      nik: string;
      job: string;
      income: string;
      phone: string;
      address: string;
      student: typeof students[0];
    }> = [];

    students.forEach((s) => {
      const studentName = s.name || '-';
      const studentClass = s.class || '-';
      const studentNis = s.nis || s.id || '-';
      const studentNisn = s.nisn || '-';
      const address = formatFullAddress(s);

      const ayahName = s.namaAyah || (s as any).fatherName || '';
      const ibuName = s.namaIbu || (s as any).NamaIbu || '';
      const waliName = s.namaWali || '';

      // 1. Ayah
      if (ayahName) {
        records.push({
          id: `${s.id}-ayah`,
          studentId: s.id,
          studentName,
          studentNis,
          studentNisn,
          studentClass,
          parentName: ayahName,
          relation: 'Ayah Kandung',
          relationType: 'ayah',
          statusKondisi: s.statusAyah || 'Masih Hidup',
          nik: s.nikAyah || '-',
          job: s.pekerjaanAyah || (s as any).fatherJob || '-',
          income: s.penghasilanAyah || '-',
          phone: s.tlpAyah || s.parentPhone || s.phone || s.noHp || '',
          address,
          student: s
        });
      }

      // 2. Ibu
      if (ibuName) {
        records.push({
          id: `${s.id}-ibu`,
          studentId: s.id,
          studentName,
          studentNis,
          studentNisn,
          studentClass,
          parentName: ibuName,
          relation: 'Ibu Kandung',
          relationType: 'ibu',
          statusKondisi: s.statusIbu || 'Masih Hidup',
          nik: s.nikIbu || '-',
          job: s.pekerjaanIbu || (s as any).motherJob || '-',
          income: s.penghasilanIbu || '-',
          phone: s.tlpIbu || s.parentPhone || s.phone || s.noHp || '',
          address,
          student: s
        });
      }

      // 3. Wali
      if (waliName && waliName !== ayahName && waliName !== ibuName) {
        records.push({
          id: `${s.id}-wali`,
          studentId: s.id,
          studentName,
          studentNis,
          studentNisn,
          studentClass,
          parentName: waliName,
          relation: s.hubunganWali || 'Wali Murid',
          relationType: 'wali',
          statusKondisi: 'Masih Hidup',
          nik: '-',
          job: s.pekerjaanWali || '-',
          income: s.penghasilanWali || '-',
          phone: s.tlpWali || s.parentPhone || s.phone || s.noHp || '',
          address,
          student: s
        });
      }

      // Fallback parent record if neither ayah, ibu, nor wali is explicitly named
      if (!ayahName && !ibuName && !waliName) {
        const genericParent = s.parentName || 'Orang Tua Siswa';
        records.push({
          id: `${s.id}-ortu`,
          studentId: s.id,
          studentName,
          studentNis,
          studentNisn,
          studentClass,
          parentName: genericParent,
          relation: 'Orang Tua / Wali',
          relationType: 'wali',
          statusKondisi: 'Masih Hidup',
          nik: '-',
          job: '-',
          income: '-',
          phone: s.parentPhone || s.phone || s.noHp || '',
          address,
          student: s
        });
      }
    });

    return records;
  }, [students]);

  const filteredParentRecords = useMemo(() => {
    return allParentRecords.filter(r => {
      const q = String(searchQuery || '').toLowerCase();
      const matchesQ = !searchQuery || 
        String(r.parentName || '').toLowerCase().includes(q) || 
        String(r.studentName || '').toLowerCase().includes(q) || 
        String(r.phone || '').toLowerCase().includes(q) || 
        String(r.job || '').toLowerCase().includes(q) || 
        String(r.address || '').toLowerCase().includes(q);
      const matchesClass = !filterClass || r.studentClass === filterClass;
      const matchesRelation = parentRelationFilter === 'all' || r.relationType === parentRelationFilter;
      return matchesQ && matchesClass && matchesRelation;
    });
  }, [allParentRecords, searchQuery, filterClass, parentRelationFilter]);

  // Derived filtered data for Yatim, Piatu & Yatim Piatu
  const filteredYatimPiatu = useMemo(() => {
    return students.map(s => {
      const statusYatim = getStudentStatusYatim(s);
      const isKps = s.penerimaKps === 'Ya' || !!s.kipUrl || !!s.noKip;
      return {
        ...s,
        computedStatusYatim: statusYatim,
        isKps
      };
    }).filter(s => {
      const q = String(searchQuery || '').toLowerCase();
      const sPhone = s.parentPhone || s.tlpAyah || s.tlpIbu || s.tlpWali || s.noHp || s.phone || '';
      const matchesQ = !searchQuery || 
        String(s.name || '').toLowerCase().includes(q) || 
        String(s.nisn || '').toLowerCase().includes(q) || 
        String(s.nis || '').toLowerCase().includes(q) || 
        (s.namaAyah && String(s.namaAyah).toLowerCase().includes(q)) || 
        (s.namaIbu && String(s.namaIbu).toLowerCase().includes(q)) || 
        (s.namaWali && String(s.namaWali).toLowerCase().includes(q)) || 
        (sPhone && String(sPhone).toLowerCase().includes(q));
      
      const matchesClass = !filterClass || s.class === filterClass;
      
      let matchesYatim = true;
      if (filterStatusYatim === 'kps') {
        matchesYatim = s.isKps;
      } else if (filterStatusYatim !== 'all') {
        matchesYatim = s.computedStatusYatim === filterStatusYatim;
      }

      return matchesQ && matchesClass && matchesYatim;
    });
  }, [students, searchQuery, filterClass, filterStatusYatim]);

  // Statistics for Yatim / Piatu
  const yatimStats = useMemo(() => {
    let yatimPiatu = 0;
    let yatim = 0;
    let piatu = 0;
    let lengkap = 0;
    let penerimaKps = 0;

    students.forEach(s => {
      const st = getStudentStatusYatim(s);
      if (st === 'Yatim Piatu') yatimPiatu++;
      else if (st === 'Yatim') yatim++;
      else if (st === 'Piatu') piatu++;
      else lengkap++;

      if (s.penerimaKps === 'Ya' || s.kipUrl || s.noKip) {
        penerimaKps++;
      }
    });

    return {
      total: students.length,
      yatimPiatu,
      yatim,
      piatu,
      lengkap,
      penerimaKps
    };
  }, [students]);

  // Statistics for Parents
  const parentStats = useMemo(() => {
    const total = allParentRecords.length;
    const ayahCount = allParentRecords.filter(r => r.relationType === 'ayah').length;
    const ibuCount = allParentRecords.filter(r => r.relationType === 'ibu').length;
    const waliCount = allParentRecords.filter(r => r.relationType === 'wali').length;
    const withPhoneCount = allParentRecords.filter(r => !!r.phone).length;

    return {
      total,
      ayahCount,
      ibuCount,
      waliCount,
      withPhoneCount
    };
  }, [allParentRecords]);

  // Keep compatibility for legacy filteredParents
  const filteredParents = useMemo(() => {
    return students.filter(s => {
      const q = searchQuery.toLowerCase();
      const parentName = (s.parentName || s.fatherName || s.namaAyah || s.namaIbu || s.NamaIbu || '').toLowerCase();
      const studentName = (s.name || '').toLowerCase();
      const phone = (s.parentPhone || s.phone || s.tlpAyah || s.tlpIbu || '').toLowerCase();
      const address = (s.address || '').toLowerCase();
      const matchesQuery = !searchQuery || parentName.includes(q) || studentName.includes(q) || phone.includes(q) || address.includes(q);
      const matchesClass = !filterClass || s.class === filterClass;
      return matchesQuery && matchesClass;
    });
  }, [students, searchQuery, filterClass]);

  const filteredMapel = useMemo(() => {
    return masterMapelList.filter(m => {
      const q = searchQuery.toLowerCase();
      const matchesQ = !searchQuery || String(m.nama || '').toLowerCase().includes(q) || String(m.kode || '').toLowerCase().includes(q) || (m.guru && String(m.guru).toLowerCase().includes(q));
      const matchesCat = !filterCategory || m.kategori === filterCategory;
      const matchesClass = !filterClass || (m.kelas && (m.kelas === 'Semua Kelas' || m.kelas.includes(filterClass)));
      return matchesQ && matchesCat && matchesClass;
    });
  }, [masterMapelList, searchQuery, filterCategory, filterClass]);

  const filteredTahun = useMemo(() => {
    return masterTahunList.filter(t => {
      const q = searchQuery.toLowerCase();
      const matchesQ = !searchQuery || String(t.tahun || '').toLowerCase().includes(q) || String(t.semester || '').toLowerCase().includes(q) || String(t.kurikulum || '').toLowerCase().includes(q);
      const matchesStatus = !filterCategory || t.status === filterCategory;
      return matchesQ && matchesStatus;
    });
  }, [masterTahunList, searchQuery, filterCategory]);

  const filteredSemester = useMemo(() => {
    return masterSemesterList.filter(s => {
      const q = searchQuery.toLowerCase();
      const matchesQ = !searchQuery || String(s.nama || s.semester || '').toLowerCase().includes(q) || String(s.tahunAjaran || s.tahun || '').toLowerCase().includes(q) || String(s.id || s.semesterId || '').toLowerCase().includes(q);
      const matchesStatus = !filterCategory || s.status === filterCategory || (filterCategory === 'Aktif' && (s.status === 'Aktif' || s.aktif === true || s.aktif === 'true' || s.aktif === 'Aktif'));
      return matchesQ && matchesStatus;
    });
  }, [masterSemesterList, searchQuery, filterCategory]);

  const filteredLibur = useMemo(() => {
    return masterLiburList.filter(l => {
      const q = searchQuery.toLowerCase();
      const matchesQ = !searchQuery || String(l.agenda || '').toLowerCase().includes(q) || String(l.tanggal || '').toLowerCase().includes(q) || (l.keterangan && String(l.keterangan).toLowerCase().includes(q));
      const matchesType = !filterCategory || l.jenis === filterCategory;
      return matchesQ && matchesType;
    });
  }, [masterLiburList, searchQuery, filterCategory]);

  const filteredTarif = useMemo(() => {
    return masterTarifList.filter(t => {
      const q = searchQuery.toLowerCase();
      const matchesQ = !searchQuery || String(t.namaPos || '').toLowerCase().includes(q) || String(t.kode || '').toLowerCase().includes(q);
      const matchesFreq = !filterCategory || t.frekuensi.includes(filterCategory);
      const matchesClass = !filterClass || (t.kelas && (t.kelas === 'Semua Kelas' || t.kelas.includes(filterClass)));
      return matchesQ && matchesFreq && matchesClass;
    });
  }, [masterTarifList, searchQuery, filterCategory, filterClass]);

  const filteredBarang = useMemo(() => {
    return masterBarangList.filter(b => {
      const q = searchQuery.toLowerCase();
      const matchesQ = !searchQuery || String(b.nama || '').toLowerCase().includes(q) || String(b.kode || '').toLowerCase().includes(q) || String(b.lokasi || '').toLowerCase().includes(q);
      const matchesCat = !filterCategory || b.kategori === filterCategory || b.kondisi === filterCategory;
      return matchesQ && matchesCat;
    });
  }, [masterBarangList, searchQuery, filterCategory]);

  const filteredClasses = useMemo(() => {
    return masterClassesList.map(c => {
      const clsKey = String(c.cls || c.namaKelas || '').trim();
      const count = students.filter(s => {
        const sc = String(s.class || '').trim();
        return sc === clsKey || sc.toLowerCase() === clsKey.toLowerCase();
      }).length;
      const male = students.filter(s => {
        const sc = String(s.class || '').trim();
        return (sc === clsKey || sc.toLowerCase() === clsKey.toLowerCase()) && s.gender === 'L';
      }).length;
      const female = students.filter(s => {
        const sc = String(s.class || '').trim();
        return (sc === clsKey || sc.toLowerCase() === clsKey.toLowerCase()) && s.gender === 'P';
      }).length;
      return { ...c, count, male, female };
    }).filter(c => {
      const q = searchQuery.toLowerCase();
      return !searchQuery || 
        String(c.kelasId || '').toLowerCase().includes(q) ||
        String(c.cls || '').toLowerCase().includes(q) || 
        String(c.namaKelas || '').toLowerCase().includes(q) || 
        String(c.jenjangId || '').toLowerCase().includes(q) || 
        String(c.tingkat || '').toLowerCase().includes(q) || 
        String(c.waliKelasId || '').toLowerCase().includes(q) || 
        String(c.namatutor || '').toLowerCase().includes(q) || 
        String(c.wali || '').toLowerCase().includes(q) || 
        String(c.ruangan || '').toLowerCase().includes(q) || 
        String(c.status || '').toLowerCase().includes(q);
    });
  }, [masterClassesList, students, searchQuery]);

  // Rekapitulasi Siswa Per Jenjang Kelas (Paket A: 4-6, Paket B: 7-9, Paket C: 10-12)
  const rekapJenjang = useMemo(() => {
    const calc = (levels: string[]) => {
      const rows = levels.map(lvl => {
        const inLevel = students.filter(s => {
          const c = String(s.class || '').trim();
          return c === lvl || c.startsWith(lvl + ' ') || c.startsWith(lvl + '-') || c.startsWith(lvl);
        });
        const aktif = inLevel.filter(s => {
          const st = String(s.status || 'Aktif').toLowerCase().trim();
          return !st.includes('tidak') && st !== 'nonaktif' && st !== 'belum' && st !== 'pindah' && st !== 'lulus' && st !== 'keluar';
        }).length;
        const nonAktif = inLevel.length - aktif;
        return {
          kelas: `Kelas ${lvl}`,
          aktif,
          nonAktif,
          total: inLevel.length
        };
      });
      const totalSiswa = rows.reduce((a, b) => a + b.total, 0);
      return { rows, totalSiswa };
    };

    return {
      paketA: calc(['4', '5', '6']),
      paketB: calc(['7', '8', '9']),
      paketC: calc(['10', '11', '12']),
    };
  }, [students]);

  const filteredDapodik = useMemo(() => {
    return students.filter(s => {
      const q = String(searchQuery || '').toLowerCase();
      const matchQ = !searchQuery || String(s.name || '').toLowerCase().includes(q) || String(s.nisn || '').includes(q) || String(s.nik || '').includes(q) || String(s.tahunMasuk || '').includes(q);
      const matchC = !filterClass || s.class === filterClass;
      const rawYr = String(s.tahunMasuk || (s as any)['TahunMasuk'] || (s as any)['ThnMasuk'] || (s as any)['tahun_masuk'] || '').trim();
      const matchYr = rawYr.match(/\b(20\d{2}|19\d{2})\b/);
      const normalizedYr = matchYr ? matchYr[1] : rawYr;
      const matchT = !filterTahunMasuk || normalizedYr === filterTahunMasuk;
      return matchQ && matchC && matchT;
    });
  }, [students, searchQuery, filterClass, filterTahunMasuk]);

  // Auto-Sync and Master Sync Handlers for Orang Tua and Yatim Piatu
  const handleAutoSyncParents = async () => {
    let updatedStudentsCount = 0;
    const currentStudents = useStore.getState().students;
    const updatedList = currentStudents.map(s => {
      let needsUpdate = false;
      const updates: any = {};

      const bestParentName = s.parentName || s.namaAyah || (s as any).fatherName || s.namaIbu || (s as any).NamaIbu || s.namaWali;
      if (bestParentName && !s.parentName) {
        updates.parentName = bestParentName;
        needsUpdate = true;
      }

      const bestPhone = s.parentPhone || s.tlpAyah || s.tlpIbu || s.tlpWali || s.noHp || s.phone;
      if (bestPhone && !s.parentPhone) {
        updates.parentPhone = bestPhone;
        needsUpdate = true;
      }

      if (needsUpdate) {
        updatedStudentsCount++;
        return { ...s, ...updates, updatedAt: new Date().toISOString() };
      }
      return s;
    });

    if (updatedStudentsCount > 0) {
      useStore.getState().setStudents(updatedList);
    }

    if (settings.scriptUrl) {
      setIsSyncingGAS(true);
      try {
        await fetchFromGAS(settings.scriptUrl, {
          action: 'sync',
          data: updatedList,
          teachers: useStore.getState().teachers,
          spreadsheetId: settings.spreadsheetId
        });
        // Kirim data terformat lengkap ke tabel ORANG_TUA
        const ortuPayload = allParentRecords.map((r, idx) => ({
          OrtuID: r.id || `ORTU-${String(1001 + idx).slice(1)}`,
          SiswaID: r.studentId || r.studentNis || '-',
          Hubungan: r.relation || r.relationType || 'Orang Tua',
          Nama: r.parentName || '-',
          NIK: r.nik && r.nik !== '-' ? (r.nik.startsWith("'") ? r.nik : `'${r.nik}`) : '-',
          Pekerjaan: r.job && r.job !== '-' ? r.job : '-',
          NoHP: r.phone && r.phone !== '-' ? (r.phone.startsWith("'") ? r.phone : `'${r.phone}`) : '-',
          Alamat: r.address || '-'
        }));
        await fetchFromGAS(settings.scriptUrl, {
          action: 'syncTable',
          table: 'ORANG_TUA',
          data: ortuPayload,
          spreadsheetId: settings.spreadsheetId
        });
        await fetchFromGAS(settings.scriptUrl, {
          action: 'AUTO_POPULATE_ORTU_YATIM',
          spreadsheetId: settings.spreadsheetId
        });
        setSyncFeedback(`✅ Berhasil menyinkronkan data Orang Tua & Wali (${allParentRecords.length} data) ke Google Sheets!`);
      } catch (err: any) {
        setSyncFeedback(`⚠️ Data orang tua lokal diperbarui, namun sync GAS tertunda: ${err?.message || ''}`);
      } finally {
        setIsSyncingGAS(false);
      }
    } else {
      setSyncFeedback(`✅ Berhasil menyinkronkan data Orang Tua & Wali! Total ${allParentRecords.length} entitas orang tua terpetakan secara otomatis.`);
    }
    setTimeout(() => setSyncFeedback(null), 6000);
  };

  const handleAutoSyncYatim = async () => {
    let updatedCount = 0;
    const currentStudents = useStore.getState().students;
    const updatedList = currentStudents.map(s => {
      const computed = getStudentStatusYatim(s);
      const current = s.statusYatim || (s as any)['StatusYatim'];
      if (current !== computed) {
        updatedCount++;
        return { ...s, statusYatim: computed, updatedAt: new Date().toISOString() };
      }
      return s;
    });

    if (updatedCount > 0) {
      useStore.getState().setStudents(updatedList);
    }

    if (settings.scriptUrl) {
      setIsSyncingGAS(true);
      try {
        await fetchFromGAS(settings.scriptUrl, {
          action: 'sync',
          data: updatedList,
          teachers: useStore.getState().teachers,
          spreadsheetId: settings.spreadsheetId
        });
        // Kirim langsung data yatim ke tabel YATIM_PIATU via syncTable
        const yatimPayload = updatedList.map((s, idx) => ({
          YatimID: `YTM-${String(1001 + idx).slice(1)}`,
          NoPDKT: (s.id || s.nis) ? `'${s.id || s.nis}` : `SISWA-${idx + 1}`,
          NISN: s.nisn ? (s.nisn.startsWith("'") ? s.nisn : `'${s.nisn}`) : '-',
          NamaSiswa: s.name,
          Kelas: s.class || '-',
          StatusYatim: s.statusYatim || getStudentStatusYatim(s),
          NamaAyah: s.namaAyah || (s as any).fatherName || s.parentName || '-',
          StatusAyah: s.statusAyah || ((s.statusYatim === 'Yatim' || s.statusYatim === 'Yatim Piatu') ? 'Meninggal Dunia' : 'Masih Hidup'),
          NamaIbu: s.namaIbu || (s as any).NamaIbu || '-',
          StatusIbu: s.statusIbu || ((s.statusYatim === 'Piatu' || s.statusYatim === 'Yatim Piatu') ? 'Meninggal Dunia' : 'Masih Hidup'),
          NamaWali: s.namaWali || '-',
          NoHPWali: (s.tlpWali || s.parentPhone || s.phone) ? `'${s.tlpWali || s.parentPhone || s.phone}` : '-',
          Alamat: formatFullAddress(s),
          PenerimaKPS_PIP: (s.penerimaKps === 'Ya' || s.kipUrl || s.noKip) ? 'Ya' : 'Tidak',
          Keterangan: 'Sinkronisasi dari Master Siswa',
          CreatedAt: new Date().toISOString(),
          UpdatedAt: new Date().toISOString()
        }));

        await fetchFromGAS(settings.scriptUrl, {
          action: 'syncTable',
          table: 'YATIM_PIATU',
          data: yatimPayload,
          spreadsheetId: settings.spreadsheetId
        });
        await fetchFromGAS(settings.scriptUrl, {
          action: 'AUTO_POPULATE_ORTU_YATIM',
          spreadsheetId: settings.spreadsheetId
        });
        setSyncFeedback(`✅ Berhasil menyinkronkan status Yatim/Piatu ke Google Sheets (Sheet SISWA & YATIM_PIATU)! (${updatedCount} data diselaraskan)`);
      } catch (err: any) {
        setSyncFeedback(`⚠️ Status lokal diperbarui (${updatedCount} data), namun sync GAS tertunda: ${err?.message || ''}`);
      } finally {
        setIsSyncingGAS(false);
      }
    } else {
      setSyncFeedback(`✅ Berhasil menyinkronkan status Yatim/Piatu (${updatedCount > 0 ? `${updatedCount} data diselaraskan.` : 'Semua data siswa sudah akurat.'})`);
    }
    setTimeout(() => setSyncFeedback(null), 6000);
  };

  const handleSyncGasBackend = async () => {
    if (!settings.scriptUrl) {
      alert("URL Google Apps Script belum dikonfigurasi di menu Pengaturan. Sinkronisasi lokal telah selesai.");
      return;
    }

    setIsSyncingGAS(true);
    try {
      // 1. Sync siswa dulu
      await fetchFromGAS(settings.scriptUrl, {
        action: 'sync',
        data: students,
        teachers: useStore.getState().teachers,
        spreadsheetId: settings.spreadsheetId
      });

      // 2. Sync langsung tabel ORANG_TUA
      const ortuPayload = allParentRecords.map((r, idx) => ({
        OrtuID: r.id || `ORTU-${String(1001 + idx).slice(1)}`,
        SiswaID: r.studentId || r.studentNis || '-',
        Hubungan: r.relation || r.relationType || 'Orang Tua',
        Nama: r.parentName || '-',
        NIK: r.nik && r.nik !== '-' ? (r.nik.startsWith("'") ? r.nik : `'${r.nik}`) : '-',
        Pekerjaan: r.job && r.job !== '-' ? r.job : '-',
        NoHP: r.phone && r.phone !== '-' ? (r.phone.startsWith("'") ? r.phone : `'${r.phone}`) : '-',
        Alamat: r.address || '-'
      }));

      await fetchFromGAS(settings.scriptUrl, {
        action: 'syncTable',
        table: 'ORANG_TUA',
        data: ortuPayload,
        spreadsheetId: settings.spreadsheetId
      });

      // 3. Sync langsung tabel YATIM_PIATU
      const yatimPayload = students.map((s, idx) => ({
        YatimID: `YTM-${String(1001 + idx).slice(1)}`,
        NoPDKT: s.id || s.nis || `SISWA-${idx + 1}`,
        NISN: s.nisn ? (s.nisn.startsWith("'") ? s.nisn : `'${s.nisn}`) : '-',
        NamaSiswa: s.name,
        Kelas: s.class || '-',
        StatusYatim: s.statusYatim || getStudentStatusYatim(s),
        NamaAyah: s.namaAyah || (s as any).fatherName || s.parentName || '-',
        StatusAyah: s.statusAyah || ((s.statusYatim === 'Yatim' || s.statusYatim === 'Yatim Piatu') ? 'Meninggal Dunia' : 'Masih Hidup'),
        NamaIbu: s.namaIbu || (s as any).NamaIbu || '-',
        StatusIbu: s.statusIbu || ((s.statusYatim === 'Piatu' || s.statusYatim === 'Yatim Piatu') ? 'Meninggal Dunia' : 'Masih Hidup'),
        NamaWali: s.namaWali || '-',
        NoHPWali: (s.tlpWali || s.parentPhone || s.phone) ? `'${s.tlpWali || s.parentPhone || s.phone}` : '-',
        Alamat: formatFullAddress(s),
        PenerimaKPS_PIP: (s.penerimaKps === 'Ya' || s.kipUrl || s.noKip) ? 'Ya' : 'Tidak',
        Keterangan: 'Sinkronisasi dari Master Siswa',
        CreatedAt: new Date().toISOString(),
        UpdatedAt: new Date().toISOString()
      }));

      await fetchFromGAS(settings.scriptUrl, {
        action: 'syncTable',
        table: 'YATIM_PIATU',
        data: yatimPayload,
        spreadsheetId: settings.spreadsheetId
      });

      // 4. Panggil auto-populate GAS sebagai pelengkap
      const res = await fetchFromGAS(settings.scriptUrl, {
        action: 'AUTO_POPULATE_ORTU_YATIM',
        spreadsheetId: settings.spreadsheetId
      });

      setSyncFeedback(`⚡ Sukses Sinkronisasi Spreadsheet! Sheet ORANG_TUA (${allParentRecords.length} data) dan YATIM_PIATU (${students.length} data) berhasil ditulis langsung ke Google Sheets.`);
    } catch (err: any) {
      console.warn("GAS sync notice:", err);
      setSyncFeedback("⚠️ Sinkronisasi lokal sukses. Untuk sinkronisasi Google Spreadsheet, pastikan Web App GAS telah di-deploy dengan versi terbaru.");
    } finally {
      setIsSyncingGAS(false);
      setTimeout(() => setSyncFeedback(null), 8000);
    }
  };

  // Export Excel Handlers for Master Data
  const handleExportOrangTuaExcel = () => {
    if (allParentRecords.length === 0) {
      alert("Tidak ada data orang tua untuk diekspor.");
      return;
    }
    exportOrangTuaMasterToExcel(students);
  };

  const handleExportYatimExcel = () => {
    if (students.length === 0) {
      alert("Tidak ada data siswa untuk diekspor.");
      return;
    }
    exportYatimPiatuToExcel(students);
  };

  const handlePrintYatimReport = () => {
    window.print();
  };

  const handleExportKelasExcel = () => {
    if (filteredClasses.length === 0) {
      alert("Tidak ada data kelas untuk diekspor.");
      return;
    }
    const rows = filteredClasses.map((item, idx) => ({
      No: idx + 1,
      'Kelas ID': item.kelasId || item.cls,
      'Nama Kelas': item.namaKelas || item.cls,
      'Jenjang ID': item.jenjangId || 'J001',
      'Tingkat / Rombel': item.tingkat || `Kelas ${item.cls}`,
      'Wali Kelas ID': item.waliKelasId || '-',
      'Nama Tutor / Wali': item.namatutor || item.wali || '-',
      'Ruang Belajar': item.ruangan || '-',
      'Status': item.status || 'AKTIF',
      'Siswa Laki-laki': item.male || 0,
      'Siswa Perempuan': item.female || 0,
      'Total Siswa': item.count || 0,
      'Kapasitas Maksimal': item.kapasitas || 32
    }));
    exportToExcel(rows, `Data_Kelas_dan_Wali_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  const handleSyncKelasGAS = async () => {
    if (!settings.scriptUrl) {
      alert("Script URL Google Apps Script belum diatur di menu Pengaturan!");
      return;
    }
    setIsSyncingGAS(true);
    try {
      const kelasPayload = masterClassesList.map(c => ({
        KelasID: c.kelasId || c.id || c.cls,
        NamaKelas: c.namaKelas || c.cls,
        JenjangID: c.jenjangId || 'J001',
        Tingkat: c.tingkat || `Kelas ${c.cls}`,
        WaliKelasID: c.waliKelasId || '-',
        NamaTutor: c.namatutor || c.wali || '-',
        Ruangan: c.ruangan || '1',
        Status: c.status || 'AKTIF'
      }));

      await fetchFromGAS(settings.scriptUrl, {
        action: 'syncTable',
        table: 'KELAS',
        data: kelasPayload,
        spreadsheetId: settings.spreadsheetId
      });

      setSyncFeedback(`⚡ Sukses Sinkronisasi! Sheet KELAS (${kelasPayload.length} rombel & wali kelas) berhasil ditulis ke Google Sheets.`);
    } catch (err: any) {
      console.warn("GAS sync notice:", err);
      setSyncFeedback(`⚠️ Sinkronisasi lokal sukses. Untuk sinkronisasi Google Spreadsheet, pastikan Web App GAS telah di-deploy.`);
    } finally {
      setIsSyncingGAS(false);
      setTimeout(() => setSyncFeedback(null), 8000);
    }
  };

  const handleExportMapelExcel = () => {
    if (filteredMapel.length === 0) {
      alert("Tidak ada data mata pelajaran untuk diekspor.");
      return;
    }
    const rows = filteredMapel.map((m, idx) => ({
      No: idx + 1,
      'Kode Mapel': m.kode,
      'Nama Mata Pelajaran': m.nama,
      'Kategori Kurikulum': m.kategori,
      'Beban JP/Minggu': m.jp,
      'KKM / KKTP Minimal': m.kkm,
      'Guru Koordinator': m.guru
    }));
    exportToExcel(rows, `Data_Mata_Pelajaran_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  const handleExportTahunAjaranExcel = () => {
    if (masterTahunList.length === 0) {
      alert("Tidak ada data tahun ajaran untuk diekspor.");
      return;
    }
    const rows = masterTahunList.map((t: any, idx: number) => ({
      No: idx + 1,
      'Tahun Pelajaran': t.tahun || t.tahunAjaran,
      'Semester': t.semester,
      'Rentang Periode': t.rentang || t.periode,
      'Kurikulum': t.kurikulum || 'Kurikulum Merdeka',
      'Status': t.status || 'Nonaktif'
    }));
    exportToExcel(rows, `Data_Tahun_Ajaran_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  const handleExportSemesterExcel = () => {
    if (filteredSemester.length === 0) {
      alert("Tidak ada data semester untuk diekspor.");
      return;
    }
    const rows = filteredSemester.map((s: any, idx: number) => ({
      No: idx + 1,
      'Kode ID': s.id || s.semesterId,
      'Nama Semester': s.nama || s.semester,
      'Tahun Ajaran': s.tahunAjaran || s.tahun,
      'Tanggal Mulai': s.tanggalMulai,
      'Tanggal Selesai': s.tanggalSelesai,
      'Status': s.status
    }));
    exportToExcel(rows, `Data_Semester_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  const handleExportHariLiburExcel = () => {
    if (filteredLibur.length === 0) {
      alert("Tidak ada data hari libur untuk diekspor.");
      return;
    }
    const rows = filteredLibur.map((l: any, idx: number) => ({
      No: idx + 1,
      'Tanggal / Rentang': l.tanggal,
      'Hari': l.hari,
      'Nama Kegiatan / Libur': l.agenda,
      'Kategori': l.jenis,
      'Keterangan Tambahan': l.keterangan || '-'
    }));
    exportToExcel(rows, `Data_Hari_Libur_Kalender_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  const handleExportTarifBiayaExcel = () => {
    if (filteredTarif.length === 0) {
      alert("Tidak ada data tarif pos biaya untuk diekspor.");
      return;
    }
    const rows = filteredTarif.map((t: any, idx: number) => ({
      No: idx + 1,
      'Kode Pos': t.kode,
      'Nama Pos Tagihan': t.namaPos,
      'Frekuensi Penarikan': t.frekuensi,
      'Nominal Tarif (Rp)': t.nominal,
      'Peruntukan Rombel': t.kelas,
      'Kewajiban': t.status
    }));
    exportToExcel(rows, `Data_Tarif_Pos_Biaya_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  const handleExportDapodikExcel = () => {
    if (filteredDapodik.length === 0) {
      alert("Tidak ada data Dapodik untuk diekspor.");
      return;
    }
    const rows = filteredDapodik.map((s, idx) => {
      const isComplete = Boolean(s.nik && s.NamaIbu);
      return {
        No: idx + 1,
        'NISN': s.nisn || '(Kosong)',
        'Nama Lengkap Siswa': s.name,
        'Kelas': s.class || '-',
        'Tahun Masuk': s.tahunMasuk || '(Kosong)',
        'NIK Siswa': s.nik || '(Kosong)',
        'No. KK': s.noKk || '(Kosong)',
        'Nama Ibu Kandung': s.NamaIbu || '(Kosong)',
        'Status Validasi': isComplete ? 'LENGKAP' : 'BELUM LENGKAP'
      };
    });
    exportToExcel(rows, `Validasi_Dapodik_2027_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  // Handlers for Save Edit & Confirm Delete
  const handleSaveEdit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editModal) return;
    const { type, data } = editModal;

    if (type === 'yatim' && data.id) {
      const updatedYatim: Partial<Student> = {
        statusYatim: data.statusYatim || (data as any)['status Yatim'],
        statusAyah: data.statusAyah || (data as any)['status Ayah'],
        statusIbu: data.statusIbu || (data as any)['status Ibu'],
        namaWali: data.namaWali || (data as any)['nama Wali'],
        parentPhone: data.parentPhone || (data as any)['parent Phone'],
        tlpWali: data.parentPhone || (data as any)['parent Phone'],
        updatedAt: new Date().toISOString()
      };
      updateStudent(data.id, updatedYatim);
      const currentList = useStore.getState().students;
      const nextList = currentList.map(s => s.id === data.id ? { ...s, ...updatedYatim } : s);
      if (settings.scriptUrl) {
        fetchFromGAS(settings.scriptUrl, {
          action: 'sync',
          data: nextList,
          teachers: useStore.getState().teachers,
          spreadsheetId: settings.spreadsheetId
        }).catch(err => console.warn("Sync error:", err));
        fetchFromGAS(settings.scriptUrl, {
          action: 'AUTO_POPULATE_ORTU_YATIM',
          spreadsheetId: settings.spreadsheetId
        }).catch(err => console.warn("Sync error:", err));
      }
      setSyncFeedback(`✅ Data status Yatim/Piatu untuk siswa berhasil diperbarui & disinkronkan!`);
      setTimeout(() => setSyncFeedback(null), 5000);
    } else if (type === 'parent' && data.id) {
      const updatedParent: Partial<Student> = {
        fatherName: data.fatherName || data.namaAyah,
        namaAyah: data.fatherName || data.namaAyah,
        NamaIbu: data.NamaIbu || data.namaIbu,
        namaIbu: data.NamaIbu || data.namaIbu,
        parentPhone: data.parentPhone,
        address: data.address,
        updatedAt: new Date().toISOString()
      };
      updateStudent(data.id, updatedParent);
      const currentList = useStore.getState().students;
      const nextList = currentList.map(s => s.id === data.id ? { ...s, ...updatedParent } : s);
      if (settings.scriptUrl) {
        fetchFromGAS(settings.scriptUrl, {
          action: 'sync',
          data: nextList,
          teachers: useStore.getState().teachers,
          spreadsheetId: settings.spreadsheetId
        }).catch(err => console.warn("Sync error:", err));
      }
      setSyncFeedback(`✅ Data orang tua siswa berhasil diperbarui & disinkronkan!`);
      setTimeout(() => setSyncFeedback(null), 5000);
    } else if (type === 'dapodik' && data.id) {
      const updatedDapodik: Partial<Student> = {
        nisn: data.nisn,
        nik: data.nik,
        noKk: data.noKk,
        NamaIbu: data.NamaIbu || data.namaIbu,
        namaIbu: data.NamaIbu || data.namaIbu,
        tahunMasuk: data.tahunMasuk,
        updatedAt: new Date().toISOString()
      };
      updateStudent(data.id, updatedDapodik);
      const currentList = useStore.getState().students;
      const nextList = currentList.map(s => s.id === data.id ? { ...s, ...updatedDapodik } : s);
      if (settings.scriptUrl) {
        fetchFromGAS(settings.scriptUrl, {
          action: 'sync',
          data: nextList,
          teachers: useStore.getState().teachers,
          spreadsheetId: settings.spreadsheetId
        }).catch(err => console.warn("Sync error:", err));
      }
      setSyncFeedback(`✅ Data Dapodik siswa berhasil diperbarui & disinkronkan!`);
      setTimeout(() => setSyncFeedback(null), 5000);
    } else if (type === 'mapel') {
      setMasterMapelList(prev => {
        const next = prev.map(m => ((m.id && data.id && m.id === data.id) || (m.kode === data.kode && (!data.kelas || m.kelas === data.kelas))) ? { ...m, ...data } : m);
        db.set('mapel', next);
        return next;
      });
    } else if (type === 'tahun') {
      setMasterTahunList(prev => {
        const next = prev.map(t => (t.id === data.id || t.tahun === data.tahun) ? { ...t, ...data } : t);
        db.set('tahun_ajaran', next);
        return next;
      });
    } else if (type === 'semester') {
      setMasterSemesterList(prev => {
        const next = prev.map(s => (s.id === data.id || s.semesterId === data.semesterId || s.nama === data.nama) ? { ...s, ...data } : s);
        db.set('semester', next);
        return next;
      });
    } else if (type === 'libur') {
      setMasterLiburList(prev => {
        const next = prev.map(l => l.id === data.id ? { ...l, ...data } : l);
        db.set('hari_libur', next);
        return next;
      });
    } else if (type === 'tarif') {
      setMasterTarifList(prev => {
        const next = prev.map(t => ((t.id && data.id && t.id === data.id) || (t.kode === data.kode && (!data.kelas || t.kelas === data.kelas))) ? { ...t, ...data, nominal: Number(data.nominal) } : t);
        db.set('tarif', next);
        return next;
      });
    } else if (type === 'barang') {
      setMasterBarangList(prev => {
        const next = prev.map(b => b.kode === data.kode ? { ...b, ...data, jumlah: Number(data.jumlah) } : b);
        db.set('barang', next);
        return next;
      });
    } else if (type === 'kelas') {
      setMasterClassesList(prev => {
        const next = prev.map(c => {
          if (c.cls === data.cls || c.kelasId === data.kelasId) {
            return {
              ...c,
              ...data,
              namatutor: data.namatutor || data.wali || c.namatutor,
              wali: data.wali || data.namatutor || c.wali,
              kapasitas: Number(data.kapasitas) || c.kapasitas || 32
            };
          }
          return c;
        });
        db.set('rombel', next);
        return next;
      });
    }

    setEditModal(null);
  };

  const handleConfirmDelete = () => {
    if (!deleteModal) return;
    const { type, id } = deleteModal;

    if (type === 'parent' || type === 'dapodik') {
      deleteStudent(id);
    } else if (type === 'mapel') {
      setMasterMapelList(prev => {
        const next = prev.filter(m => (m.id ? m.id !== id : m.kode !== id));
        db.set('mapel', next);
        return next;
      });
    } else if (type === 'tahun') {
      setMasterTahunList(prev => {
        const next = prev.filter(t => t.id !== id && t.tahun !== id);
        db.set('tahun_ajaran', next);
        return next;
      });
    } else if (type === 'semester') {
      setMasterSemesterList(prev => {
        const next = prev.filter(s => s.id !== id && s.semesterId !== id && s.nama !== id);
        db.set('semester', next);
        return next;
      });
    } else if (type === 'libur') {
      setMasterLiburList(prev => {
        const next = prev.filter(l => l.id !== id && l.agenda !== id);
        db.set('hari_libur', next);
        return next;
      });
    } else if (type === 'tarif') {
      setMasterTarifList(prev => {
        const next = prev.filter(t => (t.id ? t.id !== id : t.kode !== id));
        db.set('tarif', next);
        return next;
      });
    } else if (type === 'barang') {
      setMasterBarangList(prev => {
        const next = prev.filter(b => b.kode !== id);
        db.set('barang', next);
        return next;
      });
    } else if (type === 'kelas') {
      setMasterClassesList(prev => {
        const next = prev.filter(c => c.cls !== id && c.kelasId !== id);
        db.set('rombel', next);
        return next;
      });
    }

    setDeleteModal(null);
  };

  const handleSaveAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!addModal) return;
    const { type, data } = addModal;

    if (type === 'kelas') {
      const newClass = {
        kelasId: data.kelasId || (data.cls ? `KLS_${data.cls}` : 'KLS_NEW'),
        cls: data.cls || 'Baru',
        namaKelas: data.namaKelas || data.cls || 'Baru',
        jenjangId: data.jenjangId || 'J001',
        tingkat: data.tingkat || `Kelas ${data.cls || 'Baru'}`,
        waliKelasId: data.waliKelasId || 'GR_001',
        namatutor: data.namatutor || data.wali || 'Belum Ditentukan',
        wali: data.namatutor || data.wali || 'Belum Ditentukan',
        ruangan: data.ruangan || '1',
        status: data.status || 'AKTIF',
        kapasitas: Number(data.kapasitas) || 32
      };
      setMasterClassesList(prev => {
        const next = [...prev, newClass];
        db.set('rombel', next);
        return next;
      });
    } else if (type === 'mapel') {
      const newMapel = {
        kode: data.kode || `MPL-${Date.now().toString().slice(-4)}`,
        nama: data.nama || 'Mata Pelajaran Baru',
        jenjang: data.jenjang || 'SD/MI',
        kelas: data.kelas || 'Semua Kelas',
        kategori: data.kategori || 'Wajib Nasional',
        jp: Number(data.jp) || 2,
        kkm: Number(data.kkm) || 75,
        guru: data.guru || 'Guru Pengampu',
        status: 'Aktif'
      };
      setMasterMapelList(prev => {
        const next = [...prev, newMapel];
        db.set('mapel', next);
        return next;
      });
    } else if (type === 'tahun') {
      const newTahun = {
        id: String(Date.now()),
        tahun: data.tahun || '2026/2027',
        semester: data.semester || 'Semester Ganjil',
        rentang: data.rentang || 'Juli 2026 - Desember 2026',
        kurikulum: data.kurikulum || 'Kurikulum Merdeka 2026/2027 Kemendikdasmen',
        status: data.status || 'Aktif'
      };
      setMasterTahunList(prev => {
        const next = [...prev, newTahun];
        db.set('tahun_ajaran', next);
        return next;
      });
    } else if (type === 'semester') {
      const newSem = {
        id: String(Date.now()),
        semesterId: data.semesterId || `SEM-${Date.now().toString().slice(-4)}`,
        nama: data.nama || 'Semester Ganjil',
        tahunAjaran: data.tahunAjaran || '2026/2027',
        tanggalMulai: data.tanggalMulai || '2026-07-13',
        tanggalSelesai: data.tanggalSelesai || '2026-12-18',
        status: data.status || 'Aktif'
      };
      setMasterSemesterList(prev => {
        const next = [...prev, newSem];
        db.set('semester', next);
        return next;
      });
    } else if (type === 'libur') {
      const newLibur = {
        id: String(Date.now()),
        tanggal: data.tanggal || new Date().toISOString().split('T')[0],
        agenda: data.agenda || 'Agenda Libur',
        jenis: data.jenis || 'Libur Nasional',
        keterangan: data.keterangan || '-'
      };
      setMasterLiburList(prev => {
        const next = [...prev, newLibur];
        db.set('hari_libur', next);
        return next;
      });
    } else if (type === 'tarif') {
      const newTarif = {
        kode: data.kode || `POS-${Date.now().toString().slice(-4)}`,
        namaPos: data.namaPos || 'Pos Biaya Baru',
        frekuensi: data.frekuensi || 'Bulanan',
        nominal: Number(data.nominal) || 50000,
        kelas: data.kelas || 'Semua Kelas',
        status: data.status || 'Wajib'
      };
      setMasterTarifList(prev => {
        const next = [...prev, newTarif];
        db.set('tarif', next);
        return next;
      });
    } else if (type === 'barang') {
      const newBarang = {
        kode: data.kode || `AST-${Date.now().toString().slice(-4)}`,
        nama: data.nama || 'Aset Sarpras Baru',
        kategori: data.kategori || 'Sarpras Lembaga',
        jumlah: Number(data.jumlah) || 1,
        satuan: data.satuan || 'Unit',
        lokasi: data.lokasi || 'Ruang Inventaris',
        penanggungJawab: data.penanggungJawab || 'Pengelola Sarpras',
        kondisi: data.kondisi || 'Baik'
      };
      setMasterBarangList(prev => {
        const next = [...prev, newBarang];
        db.set('barang', next);
        return next;
      });
    }

    setAddModal(null);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Top Title */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white/90 p-5 rounded-3xl border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center border border-indigo-100/80 shadow-2xs flex-shrink-0">
            <Database size={22} />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">
              Master Data
            </h1>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              Pengelolaan pokok data kependidikan, pendidik, rombel, sarpras, serta validasi Dapodik 2027.
            </p>
          </div>
        </div>
      </div>

      {/* Sub-Navigation: Mobile Dropdown Selector & Desktop Pill Tabs */}
      <div className="md:hidden bg-white p-3 rounded-2xl border border-slate-200/80 shadow-xs">
        <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">
          Pilih Sub-Menu Master Data:
        </label>
        <div className="relative">
          <select
            value={activeSubTab}
            onChange={(e) => handleSubTabChange(e.target.value)}
            className="w-full pl-3.5 pr-10 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 appearance-none transition"
          >
            {subTabs.map((tab) => (
              <option key={tab.id} value={tab.id}>
                {tab.label}
              </option>
            ))}
          </select>
          <div className="absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
            ▼
          </div>
        </div>
      </div>

      {/* Sub-Navigation Pills (Desktop / Tablet) */}
      <div className="hidden md:flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {subTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => handleSubTabChange(tab.id)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all whitespace-nowrap active:scale-95 ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200'
                  : 'bg-white/80 text-slate-600 hover:bg-white hover:text-indigo-600 border border-slate-200/80'
              }`}
            >
              <Icon size={16} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Content Rendering based on activeSubTab */}
      {activeSubTab === 'dashboard' && (
        <div className="space-y-6 animate-in fade-in">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            <div 
              onClick={() => handleSubTabChange('siswa')}
              className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-2 cursor-pointer hover:border-indigo-300 transition group"
            >
              <div className="flex items-center justify-between text-indigo-600">
                <Users size={24} className="group-hover:scale-110 transition-transform" />
                <span className="text-xs font-bold bg-indigo-50 px-2.5 py-1 rounded-full">Jumlah</span>
              </div>
              <div className="text-3xl font-black text-slate-900">{students.length} Siswa</div>
              <p className="text-xs text-slate-500 font-medium">Buku Induk & Dapodik Siswa</p>
              <div className="pt-2 text-xs font-bold text-indigo-600 group-hover:underline flex items-center gap-1">
                <span>Kelola Data Siswa</span>
                <ChevronRight size={14} />
              </div>
            </div>

            <div 
              onClick={() => handleSubTabChange('guru')}
              className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-2 cursor-pointer hover:border-purple-300 transition group"
            >
              <div className="flex items-center justify-between text-purple-600">
                <GraduationCap size={24} className="group-hover:scale-110 transition-transform" />
                <span className="text-xs font-bold bg-purple-50 px-2.5 py-1 rounded-full">Pendidik & GTK</span>
              </div>
              <div className="text-3xl font-black text-slate-900">{teachers.length} Guru</div>
              <p className="text-xs text-slate-500 font-medium">Data Guru & Tenaga Kependidikan</p>
              <div className="pt-2 text-xs font-bold text-purple-600 group-hover:underline flex items-center gap-1">
                <span>Kelola Data GTK</span>
                <ChevronRight size={14} />
              </div>
            </div>

            <div 
              onClick={() => handleSubTabChange('orangtua')}
              className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-2 cursor-pointer hover:border-emerald-300 transition group"
            >
              <div className="flex items-center justify-between text-emerald-600">
                <HeartHandshake size={24} className="group-hover:scale-110 transition-transform" />
                <span className="text-xs font-bold bg-emerald-50 px-2.5 py-1 rounded-full">Wali Murid</span>
              </div>
              <div className="text-3xl font-black text-slate-900">{filteredParents.length} Wali</div>
              <p className="text-xs text-slate-500 font-medium">Kontak & Alamat Orang Tua</p>
              <div className="pt-2 text-xs font-bold text-emerald-600 group-hover:underline flex items-center gap-1">
                <span>Buku Kontak Wali</span>
                <ChevronRight size={14} />
              </div>
            </div>

            <div 
              onClick={() => handleSubTabChange('barang-aset')}
              className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-2 cursor-pointer hover:border-amber-300 transition group"
            >
              <div className="flex items-center justify-between text-amber-600">
                <Package size={24} className="group-hover:scale-110 transition-transform" />
                <span className="text-xs font-bold bg-amber-50 px-2.5 py-1 rounded-full">Sarpras</span>
              </div>
              <div className="text-3xl font-black text-slate-900">{masterBarangList.length} Aset</div>
              <p className="text-xs text-slate-500 font-medium">Inventaris & Sarana Prasarana</p>
              <div className="pt-2 text-xs font-bold text-amber-600 group-hover:underline flex items-center gap-1">
                <span>Inventaris Sarpras</span>
                <ChevronRight size={14} />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Embedded Complete Lists */}
      {activeSubTab === 'siswa' && <StudentsList />}
      {activeSubTab === 'berkas-siswa' && <BerkasSiswaPage />}
      {activeSubTab === 'guru' && <TeachersList />}

      {/* 1. Subtab ORANG TUA & WALI */}
      {activeSubTab === 'orangtua' && (
        <div className="space-y-5 animate-in fade-in">
          {/* Sync Feedback Toast / Banner */}
          {syncFeedback && (
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center justify-between shadow-xs">
              <div className="flex items-center gap-2">
                <Sparkles size={16} className="text-emerald-600 animate-pulse" />
                <span>{syncFeedback}</span>
              </div>
              <button onClick={() => setSyncFeedback(null)} className="text-emerald-600 hover:text-emerald-900">
                <X size={14} />
              </button>
            </div>
          )}

          {/* Info Header Banner */}
          <div className="bg-linear-to-r from-indigo-900 via-slate-900 to-indigo-950 text-white p-5 rounded-3xl border border-indigo-800/40 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-200 border border-indigo-400/30 text-[10px] font-bold uppercase tracking-wider">
                <Sparkles size={11} />
                <span>Sinkronisasi Otomatis Terintegrasi</span>
              </div>
              <h2 className="text-lg font-black tracking-tight">Direktori Master Orang Tua & Wali Murid</h2>
              <p className="text-xs text-indigo-200/80 max-w-2xl">
                Data orang tua disinkronkan langsung dari profil buku induk siswa (Ayah, Ibu, dan Wali) tanpa perlu input ganda.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
            </div>
          </div>

          {/* Quick Stat Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs space-y-1">
              <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">Total Entitas Ortu</span>
              <div className="text-2xl font-black text-slate-900">{parentStats.total}</div>
              <p className="text-[10px] text-slate-400">Seluruh Ayah, Ibu & Wali</p>
            </div>
            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs space-y-1">
              <span className="text-[11px] font-bold text-indigo-600 uppercase tracking-wider">Ayah Kandung</span>
              <div className="text-2xl font-black text-indigo-900">{parentStats.ayahCount}</div>
              <p className="text-[10px] text-slate-400">Terdata di Buku Induk</p>
            </div>
            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs space-y-1">
              <span className="text-[11px] font-bold text-rose-600 uppercase tracking-wider">Ibu Kandung</span>
              <div className="text-2xl font-black text-rose-900">{parentStats.ibuCount}</div>
              <p className="text-[10px] text-slate-400">Terdata di Buku Induk</p>
            </div>
            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs space-y-1">
              <span className="text-[11px] font-bold text-amber-600 uppercase tracking-wider">Wali Murid</span>
              <div className="text-2xl font-black text-amber-900">{parentStats.waliCount}</div>
              <p className="text-[10px] text-slate-400">Pengasuh / Wali Khusus</p>
            </div>
            <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs space-y-1 col-span-2 sm:col-span-1">
              <span className="text-[11px] font-bold text-emerald-600 uppercase tracking-wider">WhatsApp Terdata</span>
              <div className="text-2xl font-black text-emerald-900">{parentStats.withPhoneCount}</div>
              <p className="text-[10px] text-slate-400">Siap Dihubungi Langsung</p>
            </div>
          </div>

          {/* Smart Filter Bar */}
          <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
              {/* Relation Chips */}
              <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100 rounded-xl border border-slate-200">
                <button
                  onClick={() => setParentRelationFilter('all')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    parentRelationFilter === 'all'
                      ? 'bg-white text-indigo-700 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Semua ({parentStats.total})
                </button>
                <button
                  onClick={() => setParentRelationFilter('ayah')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    parentRelationFilter === 'ayah'
                      ? 'bg-indigo-600 text-white shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Ayah Kandung ({parentStats.ayahCount})
                </button>
                <button
                  onClick={() => setParentRelationFilter('ibu')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    parentRelationFilter === 'ibu'
                      ? 'bg-rose-600 text-white shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Ibu Kandung ({parentStats.ibuCount})
                </button>
                <button
                  onClick={() => setParentRelationFilter('wali')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    parentRelationFilter === 'wali'
                      ? 'bg-amber-600 text-white shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Wali Murid ({parentStats.waliCount})
                </button>
              </div>

              {/* Class and Search */}
              <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto flex-1 justify-end">
                <div className="relative flex-1 sm:w-64">
                  <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input 
                    type="text" 
                    placeholder="Cari orang tua, siswa, telepon, pekerjaan..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-8 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                  {searchQuery && (
                    <button onClick={() => setSearchQuery('')} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                      <X size={13} />
                    </button>
                  )}
                </div>

                {distinctClasses.length > 0 && (
                  <select
                    value={filterClass}
                    onChange={(e) => setFilterClass(e.target.value)}
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  >
                    <option value="">Semua Kelas</option>
                    {distinctClasses.map(cls => (
                      <option key={cls} value={cls}>Kelas {cls}</option>
                    ))}
                  </select>
                )}
              </div>
            </div>

            {/* List Table with Action Buttons */}
            <div className="overflow-x-auto rounded-2xl border border-slate-200/80">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50/90 text-slate-600 uppercase font-bold text-[11px] border-b border-slate-200">
                  <tr>
                    <th className="p-3.5 pl-4">Nama Orang Tua / Wali</th>
                    <th className="p-3.5">Hubungan</th>
                    <th className="p-3.5">Nama Siswa</th>
                    <th className="p-3.5">Kelas</th>
                    <th className="p-3.5">Pekerjaan</th>
                    <th className="p-3.5">No WhatsApp / HP</th>
                    <th className="p-3.5">Alamat Domisili</th>
                    <th className="p-3.5 pr-4 text-center">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                  {filteredParentRecords.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-8 text-center text-slate-400">
                        Tidak ada data orang tua yang cocok dengan kriteria pencarian.
                      </td>
                    </tr>
                  ) : (
                    filteredParentRecords.map((r) => {
                      const cleanPhone = String(r.phone || '').replace(/[^0-9]/g, '');
                      return (
                        <tr key={r.id} className="hover:bg-slate-50/80 transition">
                          <td className="p-3.5 pl-4 font-bold text-slate-900">
                            <div className="flex items-center gap-2.5">
                              <div className={`w-7 h-7 rounded-lg flex items-center justify-center font-bold text-[11px] ${
                                r.relationType === 'ayah' ? 'bg-indigo-100 text-indigo-700' :
                                r.relationType === 'ibu' ? 'bg-rose-100 text-rose-700' :
                                'bg-amber-100 text-amber-700'
                              }`}>
                                {r.parentName.charAt(0)}
                              </div>
                              <div>
                                <span>{r.parentName}</span>
                                {r.statusKondisi && String(r.statusKondisi).toLowerCase().includes('meninggal') && (
                                  <span className="ml-1.5 px-1.5 py-0.5 rounded text-[10px] font-bold bg-slate-200 text-slate-700">
                                    Almarhum
                                  </span>
                                )}
                              </div>
                            </div>
                          </td>
                          <td className="p-3.5">
                            <span className={`px-2 py-0.5 rounded-md text-[11px] font-bold ${
                              r.relationType === 'ayah' ? 'bg-indigo-50 text-indigo-700 border border-indigo-200/60' :
                              r.relationType === 'ibu' ? 'bg-rose-50 text-rose-700 border border-rose-200/60' :
                              'bg-amber-50 text-amber-700 border border-amber-200/60'
                            }`}>
                              {r.relation}
                            </span>
                          </td>
                          <td className="p-3.5 font-semibold text-slate-800">
                            <div>{r.studentName}</div>
                            <div className="text-[10px] text-slate-400 font-mono">NISN: {r.studentNisn || '-'}</div>
                          </td>
                          <td className="p-3.5">
                            <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-bold text-[11px]">
                              {r.studentClass || '-'}
                            </span>
                          </td>
                          <td className="p-3.5 text-slate-600">
                            <div>{r.job || '-'}</div>
                            {r.income && r.income !== '-' && (
                              <div className="text-[10px] text-slate-400">{r.income}</div>
                            )}
                          </td>
                          <td className="p-3.5">
                            {r.phone ? (
                              <a
                                href={`https://wa.me/${cleanPhone.replace(/^0/, '62')}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-700 text-xs font-mono font-bold border border-emerald-200 transition"
                                title="Chat WhatsApp Orang Tua / Wali"
                              >
                                <Phone size={12} className="text-emerald-600" />
                                <span>{r.phone}</span>
                              </a>
                            ) : (
                              <span className="text-slate-400 italic text-xs">Belum terdata</span>
                            )}
                          </td>
                          <td className="p-3.5 max-w-[180px] truncate text-slate-500" title={r.address}>
                            {r.address || '-'}
                          </td>
                          <td className="p-3.5 pr-4 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              <button
                                onClick={() => setViewDetailModal({
                                  open: true,
                                  title: `Detail Orang Tua: ${r.parentName}`,
                                  type: 'parent',
                                  data: {
                                    'Nama Orang Tua / Wali': r.parentName,
                                    'Hubungan dengan Siswa': r.relation,
                                    'Status Kondisi': r.statusKondisi || 'Masih Hidup',
                                    'Nama Siswa': r.studentName,
                                    'Kelas Siswa': r.studentClass,
                                    'NISN Siswa': r.studentNisn,
                                    'NIK Orang Tua': r.nik || '-',
                                    'Pekerjaan': r.job || '-',
                                    'Penghasilan': r.income || '-',
                                    'No. Telepon / WA': r.phone || '-',
                                    'Alamat Lengkap': r.address || '-'
                                  }
                                })}
                                className="px-2 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                                title="Lihat Detail"
                              >
                                <Eye size={12} />
                                <span className="hidden sm:inline">Lihat</span>
                              </button>
                              <button
                                onClick={() => setEditModal({
                                  open: true,
                                  title: `Edit Data Orang Tua: ${r.parentName}`,
                                  type: 'parent',
                                  data: {
                                    id: r.studentId,
                                    namaAyah: r.student.namaAyah || (r.relationType === 'ayah' ? r.parentName : ''),
                                    namaIbu: r.student.namaIbu || (r.relationType === 'ibu' ? r.parentName : ''),
                                    namaWali: r.student.namaWali || (r.relationType === 'wali' ? r.parentName : ''),
                                    parentPhone: r.phone,
                                    address: r.address || ''
                                  }
                                })}
                                className="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                                title="Edit Data"
                              >
                                <Edit size={12} />
                                <span className="hidden sm:inline">Edit</span>
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 2. Subtab DATA YATIM, PIATU & YATIM PIATU */}
      {activeSubTab === 'yatim-piatu' && (
        <div className="space-y-5 animate-in fade-in">
          {/* Sync Feedback Toast / Banner */}
          {syncFeedback && (
            <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center justify-between shadow-xs">
              <div className="flex items-center gap-2">
                <Sparkles size={16} className="text-emerald-600 animate-pulse" />
                <span>{syncFeedback}</span>
              </div>
              <button onClick={() => setSyncFeedback(null)} className="text-emerald-600 hover:text-emerald-900">
                <X size={14} />
              </button>
            </div>
          )}

          {/* Info Header Banner */}
          <div className="bg-linear-to-r from-purple-950 via-slate-900 to-indigo-950 text-white p-5 rounded-3xl border border-purple-800/40 shadow-sm flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
            <div className="space-y-1">
              <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-200 border border-purple-400/30 text-[10px] font-bold uppercase tracking-wider">
                <Heart size={11} className="text-purple-300" />
                <span>Manajemen Kesejahteraan & Bantuan Kesiswaan</span>
              </div>
              <h2 className="text-lg font-black tracking-tight">Data Siswa Yatim, Piatu & Yatim Piatu</h2>
              <p className="text-xs text-purple-200/80 max-w-2xl">
                Filter & pemetaan otomatis kondisi orang tua siswa untuk prioritas bantuan sosial, Program Indonesia Pintar (PIP), santunan, dan afirmasi kependidikan.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
            </div>
          </div>

          {/* Quick Stat Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
            <div 
              onClick={() => setFilterStatusYatim('Yatim Piatu')}
              className="bg-white p-4 rounded-2xl border border-rose-200 shadow-2xs space-y-1 cursor-pointer hover:border-rose-400 hover:shadow-xs transition"
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-rose-700 uppercase tracking-wider">🖤 Yatim Piatu</span>
                <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-rose-100 text-rose-800">Prioritas 1</span>
              </div>
              <div className="text-2xl font-black text-rose-950">{yatimStats.yatimPiatu} Siswa</div>
              <p className="text-[10px] text-slate-400">Ayah & Ibu Meninggal</p>
            </div>

            <div 
              onClick={() => setFilterStatusYatim('Yatim')}
              className="bg-white p-4 rounded-2xl border border-amber-200 shadow-2xs space-y-1 cursor-pointer hover:border-amber-400 hover:shadow-xs transition"
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-amber-700 uppercase tracking-wider">🤍 Yatim</span>
                <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-100 text-amber-800">Prioritas 2</span>
              </div>
              <div className="text-2xl font-black text-amber-950">{yatimStats.yatim} Siswa</div>
              <p className="text-[10px] text-slate-400">Ayah Meninggal Dunia</p>
            </div>

            <div 
              onClick={() => setFilterStatusYatim('Piatu')}
              className="bg-white p-4 rounded-2xl border border-purple-200 shadow-2xs space-y-1 cursor-pointer hover:border-purple-400 hover:shadow-xs transition"
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-purple-700 uppercase tracking-wider">💜 Piatu</span>
                <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-purple-100 text-purple-800">Prioritas 2</span>
              </div>
              <div className="text-2xl font-black text-purple-950">{yatimStats.piatu} Siswa</div>
              <p className="text-[10px] text-slate-400">Ibu Meninggal Dunia</p>
            </div>

            <div 
              onClick={() => setFilterStatusYatim('Lengkap')}
              className="bg-white p-4 rounded-2xl border border-emerald-200 shadow-2xs space-y-1 cursor-pointer hover:border-emerald-400 hover:shadow-xs transition"
            >
              <span className="text-[11px] font-bold text-emerald-700 uppercase tracking-wider">🌿 Ortu Lengkap</span>
              <div className="text-2xl font-black text-emerald-950">{yatimStats.lengkap} Siswa</div>
              <p className="text-[10px] text-slate-400">Ayah & Ibu Masih Hidup</p>
            </div>

            <div 
              onClick={() => setFilterStatusYatim('kps')}
              className="bg-white p-4 rounded-2xl border border-blue-200 shadow-2xs space-y-1 col-span-2 sm:col-span-1 cursor-pointer hover:border-blue-400 hover:shadow-xs transition"
            >
              <span className="text-[11px] font-bold text-blue-700 uppercase tracking-wider">🎯 Bantuan KPS / PIP</span>
              <div className="text-2xl font-black text-blue-950">{yatimStats.penerimaKps} Siswa</div>
              <p className="text-[10px] text-slate-400">Penerima Manfaat Sosial</p>
            </div>
          </div>

          {/* Smart Filter Bar & Table */}
          <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-3">
              {/* Status Tabs */}
              <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100 rounded-xl border border-slate-200">
                <button
                  onClick={() => setFilterStatusYatim('all')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    filterStatusYatim === 'all'
                      ? 'bg-white text-indigo-700 shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Semua ({yatimStats.total})
                </button>
                <button
                  onClick={() => setFilterStatusYatim('Yatim Piatu')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    filterStatusYatim === 'Yatim Piatu'
                      ? 'bg-rose-600 text-white shadow-2xs'
                      : 'text-rose-700 hover:bg-rose-50'
                  }`}
                >
                  🖤 Yatim Piatu ({yatimStats.yatimPiatu})
                </button>
                <button
                  onClick={() => setFilterStatusYatim('Yatim')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    filterStatusYatim === 'Yatim'
                      ? 'bg-amber-600 text-white shadow-2xs'
                      : 'text-amber-800 hover:bg-amber-50'
                  }`}
                >
                  🤍 Yatim ({yatimStats.yatim})
                </button>
                <button
                  onClick={() => setFilterStatusYatim('Piatu')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    filterStatusYatim === 'Piatu'
                      ? 'bg-purple-600 text-white shadow-2xs'
                      : 'text-purple-800 hover:bg-purple-50'
                  }`}
                >
                  💜 Piatu ({yatimStats.piatu})
                </button>
                <button
                  onClick={() => setFilterStatusYatim('Lengkap')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    filterStatusYatim === 'Lengkap'
                      ? 'bg-emerald-600 text-white shadow-2xs'
                      : 'text-emerald-700 hover:bg-emerald-50'
                  }`}
                >
                  🌿 Lengkap ({yatimStats.lengkap})
                </button>
                <button
                  onClick={() => setFilterStatusYatim('kps')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition ${
                    filterStatusYatim === 'kps'
                      ? 'bg-blue-600 text-white shadow-2xs'
                      : 'text-blue-700 hover:bg-blue-50'
                  }`}
                >
                  🎯 KPS/PIP ({yatimStats.penerimaKps})
                </button>
              </div>

              {/* Class and Search */}
              <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto flex-1 justify-end">
                <div className="relative flex-1 sm:w-64">
                  <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input 
                    type="text" 
                    placeholder="Cari nama siswa, NISN, wali, alamat..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full pl-9 pr-8 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                  {searchQuery && (
                    <button onClick={() => setSearchQuery('')} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                      <X size={13} />
                    </button>
                  )}
                </div>

                {distinctClasses.length > 0 && (
                  <select
                    value={filterClass}
                    onChange={(e) => setFilterClass(e.target.value)}
                    className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  >
                    <option value="">Semua Kelas</option>
                    {distinctClasses.map(cls => (
                      <option key={cls} value={cls}>Kelas {cls}</option>
                    ))}
                  </select>
                )}
              </div>
            </div>

            {/* List Table with Action Buttons */}
            <div className="overflow-x-auto rounded-2xl border border-slate-200/80">
              <table className="w-full text-xs text-left">
                <thead className="bg-slate-50/90 text-slate-600 uppercase font-bold text-[11px] border-b border-slate-200">
                  <tr>
                    <th className="p-3.5 pl-4">Nama Siswa</th>
                    <th className="p-3.5">Kelas</th>
                    <th className="p-3.5">Status Yatim / Piatu</th>
                    <th className="p-3.5">Kondisi Ayah</th>
                    <th className="p-3.5">Kondisi Ibu</th>
                    <th className="p-3.5">Wali / Kontak Pengasuh</th>
                    <th className="p-3.5">Bantuan KPS/PIP</th>
                    <th className="p-3.5 pr-4 text-center">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                  {filteredYatimPiatu.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="p-8 text-center text-slate-400">
                        Tidak ada data siswa yang cocok dengan filter status Yatim/Piatu.
                      </td>
                    </tr>
                  ) : (
                    filteredYatimPiatu.map((s) => {
                      const statusInfo = getYatimStatusInfo(s.computedStatusYatim);
                      const waliName = s.namaWali || (s.computedStatusYatim === 'Yatim' ? (s.namaIbu || s.parentName) : s.computedStatusYatim === 'Piatu' ? (s.namaAyah || s.parentName) : (s.parentName || s.namaAyah || s.namaIbu || '-'));
                      const waliPhone = s.tlpWali || s.parentPhone || s.tlpIbu || s.tlpAyah || s.noHp || s.phone || '';
                      const cleanPhone = String(waliPhone).replace(/[^0-9]/g, '');

                      return (
                        <tr key={s.id} className="hover:bg-slate-50/80 transition">
                          <td className="p-3.5 pl-4 font-bold text-slate-900">
                            <div className="flex items-center gap-2.5">
                              <div className="w-7 h-7 rounded-lg bg-indigo-50 text-indigo-700 flex items-center justify-center font-bold text-[11px]">
                                {s.name.charAt(0)}
                              </div>
                              <div>
                                <span>{s.name}</span>
                                <div className="text-[10px] text-slate-400 font-mono">NISN: {s.nisn || s.nis || '-'}</div>
                              </div>
                            </div>
                          </td>
                          <td className="p-3.5">
                            <span className="px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 font-bold text-[11px]">
                              {s.class || '-'}
                            </span>
                          </td>
                          <td className="p-3.5">
                            <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-extrabold border ${statusInfo.badgeColor}`}>
                              <span>{statusInfo.icon}</span>
                              <span>{statusInfo.label}</span>
                            </span>
                          </td>
                          <td className="p-3.5 text-slate-700">
                            <div className="font-semibold">{s.namaAyah || (s as any).fatherName || '-'}</div>
                            <div className="text-[10px] text-slate-500">
                              {s.statusAyah || (s.computedStatusYatim === 'Yatim' || s.computedStatusYatim === 'Yatim Piatu' ? 'Meninggal' : 'Masih Hidup')}
                            </div>
                          </td>
                          <td className="p-3.5 text-slate-700">
                            <div className="font-semibold">{s.namaIbu || (s as any).NamaIbu || '-'}</div>
                            <div className="text-[10px] text-slate-500">
                              {s.statusIbu || (s.computedStatusYatim === 'Piatu' || s.computedStatusYatim === 'Yatim Piatu' ? 'Meninggal' : 'Masih Hidup')}
                            </div>
                          </td>
                          <td className="p-3.5">
                            <div className="font-semibold text-slate-900">{waliName}</div>
                            {waliPhone ? (
                              <a
                                href={`https://wa.me/${cleanPhone.replace(/^0/, '62')}`}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="inline-flex items-center gap-1 text-[11px] text-emerald-700 font-mono font-bold hover:underline"
                                title="Chat WhatsApp Wali Siswa"
                              >
                                <Phone size={10} className="text-emerald-600" />
                                <span>{waliPhone}</span>
                              </a>
                            ) : (
                              <span className="text-slate-400 text-[10px] italic">Tanpa nomor WA</span>
                            )}
                          </td>
                          <td className="p-3.5">
                            {s.isKps ? (
                              <span className="px-2 py-0.5 rounded-md bg-blue-50 text-blue-700 border border-blue-200 text-[11px] font-bold">
                                Ya (PIP/KPS)
                              </span>
                            ) : (
                              <span className="text-slate-400 text-[11px]">Reguler</span>
                            )}
                          </td>
                          <td className="p-3.5 pr-4 text-center">
                            <div className="flex items-center justify-center gap-1.5">
                              <button
                                onClick={() => setViewDetailModal({
                                  open: true,
                                  title: `Detail Kondisi Siswa: ${s.name}`,
                                  type: 'yatim',
                                  data: {
                                    'Nama Siswa': s.name,
                                    'NISN / NIS': `${s.nisn || '-'} / ${s.nis || '-'}`,
                                    'Kelas': s.class,
                                    'Status Kondisi': s.computedStatusYatim,
                                    'Nama Ayah': s.namaAyah || (s as any).fatherName || '-',
                                    'Kondisi Ayah': s.statusAyah || (s.computedStatusYatim === 'Yatim' || s.computedStatusYatim === 'Yatim Piatu' ? 'Meninggal' : 'Masih Hidup'),
                                    'Nama Ibu': s.namaIbu || (s as any).NamaIbu || '-',
                                    'Kondisi Ibu': s.statusIbu || (s.computedStatusYatim === 'Piatu' || s.computedStatusYatim === 'Yatim Piatu' ? 'Meninggal' : 'Masih Hidup'),
                                    'Nama Wali / Pengasuh': waliName,
                                    'Kontak Wali': waliPhone || '-',
                                    'Alamat': formatFullAddress(s),
                                    'Penerima Bantuan Sosial': s.isKps ? 'Ya (KPS / PIP Terdaftar)' : 'Tidak'
                                  }
                                })}
                                className="px-2 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                                title="Lihat Detail"
                              >
                                <Eye size={12} />
                                <span className="hidden sm:inline">Lihat</span>
                              </button>
                              <button
                                onClick={() => setEditModal({
                                  open: true,
                                  title: `Edit Status Siswa: ${s.name}`,
                                  type: 'yatim',
                                  data: {
                                    id: s.id,
                                    statusYatim: s.computedStatusYatim,
                                    statusAyah: s.statusAyah || (s.computedStatusYatim === 'Yatim' || s.computedStatusYatim === 'Yatim Piatu' ? 'Meninggal' : 'Masih Hidup'),
                                    statusIbu: s.statusIbu || (s.computedStatusYatim === 'Piatu' || s.computedStatusYatim === 'Yatim Piatu' ? 'Meninggal' : 'Masih Hidup'),
                                    namaWali: s.namaWali || '',
                                    parentPhone: waliPhone
                                  }
                                })}
                                className="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                                title="Edit Status"
                              >
                                <Edit size={12} />
                                <span className="hidden sm:inline">Edit</span>
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* 3. Subtab KELAS & WALI */}
      {activeSubTab === 'kelas-wali' && (
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-6">
          {/* Rekapitulasi Siswa Per Jenjang Kelas (Paket A, B, C) */}
          <div className="space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <h3 className="text-base font-black text-slate-900 tracking-tight">
                  Rekapitulasi Siswa Per Jenjang Kelas
                </h3>
                <p className="text-xs text-slate-500 font-medium mt-0.5">
                  Rincian distribusi siswa aktif dan non-aktif per paket pendidikan
                </p>
              </div>

              <button
                onClick={() => handleSubTabChange('siswa')}
                className="px-3.5 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border border-indigo-200/80 active:scale-95"
              >
                <span>Kelola Master Siswa</span>
                <ChevronRight size={14} />
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
              {/* PAKET A (SD KELAS 4 - 6) */}
              <div className="p-4 rounded-2xl border border-slate-200/80 bg-slate-50/60 shadow-xs space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200/80 pb-2.5">
                  <div className="flex items-center gap-2">
                    <span className="text-sm">🎒</span>
                    <span className="text-xs font-black uppercase text-slate-800 tracking-wider">
                      PAKET A (SD KELAS 4 - 6)
                    </span>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-100">
                    Paket A
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead>
                      <tr className="border-b border-slate-200/60 text-[11px] text-slate-500 font-bold">
                        <th className="pb-2">Kelas</th>
                        <th className="pb-2 text-center text-emerald-700">Aktif</th>
                        <th className="pb-2 text-center text-slate-500">Tdk Aktif</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {rekapJenjang.paketA.rows.map((row) => (
                        <tr key={row.kelas}>
                          <td className="py-2 font-bold text-slate-800">{row.kelas}</td>
                          <td className="py-2 text-center font-mono font-bold text-emerald-700">{row.aktif}</td>
                          <td className="py-2 text-center font-mono text-slate-500">{row.nonAktif}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="pt-2 border-t border-slate-200/80 flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-600">Jumlah Siswa</span>
                  <span className="font-black font-mono text-indigo-700 bg-white px-2.5 py-1 rounded-lg border border-slate-200">
                    {rekapJenjang.paketA.totalSiswa} Siswa
                  </span>
                </div>
              </div>

              {/* PAKET B (SMP KELAS 7 - 9) */}
              <div className="p-4 rounded-2xl border border-slate-200/80 bg-slate-50/60 shadow-xs space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200/80 pb-2.5">
                  <div className="flex items-center gap-2">
                    <span className="text-sm">📘</span>
                    <span className="text-xs font-black uppercase text-slate-800 tracking-wider">
                      PAKET B (SMP KELAS 7 - 9)
                    </span>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-100">
                    Paket B
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead>
                      <tr className="border-b border-slate-200/60 text-[11px] text-slate-500 font-bold">
                        <th className="pb-2">Kelas</th>
                        <th className="pb-2 text-center text-emerald-700">Aktif</th>
                        <th className="pb-2 text-center text-slate-500">Tdk Aktif</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {rekapJenjang.paketB.rows.map((row) => (
                        <tr key={row.kelas}>
                          <td className="py-2 font-bold text-slate-800">{row.kelas}</td>
                          <td className="py-2 text-center font-mono font-bold text-emerald-700">{row.aktif}</td>
                          <td className="py-2 text-center font-mono text-slate-500">{row.nonAktif}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="pt-2 border-t border-slate-200/80 flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-600">Jumlah Siswa</span>
                  <span className="font-black font-mono text-blue-700 bg-white px-2.5 py-1 rounded-lg border border-slate-200">
                    {rekapJenjang.paketB.totalSiswa} Siswa
                  </span>
                </div>
              </div>

              {/* PAKET C (SMA KELAS 10 - 12) */}
              <div className="p-4 rounded-2xl border border-slate-200/80 bg-slate-50/60 shadow-xs space-y-3">
                <div className="flex items-center justify-between border-b border-slate-200/80 pb-2.5">
                  <div className="flex items-center gap-2">
                    <span className="text-sm">🎓</span>
                    <span className="text-xs font-black uppercase text-slate-800 tracking-wider">
                      PAKET C (SMA KELAS 10 - 12)
                    </span>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-50 text-purple-700 border border-purple-100">
                    Paket C
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-left">
                    <thead>
                      <tr className="border-b border-slate-200/60 text-[11px] text-slate-500 font-bold">
                        <th className="pb-2">Kelas</th>
                        <th className="pb-2 text-center text-emerald-700">Aktif</th>
                        <th className="pb-2 text-center text-slate-500">Tdk Aktif</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {rekapJenjang.paketC.rows.map((row) => (
                        <tr key={row.kelas}>
                          <td className="py-2 font-bold text-slate-800">{row.kelas}</td>
                          <td className="py-2 text-center font-mono font-bold text-emerald-700">{row.aktif}</td>
                          <td className="py-2 text-center font-mono text-slate-500">{row.nonAktif}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                <div className="pt-2 border-t border-slate-200/80 flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-600">Jumlah Siswa</span>
                  <span className="font-black font-mono text-purple-700 bg-white px-2.5 py-1 rounded-lg border border-slate-200">
                    {rekapJenjang.paketC.totalSiswa} Siswa
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Smart Filter Bar */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-slate-50/80 p-3.5 rounded-2xl border border-slate-200/70">
            <div className="relative flex-1 sm:w-72">
              <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input 
                type="text" 
                placeholder="Cari kelas, wali kelas, gedung..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-8 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              />
              {searchQuery && (
                <button onClick={() => setSearchQuery('')} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                  <X size={13} />
                </button>
              )}
            </div>

            <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
              <span className="text-[11px] font-bold text-slate-500 bg-white px-3 py-1.5 rounded-xl border border-slate-200">
                Total {filteredClasses.length} Rombongan Belajar
              </span>
              <button
                onClick={() => setAddModal({
                  open: true,
                  title: 'Tambah Rombongan Belajar (Kelas) Baru',
                  type: 'kelas',
                  data: {
                    kelasId: '',
                    cls: '',
                    namaKelas: '',
                    jenjangId: 'J001',
                    tingkat: '',
                    waliKelasId: 'GR_001',
                    namatutor: teachers[0]?.name || '',
                    ruangan: '1',
                    status: 'AKTIF',
                    kapasitas: 32
                  }
                })}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-xs transition active:scale-95 whitespace-nowrap"
              >
                <Plus size={14} />
                <span>Tambah Kelas</span>
              </button>
            </div>
          </div>

          {/* List Table with Action Buttons */}
          <div className="overflow-x-auto rounded-2xl border border-slate-200/80">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50/90 text-slate-600 uppercase font-bold text-[11px] border-b border-slate-200">
                <tr>
                  <th className="p-3.5 pl-4">Kelas ID</th>
                  <th className="p-3.5">Nama Kelas / Rombel</th>
                  <th className="p-3.5">Jenjang & Tingkat</th>
                  <th className="p-3.5">Wali Kelas / Tutor</th>
                  <th className="p-3.5 text-center">Ruang</th>
                  <th className="p-3.5 text-center">Siswa L / P</th>
                  <th className="p-3.5 text-center">Total Terdaftar</th>
                  <th className="p-3.5 text-center">Status</th>
                  <th className="p-3.5 pr-4 text-center">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {filteredClasses.map((item) => (
                  <tr key={item.kelasId || item.cls} className="hover:bg-slate-50/80 transition">
                    <td className="p-3.5 pl-4">
                      <span className="font-mono font-extrabold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-lg border border-indigo-100">
                        {item.kelasId || item.cls}
                      </span>
                    </td>
                    <td className="p-3.5">
                      <div className="font-black text-slate-900">
                        Kelas {item.namaKelas || item.cls}
                      </div>
                      <div className="text-[10px] text-slate-400 font-normal">
                        Kapasitas: {item.kapasitas || 32} siswa
                      </div>
                    </td>
                    <td className="p-3.5">
                      <div className="font-bold text-slate-800">
                        {item.tingkat || `Paket ${item.cls}`}
                      </div>
                      <div className="text-[10px] text-indigo-600 font-semibold">
                        Kode: {item.jenjangId || 'J001'}
                      </div>
                    </td>
                    <td className="p-3.5">
                      <div className="font-bold text-slate-800">
                        {item.namatutor || item.wali || 'Belum Ditentukan'}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        ID: {item.waliKelasId || '-'}
                      </div>
                    </td>
                    <td className="p-3.5 text-center">
                      <span className="font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded-md text-[11px]">
                        {item.ruangan && item.ruangan !== '-' ? `Ruang ${item.ruangan}` : '-'}
                      </span>
                    </td>
                    <td className="p-3.5 text-center">
                      <span className="font-bold text-blue-600">{item.male} L</span>
                      <span className="text-slate-300 mx-1">/</span>
                      <span className="font-bold text-pink-600">{item.female} P</span>
                    </td>
                    <td className="p-3.5 text-center font-black text-slate-900 text-sm">
                      {item.count}
                    </td>
                    <td className="p-3.5 text-center">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        (item.status || 'AKTIF').toUpperCase() === 'AKTIF'
                          ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                          : 'bg-purple-50 text-purple-700 border border-purple-200'
                      }`}>
                        {item.status || 'AKTIF'}
                      </span>
                    </td>
                    <td className="p-3.5 pr-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => setViewDetailModal({
                            open: true,
                            title: `Detail Kelas: ${item.namaKelas || item.cls} (${item.kelasId || item.cls})`,
                            type: 'kelas',
                            data: {
                              'Kelas ID': item.kelasId || item.cls,
                              'Nama Rombel / Kelas': `Kelas ${item.namaKelas || item.cls}`,
                              'Jenjang ID': item.jenjangId || 'J001',
                              'Tingkat / Program': item.tingkat || `Paket ${item.cls}`,
                              'Wali Kelas ID': item.waliKelasId || '-',
                              'Wali Kelas / Tutor': item.namatutor || item.wali || '-',
                              'Ruang Belajar': item.ruangan || '-',
                              'Jumlah Siswa Laki-laki': `${item.male} Siswa`,
                              'Jumlah Siswa Perempuan': `${item.female} Siswi`,
                              'Total Siswa Terdaftar': `${item.count} Siswa`,
                              'Kapasitas Maksimal': `${item.kapasitas || 32} Siswa`,
                              'Status Rombel': item.status || 'AKTIF'
                            }
                          })}
                          className="px-2 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                          title="Lihat Detail"
                        >
                          <Eye size={12} />
                          <span className="hidden sm:inline">Lihat</span>
                        </button>
                        <button
                          onClick={() => setEditModal({
                            open: true,
                            title: `Edit Kelas: ${item.namaKelas || item.cls} (${item.kelasId || item.cls})`,
                            type: 'kelas',
                            data: {
                              kelasId: item.kelasId || item.cls,
                              cls: item.cls,
                              namaKelas: item.namaKelas || item.cls,
                              jenjangId: item.jenjangId || 'J001',
                              tingkat: item.tingkat || `Kelas ${item.cls}`,
                              waliKelasId: item.waliKelasId || 'GR_001',
                              namatutor: item.namatutor || item.wali || '',
                              ruangan: item.ruangan || '1',
                              status: item.status || 'AKTIF',
                              kapasitas: item.kapasitas || 32
                            }
                          })}
                          className="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                          title="Edit Data"
                        >
                          <Edit size={12} />
                          <span className="hidden sm:inline">Edit</span>
                        </button>
                        <button
                          onClick={() => setDeleteModal({
                            open: true,
                            title: 'Hapus Rombel / Kelas',
                            id: item.cls || item.kelasId,
                            name: `Kelas ${item.namaKelas || item.cls} (${item.kelasId || item.cls})`,
                            type: 'kelas'
                          })}
                          className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                          title="Hapus Data"
                        >
                          <Trash2 size={12} />
                          <span className="hidden sm:inline">Hapus</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 3. Subtab MATA PELAJARAN */}
      {activeSubTab === 'mapel' && (
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-5">
          {/* Smart Filter Bar */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-slate-50/80 p-3.5 rounded-2xl border border-slate-200/70">
            <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto flex-1">
              <div className="relative flex-1 sm:w-64">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Cari nama mapel, kode, guru..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-8 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
                {searchQuery && (
                  <button onClick={() => setSearchQuery('')} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                    <X size={13} />
                  </button>
                )}
              </div>

              <select
                value={filterClass}
                onChange={(e) => setFilterClass(e.target.value)}
                className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              >
                <option value="">Semua Kelas</option>
                {distinctClasses.map(c => (
                  <option key={c} value={c}>Kelas {c}</option>
                ))}
              </select>

              <select
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
                className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              >
                <option value="">Semua Kategori</option>
                <option value="Wajib Nasional">Wajib Nasional</option>
                <option value="Muatan Lokal">Muatan Lokal</option>
                <option value="Pilihan Khusus">Pilihan Khusus</option>
              </select>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <span className="text-[11px] font-bold text-slate-500 bg-white px-3 py-1.5 rounded-xl border border-slate-200">
                {filteredMapel.length} Mapel
              </span>
              <button
                onClick={() => setAddModal({
                  open: true,
                  title: 'Tambah Mata Pelajaran Baru',
                  type: 'mapel',
                  data: { kode: '', nama: '', jenjang: 'SD/MI', kelas: 'Semua Kelas', kategori: 'Wajib Nasional', jp: 2, kkm: 75, guru: teachers[0]?.name || '' }
                })}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs transition active:scale-95 whitespace-nowrap"
              >
                <Plus size={14} />
                <span>Tambah Mapel</span>
              </button>
            </div>
          </div>

          {/* List Table with Action Buttons */}
          <div className="overflow-x-auto rounded-2xl border border-slate-200/80">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50/90 text-slate-600 uppercase font-bold text-[11px] border-b border-slate-200">
                <tr>
                  <th className="p-3.5 pl-4">Kode</th>
                  <th className="p-3.5">Nama Mata Pelajaran</th>
                  <th className="p-3.5">Kategori Kurikulum</th>
                  <th className="p-3.5 text-center">Beban JP/Minggu</th>
                  <th className="p-3.5 text-center">KKM / KKTP</th>
                  <th className="p-3.5">Guru Koordinator Pengampu</th>
                  <th className="p-3.5 pr-4 text-center">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {filteredMapel.map((mapel, idx) => (
                  <tr key={mapel.id || `${mapel.kode}-${mapel.kelas || ''}-${idx}`} className="hover:bg-slate-50/80 transition">
                    <td className="p-3.5 pl-4 font-mono font-bold text-indigo-600">{mapel.kode}</td>
                    <td className="p-3.5 font-bold text-slate-900 text-sm">{mapel.nama}</td>
                    <td className="p-3.5">
                      <span className="px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-700 font-bold text-[11px]">
                        {mapel.kategori}
                      </span>
                    </td>
                    <td className="p-3.5 text-center font-bold text-slate-800">{mapel.jp} JP</td>
                    <td className="p-3.5 text-center font-bold text-emerald-700">{mapel.kkm}</td>
                    <td className="p-3.5 font-semibold text-slate-800">{mapel.guru}</td>
                    <td className="p-3.5 pr-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => setViewDetailModal({
                            open: true,
                            title: `Detail Mapel: ${mapel.nama}`,
                            type: 'mapel',
                            data: {
                              'Kode Mata Pelajaran': mapel.kode,
                              'Nama Mata Pelajaran': mapel.nama,
                              'Kategori Kurikulum': mapel.kategori,
                              'Beban JP per Minggu': `${mapel.jp} Jam Pelajaran`,
                              'KKM / KKTP Minimal': mapel.kkm,
                              'Guru Pengampu': mapel.guru
                            }
                          })}
                          className="px-2 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                          title="Lihat Detail"
                        >
                          <Eye size={12} />
                          <span className="hidden sm:inline">Lihat</span>
                        </button>
                        <button
                          onClick={() => setEditModal({
                            open: true,
                            title: `Edit Mapel: ${mapel.nama}`,
                            type: 'mapel',
                            data: { ...mapel }
                          })}
                          className="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                          title="Edit Data"
                        >
                          <Edit size={12} />
                          <span className="hidden sm:inline">Edit</span>
                        </button>
                        <button
                          onClick={() => setDeleteModal({
                            open: true,
                            title: 'Hapus Mata Pelajaran',
                            id: mapel.id || mapel.kode,
                            name: mapel.nama,
                            type: 'mapel'
                          })}
                          className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                          title="Hapus Data"
                        >
                          <Trash2 size={12} />
                          <span className="hidden sm:inline">Hapus</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 4. Subtab TAHUN AJARAN */}
      {activeSubTab === 'tahun-ajaran' && (
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-5">
          <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <span className="text-[10px] font-extrabold text-emerald-700 uppercase tracking-wider bg-emerald-100 px-2 py-0.5 rounded">Tahun Ajaran Aktif Saat Ini</span>
              <h4 className="text-lg font-black text-emerald-950 mt-1">Tahun Pelajaran 2026/2027 - Semester Ganjil</h4>
              <p className="text-xs text-emerald-800/80">Periode Akademik: Juli 2026 s/d Desember 2026 | Kurikulum Merdeka 2026/2027 Kemendikdasmen</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-3.5 py-2 bg-emerald-600 text-white rounded-xl text-xs font-black shadow-xs">
                ✓ Berjalan Aktif
              </span>
              <button
                onClick={() => setAddModal({
                  open: true,
                  title: 'Tambah Tahun Ajaran / Semester Baru',
                  type: 'tahun',
                  data: { tahun: '2026/2027', semester: 'Semester Ganjil', rentang: 'Juli 2026 - Desember 2026', kurikulum: 'Kurikulum Merdeka 2026/2027 Kemendikdasmen', status: 'Aktif' }
                })}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs transition active:scale-95"
              >
                <Plus size={14} />
                <span>Tambah Tahun</span>
              </button>
            </div>
          </div>

          <div className="overflow-x-auto rounded-2xl border border-slate-200/80">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50/90 text-slate-600 uppercase font-bold text-[11px] border-b border-slate-200">
                <tr>
                  <th className="p-3.5 pl-4">Tahun Pelajaran</th>
                  <th className="p-3.5">Semester</th>
                  <th className="p-3.5">Rentang Waktu</th>
                  <th className="p-3.5">Kurikulum</th>
                  <th className="p-3.5 text-center">Status</th>
                  <th className="p-3.5 pr-4 text-center">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {masterTahunList.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-slate-400">
                      <p className="font-bold text-slate-600 text-sm">Belum Ada Data Tahun Ajaran</p>
                      <p className="text-xs text-slate-400 mt-0.5">Tambahkan data tahun ajaran melalui menu master data.</p>
                    </td>
                  </tr>
                ) : (
                  masterTahunList.map((t: any, i: number) => (
                    <tr key={i} className={t.status === 'Aktif' ? 'bg-emerald-50/40' : ''}>
                      <td className="p-3.5 pl-4 font-bold text-slate-900">{t.tahun || t.tahunAjaran}</td>
                      <td className="p-3.5 font-bold text-emerald-700">{t.semester}</td>
                      <td className="p-3.5">{t.rentang || t.periode}</td>
                      <td className="p-3.5">{t.kurikulum || 'Kurikulum Merdeka'}</td>
                      <td className="p-3.5 text-center">
                        <span className={`px-2.5 py-1 rounded-full font-bold text-[10px] ${
                          t.status === 'Aktif' ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'
                        }`}>
                          {t.status || 'Non-Aktif'}
                        </span>
                      </td>
                      <td className="p-3.5 pr-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => setViewDetailModal({
                              open: true,
                              title: `Detail Tahun Pelajaran ${t.tahun}`,
                              type: 'tahun',
                              data: t
                            })}
                            className="px-2 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                          >
                            <Eye size={12} />
                            <span>Lihat</span>
                          </button>
                          <button
                            onClick={() => setEditModal({
                              open: true,
                              title: `Edit Tahun Pelajaran: ${t.tahun}`,
                              type: 'tahun',
                              data: { ...t }
                            })}
                            className="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                            title="Edit Data"
                          >
                            <Edit size={12} />
                            <span className="hidden sm:inline">Edit</span>
                          </button>
                          <button
                            onClick={() => setDeleteModal({
                              open: true,
                              title: 'Hapus Tahun Pelajaran',
                              id: t.id || t.tahun,
                              name: `Tahun ${t.tahun}`,
                              type: 'tahun'
                            })}
                            className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                            title="Hapus Data"
                          >
                            <Trash2 size={12} />
                            <span className="hidden sm:inline">Hapus</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 4b. Subtab SEMESTER */}
      {activeSubTab === 'semester' && (
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-5">
          {/* Smart Filter Bar */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-slate-50/80 p-3.5 rounded-2xl border border-slate-200/70">
            <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto flex-1">
              <div className="relative flex-1 sm:w-72">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Cari semester, tahun ajaran, kode ID..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-8 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
                {searchQuery && (
                  <button onClick={() => setSearchQuery('')} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                    <X size={13} />
                  </button>
                )}
              </div>

              <select
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
                className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              >
                <option value="">Semua Status</option>
                <option value="Aktif">Status Aktif</option>
                <option value="Non-Aktif">Status Non-Aktif</option>
              </select>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <span className="text-[11px] font-bold text-slate-500 bg-white px-3 py-1.5 rounded-xl border border-slate-200">
                {filteredSemester.length} Semester
              </span>
              <button
                onClick={() => setAddModal({
                  open: true,
                  title: 'Tambah Data Semester Baru',
                  type: 'semester',
                  data: {
                    semesterId: `SEM-${Date.now().toString().slice(-4)}`,
                    nama: 'Semester Ganjil',
                    tahunAjaran: masterTahunList[0]?.tahun || '2026/2027',
                    tanggalMulai: '2026-07-13',
                    tanggalSelesai: '2026-12-18',
                    status: 'Aktif'
                  }
                })}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs transition active:scale-95 whitespace-nowrap"
              >
                <Plus size={14} />
                <span>Tambah Semester</span>
              </button>
            </div>
          </div>

          {/* List Table with Action Buttons */}
          <div className="overflow-x-auto rounded-2xl border border-slate-200/80">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50/90 text-slate-600 uppercase font-bold text-[11px] border-b border-slate-200">
                <tr>
                  <th className="p-3.5 pl-4">ID Semester</th>
                  <th className="p-3.5">Nama Semester</th>
                  <th className="p-3.5">Tahun Ajaran Terkait</th>
                  <th className="p-3.5">Tanggal Mulai</th>
                  <th className="p-3.5">Tanggal Selesai</th>
                  <th className="p-3.5 text-center">Status</th>
                  <th className="p-3.5 pr-4 text-center">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {filteredSemester.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="p-8 text-center text-slate-400">
                      <p className="font-bold text-slate-600 text-sm">Belum Ada Data Semester</p>
                      <p className="text-xs text-slate-400 mt-0.5">Silakan klik tombol "Tambah Semester" di atas untuk menambahkan periode semester.</p>
                    </td>
                  </tr>
                ) : (
                  filteredSemester.map((s: any, idx: number) => (
                    <tr key={s.id || s.semesterId || idx} className={s.status === 'Aktif' ? 'bg-emerald-50/30' : 'hover:bg-slate-50/80 transition'}>
                      <td className="p-3.5 pl-4 font-mono font-bold text-indigo-700">{s.semesterId || s.id || `SEM-0${idx+1}`}</td>
                      <td className="p-3.5 font-bold text-slate-900 text-sm">{s.nama || s.semester}</td>
                      <td className="p-3.5 font-semibold text-slate-800">{s.tahunAjaran || s.tahun}</td>
                      <td className="p-3.5 text-slate-600">{s.tanggalMulai || '-'}</td>
                      <td className="p-3.5 text-slate-600">{s.tanggalSelesai || '-'}</td>
                      <td className="p-3.5 text-center">
                        <span className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                          s.status === 'Aktif' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-slate-100 text-slate-600'
                        }`}>
                          {s.status || 'Aktif'}
                        </span>
                      </td>
                      <td className="p-3.5 pr-4 text-center">
                        <div className="flex items-center justify-center gap-1.5">
                          <button
                            onClick={() => setViewDetailModal({
                              open: true,
                              title: `Detail Semester: ${s.nama}`,
                              type: 'semester',
                              data: {
                                'ID Semester': s.semesterId || s.id,
                                'Nama Semester': s.nama || s.semester,
                                'Tahun Ajaran': s.tahunAjaran || s.tahun,
                                'Tanggal Mulai': s.tanggalMulai || '-',
                                'Tanggal Selesai': s.tanggalSelesai || '-',
                                'Status Aktif': s.status || 'Aktif'
                              }
                            })}
                            className="px-2 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                            title="Lihat Detail"
                          >
                            <Eye size={12} />
                            <span className="hidden sm:inline">Lihat</span>
                          </button>
                          <button
                            onClick={() => setEditModal({
                              open: true,
                              title: `Edit Semester: ${s.nama}`,
                              type: 'semester',
                              data: { ...s }
                            })}
                            className="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                            title="Edit Data"
                          >
                            <Edit size={12} />
                            <span className="hidden sm:inline">Edit</span>
                          </button>
                          <button
                            onClick={() => setDeleteModal({
                              open: true,
                              title: 'Hapus Semester',
                              id: s.id || s.semesterId || s.nama,
                              name: `Semester ${s.nama}`,
                              type: 'semester'
                            })}
                            className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                            title="Hapus Data"
                          >
                            <Trash2 size={12} />
                            <span className="hidden sm:inline">Hapus</span>
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 5. Subtab HARI LIBUR & KALENDER */}
      {activeSubTab === 'hari-libur' && (
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-5">
          {/* Smart Filter Bar */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-slate-50/80 p-3.5 rounded-2xl border border-slate-200/70">
            <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto flex-1">
              <div className="relative flex-1 sm:w-72">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Cari hari libur, tanggal, agenda..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-8 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
                {searchQuery && (
                  <button onClick={() => setSearchQuery('')} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                    <X size={13} />
                  </button>
                )}
              </div>

              <select
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
                className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              >
                <option value="">Semua Kategori</option>
                <option value="Libur Nasional">Libur Nasional</option>
                <option value="Libur Keagamaan">Libur Keagamaan</option>
                <option value="Agenda KBM">Agenda KBM / Asesmen</option>
                <option value="Agenda Akademik">Agenda Akademik</option>
                <option value="Libur Sekolah">Libur Semester Sekolah</option>
              </select>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <span className="text-[11px] font-bold text-slate-500 bg-white px-3 py-1.5 rounded-xl border border-slate-200">
                {filteredLibur.length} Agenda
              </span>
              <button
                onClick={() => setAddModal({
                  open: true,
                  title: 'Tambah Hari Libur / Agenda Baru',
                  type: 'libur',
                  data: { tanggal: new Date().toISOString().split('T')[0], agenda: '', jenis: 'Libur Nasional', keterangan: '' }
                })}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs transition active:scale-95 whitespace-nowrap"
              >
                <Plus size={14} />
                <span>Tambah Libur</span>
              </button>
            </div>
          </div>

          {/* List Table with Action Buttons */}
          <div className="overflow-x-auto rounded-2xl border border-slate-200/80">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50/90 text-slate-600 uppercase font-bold text-[11px] border-b border-slate-200">
                <tr>
                  <th className="p-3.5 pl-4">Tanggal / Rentang</th>
                  <th className="p-3.5">Hari</th>
                  <th className="p-3.5">Nama Kegiatan / Libur</th>
                  <th className="p-3.5">Kategori</th>
                  <th className="p-3.5">Keterangan Tambahan</th>
                  <th className="p-3.5 pr-4 text-center">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {filteredLibur.map((l, i) => (
                  <tr key={l.id || i} className="hover:bg-slate-50/80 transition">
                    <td className="p-3.5 pl-4 font-bold text-indigo-700">{l.tanggal}</td>
                    <td className="p-3.5 font-semibold text-slate-800">{l.hari}</td>
                    <td className="p-3.5 font-bold text-slate-900 text-sm">{l.agenda}</td>
                    <td className="p-3.5">
                      <span className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                        l.jenis === 'Libur Nasional' ? 'bg-rose-50 text-rose-700 border border-rose-200' :
                        l.jenis === 'Libur Keagamaan' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                        l.jenis === 'Agenda KBM' ? 'bg-indigo-50 text-indigo-700 border border-indigo-200' :
                        'bg-amber-50 text-amber-700 border border-amber-200'
                      }`}>
                        {l.jenis}
                      </span>
                    </td>
                    <td className="p-3.5 text-slate-500">{l.keterangan}</td>
                    <td className="p-3.5 pr-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => setViewDetailModal({
                            open: true,
                            title: `Detail Agenda: ${l.agenda}`,
                            type: 'libur',
                            data: {
                              'Tanggal Pelaksanaan': l.tanggal,
                              'Hari': l.hari,
                              'Agenda / Kegiatan': l.agenda,
                              'Jenis Kategori': l.jenis,
                              'Keterangan Lengkap': l.keterangan
                            }
                          })}
                          className="px-2 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                          title="Lihat Detail"
                        >
                          <Eye size={12} />
                          <span className="hidden sm:inline">Lihat</span>
                        </button>
                        <button
                          onClick={() => setEditModal({
                            open: true,
                            title: `Edit Agenda: ${l.agenda}`,
                            type: 'libur',
                            data: { ...l }
                          })}
                          className="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                          title="Edit Data"
                        >
                          <Edit size={12} />
                          <span className="hidden sm:inline">Edit</span>
                        </button>
                        <button
                          onClick={() => setDeleteModal({
                            open: true,
                            title: 'Hapus Agenda Libur',
                            id: l.id || l.agenda,
                            name: l.agenda,
                            type: 'libur'
                          })}
                          className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                          title="Hapus Data"
                        >
                          <Trash2 size={12} />
                          <span className="hidden sm:inline">Hapus</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 6. Subtab TARIF BIAYA SEKOLAH */}
      {activeSubTab === 'tarif-biaya' && (
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-5">
          {/* Smart Filter Bar */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-slate-50/80 p-3.5 rounded-2xl border border-slate-200/70">
            <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto flex-1">
              <div className="relative flex-1 sm:w-64">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Cari nama pos biaya, kode..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-8 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
                {searchQuery && (
                  <button onClick={() => setSearchQuery('')} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                    <X size={13} />
                  </button>
                )}
              </div>

              <select
                value={filterClass}
                onChange={(e) => setFilterClass(e.target.value)}
                className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              >
                <option value="">Semua Kelas</option>
                {distinctClasses.map(c => (
                  <option key={c} value={c}>Kelas {c}</option>
                ))}
              </select>

              <select
                value={filterCategory}
                onChange={(e) => setFilterCategory(e.target.value)}
                className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              >
                <option value="">Semua Frekuensi</option>
                <option value="Bulanan">Bulanan</option>
                <option value="Tahunan">Tahunan</option>
                <option value="Insidental">Insidental</option>
              </select>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <span className="text-[11px] font-bold text-slate-500 bg-white px-3 py-1.5 rounded-xl border border-slate-200">
                {filteredTarif.length} Pos Biaya
              </span>
              <button
                onClick={() => setAddModal({
                  open: true,
                  title: 'Tambah Pos Tagihan / Biaya Baru',
                  type: 'tarif',
                  data: { kode: '', namaPos: '', frekuensi: 'Bulanan', nominal: 100000, kelas: 'Semua Kelas', status: 'Wajib' }
                })}
                className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs transition active:scale-95 whitespace-nowrap"
              >
                <Plus size={14} />
                <span>Tambah Pos Biaya</span>
              </button>
            </div>
          </div>

          {/* List Table with Action Buttons */}
          <div className="overflow-x-auto rounded-2xl border border-slate-200/80">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50/90 text-slate-600 uppercase font-bold text-[11px] border-b border-slate-200">
                <tr>
                  <th className="p-3.5 pl-4">Kode Pos</th>
                  <th className="p-3.5">Nama Pos Pembayaran</th>
                  <th className="p-3.5">Frekuensi Penarikan</th>
                  <th className="p-3.5">Nominal Tarif</th>
                  <th className="p-3.5">Peruntukan Rombel</th>
                  <th className="p-3.5 text-center">Status Kewajiban</th>
                  <th className="p-3.5 pr-4 text-center">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {filteredTarif.map((t, idx) => (
                  <tr key={t.id || `${t.kode}-${t.kelas || ''}-${idx}`} className="hover:bg-slate-50/80 transition">
                    <td className="p-3.5 pl-4 font-mono font-bold text-indigo-600">{t.kode}</td>
                    <td className="p-3.5 font-bold text-slate-900 text-sm">{t.namaPos}</td>
                    <td className="p-3.5 text-slate-600">{t.frekuensi}</td>
                    <td className="p-3.5 font-black text-indigo-700 text-sm">
                      Rp {Number(t.nominal || 0).toLocaleString('id-ID')}
                    </td>
                    <td className="p-3.5 text-slate-600">{t.kelas}</td>
                    <td className="p-3.5 text-center">
                      <span className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] ${
                        t.status === 'Wajib' ? 'bg-indigo-50 text-indigo-700 border border-indigo-200' : 'bg-slate-100 text-slate-600'
                      }`}>
                        {t.status}
                      </span>
                    </td>
                    <td className="p-3.5 pr-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button
                          onClick={() => setViewDetailModal({
                            open: true,
                            title: `Detail Tarif: ${t.namaPos}`,
                            type: 'tarif',
                            data: {
                              'Kode Pos Biaya': t.kode,
                              'Nama Pos Tagihan': t.namaPos,
                              'Nominal Tarif': `Rp ${Number(t.nominal || 0).toLocaleString('id-ID')}`,
                              'Frekuensi Penarikan': t.frekuensi,
                              'Peruntukan Kelas': t.kelas,
                              'Kewajiban': t.status
                            }
                          })}
                          className="px-2 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                          title="Lihat Detail"
                        >
                          <Eye size={12} />
                          <span className="hidden sm:inline">Lihat</span>
                        </button>
                        <button
                          onClick={() => setEditModal({
                            open: true,
                            title: `Edit Tarif: ${t.namaPos}`,
                            type: 'tarif',
                            data: { ...t }
                          })}
                          className="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                          title="Edit Data"
                        >
                          <Edit size={12} />
                          <span className="hidden sm:inline">Edit</span>
                        </button>
                        <button
                          onClick={() => setDeleteModal({
                            open: true,
                            title: 'Hapus Pos Tarif',
                            id: t.id || t.kode,
                            name: t.namaPos,
                            type: 'tarif'
                          })}
                          className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                          title="Hapus Data"
                        >
                          <Trash2 size={12} />
                          <span className="hidden sm:inline">Hapus</span>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 7. Subtab VALIDASI DAPODIK 2027 */}
      {activeSubTab === 'dapodik-2027' && (
        <div className="bg-white p-6 rounded-3xl border border-slate-200/80 shadow-xs space-y-5">
          {/* Smart Filter Bar */}
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3 bg-slate-50/80 p-3.5 rounded-2xl border border-slate-200/70">
            <div className="flex flex-wrap items-center gap-2.5 w-full sm:w-auto flex-1">
              <div className="relative flex-1 sm:w-64">
                <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input 
                  type="text" 
                  placeholder="Cari nama siswa, NISN, NIK..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-8 py-2 bg-white border border-slate-200 rounded-xl text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                />
                {searchQuery && (
                  <button onClick={() => setSearchQuery('')} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600">
                    <X size={13} />
                  </button>
                )}
              </div>

              {distinctClasses.length > 0 && (
                <select
                  value={filterClass}
                  onChange={(e) => setFilterClass(e.target.value)}
                  className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                >
                  <option value="">Semua Kelas</option>
                  {distinctClasses.map(cls => (
                    <option key={cls} value={cls}>Kelas {cls}</option>
                  ))}
                </select>
              )}

              {/* Filter Tahun Masuk */}
              <select
                value={filterTahunMasuk}
                onChange={(e) => setFilterTahunMasuk(e.target.value)}
                className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-700 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
              >
                <option value="">📅 Semua Tahun Masuk</option>
                {distinctTahunMasuk.map(yr => (
                  <option key={yr} value={yr}>Thn Masuk {yr}</option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200">
                ✓ Validasi Dapodik 2027: Siap Sinkronisasi
              </span>
            </div>
          </div>

          {/* List Table with Action Buttons */}
          <div className="overflow-x-auto rounded-2xl border border-slate-200/80">
            <table className="w-full text-xs text-left">
              <thead className="bg-slate-50/90 text-slate-600 uppercase font-bold text-[11px] border-b border-slate-200">
                <tr>
                  <th className="p-3.5 pl-4">NISN</th>
                  <th className="p-3.5">Nama Lengkap Siswa</th>
                  <th className="p-3.5 text-center">Kelas</th>
                  <th className="p-3.5 text-center">Thn Masuk</th>
                  <th className="p-3.5">NIK Siswa</th>
                  <th className="p-3.5">No KK</th>
                  <th className="p-3.5">Ibu Kandung</th>
                  <th className="p-3.5 text-center">Status Dapodik</th>
                  <th className="p-3.5 pr-4 text-center">Aksi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-medium text-slate-700">
                {students
                  .filter(s => {
                    const q = String(searchQuery || '').toLowerCase();
                    const matchQ = !searchQuery || String(s.name || '').toLowerCase().includes(q) || String(s.nisn || '').includes(q) || String(s.nik || '').includes(q) || String(s.tahunMasuk || '').includes(q);
                    const matchC = !filterClass || s.class === filterClass;
                    const rawYr = String(s.tahunMasuk || (s as any)['TahunMasuk'] || (s as any)['ThnMasuk'] || (s as any)['tahun_masuk'] || '').trim();
                    const matchYr = rawYr.match(/\b(20\d{2}|19\d{2})\b/);
                    const normalizedYr = matchYr ? matchYr[1] : rawYr;
                    const matchT = !filterTahunMasuk || normalizedYr === filterTahunMasuk;
                    return matchQ && matchC && matchT;
                  })
                  .map((s) => {
                    const isComplete = s.nik && s.NamaIbu;
                    return (
                      <tr key={s.id} className="hover:bg-slate-50/80 transition">
                        <td className="p-3.5 pl-4 font-mono font-bold text-indigo-700">{s.nisn || '-'}</td>
                        <td className="p-3.5 font-bold text-slate-900">{s.name}</td>
                        <td className="p-3.5 text-center font-bold text-slate-700">{s.class}</td>
                        <td className="p-3.5 text-center font-mono font-bold text-indigo-800">
                          {s.tahunMasuk ? (
                            <span className="px-2 py-0.5 bg-indigo-50 border border-indigo-100 rounded-md">
                              {s.tahunMasuk}
                            </span>
                          ) : (
                            <span className="text-slate-400">-</span>
                          )}
                        </td>
                        <td className="p-3.5 font-mono">{s.nik || '-'}</td>
                        <td className="p-3.5 font-mono">{s.noKk || '-'}</td>
                        <td className="p-3.5 text-slate-800 font-semibold">{s.NamaIbu || '-'}</td>
                        <td className="p-3.5 text-center">
                          <span className={`px-2.5 py-0.5 rounded-full font-bold text-[10px] inline-flex items-center gap-1 ${
                            isComplete ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-amber-50 text-amber-700 border border-amber-200'
                          }`}>
                            <CheckCircle size={11} />
                            <span>{isComplete ? 'Valid 100%' : 'Data Cukup'}</span>
                          </span>
                        </td>
                        <td className="p-3.5 pr-4 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => setViewDetailModal({
                                open: true,
                                title: `Data Dapodik: ${s.name}`,
                                type: 'dapodik',
                                data: {
                                  'Nama Lengkap': s.name,
                                  'NISN': s.nisn || '-',
                                  'Kelas / Rombel': s.class,
                                  'Tahun Masuk': s.tahunMasuk || '-',
                                  'NIK Siswa': s.nik || '-',
                                  'No. Kartu Keluarga': s.noKk || '-',
                                  'Nama Ibu Kandung': s.NamaIbu || '-',
                                  'Nama Ayah Kandung': s.fatherName || '-',
                                  'Tempat, Tanggal Lahir': `${s.birthPlace || '-'}, ${s.birthDate || '-'}`,
                                  'Status Validasi': isComplete ? 'Lengkap 100% Sesuai Disdukcapil' : 'Perlu Kelengkapan NIK / Ibu'
                                }
                              })}
                              className="px-2 py-1 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                              title="Lihat Detail"
                            >
                              <Eye size={12} />
                              <span className="hidden sm:inline">Lihat</span>
                            </button>
                            <button
                              onClick={() => setEditModal({
                                open: true,
                                title: `Edit Data Dapodik: ${s.name}`,
                                type: 'dapodik',
                                data: {
                                  id: s.id,
                                  name: s.name,
                                  nisn: s.nisn || '',
                                  nik: s.nik || '',
                                  noKk: s.noKk || '',
                                  NamaIbu: s.NamaIbu || '',
                                  tahunMasuk: s.tahunMasuk || ''
                                }
                              })}
                              className="px-2 py-1 bg-amber-50 hover:bg-amber-100 text-amber-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                              title="Edit Data"
                            >
                              <Edit size={12} />
                              <span className="hidden sm:inline">Edit</span>
                            </button>
                            <button
                              onClick={() => setDeleteModal({
                                open: true,
                                title: 'Hapus Data Siswa & Dapodik',
                                id: s.id,
                                name: s.name,
                                type: 'dapodik'
                              })}
                              className="px-2 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 rounded-lg font-bold text-[11px] transition flex items-center gap-1"
                              title="Hapus Data"
                            >
                              <Trash2 size={12} />
                              <span className="hidden sm:inline">Hapus</span>
                            </button>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* UNIVERSAL DETAIL MODAL (LIHAT)                                            */}
      {/* ========================================================================= */}
      {viewDetailModal && viewDetailModal.open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-150 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                  <Eye size={18} />
                </div>
                <h3 className="text-base font-black text-slate-900">{viewDetailModal.title}</h3>
              </div>
              <button 
                onClick={() => setViewDetailModal(null)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition"
              >
                <X size={16} />
              </button>
            </div>

            <div className="space-y-2.5 max-h-[60vh] overflow-y-auto pr-1">
              {Object.entries(viewDetailModal.data).map(([key, value]) => (
                <div key={key} className="p-3 rounded-2xl bg-slate-50 border border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-1 text-xs">
                  <span className="font-bold text-slate-500">{key}</span>
                  <span className="font-extrabold text-slate-900 text-right">{String(value)}</span>
                </div>
              ))}
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => setViewDetailModal(null)}
                className="px-5 py-2.5 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800 transition"
              >
                Tutup Tampilan
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* UNIVERSAL EDIT MODAL (EDIT)                                              */}
      {/* ========================================================================= */}
      {editModal && editModal.open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-150 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center font-bold">
                  <Edit size={18} />
                </div>
                <h3 className="text-base font-black text-slate-900">{editModal.title}</h3>
              </div>
              <button 
                onClick={() => setEditModal(null)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-3.5 max-h-[60vh] overflow-y-auto pr-1">
              {Object.entries(editModal.data).filter(([key]) => key !== 'id').map(([key, value]) => (
                <div key={key} className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                    {key === 'kelasId' ? 'Kode / ID Kelas (contoh: A4, B7, C10)' :
                     key === 'cls' || key === 'namaKelas' ? 'Nama / Nomor Kelas (contoh: 4, 7, 10)' :
                     key === 'jenjangId' ? 'ID Jenjang (contoh: J001, J004, J007)' :
                     key === 'tingkat' ? 'Tingkat / Program (contoh: Paket A Kelas 4)' :
                     key === 'waliKelasId' ? 'ID Wali Kelas / GTK (contoh: GR_011)' :
                     key === 'namatutor' || key === 'wali' ? 'Nama Tutor / Wali Kelas' :
                     key === 'ruangan' ? 'Ruang Belajar (contoh: 1, 2, 3)' :
                     key === 'status' ? 'Status Rombel (AKTIF / ALUMNI)' :
                     key === 'kapasitas' ? 'Kapasitas Siswa Maksimal' :
                     key.replace(/([A-Z])/g, ' $1').trim()}
                  </label>
                  <input
                    type="text"
                    value={value !== undefined && value !== null ? String(value) : ''}
                    onChange={(e) => {
                      const val = e.target.value;
                      setEditModal(prev => prev ? {
                        ...prev,
                        data: { ...prev.data, [key]: val }
                      } : null);
                    }}
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                  />
                </div>
              ))}

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setEditModal(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center gap-1.5"
                >
                  <Save size={14} />
                  <span>Simpan Perubahan</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* UNIVERSAL ADD MODAL (+ TAMBAH)                                           */}
      {/* ========================================================================= */}
      {addModal && addModal.open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-150 space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-bold">
                  <Plus size={18} />
                </div>
                <h3 className="text-base font-black text-slate-900">{addModal.title}</h3>
              </div>
              <button 
                onClick={() => setAddModal(null)}
                className="w-8 h-8 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-500 flex items-center justify-center transition"
              >
                <X size={16} />
              </button>
            </div>

            <form onSubmit={handleSaveAdd} className="space-y-3.5 max-h-[60vh] overflow-y-auto pr-1">
              {Object.entries(addModal.data).map(([key, value]) => (
                <div key={key} className="space-y-1">
                  <label className="text-[11px] font-bold text-slate-600 uppercase tracking-wider">
                    {key === 'kelasId' ? 'Kode / ID Kelas (contoh: A4, B7, C10)' :
                     key === 'cls' || key === 'namaKelas' ? 'Nama / Nomor Kelas (contoh: 4, 7, 10)' :
                     key === 'jenjangId' ? 'ID Jenjang (contoh: J001, J004, J007)' :
                     key === 'tingkat' ? 'Tingkat / Program (contoh: Paket A Kelas 4)' :
                     key === 'waliKelasId' ? 'ID Wali Kelas / GTK (contoh: GR_011)' :
                     key === 'namatutor' || key === 'wali' ? 'Wali Kelas / Tutor Penanggung Jawab' :
                     key === 'ruangan' ? 'Ruang Belajar (contoh: 1, 2, 3)' :
                     key === 'status' ? 'Status Rombel (AKTIF / ALUMNI)' :
                     key === 'kapasitas' ? 'Kapasitas Siswa Maksimal' :
                     key === 'jp' ? 'Beban Jam Pelajaran (JP)' :
                     key === 'kkm' ? 'KKM / KKTP Minimal' :
                     key === 'namaPos' ? 'Nama Pos Tagihan' :
                     key === 'penanggungJawab' ? 'Penanggung Jawab Sarpras' :
                     key.replace(/([A-Z])/g, ' $1').trim()}
                  </label>
                  
                  {key === 'wali' || key === 'guru' || key === 'penanggungJawab' ? (
                    <select
                      value={String(value || '')}
                      onChange={(e) => {
                        const val = e.target.value;
                        setAddModal(prev => prev ? {
                          ...prev,
                          data: { ...prev.data, [key]: val }
                        } : null);
                      }}
                      className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                    >
                      <option value="">-- Pilih Guru / Tenaga Pendidik --</option>
                      {teachers.map((t, idx) => (
                        <option key={t.id ? `opt-teacher-${t.id}-${idx}` : `opt-teacher-${t.name}-${idx}`} value={t.name}>{t.name} ({t.class || 'GTK'})</option>
                      ))}
                    </select>
                  ) : key === 'kelas' ? (
                    <select
                      value={String(value || '')}
                      onChange={(e) => {
                        const val = e.target.value;
                        setAddModal(prev => prev ? {
                          ...prev,
                          data: { ...prev.data, [key]: val }
                        } : null);
                      }}
                      className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                    >
                      <option value="Semua Kelas">Semua Kelas</option>
                      {distinctClasses.map(c => (
                        <option key={c} value={`Kelas ${c}`}>Kelas {c}</option>
                      ))}
                    </select>
                  ) : key === 'kategori' && addModal.type === 'mapel' ? (
                    <select
                      value={String(value || '')}
                      onChange={(e) => {
                        const val = e.target.value;
                        setAddModal(prev => prev ? {
                          ...prev,
                          data: { ...prev.data, [key]: val }
                        } : null);
                      }}
                      className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                    >
                      <option value="Wajib Nasional">Wajib Nasional</option>
                      <option value="Muatan Lokal">Muatan Lokal</option>
                      <option value="Pilihan Khusus">Pilihan Khusus</option>
                    </select>
                  ) : key === 'frekuensi' ? (
                    <select
                      value={String(value || '')}
                      onChange={(e) => {
                        const val = e.target.value;
                        setAddModal(prev => prev ? {
                          ...prev,
                          data: { ...prev.data, [key]: val }
                        } : null);
                      }}
                      className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                    >
                      <option value="Bulanan">Bulanan</option>
                      <option value="Tahunan">Tahunan</option>
                      <option value="Insidental">Insidental</option>
                    </select>
                  ) : key === 'tanggal' ? (
                    <input
                      type="date"
                      value={String(value || '')}
                      onChange={(e) => {
                        const val = e.target.value;
                        setAddModal(prev => prev ? {
                          ...prev,
                          data: { ...prev.data, [key]: val }
                        } : null);
                      }}
                      className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                    />
                  ) : (
                    <input
                      type={key === 'nominal' || key === 'jumlah' || key === 'jp' || key === 'kkm' || key === 'kapasitas' ? 'number' : 'text'}
                      value={value !== undefined && value !== null ? String(value) : ''}
                      onChange={(e) => {
                        const val = e.target.value;
                        setAddModal(prev => prev ? {
                          ...prev,
                          data: { ...prev.data, [key]: val }
                        } : null);
                      }}
                      className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/20"
                    />
                  )}
                </div>
              ))}

              <div className="pt-3 flex items-center justify-end gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setAddModal(null)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center gap-1.5"
                >
                  <Save size={14} />
                  <span>Tambahkan Data</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* UNIVERSAL DELETE CONFIRMATION MODAL (HAPUS)                              */}
      {/* ========================================================================= */}
      {deleteModal && deleteModal.open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 duration-150 space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 text-rose-600 flex items-center justify-center mx-auto border border-rose-100">
              <AlertTriangle size={24} />
            </div>
            
            <div className="text-center space-y-1">
              <h3 className="text-base font-black text-slate-900">{deleteModal.title}</h3>
              <p className="text-xs text-slate-500">
                Apakah Anda yakin ingin menghapus data <strong className="text-slate-800">"{deleteModal.name}"</strong>? Data yang dihapus tidak dapat dipulihkan kembali.
              </p>
            </div>

            <div className="pt-2 flex items-center justify-center gap-2.5">
              <button
                type="button"
                onClick={() => setDeleteModal(null)}
                className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex-1"
              >
                Batal
              </button>
              <button
                type="button"
                onClick={handleConfirmDelete}
                className="px-4 py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-xs transition flex items-center justify-center gap-1.5 flex-1"
              >
                <Trash2 size={14} />
                <span>Ya, Hapus Data</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
