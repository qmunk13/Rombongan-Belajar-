import React, { useState, useRef, useEffect } from 'react';
import { useStore } from '../store';
import { Save, Copy, Check, Smartphone, Database, AlertCircle, Upload, Trash2, Image, Calendar, Download, FileJson, Link2, Folder, CloudUpload, CheckCircle2, ExternalLink, RefreshCw, ShieldAlert, FileSpreadsheet } from 'lucide-react';
import { GAS_TEMPLATE } from '../lib/constants';
import { fetchFromGAS, uploadFileToGAS } from '../lib/api';
import QRCode from "react-qr-code";
import { db } from '../data/db';
import { DEFAULT_APP_CONFIG } from '../data/config';
import { getGoogleDriveDirectImageUrl } from '../lib/utils';
import { MASTER_TABLES_60 } from '../data/masterDatabase60';
import { downloadMenuStructureExcel } from '../data/menuDataStructureExport';

export default function Settings() {
  const { settings, setSettings } = useStore();
  const [url, setUrl] = useState(settings.scriptUrl || DEFAULT_APP_CONFIG.scriptUrl);
  const [appName, setAppName] = useState((settings.appName && !settings.appName.toLowerCase().includes('citapen')) ? settings.appName : DEFAULT_APP_CONFIG.appName);
  const [schoolName, setSchoolName] = useState((settings.schoolName && !settings.schoolName.toLowerCase().includes('citapen')) ? settings.schoolName : DEFAULT_APP_CONFIG.schoolName);
  const [tahunPelajaran, setTahunPelajaran] = useState(settings.tahunPelajaran || DEFAULT_APP_CONFIG.tahunPelajaran);
  const [folderId, setFolderId] = useState(settings.folderId || DEFAULT_APP_CONFIG.folderId);
  const [folderSiswaId, setFolderSiswaId] = useState(settings.folderSiswaId || DEFAULT_APP_CONFIG.folderSiswaId);
  const [spreadsheetId, setSpreadsheetId] = useState(settings.spreadsheetId || DEFAULT_APP_CONFIG.spreadsheetId);
  const [adminUser, setAdminUser] = useState(settings.adminUsername || DEFAULT_APP_CONFIG.adminUsername);
  const [adminPass, setAdminPass] = useState(settings.adminPassword || DEFAULT_APP_CONFIG.adminPassword);
  const [schoolLogoUrl, setSchoolLogoUrl] = useState(settings.schoolLogoUrl || DEFAULT_APP_CONFIG.schoolLogoUrl);
  const [copied, setCopied] = useState(false);
  const [saveMessage, setSaveMessage] = useState('');
  const [initStatus, setInitStatus] = useState('');
  const [isInitializing, setIsInitializing] = useState(false);
  const [isSettingUpFolders, setIsSettingUpFolders] = useState(false);
  const [setupFolderResult, setSetupFolderResult] = useState<{ success: boolean; message: string; folders?: { name: string; desc: string; id: string; url: string }[] } | null>(null);
  const [isTestingUpload, setIsTestingUpload] = useState(false);
  const [testUploadResult, setTestUploadResult] = useState<{ success: boolean; message: string; url?: string } | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (settings.scriptUrl) setUrl(settings.scriptUrl);
    if (settings.tahunPelajaran) setTahunPelajaran(settings.tahunPelajaran);
    if (settings.folderId) setFolderId(settings.folderId);
    if (settings.folderSiswaId) setFolderSiswaId(settings.folderSiswaId);
    if (settings.spreadsheetId) setSpreadsheetId(settings.spreadsheetId);
    if (settings.schoolLogoUrl) setSchoolLogoUrl(settings.schoolLogoUrl);
    if (settings.schoolName) {
      setSchoolName(settings.schoolName.toLowerCase().includes('citapen') ? DEFAULT_APP_CONFIG.schoolName : settings.schoolName);
    }
    if (settings.appName) {
      setAppName(settings.appName.toLowerCase().includes('citapen') ? DEFAULT_APP_CONFIG.appName : settings.appName);
    }
  }, [settings.scriptUrl, settings.tahunPelajaran, settings.schoolName, settings.appName, settings.folderId, settings.folderSiswaId, settings.spreadsheetId, settings.schoolLogoUrl]);

  const shareConfigUrl = settings.scriptUrl ? `${window.location.origin}${window.location.pathname}?config=${encodeURIComponent(btoa(JSON.stringify({ scriptUrl: settings.scriptUrl, folderId: settings.folderId, folderSiswaId: settings.folderSiswaId, appName: settings.appName, adminUsername: settings.adminUsername, adminPassword: settings.adminPassword, tahunPelajaran: settings.tahunPelajaran, schoolName: settings.schoolName })))}` : '';

  const handleSave = async () => {
    const updatedSettings = { 
      ...settings, 
      scriptUrl: url.trim(), 
      appName: appName.trim(), 
      schoolName: schoolName.trim(),
      tahunPelajaran: tahunPelajaran.trim(),
      folderId: folderId.trim(), 
      folderSiswaId: folderSiswaId.trim(),
      spreadsheetId: spreadsheetId.trim(),
      adminUsername: adminUser.trim(), 
      adminPassword: adminPass,
      schoolLogoUrl
    };
    
    setSettings(updatedSettings);
    setSaveMessage("✅ Pengaturan Berhasil Disimpan & Dipatenkan!");
    
    // Persist to server backend so any device can load it
    fetch('/api/settings', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(updatedSettings),
    })
    .then(() => {
      setSaveMessage("✅ Pengaturan Berhasil Disimpan Global & Server!");
    })
    .catch((e) => {
      console.error("Failed to save settings on server:", e);
      setSaveMessage("Pengaturan Disimpan Lokal (Gagal sinkron server)");
    });

    // Auto-sync ke Sheet SETTING jika URL GAS tersedia
    if (url.trim()) {
      try {
        const settingRows = Object.keys(updatedSettings).map(k => ({
          Key: k,
          Value: typeof (updatedSettings as any)[k] === 'object' ? JSON.stringify((updatedSettings as any)[k]) : String((updatedSettings as any)[k] ?? '')
        }));
        await fetchFromGAS(url.trim(), {
          action: 'syncTable',
          table: 'SETTING',
          data: settingRows
        });
        setSaveMessage("✅ Pengaturan Disimpan & Disinkronkan ke Spreadsheet (Sheet SETTING)!");
      } catch (err) {
        console.warn("GAS Setting Sync optional error:", err);
      }
    }

    setTimeout(() => setSaveMessage(''), 4500);
  };

  const handleResetToDefaults = () => {
    setUrl(DEFAULT_APP_CONFIG.scriptUrl);
    setAppName(DEFAULT_APP_CONFIG.appName);
    setSchoolName(DEFAULT_APP_CONFIG.schoolName);
    setFolderId(DEFAULT_APP_CONFIG.folderId);
    setFolderSiswaId(DEFAULT_APP_CONFIG.folderSiswaId);
    setSpreadsheetId(DEFAULT_APP_CONFIG.spreadsheetId);
    setSchoolLogoUrl(DEFAULT_APP_CONFIG.schoolLogoUrl);
    setTahunPelajaran(DEFAULT_APP_CONFIG.tahunPelajaran);
    setAdminUser(DEFAULT_APP_CONFIG.adminUsername);
    setAdminPass(DEFAULT_APP_CONFIG.adminPassword);

    const defaultObj = {
      ...settings,
      ...DEFAULT_APP_CONFIG
    };
    setSettings(defaultObj);
    fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(defaultObj),
    });
    setSaveMessage("Pengaturan telah dikembalikan ke Default Paten Lembaga!");
    setTimeout(() => setSaveMessage(''), 4000);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 1.5 * 1024 * 1024) { // 1.5MB limit
      alert("Ukuran gambar terlalu besar. Maksimal 1.5MB untuk performa optimal.");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      setSchoolLogoUrl(base64);
    };
    reader.readAsDataURL(file);
  };

  const handleRemoveLogo = () => {
    setSchoolLogoUrl('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleInitializeDatabase = async () => {
    if (!url) {
      setInitStatus("Harap masukkan URL Google Apps Script terlebih dahulu.");
      setTimeout(() => setInitStatus(''), 4000);
      return;
    }
    try {
      setIsInitializing(true);
      setInitStatus('Sedang membuat & memformat seluruh Sheet Master Database secara otomatis...');
      const res = await fetchFromGAS(url, { action: 'setup' });
      if (res && (res.success || !res.error)) {
        setInitStatus('Sukses! Seluruh Sheet Master Database berhasil dibuat & diformat otomatis di Google Sheets.');
        setTimeout(() => setInitStatus(''), 6000);
      } else {
        throw new Error(res?.error || "Gagal membuat sheet");
      }
    } catch (e: any) {
      setInitStatus('Gagal: ' + e.message);
      setTimeout(() => setInitStatus(''), 6000);
    } finally {
      setIsInitializing(false);
    }
  };

  const handleSetupDriveFolders = async () => {
    if (!url) {
      setSetupFolderResult({ success: false, message: "Harap masukkan URL Google Apps Script terlebih dahulu." });
      return;
    }

    try {
      setIsSettingUpFolders(true);
      setSetupFolderResult(null);

      const res = await fetchFromGAS(url, {
        action: 'setupDriveFolders',
        folderId: folderId || 'BERKAS_SISWA_MASTER',
        folderName: 'BERKAS_SISWA_MASTER'
      });

      if (res && res.success) {
        setSetupFolderResult({
          success: true,
          message: res.message || "11 Sub-Folder Master Google Drive berhasil dibuat & dirapikan!",
          folders: res.folders
        });
      } else {
        throw new Error(res?.error || "Gagal membuat sub-folder di Google Drive");
      }
    } catch (e: any) {
      console.error("Setup folders failed:", e);
      let advice = "";
      const errMsg = String(e.message || e);
      if (errMsg.includes("DriveApp") || errMsg.includes("izin") || errMsg.includes("permission") || errMsg.includes("Access denied")) {
        advice = " 💡 Solusi: Buka editor Google Apps Script, pilih fungsi 'otorisasiDrive', klik 'Jalankan (Run ▶)' lalu izinkan Google Drive.";
      }
      setSetupFolderResult({
        success: false,
        message: `Gagal membuat struktur folder: ${errMsg}.${advice}`
      });
    } finally {
      setIsSettingUpFolders(false);
    }
  };

  const handleTestDriveUpload = async () => {
    if (!url) {
      setTestUploadResult({ success: false, message: "Harap masukkan URL Google Apps Script terlebih dahulu." });
      return;
    }

    try {
      setIsTestingUpload(true);
      setTestUploadResult(null);

      // Create a dummy small text file for test
      const testContent = `UJI_KONEKSI_GOOGLE_DRIVE\nWaktu: ${new Date().toLocaleString('id-ID')}\nStatus: Koneksi Web App & DriveApp Berhasil!`;
      const testBlob = new Blob([testContent], { type: 'text/plain' });
      const testFile = new File([testBlob], `test_koneksi_drive_${Date.now().toString().slice(-4)}.txt`, { type: 'text/plain' });

      const res = await uploadFileToGAS(
        url,
        testFile,
        folderId || 'SI_Siswa_Uploads',
        `Tes_Koneksi_Drive_${Date.now().toString().slice(-4)}.txt`
      );

      if (res && res.success && res.url) {
        setTestUploadResult({
          success: true,
          message: "Koneksi & Upload Google Drive BERHASIL 100%! Berkas tes berhasil tersimpan di Google Drive Anda.",
          url: res.url
        });
      } else {
        throw new Error((res as any)?.error || "Gagal mendapatkan URL file dari Google Apps Script");
      }
    } catch (e: any) {
      console.error("Test upload failed:", e);
      let advice = "";
      const errMsg = String(e.message || e);
      if (errMsg.includes("DriveApp") || errMsg.includes("izin") || errMsg.includes("permission") || errMsg.includes("Access denied")) {
        advice = " 💡 Solusi: Izin DriveApp belum aktif. Buka editor Google Apps Script, pilih fungsi 'setup' di toolbar atas, klik 'Jalankan (Run)', lalu berikan izin Google Drive. Setelah itu klik 'Deploy > New deployment'.";
      } else if (errMsg.includes("HTML") || errMsg.includes("404") || errMsg.includes("Failed to fetch")) {
        advice = " 💡 Solusi: Pastikan Web App di-deploy dengan 'Execute as: Me (Saya)' dan 'Who has access: Anyone (Siapa saja)'.";
      }
      setTestUploadResult({
        success: false,
        message: `Gagal mengunggah berkas: ${errMsg}.${advice}`
      });
    } finally {
      setIsTestingUpload(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(GAS_TEMPLATE);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-10">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white/80 p-5 rounded-3xl border border-indigo-100 shadow-sm">
        <div>
          <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-indigo-950">Integrasi & Pengaturan GAS</h2>
          <p className="text-slate-500 mt-1 text-xs sm:text-sm font-medium">Konfigurasi database master dengan Google Apps Script & Google Spreadsheet.</p>
        </div>
        <button
          type="button"
          onClick={downloadMenuStructureExcel}
          className="flex items-center gap-2 px-5 py-3 bg-amber-500 hover:bg-amber-400 active:scale-95 text-slate-950 font-black rounded-2xl text-xs sm:text-sm shadow-md shadow-amber-500/20 transition cursor-pointer border border-amber-400"
          title="Download file Excel pemetaan tabel dan menu lengkap"
        >
          <FileSpreadsheet size={18} />
          <span>DOWNLOAD EXCEL STRUKTUR DATA</span>
        </button>
      </div>

      <div className="bg-white/70 backdrop-blur-2xl p-5 sm:p-8 rounded-3xl sm:rounded-[2rem] border border-white/90 shadow-lg">
        <h3 className="text-xl font-bold mb-6 text-indigo-900">Konfigurasi Umum</h3>
        <div className="space-y-4 mb-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="label">Nama Aplikasi</label>
              <input 
                type="text" 
                className="input w-full text-sm sm:text-base font-semibold" 
                placeholder="Contoh: ERP ROMBEL TAMBORA"
                value={appName}
                onChange={(e) => setAppName(e.target.value)}
              />
            </div>
            <div>
              <label className="label">Nama Lembaga / Rombel</label>
              <input 
                type="text" 
                className="input w-full text-sm sm:text-base font-semibold" 
                placeholder="Contoh: ROMBEL KTCT TAMBORA"
                value={schoolName}
                onChange={(e) => setSchoolName(e.target.value)}
              />
            </div>
          </div>

          {/* Tahun Pelajaran (Ajaran) */}
          <div className="p-4 rounded-2xl bg-indigo-50/50 border border-indigo-100 space-y-3">
            <div className="flex items-center justify-between gap-2">
              <label className="label text-indigo-900 font-bold flex items-center gap-2 mb-0">
                <Calendar size={18} className="text-indigo-600" />
                Tahun Pelajaran (Ajaran)
              </label>
              <span className="text-[11px] font-bold text-indigo-600 bg-indigo-100 px-2.5 py-0.5 rounded-full">
                Aktif: {tahunPelajaran || '2026/2027'}
              </span>
            </div>
            <div className="flex flex-col sm:flex-row gap-3 items-center">
              <input 
                type="text" 
                className="input w-full sm:w-1/2 text-sm sm:text-base font-extrabold text-indigo-950 bg-white" 
                placeholder="Contoh: 2026/2027"
                value={tahunPelajaran}
                onChange={(e) => setTahunPelajaran(e.target.value)}
              />
              <div className="flex flex-wrap gap-1.5 w-full sm:w-auto">
                {['2024/2025', '2025/2026', '2026/2027', '2027/2028'].map((year) => (
                  <button
                    key={year}
                    type="button"
                    onClick={() => setTahunPelajaran(year)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-bold transition active:scale-95 ${
                      tahunPelajaran === year
                        ? 'bg-indigo-600 text-white shadow-xs'
                        : 'bg-white text-indigo-800 hover:bg-indigo-100 border border-indigo-200'
                    }`}
                  >
                    {year}
                  </button>
                ))}
              </div>
            </div>
            <p className="text-xs text-indigo-700/80">
              Tahun pelajaran ini akan digunakan secara otomatis pada cetak daftar hadir, legger nilai, dokumen administrasi, serta rekapitulasi data.
            </p>
          </div>
          <div>
            <label className="label">Logo Lembaga</label>
            <div className="flex flex-col sm:flex-row items-center gap-4 p-4 rounded-2xl bg-indigo-50/30 border border-indigo-100/50">
              <div className="w-20 h-20 bg-white rounded-2xl flex items-center justify-center border border-indigo-100 shadow-sm overflow-hidden flex-shrink-0">
                {schoolLogoUrl ? (
                  <img src={schoolLogoUrl} alt="Logo Lembaga" className="w-full h-full object-cover animate-in fade-in duration-200" referrerPolicy="no-referrer" />
                ) : (
                  <Image className="w-8 h-8 text-indigo-300" />
                )}
              </div>
              
              <div className="flex-1 space-y-2 text-center sm:text-left w-full">
                <p className="text-xs font-semibold text-gray-500">
                  {schoolLogoUrl ? 'Logo lembaga aktif' : 'Gunakan logo kustom lembaga Anda'}
                </p>
                <p className="text-[10px] text-gray-400">Format yang didukung: PNG, JPG, GIF (Maks. 1.5MB)</p>
                <div className="flex items-center justify-center sm:justify-start gap-2">
                  <input 
                    type="file" 
                    accept="image/*" 
                    ref={fileInputRef} 
                    onChange={handleLogoUpload} 
                    className="hidden" 
                  />
                  <button 
                    type="button" 
                    onClick={() => fileInputRef.current?.click()} 
                    className="flex items-center gap-1.5 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition shadow-sm active:scale-95 duration-100"
                  >
                    <Upload size={14} /> Pilih Gambar
                  </button>
                  {schoolLogoUrl && (
                    <button 
                      type="button" 
                      onClick={handleRemoveLogo} 
                      className="flex items-center gap-1.5 px-3.5 py-2 bg-rose-50 hover:bg-rose-100 text-rose-600 rounded-xl text-xs font-bold transition active:scale-95 duration-100"
                    >
                      <Trash2 size={14} /> Hapus
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="label">Username Login</label>
              <input 
                type="text" 
                className="input w-full text-sm sm:text-base" 
                placeholder="admin"
                value={adminUser}
                onChange={(e) => setAdminUser(e.target.value)}
              />
            </div>
            <div>
              <label className="label">Password Login</label>
              <input 
                type="password" 
                className="input w-full text-sm sm:text-base" 
                placeholder="admin"
                value={adminPass}
                onChange={(e) => setAdminPass(e.target.value)}
              />
            </div>
          </div>
        </div>

        <h3 className="text-xl font-bold mb-6 text-indigo-900">Integrasi Google Sheets & Drive (Paten Terhubung)</h3>
        
        <div className="space-y-4">
          <div>
            <label className="label">Google Apps Script Web App URL</label>
            <input 
              type="text" 
              className="input w-full text-sm sm:text-base font-mono" 
              placeholder="https://script.google.com/macros/s/.../exec"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
            />
            <p className="text-xs text-gray-500 mt-1.5">URL Web App resmi Google Apps Script untuk sinkronisasi seluruh ({MASTER_TABLES_60.length}) tabel master database.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="label">Spreadsheet ID</label>
              <input 
                type="text" 
                className="input w-full text-sm sm:text-base font-mono" 
                placeholder="1sT0_RCMEbLAfZVj3fTHXgWLHJBoKWKF-WdqbjbjzwLc"
                value={spreadsheetId}
                onChange={(e) => setSpreadsheetId(e.target.value)}
              />
              <div className="mt-1.5 flex items-center justify-between">
                <p className="text-[11px] text-gray-500">ID Google Spreadsheet utama</p>
                {spreadsheetId && (
                  <a 
                    href={`https://docs.google.com/spreadsheets/d/${spreadsheetId}/edit`} 
                    target="_blank" 
                    rel="noreferrer" 
                    className="text-[11px] font-bold text-indigo-600 hover:underline flex items-center gap-1"
                  >
                    <Link2 size={12} /> Buka Sheet
                  </a>
                )}
              </div>
            </div>

            <div>
              <label className="label">Folder ID Google Drive (Root / Utama)</label>
              <input 
                type="text" 
                className="input w-full text-sm sm:text-base font-mono" 
                placeholder="13W6zz_g_nN-zGJdbquP4H4NvXrZZLk0j"
                value={folderId}
                onChange={(e) => setFolderId(e.target.value)}
              />
              <div className="mt-1.5 flex items-center justify-between">
                <p className="text-[11px] text-gray-500">Folder utama simpan sistem & backup</p>
                {folderId && (
                  <a 
                    href={`https://drive.google.com/drive/folders/${folderId}`} 
                    target="_blank" 
                    rel="noreferrer" 
                    className="text-[11px] font-bold text-indigo-600 hover:underline flex items-center gap-1"
                  >
                    <Folder size={12} /> Buka Folder
                  </a>
                )}
              </div>
            </div>

            <div>
              <label className="label">Folder ID Berkas Siswa</label>
              <input 
                type="text" 
                className="input w-full text-sm sm:text-base font-mono" 
                placeholder="1DfCtp8BbsRzFafEa8fk30Suq-aVQoS7V"
                value={folderSiswaId}
                onChange={(e) => setFolderSiswaId(e.target.value)}
              />
              <div className="mt-1.5 flex items-center justify-between">
                <p className="text-[11px] text-gray-500">Folder khusus simpan berkas dokumen siswa</p>
                {folderSiswaId && (
                  <a 
                    href={`https://drive.google.com/drive/folders/${folderSiswaId}`} 
                    target="_blank" 
                    rel="noreferrer" 
                    className="text-[11px] font-bold text-indigo-600 hover:underline flex items-center gap-1"
                  >
                    <Folder size={12} /> Buka Folder Berkas
                  </a>
                )}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap gap-3 items-stretch sm:items-center pt-2">
            <button onClick={handleSave} className="btn w-full sm:w-auto">
              <Save size={18} />
              Simpan & Patenkan
            </button>

            <button 
              type="button"
              onClick={handleResetToDefaults} 
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 active:scale-95"
              title="Reset ke nilai paten Rombel Tambora"
            >
              <Check size={14} />
              Pulihkan Default Paten (Rombel Tambora)
            </button>

            {saveMessage && (
              <span className="p-2 px-4 rounded-xl bg-green-100 border border-green-200 text-green-700 text-sm font-semibold flex items-center gap-1.5 animate-pulse">
                <Check size={16} />
                {saveMessage}
              </span>
            )}
          </div>

          {/* Backup & Restore LocalStorage / Data Browser */}
          <div className="mt-6 p-6 rounded-2xl bg-slate-50 border border-slate-200 space-y-4">
            <div>
              <h4 className="font-bold text-slate-900 flex items-center gap-2">
                <FileJson size={18} className="text-indigo-600" />
                Backup, Restore & Ganti LocalStorage Browser
              </h4>
              <p className="text-xs text-slate-500 mt-1 leading-relaxed">
                Anda dapat mereset data memori sistem kapan saja atau mengosongkan tabel data untuk sinkronisasi ulang dengan Google Sheets.
              </p>
            </div>

            <div className="flex flex-wrap gap-2.5 items-center">
              {/* Reset Simulasi */}
              <button 
                type="button"
                onClick={() => {
                  if (window.confirm("Kosongkan semua data memori sistem (Sarpras, Keuangan, BK, Berita, Agenda, Dokumen)?")) {
                    db.purgeSimulationData();
                    alert("Semua data berhasil dikosongkan.");
                    window.location.reload();
                  }
                }}
                className="px-3.5 py-2.5 bg-amber-50 hover:bg-amber-100 text-amber-700 border border-amber-200 rounded-xl text-xs font-bold transition flex items-center gap-1.5 active:scale-95"
              >
                <Trash2 size={15} />
                Kosongkan Data Memori
              </button>

              {/* Reset Total */}
              <button 
                type="button"
                onClick={() => {
                  if (window.confirm("Apakah Anda yakin ingin MENGHAPUS SEMUA DATA CACHE & MEMORI sistem? Aplikasi akan dimuat ulang dari awal yang bersih.")) {
                    db.clearAll();
                    window.location.reload();
                  }
                }}
                className="px-3.5 py-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded-xl text-xs font-bold transition flex items-center gap-1.5 active:scale-95"
              >
                <Trash2 size={15} />
                Reset Total Sistem
              </button>
            </div>
          </div>

          {/* Fitur Uji Koneksi & Upload Google Drive */}
          <div className="mt-6 p-6 rounded-2xl bg-amber-50/60 border border-amber-200/80 space-y-4">
            <div>
              <h4 className="font-bold text-amber-950 flex items-center gap-2">
                <CloudUpload size={18} className="text-amber-600" />
                Uji Koneksi & Upload Berkas ke Google Drive
              </h4>
              <p className="text-xs text-amber-800/90 mt-1 leading-relaxed">
                Gunakan tombol di bawah ini untuk menguji secara instan apakah Google Apps Script dan Folder ID Google Drive Anda sudah terhubung serta memiliki izin upload berkas (pas foto, akta, KK, ijazah, rapor, dll).
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center">
              <button 
                type="button"
                onClick={handleTestDriveUpload} 
                disabled={isTestingUpload}
                className="btn w-full sm:w-auto bg-amber-600 hover:bg-amber-700 text-white disabled:bg-amber-300 font-bold text-xs"
              >
                {isTestingUpload ? (
                  <>
                    <RefreshCw size={14} className="animate-spin" />
                    Menguji Upload ke Google Drive...
                  </>
                ) : (
                  <>
                    <CloudUpload size={16} />
                    Tes Upload Berkas Sekarang
                  </>
                )}
              </button>

              {testUploadResult && (
                <div className={`p-3 px-4 rounded-xl text-xs font-semibold flex items-center gap-2 flex-1 ${
                  testUploadResult.success 
                    ? 'bg-emerald-100 border border-emerald-300 text-emerald-800' 
                    : 'bg-rose-100 border border-rose-300 text-rose-800'
                }`}>
                  {testUploadResult.success ? <CheckCircle2 size={16} className="shrink-0 text-emerald-700" /> : <AlertCircle size={16} className="shrink-0 text-rose-700" />}
                  <div className="flex-1">
                    <span>{testUploadResult.message}</span>
                    {testUploadResult.url && (
                      <div className="mt-1">
                        <a href={testUploadResult.url} target="_blank" rel="noreferrer" className="underline font-bold text-indigo-700 hover:text-indigo-900 inline-flex items-center gap-1">
                          <ExternalLink size={12} /> Buka Berkas Tes di Google Drive ↗
                        </a>
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Fitur Otomatisasi 11 Sub-Folder Google Drive */}
          <div className="mt-6 p-6 rounded-2xl bg-teal-50/60 border border-teal-200/80 space-y-4">
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div>
                <h4 className="font-bold text-teal-950 flex items-center gap-2">
                  <Folder size={18} className="text-teal-600" />
                  Struktur 11 Sub-Folder Master Google Drive (Anti-Berantakan)
                </h4>
                <p className="text-xs text-teal-800/90 mt-1 leading-relaxed">
                  Sistem akan membuat & menata hierarki folder digital sekolah secara otomatis di Google Drive Anda agar berkas siswa, guru, kegiatan bulanan, keuangan, sarpras, dan akreditasi tidak tercampur.
                </p>
              </div>

              <button 
                type="button"
                onClick={handleSetupDriveFolders}
                disabled={isSettingUpFolders}
                className="btn w-full sm:w-auto bg-teal-600 hover:bg-teal-700 text-white disabled:bg-teal-300 font-bold text-xs shrink-0 active:scale-95 shadow-sm"
              >
                {isSettingUpFolders ? (
                  <>
                    <RefreshCw size={14} className="animate-spin" />
                    Menata Folder di Drive...
                  </>
                ) : (
                  <>
                    <Folder size={15} />
                    Inisialisasi 11 Folder Drive
                  </>
                )}
              </button>
            </div>

            {setupFolderResult && (
              <div className={`p-4 rounded-xl text-xs font-semibold flex flex-col gap-2 ${
                setupFolderResult.success 
                  ? 'bg-emerald-100 border border-emerald-300 text-emerald-900' 
                  : 'bg-rose-100 border border-rose-300 text-rose-800'
              }`}>
                <div className="flex items-center gap-2">
                  {setupFolderResult.success ? <CheckCircle2 size={16} className="shrink-0 text-emerald-700" /> : <AlertCircle size={16} className="shrink-0 text-rose-700" />}
                  <span>{setupFolderResult.message}</span>
                </div>
                {setupFolderResult.folders && setupFolderResult.folders.length > 0 && (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-2 pt-2 border-t border-emerald-200">
                    {setupFolderResult.folders.map(f => (
                      <a 
                        key={f.id} 
                        href={f.url} 
                        target="_blank" 
                        rel="noreferrer" 
                        className="p-2 bg-white/80 hover:bg-white rounded-lg border border-emerald-200 text-emerald-900 flex items-center justify-between gap-1 transition"
                      >
                        <span className="font-mono font-bold truncate text-[11px]">📁 {f.name}</span>
                        <ExternalLink size={12} className="text-emerald-600 shrink-0" />
                      </a>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* Folder Previews Map */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 pt-2">
              {[
                { name: '01_BERKAS_SISWA_AKTIF', rule: '[NOPDKT] Nama Siswa', desc: 'Akta, KK, KIA, Ijazah, Rapor' },
                { name: '02_BERKAS_GURU_GTK', rule: '[NIP] Nama Lengkap', desc: 'SK, Ijazah S1/S2, Sertifikat Pendidik' },
                { name: '03_AKADEMIK_DAN_KURIKULUM', rule: 'TA_[Tahun] / [Kelas]', desc: 'Arsip Rapor, Leger Nilai & Modul' },
                { name: '04_KEUANGAN_DAN_TAGIHAN', rule: 'Periode_[YYYY-MM]', desc: 'Kwitansi Kasir, Tagihan & Dokumen BOS' },
                { name: '05_SARANA_PRASARANA', rule: '[Kategori_Ruang]', desc: 'Inventaris Barang & Foto Bangunan' },
                { name: '06_DOKUMEN_KEGIATAN', rule: '[YYYY-MM] Nama Kegiatan', desc: 'Foto & Video Dokumentasi Acara' },
                { name: '07_PENGUMUMAN_DAN_EDARAN', rule: '[YYYY-MM] Judul', desc: 'Surat Edaran & Pengumuman Resmi' },
                { name: '08_PERSURATAN_DAN_TU', rule: '[Jenis]_[Tahun]', desc: 'Arsip Surat Masuk & Surat Keluar' },
                { name: '09_SPMB_PENDAFTARAN', rule: '[NoDaftar] Nama Calon', desc: 'Arsip Berkas Pendaftar PPDB Online' },
                { name: '10_ARSIP_AKREDITASI_BANSM', rule: '[Komponen_IASP]', desc: 'Dokumen 8 Standar Nasional & IASP' },
                { name: '11_CBT_DAN_BANK_SOAL', rule: '[Mapel_Ujian]', desc: 'Bank Soal, Kisi-kisi & Naskah Soal' },
              ].map((item, idx) => (
                <div key={idx} className="bg-white/80 p-3 rounded-xl border border-teal-100 shadow-xs flex flex-col justify-between">
                  <div>
                    <div className="flex items-center gap-1.5 font-bold text-teal-950 text-xs">
                      <span className="w-2 h-2 rounded-full bg-teal-500"></span>
                      <span className="font-mono">{item.name}</span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-1 leading-snug">{item.desc}</p>
                  </div>
                  <div className="mt-2 pt-1.5 border-t border-slate-100 text-[10px] font-mono text-teal-700 bg-teal-50/50 px-2 py-0.5 rounded-md inline-block">
                    Format: {item.rule}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Fitur Pembuatan Sheet Otomatis */}
          <div className="mt-6 p-6 rounded-2xl bg-indigo-50/50 border border-indigo-100 space-y-4">
            <div>
              <h4 className="font-bold text-indigo-900 flex items-center gap-2">
                <Database size={18} className="text-indigo-600" />
                Pembuatan {MASTER_TABLES_60.length} Sheet Master Database Otomatis (Anti-Error)
              </h4>
              <p className="text-xs text-indigo-700/80 mt-1 leading-relaxed">
                Sistem akan secara otomatis membuat dan menata <strong>{MASTER_TABLES_60.length} Sheet Master Database Lengkap</strong> (Termasuk SISWA, GURU, KELAS, ABSENSI, CBT, KEUANGAN, SPMB, DAPODIK, SUARA_KOMUNITAS, TABUNGAN, dll) dengan header tebal, freeze row, dan format warna siap pakai di Google Spreadsheet Anda.
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center">
              <button 
                type="button"
                onClick={handleInitializeDatabase} 
                disabled={isInitializing}
                className="btn w-full sm:w-auto bg-indigo-600 hover:bg-indigo-700 text-white disabled:bg-indigo-300"
              >
                {isInitializing ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    Membuat {MASTER_TABLES_60.length} Sheet...
                  </>
                ) : (
                  <>
                    <Database size={16} />
                    Buat {MASTER_TABLES_60.length} Sheet Otomatis Sekarang
                  </>
                )}
              </button>

              {initStatus && (
                <span className={`p-2 px-4 rounded-xl text-sm font-medium flex items-center gap-1.5 ${
                  initStatus.startsWith('Gagal') 
                    ? 'bg-rose-100 border border-rose-200 text-rose-700' 
                    : initStatus.startsWith('Sukses')
                    ? 'bg-emerald-100 border border-emerald-200 text-emerald-700'
                    : 'bg-indigo-100 border border-indigo-200 text-indigo-700 animate-pulse'
                }`}>
                  <AlertCircle size={16} />
                  {initStatus}
                </span>
              )}
            </div>
          </div>
        </div>

        {shareConfigUrl && (
          <div className="mt-8 pt-8 border-t border-white/40">
            <h3 className="text-xl font-bold mb-4 text-indigo-900 flex items-center gap-2">
              <Smartphone size={24} className="text-indigo-600" />
              Hubungkan ke Handphone Anda
            </h3>
            <div className="bg-indigo-50/50 p-6 rounded-2xl border border-indigo-100 flex flex-col md:flex-row items-center gap-8">
              <div className="flex-shrink-0 bg-white p-3 rounded-2xl shadow-sm border border-indigo-50">
                <QRCode value={shareConfigUrl} size={150} level="M" />
              </div>
              <div>
                <h4 className="font-bold text-indigo-900 mb-2">Sinkronisasi Super Cepat!</h4>
                <p className="text-sm text-indigo-700/80 mb-4 leading-relaxed">
                  Buka aplikasi kamera atau pemindai (scanner) di Handphone Anda, dan scan QR Code di samping untuk membuka aplikasi versi Mobile. Konfigurasi Google Sheets Anda akan otomatis tersinkronisasi.
                </p>
                <div className="flex bg-white border border-indigo-100 rounded-lg overflow-hidden relative">
                  <input type="text" readOnly value={shareConfigUrl} className="w-full text-xs text-slate-500 p-2 outline-none cursor-text" />
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="mt-8 pt-8 border-t border-white/40">
          {/* Banner Solusi Error DriveApp */}
          <div className="mb-6 p-5 rounded-2xl bg-amber-500/10 border-2 border-amber-500/30 text-amber-950">
            <h4 className="font-bold text-base flex items-center gap-2 text-amber-900">
              <ShieldAlert className="text-amber-600" size={20} />
              Solusi Mengatasi Error: "Akses ditolak: DriveApp" (Izin Google Drive)
            </h4>
            <p className="text-xs text-amber-900/80 mt-1 leading-relaxed">
              Jika saat upload berkas muncul pesan <em>"Exception: Akses ditolak: DriveApp"</em>, hal ini terjadi karena Google Apps Script belum diberikan izin untuk mengakses Google Drive Anda. Ikuti 3 langkah mudah berikut:
            </p>
            <div className="mt-3 grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
              <div className="p-3 bg-white rounded-xl border border-amber-200 shadow-xs">
                <span className="font-bold text-amber-800 block mb-1">1. Buka Apps Script</span>
                Buka Spreadsheet Google Anda, klik menu <strong>Ekstensi &gt; Apps Script</strong>, dan pastikan kode di bawah sudah Anda paste.
              </div>
              <div className="p-3 bg-white rounded-xl border border-amber-200 shadow-xs">
                <span className="font-bold text-amber-800 block mb-1">2. Jalankan 'otorisasiDrive'</span>
                Di toolbar atas Apps Script, pilih fungsi <strong>otorisasiDrive</strong>, lalu klik tombol <strong>Jalankan (Run ▶)</strong>. Klik <em>Tinjau Izin &gt; Akun Anda &gt; Lanjutan &gt; Buka project (tidak aman) &gt; Izinkan</em>.
              </div>
              <div className="p-3 bg-white rounded-xl border border-amber-200 shadow-xs">
                <span className="font-bold text-amber-800 block mb-1">3. Terapkan Versi Baru</span>
                Klik <strong>Deploy (Terapkan) &gt; Deployment Baru</strong>. Pilih jenis <strong>Aplikasi Web</strong>, pastikan <em>Jalankan sebagai: Saya</em> dan <em>Akses: Siapa saja</em>, lalu klik <strong>Terapkan</strong>.
              </div>
            </div>
          </div>

          <h4 className="font-semibold text-indigo-900 mb-3 text-lg">Panduan Instalasi Script</h4>
          <ol className="list-decimal list-inside text-sm text-gray-600 space-y-2 mb-6 leading-relaxed">
            <li>Buat Google Spreadsheet baru di Google Drive Anda.</li>
            <li>Klik menu <strong>Ekstensi</strong> {'>'} <strong>Apps Script</strong>.</li>
            <li>Hapus semua kode yang ada, copy paste kode di bawah ini <b>(Pastikan menyalin kode terbaru ini)</b>.</li>
            <li>Klik tombol <strong>Simpan</strong> (ikon Disket).</li>
            <li className="text-rose-600 font-bold">SANGAT PENTING: Untuk mengaktifkan izin upload Google Drive & database, pilih fungsi <code>otorisasiDrive</code> di toolbar atas editor Apps Script, lalu klik <strong>Jalankan (Run ▶)</strong>.</li>
            <li className="text-rose-600 font-bold">Saat muncul pop-up otorisasi "Otorisasi Diperlukan": Klik Tinjau Izin {'>'} Pilih akun Google Anda {'>'} Klik Lanjutan (Advanced) di kiri bawah {'>'} Klik Buka project (tidak aman) {'>'} Klik Izinkan (Allow).</li>
            <li>Klik tombol biru <strong>Terapkan (Deploy)</strong> di kanan atas {'>'} <strong>Deployment Baru (New deployment)</strong>. <i>(Wajib pilih "Deployment Baru" agar izin DriveApp aktif di Web App)</i>.</li>
            <li>Pilih Jenis <strong>Aplikasi Web (Web App)</strong>.</li>
            <li>Atur Akses {'>'} Jalankan sebagai: <strong>Saya (Me)</strong>, Siapa yang memiliki akses: <strong>Siapa saja (Anyone)</strong>.</li>
            <li>Klik Terapkan.</li>
            <li>Copy URL Web App dan paste di form konfigurasi di atas.</li>
          </ol>

          <div className="relative">
            <button 
              onClick={handleCopy}
              className="absolute top-2 right-2 p-2 bg-slate-800 text-white rounded hover:bg-slate-700 transition"
            >
              {copied ? <Check size={16} /> : <Copy size={16} />}
            </button>
            <pre className="bg-slate-900 text-slate-300 p-4 rounded-lg text-sm overflow-auto h-96">
              <code>{GAS_TEMPLATE}</code>
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
}
