import React, { useState, useMemo } from 'react';
import { 
  GraduationCap, BookOpen, Calendar, Users, BookMarked, CalendarCheck, 
  UserCheck, QrCode, PenTool, FileSpreadsheet, Award, TrendingUp, CheckCircle,
  Lock, FileText
} from 'lucide-react';
import { useStore } from '../store';
import { db } from '../data/db';
import { getSemestersList, getActiveSemester, SemesterEntity } from '../lib/semester';
import { matchStatusActive } from '../lib/utils';
import Kurikulum from './Kurikulum';
import AttendancePrint from './AttendancePrint';
import KenaikanKelas from './KenaikanKelas';
import JadwalRombelTab from '../components/akademik/JadwalRombelTab';
import SiswaKelasTab from '../components/akademik/SiswaKelasTab';
import AgendaGuruTab from '../components/akademik/AgendaGuruTab';
import AbsensiGuruTab from '../components/akademik/AbsensiGuruTab';
import QrScannerTab from '../components/akademik/QrScannerTab';
import InputNilaiTab from '../components/akademik/InputNilaiTab';
import RaporAkhirTab from '../components/akademik/RaporAkhirTab';
import PeringkatRankingTab from '../components/akademik/PeringkatRankingTab';
import PerizinanSiswaTab from '../components/akademik/PerizinanSiswaTab';

export default function AkademikPage() {
  const [activeSubTab, setActiveSubTab] = useState('dashboard');
  const { students, teachers, settings } = useStore();
  const currentTP = settings.tahunPelajaran || '2026/2027';
  const [semestersList] = useState<SemesterEntity[]>(() => getSemestersList());
  const activeSemester = useMemo(() => {
    return getActiveSemester(currentTP);
  }, [currentTP, semestersList]);

  const absensiList = useMemo(() => (db.get('absensi') as any[]) || [], []);
  const absensiGuruList = useMemo(() => (db.get('absensi_guru') as any[]) || [], []);
  const gradesMap = useMemo(() => (db.get('nilai_akademik_map') as any[]) || {}, []);

  // Calculate real metrics
  const presensiRate = useMemo(() => {
    if (!absensiList || absensiList.length === 0) return 0;
    const hadirCount = absensiList.filter((a: any) => a.status === 'H' || a.status === 'Hadir').length;
    return Math.round((hadirCount / absensiList.length) * 100);
  }, [absensiList]);

  const gradedStudentsCount = useMemo(() => {
    const keys = Object.keys(gradesMap);
    return keys.length;
  }, [gradesMap]);

  const todayStr = new Date().toISOString().slice(0, 10);
  const guruHadirToday = useMemo(() => {
    return absensiGuruList.filter((g: any) => g.tanggal === todayStr && (g.status === 'Tepat Waktu' || g.status === 'Terlambat')).length;
  }, [absensiGuruList, todayStr]);
  const activeStudents = useMemo(() => students.filter(s => matchStatusActive(s.status)), [students]);

  const subTabs = [
    { id: 'dashboard', label: 'Dashboard Akademik', icon: GraduationCap },
    { id: 'kurikulum', label: 'Kurikulum Kemendikdasmen', icon: BookOpen },
    { id: 'jadwal', label: 'Jadwal Rombel', icon: Calendar },
    { id: 'siswa-kelas', label: 'Data Siswa Kelas', icon: Users },
    { id: 'agenda', label: 'Agenda Guru (Jurnal KBM)', icon: BookMarked },
    { id: 'absensi-siswa', label: 'Absensi Siswa', icon: CalendarCheck },
    { id: 'perizinan-siswa', label: 'Perizinan & Surat Izin/Sakit', icon: FileText },
    { id: 'absensi-guru', label: 'Absensi Guru', icon: UserCheck },
    { id: 'qr-scanner', label: 'QR Scanner Portal', icon: QrCode },
    { id: 'input-nilai', label: 'Input Nilai', icon: PenTool },
    { id: 'rapor', label: 'Rapor Akhir', icon: FileSpreadsheet },
    { id: 'peringkat', label: 'Peringkat & Ranking', icon: Award },
    { id: 'kenaikan', label: 'Kenaikan Kelas', icon: TrendingUp },
  ];

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Title & Semester Selector */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white/90 p-5 rounded-3xl border border-slate-200/80 shadow-xs">
        <div className="flex items-center gap-3.5">
          <div className="w-11 h-11 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center border border-indigo-100/80 shadow-2xs flex-shrink-0">
            <GraduationCap size={22} />
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900">
              Akademik & Kurikulum
            </h1>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              Pengelolaan KBM, jadwal rombel, jurnal harian guru, presensi QR, penilaian Kurikulum Merdeka, rapor akhir, & promosi kelas.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2.5 bg-emerald-50/70 border border-emerald-200/90 px-3.5 py-2.5 rounded-2xl w-full sm:w-auto shadow-2xs">
          <div className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse"></div>
          <div className="text-left flex-1 sm:flex-initial">
            <div className="flex items-center gap-1.5" title="Terkunci - Pengaturan semester dilakukan melalui menu Pengaturan">
              <span className="text-[10px] font-black text-emerald-700 uppercase tracking-wider block">Semester Aktif Sistem</span>
              <Lock size={11} className="text-emerald-600" />
            </div>
            <span className="text-xs font-black text-emerald-950 block">
              {activeSemester.name} ({activeSemester.tahunPelajaran})
            </span>
          </div>
        </div>
      </div>

      {/* Sub-Navigation: Mobile Dropdown Selector & Desktop Pill Tabs */}
      <div className="md:hidden bg-white p-3 rounded-2xl border border-slate-200/80 shadow-xs">
        <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wider block mb-1.5">
          Pilih Sub-Menu Akademik:
        </label>
        <div className="relative">
          <select
            value={activeSubTab}
            onChange={(e) => setActiveSubTab(e.target.value)}
            className="w-full pl-3.5 pr-10 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500 appearance-none transition"
          >
            {subTabs.map((tab) => (
              <option key={tab.id} value={tab.id}>
                {tab.label}
              </option>
            ))}
          </select>
          <div className="absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
            ▼
          </div>
        </div>
      </div>

      {/* Sub Tabs (Desktop / Tablet) */}
      <div className="hidden md:flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {subTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id)}
              className={`flex items-center gap-2 px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all whitespace-nowrap active:scale-95 ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-md shadow-indigo-200'
                  : 'bg-white/80 text-slate-600 hover:bg-white hover:text-indigo-600 border border-slate-200/80'
              }`}
            >
              <Icon size={15} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* SubTab Views */}
      {activeSubTab === 'dashboard' && (
        <div className="space-y-6 animate-in fade-in">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
              <span className="text-xs font-bold text-slate-500">Rekap Nilai Terdata</span>
              <div className="text-3xl font-black text-indigo-600">
                {gradedStudentsCount > 0 ? `${gradedStudentsCount} Rekap` : '0 Data'}
              </div>
              <p className="text-[11px] text-slate-500">
                {gradedStudentsCount > 0 ? 'Asesmen TP/STS/SAS tersimpan' : 'Belum ada input nilai'}
              </p>
            </div>
            <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
              <span className="text-xs font-bold text-slate-500">Tingkat Presensi Siswa</span>
              <div className="text-3xl font-black text-emerald-600">
                {absensiList.length > 0 ? `${presensiRate}%` : '0%'}
              </div>
              <p className="text-[11px] text-slate-500">
                {absensiList.length > 0 ? `${absensiList.length} Log Presensi Tercatat` : 'Belum ada log presensi'}
              </p>
            </div>
            <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
              <span className="text-xs font-bold text-slate-500">Kehadiran Guru Hari Ini</span>
              <div className="text-3xl font-black text-purple-600">
                {teachers.length > 0 ? `${guruHadirToday} / ${teachers.length}` : '0 GTK'}
              </div>
              <p className="text-[11px] text-slate-500">
                {absensiGuruList.length > 0 ? `${absensiGuruList.length} Log Presensi Guru` : 'Presensi Guru Real-time'}
              </p>
            </div>
            <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
              <span className="text-xs font-bold text-slate-500">Total Siswa Aktif</span>
              <div className="text-3xl font-black text-slate-900">
                {activeStudents.length} Siswa
              </div>
              <p className="text-[11px] text-slate-500">
                T.A {settings.tahunPelajaran || '2026/2027'}
              </p>
            </div>
          </div>
        </div>
      )}

      {activeSubTab === 'kurikulum' && <Kurikulum />}
      {activeSubTab === 'jadwal' && <JadwalRombelTab />}
      {activeSubTab === 'siswa-kelas' && <SiswaKelasTab />}
      {activeSubTab === 'agenda' && <AgendaGuruTab />}
      {activeSubTab === 'absensi-siswa' && <AttendancePrint />}
      {activeSubTab === 'perizinan-siswa' && <PerizinanSiswaTab />}
      {activeSubTab === 'absensi-guru' && <AbsensiGuruTab />}
      {activeSubTab === 'qr-scanner' && <QrScannerTab />}
      {activeSubTab === 'input-nilai' && <InputNilaiTab />}
      {activeSubTab === 'rapor' && <RaporAkhirTab />}
      {activeSubTab === 'peringkat' && <PeringkatRankingTab />}
      {activeSubTab === 'kenaikan' && <KenaikanKelas />}
    </div>
  );
}
