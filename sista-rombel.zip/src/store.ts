import { create } from 'zustand';
import { AppState, Student, Teacher, Gender } from './types';
import { normalizeClassName } from './lib/utils';
import { db } from './data/db';
import { DEFAULT_APP_CONFIG } from './data/config';

const cleanStudentClass = (raw: any): Student => {
  if (!raw) return raw;
  
  // Normalisasi ID dan NIS/NoPDKT
  const id = String(raw.id || raw.nopdkt || raw.NoPDKT || raw.nis || raw.NIS || raw.nisn || raw.NISN || crypto.randomUUID()).trim();
  const nis = String(raw.nis || raw.NIS || raw.nopdkt || raw.NoPDKT || raw.id || '').trim();
  const nisn = String(raw.nisn || raw.NISN || raw['No NISN'] || '').trim();
  const nik = String(raw.nik || raw.NIK || raw['No KTP / NIK'] || '').trim();
  const name = String(raw.name || raw.NamaLengkap || raw.Nama || raw['Nama Lengkap'] || raw.nama || raw.namaLengkap || '').trim();

  // Normalisasi Kelas
  const rawClass = raw.class || raw.KelasSaatini || raw.Kelas || raw.kelas || raw.rombel || raw.Rombel || '1A';
  const assignedClass = normalizeClassName(rawClass) || '1A';

  // Normalisasi Gender
  const genderRaw = String(raw.gender || raw.JenisKelamin || raw['Jenis Kelamin'] || raw['L/P'] || raw.JK || raw.jk || 'L').trim().toUpperCase();
  const gender: Gender = (genderRaw.startsWith('P') || genderRaw === 'PEREMPUAN' || genderRaw === 'WANITA') ? 'P' : 'L';

  // Normalisasi Tempat & Tanggal Lahir
  const pob = String(raw.pob || raw['Tempat Lahir'] || raw.TempatLahir || raw.tempatLahir || '').trim();
  const dob = String(raw.dob || raw.TanggalLahir || raw['Tanggal Lahir'] || raw.tanggalLahir || '').trim();

  // Normalisasi nomor HP / telepon
  const rawNoHp = raw.noHp || raw.NomorHP || raw['No HP'] || raw.no_hp || raw.telepon || raw.phone || raw.nomorHp || raw.nomor_hp || raw.kontak || raw.wa || raw.tlp || raw.tlpAyah || raw.tlpIbu || raw.tlpWali || '';
  
  // Normalisasi status dari Google Sheet
  let status = raw.status || raw.Status || 'Aktif';
  if (typeof status === 'string') {
    const sLow = status.toLowerCase().trim();
    if (sLow === 'aktif' || sLow === 'active' || sLow === '1') status = 'Aktif';
    else if (sLow.includes('lulus') || sLow === 'graduated') status = 'Lulus';
    else if (sLow.includes('pindah') || sLow.includes('mutasi') || sLow === 'transfer') status = 'Pindah';
    else if (sLow.includes('keluar') || sLow.includes('drop') || sLow === 'do') status = 'Keluar';
    else if (sLow === 'belum' || sLow === 'pending') status = 'Belum';
  }

  // Data Ortu
  const namaAyah = String(raw.namaAyah || raw.NamaAyah || raw.fatherName || '').trim();
  const namaIbu = String(raw.namaIbu || raw.NamaIbu || raw.NamaIbu || '').trim();
  const namaWali = String(raw.namaWali || raw.NamaWali || '').trim();
  const parentName = String(raw.parentName || raw.NamaAyah || raw.namaAyah || raw.NamaIbu || raw.namaIbu || raw.NamaWali || raw.namaWali || 'Orang Tua').trim();

  const statusAyah = String(raw.statusAyah || raw.StatusAyah || (namaAyah.toLowerCase().includes('alm') ? 'Meninggal' : 'Masih Hidup')).trim();
  const statusIbu = String(raw.statusIbu || raw.StatusIbu || (namaIbu.toLowerCase().includes('alm') ? 'Meninggal' : 'Masih Hidup')).trim();

  let statusYatim = String(raw.statusYatim || raw.StatusYatim || '').trim();
  if (!statusYatim) {
    const aMeninggal = statusAyah.toLowerCase().includes('meninggal') || namaAyah.toLowerCase().includes('alm');
    const iMeninggal = statusIbu.toLowerCase().includes('meninggal') || namaIbu.toLowerCase().includes('alm');
    if (aMeninggal && iMeninggal) statusYatim = 'Yatim Piatu';
    else if (aMeninggal) statusYatim = 'Yatim';
    else if (iMeninggal) statusYatim = 'Piatu';
    else statusYatim = 'Lengkap';
  }

  // Normalisasi berkas dokumen jika ada nama field alternatif di sheet
  const akta = raw.aktaKelahiranUrl || raw.AktaKelahiran || raw.akteUrl || raw.Akte || raw.akta || raw.linkAkta || '';
  const kk = raw.kartuKeluargaUrl || raw.KartuKeluarga || raw.kkUrl || raw.KK || raw.kartuKeluarga || raw.linkKk || '';
  const kia = raw.kiaUrl || raw.KIA || raw.ktpAnakUrl || raw.ktpAnak || raw.linkKia || '';
  const ktpAyah = raw.ktpAyahUrl || raw.KTPAyah || raw.ktpAyah || '';
  const ktpIbu = raw.ktpIbuUrl || raw.KTPIbu || raw.ktpIbu || '';
  const ktpWali = raw.ktpWaliUrl || raw.KTPWali || raw.ktpWali || '';
  const ijazah = raw.ijazahUrl || raw.Ijazah || raw.linkIjazah || '';
  const rapor = raw.raporUrl || raw.Rapor || raw.rapotUrl || raw.Rapot || '';
  const suratPindah = raw.suratPindahUrl || raw['S.Pindah'] || raw.suratPindah || '';
  const suKet = raw.suKetUrl || raw.SuKet || raw.dokumenLainUrl || '';
  const suratDomisili = raw.suratDomisiliUrl || raw['S.Domisili'] || raw.suratDomisili || '';
  const foto = raw.fotoUrl || raw.PasFoto || raw.pasFoto || raw.foto || raw.linkFoto || '';

  return {
    ...raw,
    id,
    nis: nis || id,
    nisn: nisn || raw.nisn || undefined,
    nik: nik || raw.nik || undefined,
    name: name || raw.name || 'Siswa',
    class: assignedClass,
    gender,
    pob: pob || raw.pob || undefined,
    dob: dob || raw.dob || '',
    address: String(raw.address || raw.Alamat || raw.alamat || '').trim(),
    parentName,
    
    // Dapodik
    tahunMasuk: raw.tahunMasuk || raw.TahunMasuk || raw['Tahun Masuk'] || raw.ThnMasuk || raw['Thn Masuk'] || raw.tahun_masuk || raw['Tahun Angkatan'] || raw.angkatan || undefined,
    TahunMasuk: raw.tahunMasuk || raw.TahunMasuk || raw['Tahun Masuk'] || raw.ThnMasuk || raw['Thn Masuk'] || raw.tahun_masuk || raw['Tahun Angkatan'] || raw.angkatan || undefined,
    anakKe: raw.anakKe || raw['Anak ke'] || raw.AnakKe || undefined,
    saudara: raw.saudara || raw.Saudara || undefined,
    agama: raw.agama || raw.Agama || 'Islam',
    golonganDarah: raw.golonganDarah || raw['Golongan Darah'] || raw.GolonganDarah || undefined,
    tinggiBadan: raw.tinggiBadan || raw['TinggiBadan(cm)'] || raw.TinggiBadan || undefined,
    beratBadan: raw.beratBadan || raw['BeratBadan(kg)'] || raw.BeratBadan || undefined,
    prestasi: raw.prestasi || raw.Prestasi || undefined,
    hobi: raw.hobi || raw.Hobi || undefined,
    catatanPenting: raw.catatanPenting || raw['Catatan Penting'] || raw.CatatanPenting || undefined,

    // Alamat detail
    rt: raw.rt || raw.RT || undefined,
    rw: raw.rw || raw.RW || undefined,
    kelurahan: raw.kelurahan || raw.Kelurahan || undefined,
    kecamatan: raw.kecamatan || raw.Kecamatan || undefined,
    kota: raw.kota || raw.Kota || undefined,
    provinsi: raw.provinsi || raw.Provinsi || undefined,
    kodePos: raw.kodePos || raw.KodePos || undefined,
    jenisTinggal: raw.jenisTinggal || raw.JenisTinggal || undefined,
    alatTransportasi: raw.alatTransportasi || raw.AlatTransportasi || undefined,
    noHp: rawNoHp ? String(rawNoHp).trim() : (raw.noHp || undefined),
    email: raw.email || raw['E-Mail'] || raw.Email || undefined,
    sekolahAsal: raw.sekolahAsal || raw.AsalSekolah || raw.sekolah_asal || undefined,
    skhun: raw.skhun || raw.SKHUN || undefined,
    penerimaKps: raw.penerimaKps || raw.PenerimaKPS || raw.kps || undefined,
    ijazahNo: raw.ijazahNo || raw.NoIjazah || raw['No Ijazah'] || undefined,
    status: status || 'Aktif',

    // Orang Tua & Wali
    noKk: raw.noKk || raw.NomorKartuKeluarga || raw['No KK'] || undefined,
    namaAyah: namaAyah || undefined,
    nikAyah: raw.nikAyah || raw.NIKAyah || undefined,
    tempatLahirAyah: raw.tempatLahirAyah || raw.TempatLahirAyah || undefined,
    tanggalLahirAyah: raw.tanggalLahirAyah || raw.TanggalLahirAyah || undefined,
    pendidikanAyah: raw.pendidikanAyah || raw.PendidikanAyah || undefined,
    pekerjaanAyah: raw.pekerjaanAyah || raw.PekerjaanAyah || undefined,
    penghasilanAyah: raw.penghasilanAyah || raw.PenghasilanAyah || undefined,
    tlpAyah: raw.tlpAyah || raw.TlpAyah || undefined,
    statusAyah,

    namaIbu: namaIbu || undefined,
    nikIbu: raw.nikIbu || raw.NIKIbu || undefined,
    tempatLahirIbu: raw.tempatLahirIbu || raw.TempatLahirIbu || undefined,
    tanggalLahirIbu: raw.tanggalLahirIbu || raw.TanggalLahirIbu || undefined,
    pendidikanIbu: raw.pendidikanIbu || raw.PendidikanIbu || undefined,
    pekerjaanIbu: raw.pekerjaanIbu || raw.PekerjaanIbu || undefined,
    penghasilanIbu: raw.penghasilanIbu || raw.PenghasilanIbu || undefined,
    tlpIbu: raw.tlpIbu || raw.TlpIbu || undefined,
    statusIbu,
    statusYatim,

    namaWali: namaWali || undefined,
    tempatLahirWali: raw.tempatLahirWali || raw.TempatLahirWali || undefined,
    tglLahirWali: raw.tglLahirWali || raw.TglLahirWali || undefined,
    pendidikanWali: raw.pendidikanWali || raw.PendidikanWali || undefined,
    pekerjaanWali: raw.pekerjaanWali || raw.PekerjaanWali || undefined,
    penghasilanWali: raw.penghasilanWali || raw.PenghasilanWali || undefined,
    hubunganWali: raw.hubunganWali || raw.Hubungan || undefined,
    tlpWali: raw.tlpWali || raw['Tlp.Wali'] || undefined,

    // 12 Berkas Dokumen Resmi
    aktaKelahiranUrl: akta || raw.aktaKelahiranUrl,
    akteUrl: akta || raw.akteUrl,
    kartuKeluargaUrl: kk || raw.kartuKeluargaUrl,
    kkUrl: kk || raw.kkUrl,
    kiaUrl: kia || raw.kiaUrl,
    ktpAyahUrl: ktpAyah || raw.ktpAyahUrl,
    ktpIbuUrl: ktpIbu || raw.ktpIbuUrl,
    ktpWaliUrl: ktpWali || raw.ktpWaliUrl,
    ijazahUrl: ijazah || raw.ijazahUrl,
    raporUrl: rapor || raw.raporUrl,
    rapotUrl: rapor || raw.rapotUrl,
    suratPindahUrl: suratPindah || raw.suratPindahUrl,
    suKetUrl: suKet || raw.suKetUrl,
    suratDomisiliUrl: suratDomisili || raw.suratDomisiliUrl,
    fotoUrl: foto || raw.fotoUrl,
    pasFoto: foto || raw.pasFoto,
  };
};

const cleanTeacher = (raw: any): Teacher => {
  if (!raw) return raw;

  const id = raw.id || raw.GuruID || raw.guruId || raw.ID || crypto.randomUUID();
  const name = raw.name || raw.Nama || raw.NamaLengkap || raw.nama || raw.namaLengkap || raw.NamaGuru || '';
  const nip = String(raw.nip || raw.NIP || raw.nuptk || raw.NUPTK || raw.nik || raw.NIK || raw.GuruID || '').trim();
  const nik = String(raw.nik || raw.NIK || '').trim();
  const nuptk = String(raw.nuptk || raw.NUPTK || '').trim();
  const gelar = raw.gelar || raw.Gelar || raw.gelarAkademik || '';
  
  // Gender
  const genderRaw = String(raw.gender || raw.JenisKelamin || raw['Jenis Kelamin'] || raw['L/P'] || raw.JK || 'L').trim().toUpperCase();
  const gender: 'L' | 'P' = (genderRaw.startsWith('P') || genderRaw === 'PEREMPUAN' || genderRaw === 'WANITA') ? 'P' : 'L';

  const tempatLahir = raw.tempatLahir || raw.TempatLahir || raw['Tempat Lahir'] || '';
  const tanggalLahir = raw.tanggalLahir || raw.TanggalLahir || raw['Tanggal Lahir'] || '';
  const agama = raw.agama || raw.Agama || 'Islam';
  const alamat = raw.alamat || raw.Alamat || raw.address || '';
  
  // Jabatan / Class
  let assignedClassRaw = String(raw.class || raw.Jabatan || raw.jabatan || raw.waliKelas || raw.WaliKelas || raw['Wali Kelas'] || 'None').trim();
  let assignedClass = 'None';
  if (assignedClassRaw.toUpperCase().includes('KEPALA') || assignedClassRaw.toUpperCase() === 'KS') {
    assignedClass = 'Kepala Sekolah';
  } else if (assignedClassRaw.toUpperCase() === 'NONE' || assignedClassRaw === '-' || !assignedClassRaw) {
    assignedClass = 'None';
  } else if (/^[1-6][A-Z]?$/i.test(assignedClassRaw) || assignedClassRaw.toUpperCase().startsWith('KELAS')) {
    assignedClass = assignedClassRaw.toUpperCase().replace(/KELAS/g, '').replace(/[-_]/g, '').trim() || 'None';
  } else {
    assignedClass = assignedClassRaw;
  }

  const phone = String(raw.phone || raw.NoHP || raw['No HP'] || raw.noHp || raw.telepon || raw.no_hp || raw.kontak || raw.wa || '').trim();
  const email = raw.email || raw.Email || raw['E-Mail'] || '';
  const pendidikan = raw.pendidikan || raw.Pendidikan || raw['Pendidikan Terakhir'] || 'S1';
  const jurusan = raw.jurusan || raw.Jurusan || '';
  const statusKepegawaian = raw.statusKepegawaian || raw.StatusKepegawaian || raw['Status Kepegawaian'] || 'Tetap';
  const tmt = raw.tmt || raw.TMT || raw['Tgl Mulai Tugas'] || '';
  
  // Status
  let statusRaw = String(raw.status || raw.Status || 'Aktif').trim().toLowerCase();
  const status: 'Aktif' | 'Nonaktif' = statusRaw.includes('non') ? 'Nonaktif' : 'Aktif';

  const fotoUrl = raw.fotoUrl || raw.Foto || raw['Foto Profil'] || raw.foto || '';

  return {
    ...raw,
    id,
    nip: nip || nik || nuptk || '',
    nik: nik || undefined,
    nuptk: nuptk || undefined,
    name,
    gelar: gelar || undefined,
    gender,
    tempatLahir: tempatLahir || undefined,
    tanggalLahir: tanggalLahir || undefined,
    agama: agama || undefined,
    alamat: alamat || undefined,
    class: assignedClass,
    jabatan: assignedClass,
    phone,
    email,
    pendidikan: pendidikan || undefined,
    jurusan: jurusan || undefined,
    statusKepegawaian: statusKepegawaian || undefined,
    tmt: tmt || undefined,
    status,
    fotoUrl: fotoUrl || undefined,
    createdAt: raw.createdAt || raw.CreatedAt || new Date().toISOString(),
    updatedAt: raw.updatedAt || raw.UpdatedAt || new Date().toISOString(),
  };
};

export const useStore = create<AppState>()((set) => ({
  isAuthenticated: false,
  students: [],
  teachers: [],
  settings: { 
    scriptUrl: DEFAULT_APP_CONFIG.scriptUrl, 
    appName: DEFAULT_APP_CONFIG.appName, 
    schoolName: DEFAULT_APP_CONFIG.schoolName,
    folderId: DEFAULT_APP_CONFIG.folderId, 
    folderSiswaId: DEFAULT_APP_CONFIG.folderSiswaId,
    spreadsheetId: DEFAULT_APP_CONFIG.spreadsheetId,
    tahunPelajaran: DEFAULT_APP_CONFIG.tahunPelajaran, 
    schoolLogoUrl: DEFAULT_APP_CONFIG.schoolLogoUrl,
    adminUsername: DEFAULT_APP_CONFIG.adminUsername,
    adminPassword: DEFAULT_APP_CONFIG.adminPassword
  },
  isLoading: false,
  error: null,
  lastSyncedAt: null,
  isSyncingGlobal: false,
  login: () => set({ isAuthenticated: true }),
  logout: () => set({ isAuthenticated: false, students: [], teachers: [] }),
  setStudents: (students) => set({ students: students.map(cleanStudentClass), error: null }),
  addStudent: (student) => set((state) => ({ students: [...state.students, cleanStudentClass(student)] })),
  updateStudent: (id, data) =>
    set((state) => ({
      students: state.students.map((s) => {
        const isMatch = s.id === id || 
          (s.nis && data.nis && String(s.nis).trim() === String(data.nis).trim()) ||
          (s.nik && data.nik && String(s.nik).trim() === String(data.nik).trim());
        return isMatch ? cleanStudentClass({ ...s, ...data, id: s.id || id }) : s;
      }),
    })),
  updateStudentsBulk: (updates) =>
    set((state) => {
      const updateMap = new Map(updates.map((u) => [u.id, u.data]));
      return {
        students: state.students.map((s) =>
          updateMap.has(s.id) ? cleanStudentClass({ ...s, ...updateMap.get(s.id) }) : s
        ),
      };
    }),
  deleteStudent: (id) =>
    set((state) => ({
      students: state.students.filter((s) => s.id !== id && s.nis !== id),
    })),
  setTeachers: (teachers) => set({ teachers: teachers.map(cleanTeacher), error: null }),
  addTeacher: (teacher) => set((state) => ({ teachers: [...state.teachers, cleanTeacher(teacher)] })),
  updateTeacher: (id, data) =>
    set((state) => ({
      teachers: state.teachers.map((t) => {
        const isMatch = t.id === id ||
          (t.nip && data.nip && String(t.nip).trim() === String(data.nip).trim()) ||
          (t.nik && data.nik && String(t.nik).trim() === String(data.nik).trim());
        return isMatch ? cleanTeacher({ ...t, ...data, id: t.id || id }) : t;
      }),
    })),
  deleteTeacher: (id) =>
    set((state) => ({
      teachers: state.teachers.filter((t) => t.id !== id && t.nip !== id),
    })),
  setSettings: (settings) => set({ settings }),
  setLoading: (isLoading) => set({ isLoading }),
  setError: (error) => set({ error }),
  setLastSyncedAt: (lastSyncedAt) => set({ lastSyncedAt }),
  setIsSyncingGlobal: (isSyncingGlobal) => set({ isSyncingGlobal }),
  clearAllData: () => {
    db.clearAll();
    set({
      students: [],
      teachers: [],
      lastSyncedAt: null,
      error: null
    });
  },
}));
