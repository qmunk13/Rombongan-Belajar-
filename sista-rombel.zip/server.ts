import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";

const app = express();
const PORT = 3000;

app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ limit: "50mb", extended: true }));

const SETTINGS_FILE = path.join(process.cwd(), "settings-db.json");

const DEFAULT_SETTINGS = {
  scriptUrl: "https://script.google.com/macros/s/AKfycbz9ElB9x-jfZ7ZZSThMSi_QLm80VuJ7AWKAw1VX5XTi_le0ZNwD6NcI43L2yPtOj1k/exec",
  appName: "ROMBEL TAMBORA",
  schoolName: "ROMBEL TAMBORA",
  spreadsheetId: "1XTfNFkele0iVbb7W8qlJDujWKFbq-bqJO5VabY82bCk",
  folderId: "13W6zz_g_nN-zGJdbquP4H4NvXrZZLk0j",
  folderSiswaId: "1DfCtp8BbsRzFafEa8fk30Suq-aVQoS7V",
  adminUsername: "admin",
  adminPassword: "admin",
  schoolLogoUrl: "https://lh3.googleusercontent.com/d/1Tg-mI0FDd8VDck4LVYt9NiDifdnoAyiJ",
  tahunPelajaran: "2026/2027"
};

// Helper to read settings
function readSettings() {
  if (fs.existsSync(SETTINGS_FILE)) {
    try {
      const content = fs.readFileSync(SETTINGS_FILE, "utf-8").trim();
      if (content) {
        return JSON.parse(content);
      }
    } catch (e) {
      console.error("Error reading settings file:", e);
    }
  }
  return DEFAULT_SETTINGS;
}

// Helper to write settings
function writeSettings(settings: any) {
  try {
    fs.writeFileSync(SETTINGS_FILE, JSON.stringify(settings, null, 2), "utf-8");
  } catch (e) {
    console.error("Error writing settings file:", e);
  }
}

// API Routes
app.get("/api/settings", (req, res) => {
  res.json(readSettings());
});

app.post("/api/settings", (req, res) => {
  const current = readSettings();
  const updated = { ...current, ...req.body };
  writeSettings(updated);
  res.json({ success: true, settings: updated });
});

// Proxy for Google Apps Script to bypass browser CORS / fetch limitations
app.post("/api/gas-proxy", async (req, res) => {
  try {
    const { url, payload } = req.body;
    if (!url) {
      return res.status(400).json({ error: "Missing script url" });
    }

    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "text/plain;charset=utf-8",
      },
      body: typeof payload === "string" ? payload : JSON.stringify(payload),
    });

    const text = await response.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch (e) {
      data = { raw: text };
    }

    res.json(data);
  } catch (error: any) {
    console.error("GAS Proxy Error:", error);
    res.status(500).json({ error: error.message || "Failed to proxy GAS request" });
  }
});

async function startServer() {
  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
